insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1', '20170629', '����췢[2017]87��', 'CHO IL U', 'Cho Il Woo', '01', 'CHO IL U', 'CHO IL U', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('2', '20170629', '����췢[2017]87��', 'CHO IL U', 'Cho Il Woo', '03', 'Cho Il Woo', 'CHO IL WOO', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('3', '20170629', '����췢[2017]87��', 'CHO YON CHUN', 'Jo Yon Jun', '01', 'CHO YON CHUN', 'CHO YON CHUN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('4', '20170629', '����췢[2017]87��', 'CHO YON CHUN', 'Jo Yon Jun', '03', 'Jo Yon Jun', 'JO YON JUN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('5', '20170629', '����췢[2017]87��', 'CHOE HWI', null, '01', 'CHOE HWI', 'CHOE HWI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('6', '20170629', '����췢[2017]87��', 'JO YONG-WON', 'Cho Yongwon', '01', 'JO YONG-WON', 'JO YONG-WON', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('7', '20170629', '����췢[2017]87��', 'JO YONG-WON', 'Cho Yongwon', '03', 'Cho Yongwon', 'CHO YONGWON', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('8', '20170629', '����췢[2017]87��', 'KANGBONG TRADING CORPORATION', null, '01', 'KANGBONG TRADING CORPORATION', 'KANGBONG TRADING CORPORATION', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('9', '20170629', '����췢[2017]87��', 'KIM CHOL NAM', null, '01', 'KIM CHOL NAM', 'KIM CHOL NAM', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('10', '20170629', '����췢[2017]87��', 'KIM KYONG OK', 'Kim Kyong Ok', '01', 'KIM KYONG OK', 'KIM KYONG OK', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('11', '20170629', '����췢[2017]87��', 'KIM KYONG OK', 'Kim Kyong Ok', '03', 'Kim Kyong Ok', 'KIM KYONG OK', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('12', '20170629', '����췢[2017]87��', 'KING TONG-HO', null, '01', 'KING TONG-HO', 'KING TONG-HO', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('13', '20170629', '����췢[2017]87��', 'KOREA KUMSAN TRADING CORPORATION', null, '01', 'KOREA KUMSAN TRADING CORPORATION', 'KOREA KUMSAN TRADING CORPORATION', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('14', '20170629', '����췢[2017]87��', 'KORYO BANK', null, '01', 'KORYO BANK', 'KORYO BANK', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('15', '20170629', '����췢[2017]87��', 'MIN BYONG CHOL', 'Min Pyo''ng-ch''o''l, Min Byong-chol, Min Byong Chun', '01', 'MIN BYONG CHOL', 'MIN BYONG CHOL', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('16', '20170629', '����췢[2017]87��', 'MIN BYONG CHOL', 'Min Pyo''ng-ch''o''l, Min Byong-chol, Min Byong Chun', '04', 'Min Byong Chun', 'MIN BYONG CHUN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('17', '20170629', '����췢[2017]87��', 'MIN BYONG CHOL', 'Min Pyo''ng-ch''o''l, Min Byong-chol, Min Byong Chun', '04', 'Min Byong-chol', 'MIN BYONG-CHOL', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('18', '20170629', '����췢[2017]87��', 'MIN BYONG CHOL', 'Min Pyo''ng-ch''o''l, Min Byong-chol, Min Byong Chun', '04', 'Min Pyo''ng-ch''o''l', 'MIN PYO''NG-CH''O''L', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('19', '20170629', '����췢[2017]87��', 'PAEK SE BONG', null, '01', 'PAEK SE BONG', 'PAEK SE BONG', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('20', '20170629', '����췢[2017]87��', 'PAK HAN SE', 'Kang Myong Chol', '01', 'PAK HAN SE', 'PAK HAN SE', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('21', '20170629', '����췢[2017]87��', 'PAK HAN SE', 'Kang Myong Chol', '03', 'Kang Myong Chol', 'KANG MYONG CHOL', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('22', '20170629', '����췢[2017]87��', 'PAK TO CHUN', 'Pak Do Chun', '01', 'PAK TO CHUN', 'PAK TO CHUN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('23', '20170629', '����췢[2017]87��', 'PAK TO CHUN', 'Pak Do Chun', '03', 'Pak Do Chun', 'PAK DO CHUN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('24', '20170629', '����췢[2017]87��', 'RI JAE IL', 'Rl, Chae-Il', '01', 'RI JAE IL', 'RI JAE IL', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('25', '20170629', '����췢[2017]87��', 'RI JAE IL', 'Rl, Chae-Il', '03', 'Rl, Chae-Il', 'RL, CHAE-IL', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('26', '20170629', '����췢[2017]87��', 'RI SU YONG', null, '01', 'RI SU YONG', 'RI SU YONG', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('27', '20170629', '����췢[2017]87��', 'RI YONG MU', null, '01', 'RI YONG MU', 'RI YONG MU', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('28', '20170629', '����췢[2017]87��', 'STRATEGIC ROCKET FORCE OF THE KOREAN PEOPLE''S ARMY', null, '01', 'STRATEGIC ROCKET FORCE OF THE KOREAN PEOPLE''S ARMY', 'STRATEGIC ROCKET FORCE OF THE KOREAN PEOPLE''S ARMY', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('29', '20170724', '����췢[2017]101��', '1: FARED 2: SAAL 3: na 4: na', null, '02', 'FARED SAAL', 'FARED SAAL', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('30', '20170724', '����췢[2017]101��', 'HAO FAN 6', null, '01', 'HAO FAN 6', 'HAO FAN 6', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('31', '20170724', '����췢[2017]101��', 'JIE SHUN', null, '01', 'JIE SHUN', 'JIE SHUN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('32', '20170724', '����췢[2017]101��', 'PETREL 8', null, '01', 'PETREL 8', 'PETREL 8', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('33', '20170724', '����췢[2017]101��', 'TONG SAN 2', null, '01', 'TONG SAN 2', 'TONG SAN 2', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('34', '20170807', '����췢[2017]106��', '1: ''ABD AL-MALIK 2: MUHAMMAD 3: YUSUF 4: ''UTHMAN ''ABD AL-SALAM', 'Abd al-Malik Muhammad Yusif ''Abd-al-Salam', '02', 'ABD AL-MALIK MUHAMMAD', 'ABD AL-MALIK MUHAMMAD', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('35', '20170807', '����췢[2017]106��', '1: ''ABD AL-MALIK 2: MUHAMMAD 3: YUSUF 4: ''UTHMAN ''ABD AL-SALAM', 'Abd al-Malik Muhammad Yusif ''Abd-al-Salam', '03', 'Abd al-Malik Muhammad Yusif ''Abd-al-Salam', 'ABD AL-MALIK MUHAMMAD YUSIF ''ABD-AL-SALAM', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('36', '20170807', '����췢[2017]106��', '1: AAMIR 2: ALI 3: CHAUDHRY 4: na', 'a) Aamir Ali Chaudary; b) Aamir Ali Choudry; c) Amir Ali Chaudry', '02', 'AAMIR ALI', 'AAMIR ALI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('37', '20170807', '����췢[2017]106��', '1: AAMIR 2: ALI 3: CHAUDHRY 4: na', 'a) Aamir Ali Chaudary; b) Aamir Ali Choudry; c) Amir Ali Chaudry', '04', 'Aamir Ali Choudry', 'AAMIR ALI CHOUDRY', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('38', '20170807', '����췢[2017]106��', '1: AAMIR 2: ALI 3: CHAUDHRY 4: na', 'a) Aamir Ali Chaudary; b) Aamir Ali Choudry; c) Amir Ali Chaudry', '04', 'Aamir Ali Chaudary', 'AAMIR ALI CHAUDARY', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('39', '20170807', '����췢[2017]106��', '1: AAMIR 2: ALI 3: CHAUDHRY 4: na', 'a) Aamir Ali Chaudary; b) Aamir Ali Choudry; c) Amir Ali Chaudry', '04', 'Amir Ali Chaudry', 'AMIR ALI CHAUDRY', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('40', '20170807', '����췢[2017]106��', '1: ABD AL-AZIZ 2: ADAY 3: ZIMIN 4: AL-FADHIL', 'a) Abd al-Aziz Udai Samin al-Fadhli; b) Abd al-Aziz Udai Samin al-Fadhl; c) Abd al-Aziz Adhay Zimin al-Fadhi; d) Abdalaziz Adai Samin Fadhli al-Fadhali', '02', 'ABD AL-AZIZ ADAY', 'ABD AL-AZIZ ADAY', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('41', '20170807', '����췢[2017]106��', '1: ABD AL-AZIZ 2: ADAY 3: ZIMIN 4: AL-FADHIL', 'a) Abd al-Aziz Udai Samin al-Fadhli; b) Abd al-Aziz Udai Samin al-Fadhl; c) Abd al-Aziz Adhay Zimin al-Fadhi; d) Abdalaziz Adai Samin Fadhli al-Fadhali', '04', 'Abdalaziz Adai Samin Fadhli al-Fadhali', 'ABDALAZIZ ADAI SAMIN FADHLI AL-FADHALI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('42', '20170807', '����췢[2017]106��', '1: ABD AL-AZIZ 2: ADAY 3: ZIMIN 4: AL-FADHIL', 'a) Abd al-Aziz Udai Samin al-Fadhli; b) Abd al-Aziz Udai Samin al-Fadhl; c) Abd al-Aziz Adhay Zimin al-Fadhi; d) Abdalaziz Adai Samin Fadhli al-Fadhali', '04', 'Abd al-Aziz Adhay Zimin al-Fadhi', 'ABD AL-AZIZ ADHAY ZIMIN AL-FADHI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('43', '20170807', '����췢[2017]106��', '1: ABD AL-AZIZ 2: ADAY 3: ZIMIN 4: AL-FADHIL', 'a) Abd al-Aziz Udai Samin al-Fadhli; b) Abd al-Aziz Udai Samin al-Fadhl; c) Abd al-Aziz Adhay Zimin al-Fadhi; d) Abdalaziz Adai Samin Fadhli al-Fadhali', '04', 'Abd al-Aziz Udai Samin al-Fadhli', 'ABD AL-AZIZ UDAI SAMIN AL-FADHLI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('44', '20170807', '����췢[2017]106��', '1: ABD AL-AZIZ 2: ADAY 3: ZIMIN 4: AL-FADHIL', 'a) Abd al-Aziz Udai Samin al-Fadhli; b) Abd al-Aziz Udai Samin al-Fadhl; c) Abd al-Aziz Adhay Zimin al-Fadhi; d) Abdalaziz Adai Samin Fadhli al-Fadhali', '04', 'Abd al-Aziz Udai Samin al-Fadhl', 'ABD AL-AZIZ UDAI SAMIN AL-FADHL', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('45', '20170807', '����췢[2017]106��', '1: ABD AL-BASET 2: AZZOUZ 3: na 4: na', 'a) Abdelbassed Azouz; b) Abdul Baset Azouz', '02', 'ABD AL-BASET AZZOUZ', 'ABD AL-BASET AZZOUZ', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('46', '20170807', '����췢[2017]106��', '1: ABD AL-BASET 2: AZZOUZ 3: na 4: na', 'a) Abdelbassed Azouz; b) Abdul Baset Azouz', '04', 'Abdelbassed Azouz', 'ABDELBASSED AZOUZ', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('47', '20170807', '����췢[2017]106��', '1: ABD AL-BASET 2: AZZOUZ 3: na 4: na', 'a) Abdelbassed Azouz; b) Abdul Baset Azouz', '04', 'Abdul Baset Azouz', 'ABDUL BASET AZOUZ', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('48', '20170807', '����췢[2017]106��', '1: ABD AL-LATIF 2: BIN ABDALLAH 3: SALIH MUHAMMAD 4: AL-KAWARI', 'a) Abd-al-Latif Abdallah Salih al-Kawari; b) Abd-al-Latif Abdallah Salih al-Kuwari; c) Abd-al-Latif Abdallah al-Kawwari; d) Abd-al-Latif Abdallah al-Kawari; e) Abu Ali al-Kawari', '02', 'ABD AL-LATIF BIN ABDALLAH', 'ABD AL-LATIF BIN ABDALLAH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('49', '20170807', '����췢[2017]106��', '1: ABD AL-LATIF 2: BIN ABDALLAH 3: SALIH MUHAMMAD 4: AL-KAWARI', 'a) Abd-al-Latif Abdallah Salih al-Kawari; b) Abd-al-Latif Abdallah Salih al-Kuwari; c) Abd-al-Latif Abdallah al-Kawwari; d) Abd-al-Latif Abdallah al-Kawari; e) Abu Ali al-Kawari', '04', 'Abd-al-Latif Abdallah Salih al-Kawari', 'ABD-AL-LATIF ABDALLAH SALIH AL-KAWARI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('50', '20170807', '����췢[2017]106��', '1: ABD AL-LATIF 2: BIN ABDALLAH 3: SALIH MUHAMMAD 4: AL-KAWARI', 'a) Abd-al-Latif Abdallah Salih al-Kawari; b) Abd-al-Latif Abdallah Salih al-Kuwari; c) Abd-al-Latif Abdallah al-Kawwari; d) Abd-al-Latif Abdallah al-Kawari; e) Abu Ali al-Kawari', '04', 'Abd-al-Latif Abdallah Salih al-Kuwari', 'ABD-AL-LATIF ABDALLAH SALIH AL-KUWARI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('51', '20170807', '����췢[2017]106��', '1: ABD AL-LATIF 2: BIN ABDALLAH 3: SALIH MUHAMMAD 4: AL-KAWARI', 'a) Abd-al-Latif Abdallah Salih al-Kawari; b) Abd-al-Latif Abdallah Salih al-Kuwari; c) Abd-al-Latif Abdallah al-Kawwari; d) Abd-al-Latif Abdallah al-Kawari; e) Abu Ali al-Kawari', '04', 'Abd-al-Latif Abdallah al-Kawari', 'ABD-AL-LATIF ABDALLAH AL-KAWARI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('52', '20170807', '����췢[2017]106��', '1: ABD AL-LATIF 2: BIN ABDALLAH 3: SALIH MUHAMMAD 4: AL-KAWARI', 'a) Abd-al-Latif Abdallah Salih al-Kawari; b) Abd-al-Latif Abdallah Salih al-Kuwari; c) Abd-al-Latif Abdallah al-Kawwari; d) Abd-al-Latif Abdallah al-Kawari; e) Abu Ali al-Kawari', '04', 'Abd-al-Latif Abdallah al-Kawwari', 'ABD-AL-LATIF ABDALLAH AL-KAWWARI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('53', '20170807', '����췢[2017]106��', '1: ABD AL-LATIF 2: BIN ABDALLAH 3: SALIH MUHAMMAD 4: AL-KAWARI', 'a) Abd-al-Latif Abdallah Salih al-Kawari; b) Abd-al-Latif Abdallah Salih al-Kuwari; c) Abd-al-Latif Abdallah al-Kawwari; d) Abd-al-Latif Abdallah al-Kawari; e) Abu Ali al-Kawari', '04', 'Abu Ali al-Kawari', 'ABU ALI AL-KAWARI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('54', '20170807', '����췢[2017]106��', '1: ABD AL-RAHMAN 2: BIN UMAYR 3: AL-NUAYMI 4: na', 'a) Abd al-Rahman bin Amir al-Naimi b) Abd al-Rahman al-Nuaimi c) Abd al-Rahman bin Amir Al-Nuimi; d) Abd al-Rahman bin Amir al-Nuaymi; e) Abdallah Muhammad al-Nuaymi; f) Abd al-Rahman al-Nuaymi g) A. Rahman al-Naimi; h) Abdelrahman Imer al Jaber al Naimeh; i) A. Rahman Omair J Alnaimi; j) Abdulrahman Omair al Neaimi', '02', 'ABD AL-RAHMAN BIN UMAYR', 'ABD AL-RAHMAN BIN UMAYR', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('55', '20170807', '����췢[2017]106��', '1: ABD AL-RAHMAN 2: BIN UMAYR 3: AL-NUAYMI 4: na', 'a) Abd al-Rahman bin Amir al-Naimi b) Abd al-Rahman al-Nuaimi c) Abd al-Rahman bin Amir Al-Nuimi; d) Abd al-Rahman bin Amir al-Nuaymi; e) Abdallah Muhammad al-Nuaymi; f) Abd al-Rahman al-Nuaymi g) A. Rahman al-Naimi; h) Abdelrahman Imer al Jaber al Naimeh; i) A. Rahman Omair J Alnaimi; j) Abdulrahman Omair al Neaimi', '04', 'Abd al-Rahman bin Amir al-Naimi', 'ABD AL-RAHMAN BIN AMIR AL-NAIMI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('56', '20170807', '����췢[2017]106��', '1: ABD AL-RAHMAN 2: BIN UMAYR 3: AL-NUAYMI 4: na', 'a) Abd al-Rahman bin Amir al-Naimi b) Abd al-Rahman al-Nuaimi c) Abd al-Rahman bin Amir Al-Nuimi; d) Abd al-Rahman bin Amir al-Nuaymi; e) Abdallah Muhammad al-Nuaymi; f) Abd al-Rahman al-Nuaymi g) A. Rahman al-Naimi; h) Abdelrahman Imer al Jaber al Naimeh; i) A. Rahman Omair J Alnaimi; j) Abdulrahman Omair al Neaimi', '04', 'Abd al-Rahman bin Amir Al-Nuimi', 'ABD AL-RAHMAN BIN AMIR AL-NUIMI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('57', '20170807', '����췢[2017]106��', '1: ABD AL-RAHMAN 2: BIN UMAYR 3: AL-NUAYMI 4: na', 'a) Abd al-Rahman bin Amir al-Naimi b) Abd al-Rahman al-Nuaimi c) Abd al-Rahman bin Amir Al-Nuimi; d) Abd al-Rahman bin Amir al-Nuaymi; e) Abdallah Muhammad al-Nuaymi; f) Abd al-Rahman al-Nuaymi g) A. Rahman al-Naimi; h) Abdelrahman Imer al Jaber al Naimeh; i) A. Rahman Omair J Alnaimi; j) Abdulrahman Omair al Neaimi', '04', 'Abd al-Rahman bin Amir al-Nuaymi', 'ABD AL-RAHMAN BIN AMIR AL-NUAYMI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('58', '20170807', '����췢[2017]106��', '1: ABD AL-RAHMAN 2: BIN UMAYR 3: AL-NUAYMI 4: na', 'a) Abd al-Rahman bin Amir al-Naimi b) Abd al-Rahman al-Nuaimi c) Abd al-Rahman bin Amir Al-Nuimi; d) Abd al-Rahman bin Amir al-Nuaymi; e) Abdallah Muhammad al-Nuaymi; f) Abd al-Rahman al-Nuaymi g) A. Rahman al-Naimi; h) Abdelrahman Imer al Jaber al Naimeh; i) A. Rahman Omair J Alnaimi; j) Abdulrahman Omair al Neaimi', '04', 'Abdallah Muhammad al-Nuaymi', 'ABDALLAH MUHAMMAD AL-NUAYMI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('59', '20170807', '����췢[2017]106��', '1: ABD AL-RAHMAN 2: BIN UMAYR 3: AL-NUAYMI 4: na', 'a) Abd al-Rahman bin Amir al-Naimi b) Abd al-Rahman al-Nuaimi c) Abd al-Rahman bin Amir Al-Nuimi; d) Abd al-Rahman bin Amir al-Nuaymi; e) Abdallah Muhammad al-Nuaymi; f) Abd al-Rahman al-Nuaymi g) A. Rahman al-Naimi; h) Abdelrahman Imer al Jaber al Naimeh; i) A. Rahman Omair J Alnaimi; j) Abdulrahman Omair al Neaimi', '04', 'Abd al-Rahman al-Nuaymi', 'ABD AL-RAHMAN AL-NUAYMI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('60', '20170807', '����췢[2017]106��', '1: ABD AL-RAHMAN 2: BIN UMAYR 3: AL-NUAYMI 4: na', 'a) Abd al-Rahman bin Amir al-Naimi b) Abd al-Rahman al-Nuaimi c) Abd al-Rahman bin Amir Al-Nuimi; d) Abd al-Rahman bin Amir al-Nuaymi; e) Abdallah Muhammad al-Nuaymi; f) Abd al-Rahman al-Nuaymi g) A. Rahman al-Naimi; h) Abdelrahman Imer al Jaber al Naimeh; i) A. Rahman Omair J Alnaimi; j) Abdulrahman Omair al Neaimi', '04', 'Abdelrahman Imer al Jaber al Naimeh', 'ABDELRAHMAN IMER AL JABER AL NAIMEH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('61', '20170807', '����췢[2017]106��', '1: ABD AL-RAHMAN 2: BIN UMAYR 3: AL-NUAYMI 4: na', 'a) Abd al-Rahman bin Amir al-Naimi b) Abd al-Rahman al-Nuaimi c) Abd al-Rahman bin Amir Al-Nuimi; d) Abd al-Rahman bin Amir al-Nuaymi; e) Abdallah Muhammad al-Nuaymi; f) Abd al-Rahman al-Nuaymi g) A. Rahman al-Naimi; h) Abdelrahman Imer al Jaber al Naimeh; i) A. Rahman Omair J Alnaimi; j) Abdulrahman Omair al Neaimi', '04', 'A. Rahman Omair J Alnaimi', 'A. RAHMAN OMAIR J ALNAIMI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('62', '20170807', '����췢[2017]106��', '1: ABD AL-RAHMAN 2: BIN UMAYR 3: AL-NUAYMI 4: na', 'a) Abd al-Rahman bin Amir al-Naimi b) Abd al-Rahman al-Nuaimi c) Abd al-Rahman bin Amir Al-Nuimi; d) Abd al-Rahman bin Amir al-Nuaymi; e) Abdallah Muhammad al-Nuaymi; f) Abd al-Rahman al-Nuaymi g) A. Rahman al-Naimi; h) Abdelrahman Imer al Jaber al Naimeh; i) A. Rahman Omair J Alnaimi; j) Abdulrahman Omair al Neaimi', '04', 'Abd al-Rahman al-Nuaimi', 'ABD AL-RAHMAN AL-NUAIMI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('63', '20170807', '����췢[2017]106��', '1: ABD AL-RAHMAN 2: BIN UMAYR 3: AL-NUAYMI 4: na', 'a) Abd al-Rahman bin Amir al-Naimi b) Abd al-Rahman al-Nuaimi c) Abd al-Rahman bin Amir Al-Nuimi; d) Abd al-Rahman bin Amir al-Nuaymi; e) Abdallah Muhammad al-Nuaymi; f) Abd al-Rahman al-Nuaymi g) A. Rahman al-Naimi; h) Abdelrahman Imer al Jaber al Naimeh; i) A. Rahman Omair J Alnaimi; j) Abdulrahman Omair al Neaimi', '04', 'Abdulrahman Omair al Neaimi', 'ABDULRAHMAN OMAIR AL NEAIMI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('64', '20170807', '����췢[2017]106��', '1: ABD AL-RAHMAN 2: KHALAF 3: UBAYD JUDAY 4: AL-ANIZI', 'a) Abd al-Rahman Khalaf al-Anizi; b) Abd al-Rahamn Khalaf al-Anzi', '02', 'ABD AL-RAHMAN KHALAF', 'ABD AL-RAHMAN KHALAF', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('65', '20170807', '����췢[2017]106��', '1: ABD AL-RAHMAN 2: KHALAF 3: UBAYD JUDAY 4: AL-ANIZI', 'a) Abd al-Rahman Khalaf al-Anizi; b) Abd al-Rahamn Khalaf al-Anzi', '04', 'Abd al-Rahman Khalaf al-Anizi', 'ABD AL-RAHMAN KHALAF AL-ANIZI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('66', '20170807', '����췢[2017]106��', '1: ABD AL-RAHMAN 2: KHALAF 3: UBAYD JUDAY 4: AL-ANIZI', 'a) Abd al-Rahman Khalaf al-Anizi; b) Abd al-Rahamn Khalaf al-Anzi', '04', 'Abd al-Rahamn Khalaf al-Anzi', 'ABD AL-RAHAMN KHALAF AL-ANZI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('67', '20170807', '����췢[2017]106��', '1: ABD AL-RAHMAN 2: MUHAMMAD 3: MUSTAFA 4: AL-QADULI', 'a) Abd al-Rahman Muhammad Mustafa Shaykhlari; b) Umar Muhammad Khalil Mustafa; c) Abdul Rahman Muhammad al-Bayati; d) Tahir Muhammad Khalil Mustafa al-Bayati; e) Aliazra Raad Ahmad', '02', 'ABD AL-RAHMAN MUHAMMAD', 'ABD AL-RAHMAN MUHAMMAD', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('68', '20170807', '����췢[2017]106��', '1: ABD AL-RAHMAN 2: MUHAMMAD 3: MUSTAFA 4: AL-QADULI', 'a) Abd al-Rahman Muhammad Mustafa Shaykhlari; b) Umar Muhammad Khalil Mustafa; c) Abdul Rahman Muhammad al-Bayati; d) Tahir Muhammad Khalil Mustafa al-Bayati; e) Aliazra Raad Ahmad', '04', 'Abdul Rahman Muhammad al-Bayati', 'ABDUL RAHMAN MUHAMMAD AL-BAYATI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('69', '20170807', '����췢[2017]106��', '1: ABD AL-RAHMAN 2: MUHAMMAD 3: MUSTAFA 4: AL-QADULI', 'a) Abd al-Rahman Muhammad Mustafa Shaykhlari; b) Umar Muhammad Khalil Mustafa; c) Abdul Rahman Muhammad al-Bayati; d) Tahir Muhammad Khalil Mustafa al-Bayati; e) Aliazra Raad Ahmad', '04', 'Abd al-Rahman Muhammad Mustafa Shaykhlari', 'ABD AL-RAHMAN MUHAMMAD MUSTAFA SHAYKHLARI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('70', '20170807', '����췢[2017]106��', '1: ABD AL-RAHMAN 2: MUHAMMAD 3: MUSTAFA 4: AL-QADULI', 'a) Abd al-Rahman Muhammad Mustafa Shaykhlari; b) Umar Muhammad Khalil Mustafa; c) Abdul Rahman Muhammad al-Bayati; d) Tahir Muhammad Khalil Mustafa al-Bayati; e) Aliazra Raad Ahmad', '04', 'Umar Muhammad Khalil Mustafa', 'UMAR MUHAMMAD KHALIL MUSTAFA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('71', '20170807', '����췢[2017]106��', '1: ABD AL-RAHMAN 2: MUHAMMAD 3: MUSTAFA 4: AL-QADULI', 'a) Abd al-Rahman Muhammad Mustafa Shaykhlari; b) Umar Muhammad Khalil Mustafa; c) Abdul Rahman Muhammad al-Bayati; d) Tahir Muhammad Khalil Mustafa al-Bayati; e) Aliazra Raad Ahmad', '04', 'Aliazra Raad Ahmad', 'ALIAZRA RAAD AHMAD', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('72', '20170807', '����췢[2017]106��', '1: ABD AL-RAHMAN 2: MUHAMMAD 3: MUSTAFA 4: AL-QADULI', 'a) Abd al-Rahman Muhammad Mustafa Shaykhlari; b) Umar Muhammad Khalil Mustafa; c) Abdul Rahman Muhammad al-Bayati; d) Tahir Muhammad Khalil Mustafa al-Bayati; e) Aliazra Raad Ahmad', '04', 'Tahir Muhammad Khalil Mustafa al-Bayati', 'TAHIR MUHAMMAD KHALIL MUSTAFA AL-BAYATI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('73', '20170807', '����췢[2017]106��', '1: ABD AL-RAHMAN 2: OULD MUHAMMAD AL-HUSAYN 3: OULD MUHAMMAD SALIM 4: na', 'a) Abdarrahmane ould Mohamed el Houcein ould Mohamed Salem; b) Yunis al-Mauritani; Younis al-Mauritani; Sheikh Yunis al-Mauritani; Shaykh Yunis the Mauritanian', '02', 'ABD AL-RAHMAN OULD MUHAMMAD AL-HUSAYN', 'ABD AL-RAHMAN OULD MUHAMMAD AL-HUSAYN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('74', '20170807', '����췢[2017]106��', '1: ABD AL-RAHMAN 2: OULD MUHAMMAD AL-HUSAYN 3: OULD MUHAMMAD SALIM 4: na', 'a) Abdarrahmane ould Mohamed el Houcein ould Mohamed Salem; b) Yunis al-Mauritani; Younis al-Mauritani; Sheikh Yunis al-Mauritani; Shaykh Yunis the Mauritanian', '04', 'Yunis al-Mauritani', 'YUNIS AL-MAURITANI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('75', '20170807', '����췢[2017]106��', '1: ABD AL-RAHMAN 2: OULD MUHAMMAD AL-HUSAYN 3: OULD MUHAMMAD SALIM 4: na', 'a) Abdarrahmane ould Mohamed el Houcein ould Mohamed Salem; b) Yunis al-Mauritani; Younis al-Mauritani; Sheikh Yunis al-Mauritani; Shaykh Yunis the Mauritanian', '04', 'Younis al-Mauritani', 'YOUNIS AL-MAURITANI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('76', '20170807', '����췢[2017]106��', '1: ABD AL-RAHMAN 2: OULD MUHAMMAD AL-HUSAYN 3: OULD MUHAMMAD SALIM 4: na', 'a) Abdarrahmane ould Mohamed el Houcein ould Mohamed Salem; b) Yunis al-Mauritani; Younis al-Mauritani; Sheikh Yunis al-Mauritani; Shaykh Yunis the Mauritanian', '04', 'Sheikh Yunis al-Mauritani', 'SHEIKH YUNIS AL-MAURITANI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('77', '20170807', '����췢[2017]106��', '1: ABD AL-RAHMAN 2: OULD MUHAMMAD AL-HUSAYN 3: OULD MUHAMMAD SALIM 4: na', 'a) Abdarrahmane ould Mohamed el Houcein ould Mohamed Salem; b) Yunis al-Mauritani; Younis al-Mauritani; Sheikh Yunis al-Mauritani; Shaykh Yunis the Mauritanian', '04', 'Shaykh Yunis the Mauritanian', 'SHAYKH YUNIS THE MAURITANIAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('78', '20170807', '����췢[2017]106��', '1: ABD AL-RAHMAN 2: OULD MUHAMMAD AL-HUSAYN 3: OULD MUHAMMAD SALIM 4: na', 'a) Abdarrahmane ould Mohamed el Houcein ould Mohamed Salem; b) Yunis al-Mauritani; Younis al-Mauritani; Sheikh Yunis al-Mauritani; Shaykh Yunis the Mauritanian', '04', 'Abdarrahmane ould Mohamed el Houcein ould Mohamed Salem', 'ABDARRAHMANE OULD MOHAMED EL HOUCEIN OULD MOHAMED SALEM', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('79', '20170807', '����췢[2017]106��', '1: ABD ALLAH 2: MOHAMED 3: RAGAB 4: ABDEL RAHMAN', 'a) Abu Al-Khayr; b) Ahmad Hasan; c) Abu Jihad', '02', 'ABD ALLAH MOHAMED', 'ABD ALLAH MOHAMED', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('80', '20170807', '����췢[2017]106��', '1: ABD ALLAH 2: MOHAMED 3: RAGAB 4: ABDEL RAHMAN', 'a) Abu Al-Khayr; b) Ahmad Hasan; c) Abu Jihad', '04', 'Abu Jihad', 'ABU JIHAD', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('81', '20170807', '����췢[2017]106��', '1: ABD ALLAH 2: MOHAMED 3: RAGAB 4: ABDEL RAHMAN', 'a) Abu Al-Khayr; b) Ahmad Hasan; c) Abu Jihad', '04', 'Abu Al-Khayr', 'ABU AL-KHAYR', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('82', '20170807', '����췢[2017]106��', '1: ABD ALLAH 2: MOHAMED 3: RAGAB 4: ABDEL RAHMAN', 'a) Abu Al-Khayr; b) Ahmad Hasan; c) Abu Jihad', '04', 'Ahmad Hasan', 'AHMAD HASAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('83', '20170807', '����췢[2017]106��', '1: ABD EL KADER 2: MAHMOUD 3: MOHAMED 4: EL SAYED', 'a) Es Sayed, Kader; b) Abdel Khader Mahmoud Mohamed el Sayed', '02', 'ABD EL KADER MAHMOUD', 'ABD EL KADER MAHMOUD', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('84', '20170807', '����췢[2017]106��', '1: ABD EL KADER 2: MAHMOUD 3: MOHAMED 4: EL SAYED', 'a) Es Sayed, Kader; b) Abdel Khader Mahmoud Mohamed el Sayed', '04', 'Es Sayed', 'ES SAYED', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('85', '20170807', '����췢[2017]106��', '1: ABD EL KADER 2: MAHMOUD 3: MOHAMED 4: EL SAYED', 'a) Es Sayed, Kader; b) Abdel Khader Mahmoud Mohamed el Sayed', '04', 'Kader', 'KADER', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('86', '20170807', '����췢[2017]106��', '1: ABD EL KADER 2: MAHMOUD 3: MOHAMED 4: EL SAYED', 'a) Es Sayed, Kader; b) Abdel Khader Mahmoud Mohamed el Sayed', '04', 'Abdel Khader Mahmoud Mohamed el Sayed', 'ABDEL KHADER MAHMOUD MOHAMED EL SAYED', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('87', '20170807', '����췢[2017]106��', '1: ABD-AL-HAMID 2: AL-MASLI 3: na 4: na', 'a) Abd-al-Hamid Muhammad Abd-al-Hamid Al-Masli; b) Abd-al-Hamid Musalli; c) Hamid Masli', '02', 'ABD-AL-HAMID AL-MASLI', 'ABD-AL-HAMID AL-MASLI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('88', '20170807', '����췢[2017]106��', '1: ABD-AL-HAMID 2: AL-MASLI 3: na 4: na', 'a) Abd-al-Hamid Muhammad Abd-al-Hamid Al-Masli; b) Abd-al-Hamid Musalli; c) Hamid Masli', '04', 'Abd-al-Hamid Muhammad Abd-al-Hamid Al-Masli', 'ABD-AL-HAMID MUHAMMAD ABD-AL-HAMID AL-MASLI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('89', '20170807', '����췢[2017]106��', '1: ABD-AL-HAMID 2: AL-MASLI 3: na 4: na', 'a) Abd-al-Hamid Muhammad Abd-al-Hamid Al-Masli; b) Abd-al-Hamid Musalli; c) Hamid Masli', '04', 'Hamid Masli', 'HAMID MASLI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('90', '20170807', '����췢[2017]106��', '1: ABD-AL-HAMID 2: AL-MASLI 3: na 4: na', 'a) Abd-al-Hamid Muhammad Abd-al-Hamid Al-Masli; b) Abd-al-Hamid Musalli; c) Hamid Masli', '04', 'Abd-al-Hamid Musalli', 'ABD-AL-HAMID MUSALLI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('91', '20170807', '����췢[2017]106��', '1: ABD-AL-MAJID 2: AZIZ 3: AL-ZINDANI 4: na', 'a) Abdelmajid Al-Zindani; b) Shaykh Abd Al-Majid Al-Zindani; c) Sheikh Abd Al-Meguid Al-Zandani', '02', 'ABD-AL-MAJID AZIZ', 'ABD-AL-MAJID AZIZ', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('92', '20170807', '����췢[2017]106��', '1: ABD-AL-MAJID 2: AZIZ 3: AL-ZINDANI 4: na', 'a) Abdelmajid Al-Zindani; b) Shaykh Abd Al-Majid Al-Zindani; c) Sheikh Abd Al-Meguid Al-Zandani', '04', 'Shaykh Abd Al-Majid Al-Zindani', 'SHAYKH ABD AL-MAJID AL-ZINDANI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('93', '20170807', '����췢[2017]106��', '1: ABD-AL-MAJID 2: AZIZ 3: AL-ZINDANI 4: na', 'a) Abdelmajid Al-Zindani; b) Shaykh Abd Al-Majid Al-Zindani; c) Sheikh Abd Al-Meguid Al-Zandani', '04', 'Sheikh Abd Al-Meguid Al-Zandani', 'SHEIKH ABD AL-MEGUID AL-ZANDANI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('94', '20170807', '����췢[2017]106��', '1: ABD-AL-MAJID 2: AZIZ 3: AL-ZINDANI 4: na', 'a) Abdelmajid Al-Zindani; b) Shaykh Abd Al-Majid Al-Zindani; c) Sheikh Abd Al-Meguid Al-Zandani', '04', 'Abdelmajid Al-Zindani', 'ABDELMAJID AL-ZINDANI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('95', '20170807', '����췢[2017]106��', '1: ABDELHALIM 2: HAFED 3: ABDELFATTAH 4: REMADNA', 'a) Abdelhalim Remadna', '02', 'ABDELHALIM HAFED', 'ABDELHALIM HAFED', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('96', '20170807', '����췢[2017]106��', '1: ABDELHALIM 2: HAFED 3: ABDELFATTAH 4: REMADNA', 'a) Abdelhalim Remadna', '03', 'Abdelhalim Remadna', 'ABDELHALIM REMADNA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('97', '20170807', '����췢[2017]106��', '1: ABDELKADER 2: LAAGOUB 3: na 4: na', null, '02', 'ABDELKADER LAAGOUB', 'ABDELKADER LAAGOUB', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('98', '20170807', '����췢[2017]106��', '1: ABDELMALEK 2: DROUKDEL 3: na 4: na', 'a) Abou Mossaab Abdelouadoud', '02', 'ABDELMALEK DROUKDEL', 'ABDELMALEK DROUKDEL', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('99', '20170807', '����췢[2017]106��', '1: ABDELMALEK 2: DROUKDEL 3: na 4: na', 'a) Abou Mossaab Abdelouadoud', '03', 'Abou Mossaab Abdelouadoud', 'ABOU MOSSAAB ABDELOUADOUD', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('100', '20170807', '����췢[2017]106��', '1: ABDELRAHMAN 2: MOUHAMAD ZAFIR 3: AL DABIDI 4: AL JAHANI', 'a) Abd Al-Rahman Muhammad Zafir Al-Dubaysi Al-Juhni; b) Abd Al-Rahman Muhammad Zafir al-Dubaysi al-Jahni; c) Abd Al-Rahman Muhammad Zafir al-Dubaysi al-Jahani; d) Abd Al-Rahman Muhammad Zafir al-Dubaysi al-Juhani; e) Abdulrhman Mohammed D. Aliahani; f) Abu al-Wafa; g) Abu Anas; h) Abd al-Rahman Muhammad Zafir al-Dabisi al-Jahani; i) Abu Wafa al-Saudi; j) Abu al-Wafa; k) Abd al-Rahman Muhammad Thafir al-Jahni; l) Abd al-Rahman Muhammad al-Juhani; m) Abdelrahman Mouhamad Zafir al Dabissi Juhan; n) Abdelrahman Mouhamad Zafir al Dabissi Juhani', '02', 'ABDELRAHMAN MOUHAMAD', 'ABDELRAHMAN MOUHAMAD', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('101', '20170807', '����췢[2017]106��', '1: ABDELRAHMAN 2: MOUHAMAD ZAFIR 3: AL DABIDI 4: AL JAHANI', 'a) Abd Al-Rahman Muhammad Zafir Al-Dubaysi Al-Juhni; b) Abd Al-Rahman Muhammad Zafir al-Dubaysi al-Jahni; c) Abd Al-Rahman Muhammad Zafir al-Dubaysi al-Jahani; d) Abd Al-Rahman Muhammad Zafir al-Dubaysi al-Juhani; e) Abdulrhman Mohammed D. Aliahani; f) Abu al-Wafa; g) Abu Anas; h) Abd al-Rahman Muhammad Zafir al-Dabisi al-Jahani; i) Abu Wafa al-Saudi; j) Abu al-Wafa; k) Abd al-Rahman Muhammad Thafir al-Jahni; l) Abd al-Rahman Muhammad al-Juhani; m) Abdelrahman Mouhamad Zafir al Dabissi Juhan; n) Abdelrahman Mouhamad Zafir al Dabissi Juhani', '04', 'Abd Al-Rahman Muhammad Zafir al-Dubaysi al-Jahni', 'ABD AL-RAHMAN MUHAMMAD ZAFIR AL-DUBAYSI AL-JAHNI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('102', '20170807', '����췢[2017]106��', '1: ABDELRAHMAN 2: MOUHAMAD ZAFIR 3: AL DABIDI 4: AL JAHANI', 'a) Abd Al-Rahman Muhammad Zafir Al-Dubaysi Al-Juhni; b) Abd Al-Rahman Muhammad Zafir al-Dubaysi al-Jahni; c) Abd Al-Rahman Muhammad Zafir al-Dubaysi al-Jahani; d) Abd Al-Rahman Muhammad Zafir al-Dubaysi al-Juhani; e) Abdulrhman Mohammed D. Aliahani; f) Abu al-Wafa; g) Abu Anas; h) Abd al-Rahman Muhammad Zafir al-Dabisi al-Jahani; i) Abu Wafa al-Saudi; j) Abu al-Wafa; k) Abd al-Rahman Muhammad Thafir al-Jahni; l) Abd al-Rahman Muhammad al-Juhani; m) Abdelrahman Mouhamad Zafir al Dabissi Juhan; n) Abdelrahman Mouhamad Zafir al Dabissi Juhani', '04', 'Abdelrahman Mouhamad Zafir al Dabissi Juhan', 'ABDELRAHMAN MOUHAMAD ZAFIR AL DABISSI JUHAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('103', '20170807', '����췢[2017]106��', '1: ABDELRAHMAN 2: MOUHAMAD ZAFIR 3: AL DABIDI 4: AL JAHANI', 'a) Abd Al-Rahman Muhammad Zafir Al-Dubaysi Al-Juhni; b) Abd Al-Rahman Muhammad Zafir al-Dubaysi al-Jahni; c) Abd Al-Rahman Muhammad Zafir al-Dubaysi al-Jahani; d) Abd Al-Rahman Muhammad Zafir al-Dubaysi al-Juhani; e) Abdulrhman Mohammed D. Aliahani; f) Abu al-Wafa; g) Abu Anas; h) Abd al-Rahman Muhammad Zafir al-Dabisi al-Jahani; i) Abu Wafa al-Saudi; j) Abu al-Wafa; k) Abd al-Rahman Muhammad Thafir al-Jahni; l) Abd al-Rahman Muhammad al-Juhani; m) Abdelrahman Mouhamad Zafir al Dabissi Juhan; n) Abdelrahman Mouhamad Zafir al Dabissi Juhani', '04', 'Abd al-Rahman Muhammad al-Juhani', 'ABD AL-RAHMAN MUHAMMAD AL-JUHANI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('104', '20170807', '����췢[2017]106��', '1: ABDELRAHMAN 2: MOUHAMAD ZAFIR 3: AL DABIDI 4: AL JAHANI', 'a) Abd Al-Rahman Muhammad Zafir Al-Dubaysi Al-Juhni; b) Abd Al-Rahman Muhammad Zafir al-Dubaysi al-Jahni; c) Abd Al-Rahman Muhammad Zafir al-Dubaysi al-Jahani; d) Abd Al-Rahman Muhammad Zafir al-Dubaysi al-Juhani; e) Abdulrhman Mohammed D. Aliahani; f) Abu al-Wafa; g) Abu Anas; h) Abd al-Rahman Muhammad Zafir al-Dabisi al-Jahani; i) Abu Wafa al-Saudi; j) Abu al-Wafa; k) Abd al-Rahman Muhammad Thafir al-Jahni; l) Abd al-Rahman Muhammad al-Juhani; m) Abdelrahman Mouhamad Zafir al Dabissi Juhan; n) Abdelrahman Mouhamad Zafir al Dabissi Juhani', '04', 'Abd al-Rahman Muhammad Thafir al-Jahni', 'ABD AL-RAHMAN MUHAMMAD THAFIR AL-JAHNI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('105', '20170807', '����췢[2017]106��', '1: ABDELRAHMAN 2: MOUHAMAD ZAFIR 3: AL DABIDI 4: AL JAHANI', 'a) Abd Al-Rahman Muhammad Zafir Al-Dubaysi Al-Juhni; b) Abd Al-Rahman Muhammad Zafir al-Dubaysi al-Jahni; c) Abd Al-Rahman Muhammad Zafir al-Dubaysi al-Jahani; d) Abd Al-Rahman Muhammad Zafir al-Dubaysi al-Juhani; e) Abdulrhman Mohammed D. Aliahani; f) Abu al-Wafa; g) Abu Anas; h) Abd al-Rahman Muhammad Zafir al-Dabisi al-Jahani; i) Abu Wafa al-Saudi; j) Abu al-Wafa; k) Abd al-Rahman Muhammad Thafir al-Jahni; l) Abd al-Rahman Muhammad al-Juhani; m) Abdelrahman Mouhamad Zafir al Dabissi Juhan; n) Abdelrahman Mouhamad Zafir al Dabissi Juhani', '04', 'Abd Al-Rahman Muhammad Zafir Al-Dubaysi Al-Juhni', 'ABD AL-RAHMAN MUHAMMAD ZAFIR AL-DUBAYSI AL-JUHNI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('106', '20170807', '����췢[2017]106��', '1: ABDELRAHMAN 2: MOUHAMAD ZAFIR 3: AL DABIDI 4: AL JAHANI', 'a) Abd Al-Rahman Muhammad Zafir Al-Dubaysi Al-Juhni; b) Abd Al-Rahman Muhammad Zafir al-Dubaysi al-Jahni; c) Abd Al-Rahman Muhammad Zafir al-Dubaysi al-Jahani; d) Abd Al-Rahman Muhammad Zafir al-Dubaysi al-Juhani; e) Abdulrhman Mohammed D. Aliahani; f) Abu al-Wafa; g) Abu Anas; h) Abd al-Rahman Muhammad Zafir al-Dabisi al-Jahani; i) Abu Wafa al-Saudi; j) Abu al-Wafa; k) Abd al-Rahman Muhammad Thafir al-Jahni; l) Abd al-Rahman Muhammad al-Juhani; m) Abdelrahman Mouhamad Zafir al Dabissi Juhan; n) Abdelrahman Mouhamad Zafir al Dabissi Juhani', '04', 'Abdelrahman Mouhamad Zafir al Dabissi Juhani', 'ABDELRAHMAN MOUHAMAD ZAFIR AL DABISSI JUHANI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('107', '20170807', '����췢[2017]106��', '1: ABDELRAHMAN 2: MOUHAMAD ZAFIR 3: AL DABIDI 4: AL JAHANI', 'a) Abd Al-Rahman Muhammad Zafir Al-Dubaysi Al-Juhni; b) Abd Al-Rahman Muhammad Zafir al-Dubaysi al-Jahni; c) Abd Al-Rahman Muhammad Zafir al-Dubaysi al-Jahani; d) Abd Al-Rahman Muhammad Zafir al-Dubaysi al-Juhani; e) Abdulrhman Mohammed D. Aliahani; f) Abu al-Wafa; g) Abu Anas; h) Abd al-Rahman Muhammad Zafir al-Dabisi al-Jahani; i) Abu Wafa al-Saudi; j) Abu al-Wafa; k) Abd al-Rahman Muhammad Thafir al-Jahni; l) Abd al-Rahman Muhammad al-Juhani; m) Abdelrahman Mouhamad Zafir al Dabissi Juhan; n) Abdelrahman Mouhamad Zafir al Dabissi Juhani', '04', 'Abd Al-Rahman Muhammad Zafir al-Dubaysi al-Jahani', 'ABD AL-RAHMAN MUHAMMAD ZAFIR AL-DUBAYSI AL-JAHANI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('108', '20170807', '����췢[2017]106��', '1: ABDELRAHMAN 2: MOUHAMAD ZAFIR 3: AL DABIDI 4: AL JAHANI', 'a) Abd Al-Rahman Muhammad Zafir Al-Dubaysi Al-Juhni; b) Abd Al-Rahman Muhammad Zafir al-Dubaysi al-Jahni; c) Abd Al-Rahman Muhammad Zafir al-Dubaysi al-Jahani; d) Abd Al-Rahman Muhammad Zafir al-Dubaysi al-Juhani; e) Abdulrhman Mohammed D. Aliahani; f) Abu al-Wafa; g) Abu Anas; h) Abd al-Rahman Muhammad Zafir al-Dabisi al-Jahani; i) Abu Wafa al-Saudi; j) Abu al-Wafa; k) Abd al-Rahman Muhammad Thafir al-Jahni; l) Abd al-Rahman Muhammad al-Juhani; m) Abdelrahman Mouhamad Zafir al Dabissi Juhan; n) Abdelrahman Mouhamad Zafir al Dabissi Juhani', '04', 'Abd Al-Rahman Muhammad Zafir al-Dubaysi al-Juhani', 'ABD AL-RAHMAN MUHAMMAD ZAFIR AL-DUBAYSI AL-JUHANI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('109', '20170807', '����췢[2017]106��', '1: ABDELRAHMAN 2: MOUHAMAD ZAFIR 3: AL DABIDI 4: AL JAHANI', 'a) Abd Al-Rahman Muhammad Zafir Al-Dubaysi Al-Juhni; b) Abd Al-Rahman Muhammad Zafir al-Dubaysi al-Jahni; c) Abd Al-Rahman Muhammad Zafir al-Dubaysi al-Jahani; d) Abd Al-Rahman Muhammad Zafir al-Dubaysi al-Juhani; e) Abdulrhman Mohammed D. Aliahani; f) Abu al-Wafa; g) Abu Anas; h) Abd al-Rahman Muhammad Zafir al-Dabisi al-Jahani; i) Abu Wafa al-Saudi; j) Abu al-Wafa; k) Abd al-Rahman Muhammad Thafir al-Jahni; l) Abd al-Rahman Muhammad al-Juhani; m) Abdelrahman Mouhamad Zafir al Dabissi Juhan; n) Abdelrahman Mouhamad Zafir al Dabissi Juhani', '04', 'Abdulrhman Mohammed D. Aliahani', 'ABDULRHMAN MOHAMMED D. ALIAHANI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('110', '20170807', '����췢[2017]106��', '1: ABDELRAHMAN 2: MOUHAMAD ZAFIR 3: AL DABIDI 4: AL JAHANI', 'a) Abd Al-Rahman Muhammad Zafir Al-Dubaysi Al-Juhni; b) Abd Al-Rahman Muhammad Zafir al-Dubaysi al-Jahni; c) Abd Al-Rahman Muhammad Zafir al-Dubaysi al-Jahani; d) Abd Al-Rahman Muhammad Zafir al-Dubaysi al-Juhani; e) Abdulrhman Mohammed D. Aliahani; f) Abu al-Wafa; g) Abu Anas; h) Abd al-Rahman Muhammad Zafir al-Dabisi al-Jahani; i) Abu Wafa al-Saudi; j) Abu al-Wafa; k) Abd al-Rahman Muhammad Thafir al-Jahni; l) Abd al-Rahman Muhammad al-Juhani; m) Abdelrahman Mouhamad Zafir al Dabissi Juhan; n) Abdelrahman Mouhamad Zafir al Dabissi Juhani', '04', 'Abu al-Wafa', 'ABU AL-WAFA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('111', '20170807', '����췢[2017]106��', '1: ABDELRAHMAN 2: MOUHAMAD ZAFIR 3: AL DABIDI 4: AL JAHANI', 'a) Abd Al-Rahman Muhammad Zafir Al-Dubaysi Al-Juhni; b) Abd Al-Rahman Muhammad Zafir al-Dubaysi al-Jahni; c) Abd Al-Rahman Muhammad Zafir al-Dubaysi al-Jahani; d) Abd Al-Rahman Muhammad Zafir al-Dubaysi al-Juhani; e) Abdulrhman Mohammed D. Aliahani; f) Abu al-Wafa; g) Abu Anas; h) Abd al-Rahman Muhammad Zafir al-Dabisi al-Jahani; i) Abu Wafa al-Saudi; j) Abu al-Wafa; k) Abd al-Rahman Muhammad Thafir al-Jahni; l) Abd al-Rahman Muhammad al-Juhani; m) Abdelrahman Mouhamad Zafir al Dabissi Juhan; n) Abdelrahman Mouhamad Zafir al Dabissi Juhani', '04', 'Abu Anas', 'ABU ANAS', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('112', '20170807', '����췢[2017]106��', '1: ABDELRAHMAN 2: MOUHAMAD ZAFIR 3: AL DABIDI 4: AL JAHANI', 'a) Abd Al-Rahman Muhammad Zafir Al-Dubaysi Al-Juhni; b) Abd Al-Rahman Muhammad Zafir al-Dubaysi al-Jahni; c) Abd Al-Rahman Muhammad Zafir al-Dubaysi al-Jahani; d) Abd Al-Rahman Muhammad Zafir al-Dubaysi al-Juhani; e) Abdulrhman Mohammed D. Aliahani; f) Abu al-Wafa; g) Abu Anas; h) Abd al-Rahman Muhammad Zafir al-Dabisi al-Jahani; i) Abu Wafa al-Saudi; j) Abu al-Wafa; k) Abd al-Rahman Muhammad Thafir al-Jahni; l) Abd al-Rahman Muhammad al-Juhani; m) Abdelrahman Mouhamad Zafir al Dabissi Juhan; n) Abdelrahman Mouhamad Zafir al Dabissi Juhani', '04', 'Abd al-Rahman Muhammad Zafir al-Dabisi al-Jahani', 'ABD AL-RAHMAN MUHAMMAD ZAFIR AL-DABISI AL-JAHANI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('113', '20170807', '����췢[2017]106��', '1: ABDELRAHMAN 2: MOUHAMAD ZAFIR 3: AL DABIDI 4: AL JAHANI', 'a) Abd Al-Rahman Muhammad Zafir Al-Dubaysi Al-Juhni; b) Abd Al-Rahman Muhammad Zafir al-Dubaysi al-Jahni; c) Abd Al-Rahman Muhammad Zafir al-Dubaysi al-Jahani; d) Abd Al-Rahman Muhammad Zafir al-Dubaysi al-Juhani; e) Abdulrhman Mohammed D. Aliahani; f) Abu al-Wafa; g) Abu Anas; h) Abd al-Rahman Muhammad Zafir al-Dabisi al-Jahani; i) Abu Wafa al-Saudi; j) Abu al-Wafa; k) Abd al-Rahman Muhammad Thafir al-Jahni; l) Abd al-Rahman Muhammad al-Juhani; m) Abdelrahman Mouhamad Zafir al Dabissi Juhan; n) Abdelrahman Mouhamad Zafir al Dabissi Juhani', '04', 'Abu Wafa al-Saudi', 'ABU WAFA AL-SAUDI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('114', '20170807', '����췢[2017]106��', '1: ABDELRAHMAN 2: MOUHAMAD ZAFIR 3: AL DABIDI 4: AL JAHANI', 'a) Abd Al-Rahman Muhammad Zafir Al-Dubaysi Al-Juhni; b) Abd Al-Rahman Muhammad Zafir al-Dubaysi al-Jahni; c) Abd Al-Rahman Muhammad Zafir al-Dubaysi al-Jahani; d) Abd Al-Rahman Muhammad Zafir al-Dubaysi al-Juhani; e) Abdulrhman Mohammed D. Aliahani; f) Abu al-Wafa; g) Abu Anas; h) Abd al-Rahman Muhammad Zafir al-Dabisi al-Jahani; i) Abu Wafa al-Saudi; j) Abu al-Wafa; k) Abd al-Rahman Muhammad Thafir al-Jahni; l) Abd al-Rahman Muhammad al-Juhani; m) Abdelrahman Mouhamad Zafir al Dabissi Juhan; n) Abdelrahman Mouhamad Zafir al Dabissi Juhani', '04', 'Abu al-Wafa', 'ABU AL-WAFA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('115', '20170807', '����췢[2017]106��', '1: ABDERRAHMANE 2: OULD EL AMAR 3: na 4: na', 'a) Ahmed el Tilemsi; b) Abderrahmane Ould el Amar Ould Sidahmed Loukbeiti; c) Ahmad Ould Amar', '02', 'ABDERRAHMANE OULD EL AMAR', 'ABDERRAHMANE OULD EL AMAR', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('116', '20170807', '����췢[2017]106��', '1: ABDERRAHMANE 2: OULD EL AMAR 3: na 4: na', 'a) Ahmed el Tilemsi; b) Abderrahmane Ould el Amar Ould Sidahmed Loukbeiti; c) Ahmad Ould Amar', '04', 'Abderrahmane Ould el Amar Ould Sidahmed Loukbeiti', 'ABDERRAHMANE OULD EL AMAR OULD SIDAHMED LOUKBEITI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('117', '20170807', '����췢[2017]106��', '1: ABDERRAHMANE 2: OULD EL AMAR 3: na 4: na', 'a) Ahmed el Tilemsi; b) Abderrahmane Ould el Amar Ould Sidahmed Loukbeiti; c) Ahmad Ould Amar', '04', 'Ahmed el Tilemsi', 'AHMED EL TILEMSI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('118', '20170807', '����췢[2017]106��', '1: ABDERRAHMANE 2: OULD EL AMAR 3: na 4: na', 'a) Ahmed el Tilemsi; b) Abderrahmane Ould el Amar Ould Sidahmed Loukbeiti; c) Ahmad Ould Amar', '04', 'Ahmad Ould Amar', 'AHMAD OULD AMAR', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('119', '20170807', '����췢[2017]106��', '1: ABDUL 2: HAQ 3: na 4: na', 'a) Maimaitiming Maimaiti; b) Abdul Heq; c) Abuduhake; d) Abdulheq Jundullah; e) Abd Al-Haq; f) Memetiming Memeti; g) Memetiming Aximu; h) Memetiming Qekeman; i) Maiumaitimin Maimaiti; j) Abdul Saimaiti; k) Muhammad Ahmed Khaliq', '02', 'ABDUL HAQ', 'ABDUL HAQ', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('120', '20170807', '����췢[2017]106��', '1: ABDUL 2: HAQ 3: na 4: na', 'a) Maimaitiming Maimaiti; b) Abdul Heq; c) Abuduhake; d) Abdulheq Jundullah; e) Abd Al-Haq; f) Memetiming Memeti; g) Memetiming Aximu; h) Memetiming Qekeman; i) Maiumaitimin Maimaiti; j) Abdul Saimaiti; k) Muhammad Ahmed Khaliq', '04', 'Abdulheq Jundullah', 'ABDULHEQ JUNDULLAH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('121', '20170807', '����췢[2017]106��', '1: ABDUL 2: HAQ 3: na 4: na', 'a) Maimaitiming Maimaiti; b) Abdul Heq; c) Abuduhake; d) Abdulheq Jundullah; e) Abd Al-Haq; f) Memetiming Memeti; g) Memetiming Aximu; h) Memetiming Qekeman; i) Maiumaitimin Maimaiti; j) Abdul Saimaiti; k) Muhammad Ahmed Khaliq', '04', 'Memetiming Aximu', 'MEMETIMING AXIMU', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('122', '20170807', '����췢[2017]106��', '1: ABDUL 2: HAQ 3: na 4: na', 'a) Maimaitiming Maimaiti; b) Abdul Heq; c) Abuduhake; d) Abdulheq Jundullah; e) Abd Al-Haq; f) Memetiming Memeti; g) Memetiming Aximu; h) Memetiming Qekeman; i) Maiumaitimin Maimaiti; j) Abdul Saimaiti; k) Muhammad Ahmed Khaliq', '04', 'Muhammad Ahmed Khaliq', 'MUHAMMAD AHMED KHALIQ', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('123', '20170807', '����췢[2017]106��', '1: ABDUL 2: HAQ 3: na 4: na', 'a) Maimaitiming Maimaiti; b) Abdul Heq; c) Abuduhake; d) Abdulheq Jundullah; e) Abd Al-Haq; f) Memetiming Memeti; g) Memetiming Aximu; h) Memetiming Qekeman; i) Maiumaitimin Maimaiti; j) Abdul Saimaiti; k) Muhammad Ahmed Khaliq', '04', 'Maiumaitimin Maimaiti', 'MAIUMAITIMIN MAIMAITI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('124', '20170807', '����췢[2017]106��', '1: ABDUL 2: HAQ 3: na 4: na', 'a) Maimaitiming Maimaiti; b) Abdul Heq; c) Abuduhake; d) Abdulheq Jundullah; e) Abd Al-Haq; f) Memetiming Memeti; g) Memetiming Aximu; h) Memetiming Qekeman; i) Maiumaitimin Maimaiti; j) Abdul Saimaiti; k) Muhammad Ahmed Khaliq', '04', 'Abd Al-Haq', 'ABD AL-HAQ', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('125', '20170807', '����췢[2017]106��', '1: ABDUL 2: HAQ 3: na 4: na', 'a) Maimaitiming Maimaiti; b) Abdul Heq; c) Abuduhake; d) Abdulheq Jundullah; e) Abd Al-Haq; f) Memetiming Memeti; g) Memetiming Aximu; h) Memetiming Qekeman; i) Maiumaitimin Maimaiti; j) Abdul Saimaiti; k) Muhammad Ahmed Khaliq', '04', 'Abuduhake', 'ABUDUHAKE', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('126', '20170807', '����췢[2017]106��', '1: ABDUL 2: HAQ 3: na 4: na', 'a) Maimaitiming Maimaiti; b) Abdul Heq; c) Abuduhake; d) Abdulheq Jundullah; e) Abd Al-Haq; f) Memetiming Memeti; g) Memetiming Aximu; h) Memetiming Qekeman; i) Maiumaitimin Maimaiti; j) Abdul Saimaiti; k) Muhammad Ahmed Khaliq', '04', 'Abdul Heq', 'ABDUL HEQ', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('127', '20170807', '����췢[2017]106��', '1: ABDUL 2: HAQ 3: na 4: na', 'a) Maimaitiming Maimaiti; b) Abdul Heq; c) Abuduhake; d) Abdulheq Jundullah; e) Abd Al-Haq; f) Memetiming Memeti; g) Memetiming Aximu; h) Memetiming Qekeman; i) Maiumaitimin Maimaiti; j) Abdul Saimaiti; k) Muhammad Ahmed Khaliq', '04', 'Memetiming Qekeman', 'MEMETIMING QEKEMAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('128', '20170807', '����췢[2017]106��', '1: ABDUL 2: HAQ 3: na 4: na', 'a) Maimaitiming Maimaiti; b) Abdul Heq; c) Abuduhake; d) Abdulheq Jundullah; e) Abd Al-Haq; f) Memetiming Memeti; g) Memetiming Aximu; h) Memetiming Qekeman; i) Maiumaitimin Maimaiti; j) Abdul Saimaiti; k) Muhammad Ahmed Khaliq', '04', 'Memetiming Memeti', 'MEMETIMING MEMETI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('129', '20170807', '����췢[2017]106��', '1: ABDUL 2: HAQ 3: na 4: na', 'a) Maimaitiming Maimaiti; b) Abdul Heq; c) Abuduhake; d) Abdulheq Jundullah; e) Abd Al-Haq; f) Memetiming Memeti; g) Memetiming Aximu; h) Memetiming Qekeman; i) Maiumaitimin Maimaiti; j) Abdul Saimaiti; k) Muhammad Ahmed Khaliq', '04', 'Abdul Saimaiti', 'ABDUL SAIMAITI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('130', '20170807', '����췢[2017]106��', '1: ABDUL 2: HAQ 3: na 4: na', 'a) Maimaitiming Maimaiti; b) Abdul Heq; c) Abuduhake; d) Abdulheq Jundullah; e) Abd Al-Haq; f) Memetiming Memeti; g) Memetiming Aximu; h) Memetiming Qekeman; i) Maiumaitimin Maimaiti; j) Abdul Saimaiti; k) Muhammad Ahmed Khaliq', '04', 'Maimaitiming Maimaiti', 'MAIMAITIMING MAIMAITI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('131', '20170807', '����췢[2017]106��', '1: ABDUL 2: ROSYID 3: RIDHO 4: BAASYIR', 'a) Abdul Rosyid Ridho Bashir; b) Rashid Rida Baaysir; c) Rashid Rida Bashir', '02', 'ABDUL ROSYID', 'ABDUL ROSYID', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('132', '20170807', '����췢[2017]106��', '1: ABDUL 2: ROSYID 3: RIDHO 4: BAASYIR', 'a) Abdul Rosyid Ridho Bashir; b) Rashid Rida Baaysir; c) Rashid Rida Bashir', '04', 'Rashid Rida Baaysir', 'RASHID RIDA BAAYSIR', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('133', '20170807', '����췢[2017]106��', '1: ABDUL 2: ROSYID 3: RIDHO 4: BAASYIR', 'a) Abdul Rosyid Ridho Bashir; b) Rashid Rida Baaysir; c) Rashid Rida Bashir', '04', 'Abdul Rosyid Ridho Bashir', 'ABDUL ROSYID RIDHO BASHIR', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('134', '20170807', '����췢[2017]106��', '1: ABDUL 2: ROSYID 3: RIDHO 4: BAASYIR', 'a) Abdul Rosyid Ridho Bashir; b) Rashid Rida Baaysir; c) Rashid Rida Bashir', '04', 'Rashid Rida Bashir', 'RASHID RIDA BASHIR', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('135', '20170807', '����췢[2017]106��', '1: ABDUL HAKIM 2: MURAD 3: na 4: na', 'a) Murad, Abdul Hakim Hasim; b) Murad, Abdul Hakim Ali Hashim; c) Murad, Abdul Hakim al Hashim; d) Saeed Akman; e) Saeed Ahmed; f) Abdul Hakim Ali al-Hashem Murad', '02', 'ABDUL HAKIM MURAD', 'ABDUL HAKIM MURAD', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('136', '20170807', '����췢[2017]106��', '1: ABDUL HAKIM 2: MURAD 3: na 4: na', 'a) Murad, Abdul Hakim Hasim; b) Murad, Abdul Hakim Ali Hashim; c) Murad, Abdul Hakim al Hashim; d) Saeed Akman; e) Saeed Ahmed; f) Abdul Hakim Ali al-Hashem Murad', '04', 'Abdul Hakim Ali al-Hashem Murad', 'ABDUL HAKIM ALI AL-HASHEM MURAD', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('137', '20170807', '����췢[2017]106��', '1: ABDUL HAKIM 2: MURAD 3: na 4: na', 'a) Murad, Abdul Hakim Hasim; b) Murad, Abdul Hakim Ali Hashim; c) Murad, Abdul Hakim al Hashim; d) Saeed Akman; e) Saeed Ahmed; f) Abdul Hakim Ali al-Hashem Murad', '04', 'Saeed Ahmed', 'SAEED AHMED', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('138', '20170807', '����췢[2017]106��', '1: ABDUL HAKIM 2: MURAD 3: na 4: na', 'a) Murad, Abdul Hakim Hasim; b) Murad, Abdul Hakim Ali Hashim; c) Murad, Abdul Hakim al Hashim; d) Saeed Akman; e) Saeed Ahmed; f) Abdul Hakim Ali al-Hashem Murad', '04', 'Saeed Akman', 'SAEED AKMAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('139', '20170807', '����췢[2017]106��', '1: ABDUL HAKIM 2: MURAD 3: na 4: na', 'a) Murad, Abdul Hakim Hasim; b) Murad, Abdul Hakim Ali Hashim; c) Murad, Abdul Hakim al Hashim; d) Saeed Akman; e) Saeed Ahmed; f) Abdul Hakim Ali al-Hashem Murad', '04', 'Murad, Abdul Hakim Hasim', 'MURAD, ABDUL HAKIM HASIM', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('140', '20170807', '����췢[2017]106��', '1: ABDUL HAKIM 2: MURAD 3: na 4: na', 'a) Murad, Abdul Hakim Hasim; b) Murad, Abdul Hakim Ali Hashim; c) Murad, Abdul Hakim al Hashim; d) Saeed Akman; e) Saeed Ahmed; f) Abdul Hakim Ali al-Hashem Murad', '04', 'Murad, Abdul Hakim al Hashim', 'MURAD, ABDUL HAKIM AL HASHIM', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('141', '20170807', '����췢[2017]106��', '1: ABDUL HAKIM 2: MURAD 3: na 4: na', 'a) Murad, Abdul Hakim Hasim; b) Murad, Abdul Hakim Ali Hashim; c) Murad, Abdul Hakim al Hashim; d) Saeed Akman; e) Saeed Ahmed; f) Abdul Hakim Ali al-Hashem Murad', '04', 'Murad, Abdul Hakim Ali Hashim', 'MURAD, ABDUL HAKIM ALI HASHIM', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('142', '20170807', '����췢[2017]106��', '1: ABDUL MANAN AGHA 2: na 3: na 4: na', 'Abdul Manan', '02', 'ABDUL MANAN AGHA', 'ABDUL MANAN AGHA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('143', '20170807', '����췢[2017]106��', '1: ABDUL MANAN AGHA 2: na 3: na 4: na', 'Abdul Manan', '03', 'Abdul Manan', 'ABDUL MANAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('144', '20170807', '����췢[2017]106��', '1: ABDUL MOHSEN 2: ABDALLAH 3: IBRAHIM 4: AL CHAREKH', 'a) Abdul Mohsen Abdullah Ibrahim Al-Sharikh; b) Sanafi al Nasr', '02', 'ABDUL MOHSEN', 'ABDUL MOHSEN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('145', '20170807', '����췢[2017]106��', '1: ABDUL MOHSEN 2: ABDALLAH 3: IBRAHIM 4: AL CHAREKH', 'a) Abdul Mohsen Abdullah Ibrahim Al-Sharikh; b) Sanafi al Nasr', '04', 'Abdul Mohsen Abdullah Ibrahim Al-Sharikh', 'ABDUL MOHSEN ABDULLAH IBRAHIM AL-SHARIKH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('146', '20170807', '����췢[2017]106��', '1: ABDUL MOHSEN 2: ABDALLAH 3: IBRAHIM 4: AL CHAREKH', 'a) Abdul Mohsen Abdullah Ibrahim Al-Sharikh; b) Sanafi al Nasr', '04', 'Sanafi al Nasr', 'SANAFI AL NASR', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('147', '20170807', '����췢[2017]106��', '1: ABDUL RAHIM 2: BAAYSIR 3: na 4: na ', 'a) Abdul Rahim Bashir; b) Abd Al-Rahim Baasyir; c) Abd Al-Rahim Bashir; d) Abdurrahim Baasyir; e) Abdurrahim Bashir; f) Abdul Rachim Baasyir; g) Abdul Rachim Bashir; h) Abdul Rochim Baasyir; i) Abdul Rochim Bashir; j) Abdurochim Baasyir; k) Abdurochim Bashir; l) Abdurrochim Baasyir; m) Abdurrochim Bashir Bashir; n) Abdurrahman Baasyir; o) Abdurrahman Bashir', '02', 'ABDUL RAHIM BAAYSIR', 'ABDUL RAHIM BAAYSIR', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('148', '20170807', '����췢[2017]106��', '1: ABDUL RAHIM 2: BAAYSIR 3: na 4: na ', 'a) Abdul Rahim Bashir; b) Abd Al-Rahim Baasyir; c) Abd Al-Rahim Bashir; d) Abdurrahim Baasyir; e) Abdurrahim Bashir; f) Abdul Rachim Baasyir; g) Abdul Rachim Bashir; h) Abdul Rochim Baasyir; i) Abdul Rochim Bashir; j) Abdurochim Baasyir; k) Abdurochim Bashir; l) Abdurrochim Baasyir; m) Abdurrochim Bashir Bashir; n) Abdurrahman Baasyir; o) Abdurrahman Bashir', '04', 'Abdurrahman Bashir', 'ABDURRAHMAN BASHIR', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('149', '20170807', '����췢[2017]106��', '1: ABDUL RAHIM 2: BAAYSIR 3: na 4: na ', 'a) Abdul Rahim Bashir; b) Abd Al-Rahim Baasyir; c) Abd Al-Rahim Bashir; d) Abdurrahim Baasyir; e) Abdurrahim Bashir; f) Abdul Rachim Baasyir; g) Abdul Rachim Bashir; h) Abdul Rochim Baasyir; i) Abdul Rochim Bashir; j) Abdurochim Baasyir; k) Abdurochim Bashir; l) Abdurrochim Baasyir; m) Abdurrochim Bashir Bashir; n) Abdurrahman Baasyir; o) Abdurrahman Bashir', '04', 'Abdurrahman Baasyir', 'ABDURRAHMAN BAASYIR', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('150', '20170807', '����췢[2017]106��', '1: ABDUL RAHIM 2: BAAYSIR 3: na 4: na ', 'a) Abdul Rahim Bashir; b) Abd Al-Rahim Baasyir; c) Abd Al-Rahim Bashir; d) Abdurrahim Baasyir; e) Abdurrahim Bashir; f) Abdul Rachim Baasyir; g) Abdul Rachim Bashir; h) Abdul Rochim Baasyir; i) Abdul Rochim Bashir; j) Abdurochim Baasyir; k) Abdurochim Bashir; l) Abdurrochim Baasyir; m) Abdurrochim Bashir Bashir; n) Abdurrahman Baasyir; o) Abdurrahman Bashir', '04', 'Abdurrochim Baasyir', 'ABDURROCHIM BAASYIR', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('151', '20170807', '����췢[2017]106��', '1: ABDUL RAHIM 2: BAAYSIR 3: na 4: na ', 'a) Abdul Rahim Bashir; b) Abd Al-Rahim Baasyir; c) Abd Al-Rahim Bashir; d) Abdurrahim Baasyir; e) Abdurrahim Bashir; f) Abdul Rachim Baasyir; g) Abdul Rachim Bashir; h) Abdul Rochim Baasyir; i) Abdul Rochim Bashir; j) Abdurochim Baasyir; k) Abdurochim Bashir; l) Abdurrochim Baasyir; m) Abdurrochim Bashir Bashir; n) Abdurrahman Baasyir; o) Abdurrahman Bashir', '04', 'Abdurochim Bashir', 'ABDUROCHIM BASHIR', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('152', '20170807', '����췢[2017]106��', '1: ABDUL RAHIM 2: BAAYSIR 3: na 4: na ', 'a) Abdul Rahim Bashir; b) Abd Al-Rahim Baasyir; c) Abd Al-Rahim Bashir; d) Abdurrahim Baasyir; e) Abdurrahim Bashir; f) Abdul Rachim Baasyir; g) Abdul Rachim Bashir; h) Abdul Rochim Baasyir; i) Abdul Rochim Bashir; j) Abdurochim Baasyir; k) Abdurochim Bashir; l) Abdurrochim Baasyir; m) Abdurrochim Bashir Bashir; n) Abdurrahman Baasyir; o) Abdurrahman Bashir', '04', 'Abdurochim Baasyir', 'ABDUROCHIM BAASYIR', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('153', '20170807', '����췢[2017]106��', '1: ABDUL RAHIM 2: BAAYSIR 3: na 4: na ', 'a) Abdul Rahim Bashir; b) Abd Al-Rahim Baasyir; c) Abd Al-Rahim Bashir; d) Abdurrahim Baasyir; e) Abdurrahim Bashir; f) Abdul Rachim Baasyir; g) Abdul Rachim Bashir; h) Abdul Rochim Baasyir; i) Abdul Rochim Bashir; j) Abdurochim Baasyir; k) Abdurochim Bashir; l) Abdurrochim Baasyir; m) Abdurrochim Bashir Bashir; n) Abdurrahman Baasyir; o) Abdurrahman Bashir', '04', 'Abdul Rochim Bashir', 'ABDUL ROCHIM BASHIR', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('154', '20170807', '����췢[2017]106��', '1: ABDUL RAHIM 2: BAAYSIR 3: na 4: na ', 'a) Abdul Rahim Bashir; b) Abd Al-Rahim Baasyir; c) Abd Al-Rahim Bashir; d) Abdurrahim Baasyir; e) Abdurrahim Bashir; f) Abdul Rachim Baasyir; g) Abdul Rachim Bashir; h) Abdul Rochim Baasyir; i) Abdul Rochim Bashir; j) Abdurochim Baasyir; k) Abdurochim Bashir; l) Abdurrochim Baasyir; m) Abdurrochim Bashir Bashir; n) Abdurrahman Baasyir; o) Abdurrahman Bashir', '04', 'Abd Al-Rahim Bashir', 'ABD AL-RAHIM BASHIR', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('155', '20170807', '����췢[2017]106��', '1: ABDUL RAHIM 2: BAAYSIR 3: na 4: na ', 'a) Abdul Rahim Bashir; b) Abd Al-Rahim Baasyir; c) Abd Al-Rahim Bashir; d) Abdurrahim Baasyir; e) Abdurrahim Bashir; f) Abdul Rachim Baasyir; g) Abdul Rachim Bashir; h) Abdul Rochim Baasyir; i) Abdul Rochim Bashir; j) Abdurochim Baasyir; k) Abdurochim Bashir; l) Abdurrochim Baasyir; m) Abdurrochim Bashir Bashir; n) Abdurrahman Baasyir; o) Abdurrahman Bashir', '04', 'Abdurrochim Bashir Bashir', 'ABDURROCHIM BASHIR BASHIR', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('156', '20170807', '����췢[2017]106��', '1: ABDUL RAHIM 2: BAAYSIR 3: na 4: na ', 'a) Abdul Rahim Bashir; b) Abd Al-Rahim Baasyir; c) Abd Al-Rahim Bashir; d) Abdurrahim Baasyir; e) Abdurrahim Bashir; f) Abdul Rachim Baasyir; g) Abdul Rachim Bashir; h) Abdul Rochim Baasyir; i) Abdul Rochim Bashir; j) Abdurochim Baasyir; k) Abdurochim Bashir; l) Abdurrochim Baasyir; m) Abdurrochim Bashir Bashir; n) Abdurrahman Baasyir; o) Abdurrahman Bashir', '04', 'Abdul Rachim Baasyir', 'ABDUL RACHIM BAASYIR', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('157', '20170807', '����췢[2017]106��', '1: ABDUL RAHIM 2: BAAYSIR 3: na 4: na ', 'a) Abdul Rahim Bashir; b) Abd Al-Rahim Baasyir; c) Abd Al-Rahim Bashir; d) Abdurrahim Baasyir; e) Abdurrahim Bashir; f) Abdul Rachim Baasyir; g) Abdul Rachim Bashir; h) Abdul Rochim Baasyir; i) Abdul Rochim Bashir; j) Abdurochim Baasyir; k) Abdurochim Bashir; l) Abdurrochim Baasyir; m) Abdurrochim Bashir Bashir; n) Abdurrahman Baasyir; o) Abdurrahman Bashir', '04', 'Abdul Rochim Baasyir', 'ABDUL ROCHIM BAASYIR', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('158', '20170807', '����췢[2017]106��', '1: ABDUL RAHIM 2: BAAYSIR 3: na 4: na ', 'a) Abdul Rahim Bashir; b) Abd Al-Rahim Baasyir; c) Abd Al-Rahim Bashir; d) Abdurrahim Baasyir; e) Abdurrahim Bashir; f) Abdul Rachim Baasyir; g) Abdul Rachim Bashir; h) Abdul Rochim Baasyir; i) Abdul Rochim Bashir; j) Abdurochim Baasyir; k) Abdurochim Bashir; l) Abdurrochim Baasyir; m) Abdurrochim Bashir Bashir; n) Abdurrahman Baasyir; o) Abdurrahman Bashir', '04', 'Abdul Rachim Bashir', 'ABDUL RACHIM BASHIR', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('159', '20170807', '����췢[2017]106��', '1: ABDUL RAHIM 2: BAAYSIR 3: na 4: na ', 'a) Abdul Rahim Bashir; b) Abd Al-Rahim Baasyir; c) Abd Al-Rahim Bashir; d) Abdurrahim Baasyir; e) Abdurrahim Bashir; f) Abdul Rachim Baasyir; g) Abdul Rachim Bashir; h) Abdul Rochim Baasyir; i) Abdul Rochim Bashir; j) Abdurochim Baasyir; k) Abdurochim Bashir; l) Abdurrochim Baasyir; m) Abdurrochim Bashir Bashir; n) Abdurrahman Baasyir; o) Abdurrahman Bashir', '04', 'Abdurrahim Bashir', 'ABDURRAHIM BASHIR', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('160', '20170807', '����췢[2017]106��', '1: ABDUL RAHIM 2: BAAYSIR 3: na 4: na ', 'a) Abdul Rahim Bashir; b) Abd Al-Rahim Baasyir; c) Abd Al-Rahim Bashir; d) Abdurrahim Baasyir; e) Abdurrahim Bashir; f) Abdul Rachim Baasyir; g) Abdul Rachim Bashir; h) Abdul Rochim Baasyir; i) Abdul Rochim Bashir; j) Abdurochim Baasyir; k) Abdurochim Bashir; l) Abdurrochim Baasyir; m) Abdurrochim Bashir Bashir; n) Abdurrahman Baasyir; o) Abdurrahman Bashir', '04', 'Abdurrahim Baasyir', 'ABDURRAHIM BAASYIR', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('161', '20170807', '����췢[2017]106��', '1: ABDUL RAHIM 2: BAAYSIR 3: na 4: na ', 'a) Abdul Rahim Bashir; b) Abd Al-Rahim Baasyir; c) Abd Al-Rahim Bashir; d) Abdurrahim Baasyir; e) Abdurrahim Bashir; f) Abdul Rachim Baasyir; g) Abdul Rachim Bashir; h) Abdul Rochim Baasyir; i) Abdul Rochim Bashir; j) Abdurochim Baasyir; k) Abdurochim Bashir; l) Abdurrochim Baasyir; m) Abdurrochim Bashir Bashir; n) Abdurrahman Baasyir; o) Abdurrahman Bashir', '04', 'Abd Al-Rahim Baasyir', 'ABD AL-RAHIM BAASYIR', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('162', '20170807', '����췢[2017]106��', '1: ABDUL RAHIM 2: BAAYSIR 3: na 4: na ', 'a) Abdul Rahim Bashir; b) Abd Al-Rahim Baasyir; c) Abd Al-Rahim Bashir; d) Abdurrahim Baasyir; e) Abdurrahim Bashir; f) Abdul Rachim Baasyir; g) Abdul Rachim Bashir; h) Abdul Rochim Baasyir; i) Abdul Rochim Bashir; j) Abdurochim Baasyir; k) Abdurochim Bashir; l) Abdurrochim Baasyir; m) Abdurrochim Bashir Bashir; n) Abdurrahman Baasyir; o) Abdurrahman Bashir', '04', 'Abdul Rahim Bashir', 'ABDUL RAHIM BASHIR', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('163', '20170807', '����췢[2017]106��', '1: ABDUL RAHMAN 2: YASIN 3: na 4: na', 'a) Taha, Abdul Rahman S.; b) Taher, Abdul Rahman S.; c) Yasin, Abdul Rahman Said; d) Yasin, Aboud', '02', 'ABDUL RAHMAN YASIN', 'ABDUL RAHMAN YASIN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('164', '20170807', '����췢[2017]106��', '1: ABDUL RAHMAN 2: YASIN 3: na 4: na', 'a) Taha, Abdul Rahman S.; b) Taher, Abdul Rahman S.; c) Yasin, Abdul Rahman Said; d) Yasin, Aboud', '04', 'Yasin, Abdul Rahman Said', 'YASIN, ABDUL RAHMAN SAID', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('165', '20170807', '����췢[2017]106��', '1: ABDUL RAHMAN 2: YASIN 3: na 4: na', 'a) Taha, Abdul Rahman S.; b) Taher, Abdul Rahman S.; c) Yasin, Abdul Rahman Said; d) Yasin, Aboud', '04', 'Taha, Abdul Rahman S.', 'TAHA, ABDUL RAHMAN S.', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('166', '20170807', '����췢[2017]106��', '1: ABDUL RAHMAN 2: YASIN 3: na 4: na', 'a) Taha, Abdul Rahman S.; b) Taher, Abdul Rahman S.; c) Yasin, Abdul Rahman Said; d) Yasin, Aboud', '04', 'Yasin, Aboud', 'YASIN, ABOUD', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('167', '20170807', '����췢[2017]106��', '1: ABDUL RAHMAN 2: YASIN 3: na 4: na', 'a) Taha, Abdul Rahman S.; b) Taher, Abdul Rahman S.; c) Yasin, Abdul Rahman Said; d) Yasin, Aboud', '04', 'Taher, Abdul Rahman S.', 'TAHER, ABDUL RAHMAN S.', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('168', '20170807', '����췢[2017]106��', '1: ABDULLAH 2: AHMED 3: ABDULLAH 4: EL ALFI', null, '02', 'ABDULLAH AHMED', 'ABDULLAH AHMED', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('169', '20170807', '����췢[2017]106��', '1: ABDULLAH 2: ANSHORI 3: na 4: na', 'a) Abu Fatih; b) Thoyib, Ibnu; c) Toyib, Ibnu; d) Abu Fathi', '02', 'ABDULLAH ANSHORI', 'ABDULLAH ANSHORI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('170', '20170807', '����췢[2017]106��', '1: ABDULLAH 2: ANSHORI 3: na 4: na', 'a) Abu Fatih; b) Thoyib, Ibnu; c) Toyib, Ibnu; d) Abu Fathi', '04', 'Abu Fathi', 'ABU FATHI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('171', '20170807', '����췢[2017]106��', '1: ABDULLAH 2: ANSHORI 3: na 4: na', 'a) Abu Fatih; b) Thoyib, Ibnu; c) Toyib, Ibnu; d) Abu Fathi', '04', 'Toyib, Ibnu', 'TOYIB, IBNU', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('172', '20170807', '����췢[2017]106��', '1: ABDULLAH 2: ANSHORI 3: na 4: na', 'a) Abu Fatih; b) Thoyib, Ibnu; c) Toyib, Ibnu; d) Abu Fathi', '04', 'Thoyib, Ibnu', 'THOYIB, IBNU', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('173', '20170807', '����췢[2017]106��', '1: ABDULLAH 2: ANSHORI 3: na 4: na', 'a) Abu Fatih; b) Thoyib, Ibnu; c) Toyib, Ibnu; d) Abu Fathi', '04', 'Abu Fatih', 'ABU FATIH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('174', '20170807', '����췢[2017]106��', '1: ABDUR REHMAN 2: na 3: na 4: na', 'a) Abdul Rehman; Abd Ur-Rehman; Abdur Rahman; b) Abdul Rehman Sindhi; Abdul Rehman al-Sindhi; Abdur Rahman Sindhi; Abdurahman Sindhi; c) Abdullah Sindhi', '02', 'ABDUR REHMAN', 'ABDUR REHMAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('175', '20170807', '����췢[2017]106��', '1: ABDUR REHMAN 2: na 3: na 4: na', 'a) Abdul Rehman; Abd Ur-Rehman; Abdur Rahman; b) Abdul Rehman Sindhi; Abdul Rehman al-Sindhi; Abdur Rahman Sindhi; Abdurahman Sindhi; c) Abdullah Sindhi', '04', 'Abd Ur-Rehman', 'ABD UR-REHMAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('176', '20170807', '����췢[2017]106��', '1: ABDUR REHMAN 2: na 3: na 4: na', 'a) Abdul Rehman; Abd Ur-Rehman; Abdur Rahman; b) Abdul Rehman Sindhi; Abdul Rehman al-Sindhi; Abdur Rahman Sindhi; Abdurahman Sindhi; c) Abdullah Sindhi', '04', 'Abdullah Sindhi', 'ABDULLAH SINDHI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('177', '20170807', '����췢[2017]106��', '1: ABDUR REHMAN 2: na 3: na 4: na', 'a) Abdul Rehman; Abd Ur-Rehman; Abdur Rahman; b) Abdul Rehman Sindhi; Abdul Rehman al-Sindhi; Abdur Rahman Sindhi; Abdurahman Sindhi; c) Abdullah Sindhi', '04', 'Abdul Rehman Sindhi', 'ABDUL REHMAN SINDHI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('178', '20170807', '����췢[2017]106��', '1: ABDUR REHMAN 2: na 3: na 4: na', 'a) Abdul Rehman; Abd Ur-Rehman; Abdur Rahman; b) Abdul Rehman Sindhi; Abdul Rehman al-Sindhi; Abdur Rahman Sindhi; Abdurahman Sindhi; c) Abdullah Sindhi', '04', 'Abdurahman Sindhi', 'ABDURAHMAN SINDHI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('179', '20170807', '����췢[2017]106��', '1: ABDUR REHMAN 2: na 3: na 4: na', 'a) Abdul Rehman; Abd Ur-Rehman; Abdur Rahman; b) Abdul Rehman Sindhi; Abdul Rehman al-Sindhi; Abdur Rahman Sindhi; Abdurahman Sindhi; c) Abdullah Sindhi', '04', 'Abdur Rahman Sindhi', 'ABDUR RAHMAN SINDHI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('180', '20170807', '����췢[2017]106��', '1: ABDUR REHMAN 2: na 3: na 4: na', 'a) Abdul Rehman; Abd Ur-Rehman; Abdur Rahman; b) Abdul Rehman Sindhi; Abdul Rehman al-Sindhi; Abdur Rahman Sindhi; Abdurahman Sindhi; c) Abdullah Sindhi', '04', 'Abdul Rehman al-Sindhi', 'ABDUL REHMAN AL-SINDHI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('181', '20170807', '����췢[2017]106��', '1: ABDUR REHMAN 2: na 3: na 4: na', 'a) Abdul Rehman; Abd Ur-Rehman; Abdur Rahman; b) Abdul Rehman Sindhi; Abdul Rehman al-Sindhi; Abdur Rahman Sindhi; Abdurahman Sindhi; c) Abdullah Sindhi', '04', 'Abdul Rehman', 'ABDUL REHMAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('182', '20170807', '����췢[2017]106��', '1: ABDUR REHMAN 2: na 3: na 4: na', 'a) Abdul Rehman; Abd Ur-Rehman; Abdur Rahman; b) Abdul Rehman Sindhi; Abdul Rehman al-Sindhi; Abdur Rahman Sindhi; Abdurahman Sindhi; c) Abdullah Sindhi', '04', 'Abdur Rahman', 'ABDUR RAHMAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('183', '20170807', '����췢[2017]106��', '1: ABOU 2: MOHAMED 3: AL ADNANI 4:na', 'a) Yaser Khalaf Nazzal Alrawi; b) Jaber Taha Falah; c) Abou Khattab; d) Abou Sadeq Alrawi; e) Tah al Binchi; f) Abu Mohammed al-Adnani; g) Taha Sobhi Falaha; h)Yasser Khalaf Hussein Nazal al-Rawi; i) Abu Baker al-Khatab; j) Abu Sadek al-Rawi; k) Taha al-Banshi; l) Abu Mohamed al-Adnani; m) Abu-Mohammad al-Adnani al-Shami; n) Hajj Ibrahim', '02', 'ABOU MOHAMED', 'ABOU MOHAMED', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('184', '20170807', '����췢[2017]106��', '1: ABOU 2: MOHAMED 3: AL ADNANI 4:na', 'a) Yaser Khalaf Nazzal Alrawi; b) Jaber Taha Falah; c) Abou Khattab; d) Abou Sadeq Alrawi; e) Tah al Binchi; f) Abu Mohammed al-Adnani; g) Taha Sobhi Falaha; h)Yasser Khalaf Hussein Nazal al-Rawi; i) Abu Baker al-Khatab; j) Abu Sadek al-Rawi; k) Taha al-Banshi; l) Abu Mohamed al-Adnani; m) Abu-Mohammad al-Adnani al-Shami; n) Hajj Ibrahim', '04', 'Abou Khattab', 'ABOU KHATTAB', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('185', '20170807', '����췢[2017]106��', '1: ABOU 2: MOHAMED 3: AL ADNANI 4:na', 'a) Yaser Khalaf Nazzal Alrawi; b) Jaber Taha Falah; c) Abou Khattab; d) Abou Sadeq Alrawi; e) Tah al Binchi; f) Abu Mohammed al-Adnani; g) Taha Sobhi Falaha; h)Yasser Khalaf Hussein Nazal al-Rawi; i) Abu Baker al-Khatab; j) Abu Sadek al-Rawi; k) Taha al-Banshi; l) Abu Mohamed al-Adnani; m) Abu-Mohammad al-Adnani al-Shami; n) Hajj Ibrahim', '04', 'Yaser Khalaf Nazzal Alrawi', 'YASER KHALAF NAZZAL ALRAWI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('186', '20170807', '����췢[2017]106��', '1: ABOU 2: MOHAMED 3: AL ADNANI 4:na', 'a) Yaser Khalaf Nazzal Alrawi; b) Jaber Taha Falah; c) Abou Khattab; d) Abou Sadeq Alrawi; e) Tah al Binchi; f) Abu Mohammed al-Adnani; g) Taha Sobhi Falaha; h)Yasser Khalaf Hussein Nazal al-Rawi; i) Abu Baker al-Khatab; j) Abu Sadek al-Rawi; k) Taha al-Banshi; l) Abu Mohamed al-Adnani; m) Abu-Mohammad al-Adnani al-Shami; n) Hajj Ibrahim', '04', 'Abu-Mohammad al-Adnani al-Shami', 'ABU-MOHAMMAD AL-ADNANI AL-SHAMI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('187', '20170807', '����췢[2017]106��', '1: ABOU 2: MOHAMED 3: AL ADNANI 4:na', 'a) Yaser Khalaf Nazzal Alrawi; b) Jaber Taha Falah; c) Abou Khattab; d) Abou Sadeq Alrawi; e) Tah al Binchi; f) Abu Mohammed al-Adnani; g) Taha Sobhi Falaha; h)Yasser Khalaf Hussein Nazal al-Rawi; i) Abu Baker al-Khatab; j) Abu Sadek al-Rawi; k) Taha al-Banshi; l) Abu Mohamed al-Adnani; m) Abu-Mohammad al-Adnani al-Shami; n) Hajj Ibrahim', '04', 'Taha al-Banshi', 'TAHA AL-BANSHI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('188', '20170807', '����췢[2017]106��', '1: ABOU 2: MOHAMED 3: AL ADNANI 4:na', 'a) Yaser Khalaf Nazzal Alrawi; b) Jaber Taha Falah; c) Abou Khattab; d) Abou Sadeq Alrawi; e) Tah al Binchi; f) Abu Mohammed al-Adnani; g) Taha Sobhi Falaha; h)Yasser Khalaf Hussein Nazal al-Rawi; i) Abu Baker al-Khatab; j) Abu Sadek al-Rawi; k) Taha al-Banshi; l) Abu Mohamed al-Adnani; m) Abu-Mohammad al-Adnani al-Shami; n) Hajj Ibrahim', '04', 'Abu Sadek al-Rawi', 'ABU SADEK AL-RAWI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('189', '20170807', '����췢[2017]106��', '1: ABOU 2: MOHAMED 3: AL ADNANI 4:na', 'a) Yaser Khalaf Nazzal Alrawi; b) Jaber Taha Falah; c) Abou Khattab; d) Abou Sadeq Alrawi; e) Tah al Binchi; f) Abu Mohammed al-Adnani; g) Taha Sobhi Falaha; h)Yasser Khalaf Hussein Nazal al-Rawi; i) Abu Baker al-Khatab; j) Abu Sadek al-Rawi; k) Taha al-Banshi; l) Abu Mohamed al-Adnani; m) Abu-Mohammad al-Adnani al-Shami; n) Hajj Ibrahim', '04', 'Abu Baker al-Khatab', 'ABU BAKER AL-KHATAB', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('190', '20170807', '����췢[2017]106��', '1: ABOU 2: MOHAMED 3: AL ADNANI 4:na', 'a) Yaser Khalaf Nazzal Alrawi; b) Jaber Taha Falah; c) Abou Khattab; d) Abou Sadeq Alrawi; e) Tah al Binchi; f) Abu Mohammed al-Adnani; g) Taha Sobhi Falaha; h)Yasser Khalaf Hussein Nazal al-Rawi; i) Abu Baker al-Khatab; j) Abu Sadek al-Rawi; k) Taha al-Banshi; l) Abu Mohamed al-Adnani; m) Abu-Mohammad al-Adnani al-Shami; n) Hajj Ibrahim', '04', 'Yasser Khalaf Hussein Nazal al-Rawi', 'YASSER KHALAF HUSSEIN NAZAL AL-RAWI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('191', '20170807', '����췢[2017]106��', '1: ABOU 2: MOHAMED 3: AL ADNANI 4:na', 'a) Yaser Khalaf Nazzal Alrawi; b) Jaber Taha Falah; c) Abou Khattab; d) Abou Sadeq Alrawi; e) Tah al Binchi; f) Abu Mohammed al-Adnani; g) Taha Sobhi Falaha; h)Yasser Khalaf Hussein Nazal al-Rawi; i) Abu Baker al-Khatab; j) Abu Sadek al-Rawi; k) Taha al-Banshi; l) Abu Mohamed al-Adnani; m) Abu-Mohammad al-Adnani al-Shami; n) Hajj Ibrahim', '04', 'Taha Sobhi Falaha', 'TAHA SOBHI FALAHA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('192', '20170807', '����췢[2017]106��', '1: ABOU 2: MOHAMED 3: AL ADNANI 4:na', 'a) Yaser Khalaf Nazzal Alrawi; b) Jaber Taha Falah; c) Abou Khattab; d) Abou Sadeq Alrawi; e) Tah al Binchi; f) Abu Mohammed al-Adnani; g) Taha Sobhi Falaha; h)Yasser Khalaf Hussein Nazal al-Rawi; i) Abu Baker al-Khatab; j) Abu Sadek al-Rawi; k) Taha al-Banshi; l) Abu Mohamed al-Adnani; m) Abu-Mohammad al-Adnani al-Shami; n) Hajj Ibrahim', '04', 'Abu Mohammed al-Adnani', 'ABU MOHAMMED AL-ADNANI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('193', '20170807', '����췢[2017]106��', '1: ABOU 2: MOHAMED 3: AL ADNANI 4:na', 'a) Yaser Khalaf Nazzal Alrawi; b) Jaber Taha Falah; c) Abou Khattab; d) Abou Sadeq Alrawi; e) Tah al Binchi; f) Abu Mohammed al-Adnani; g) Taha Sobhi Falaha; h)Yasser Khalaf Hussein Nazal al-Rawi; i) Abu Baker al-Khatab; j) Abu Sadek al-Rawi; k) Taha al-Banshi; l) Abu Mohamed al-Adnani; m) Abu-Mohammad al-Adnani al-Shami; n) Hajj Ibrahim', '04', 'Tah al Binchi', 'TAH AL BINCHI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('194', '20170807', '����췢[2017]106��', '1: ABOU 2: MOHAMED 3: AL ADNANI 4:na', 'a) Yaser Khalaf Nazzal Alrawi; b) Jaber Taha Falah; c) Abou Khattab; d) Abou Sadeq Alrawi; e) Tah al Binchi; f) Abu Mohammed al-Adnani; g) Taha Sobhi Falaha; h)Yasser Khalaf Hussein Nazal al-Rawi; i) Abu Baker al-Khatab; j) Abu Sadek al-Rawi; k) Taha al-Banshi; l) Abu Mohamed al-Adnani; m) Abu-Mohammad al-Adnani al-Shami; n) Hajj Ibrahim', '04', 'Jaber Taha Falah', 'JABER TAHA FALAH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('195', '20170807', '����췢[2017]106��', '1: ABOU 2: MOHAMED 3: AL ADNANI 4:na', 'a) Yaser Khalaf Nazzal Alrawi; b) Jaber Taha Falah; c) Abou Khattab; d) Abou Sadeq Alrawi; e) Tah al Binchi; f) Abu Mohammed al-Adnani; g) Taha Sobhi Falaha; h)Yasser Khalaf Hussein Nazal al-Rawi; i) Abu Baker al-Khatab; j) Abu Sadek al-Rawi; k) Taha al-Banshi; l) Abu Mohamed al-Adnani; m) Abu-Mohammad al-Adnani al-Shami; n) Hajj Ibrahim', '04', 'Abou Sadeq Alrawi', 'ABOU SADEQ ALRAWI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('196', '20170807', '����췢[2017]106��', '1: ABOU 2: MOHAMED 3: AL ADNANI 4:na', 'a) Yaser Khalaf Nazzal Alrawi; b) Jaber Taha Falah; c) Abou Khattab; d) Abou Sadeq Alrawi; e) Tah al Binchi; f) Abu Mohammed al-Adnani; g) Taha Sobhi Falaha; h)Yasser Khalaf Hussein Nazal al-Rawi; i) Abu Baker al-Khatab; j) Abu Sadek al-Rawi; k) Taha al-Banshi; l) Abu Mohamed al-Adnani; m) Abu-Mohammad al-Adnani al-Shami; n) Hajj Ibrahim', '04', 'Abu Mohamed al-Adnani', 'ABU MOHAMED AL-ADNANI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('197', '20170807', '����췢[2017]106��', '1: ABOU 2: MOHAMED 3: AL ADNANI 4:na', 'a) Yaser Khalaf Nazzal Alrawi; b) Jaber Taha Falah; c) Abou Khattab; d) Abou Sadeq Alrawi; e) Tah al Binchi; f) Abu Mohammed al-Adnani; g) Taha Sobhi Falaha; h)Yasser Khalaf Hussein Nazal al-Rawi; i) Abu Baker al-Khatab; j) Abu Sadek al-Rawi; k) Taha al-Banshi; l) Abu Mohamed al-Adnani; m) Abu-Mohammad al-Adnani al-Shami; n) Hajj Ibrahim', '04', 'Hajj Ibrahim', 'HAJJ IBRAHIM', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('198', '20170807', '����췢[2017]106��', '1: ABU 2: RUSDAN 3: na 4: na', null, '02', 'ABU RUSDAN', 'ABU RUSDAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('199', '20170807', '����췢[2017]106��', '1: ABU BAKAR 2: BAASYIR 3: na 4: na', 'a) Abu Bakar Baasyir born 17 Aug. 1938 in Jombang. East Java, Indonesia; b) Abu Bakar Bashir born 17 Aug. 1938 in Jombang. East Java, Indonesia; c) Abdus Samad; d) Abdus Somad', '02', 'ABU BAKAR BAASYIR', 'ABU BAKAR BAASYIR', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('200', '20170807', '����췢[2017]106��', '1: ABU BAKAR 2: BAASYIR 3: na 4: na', 'a) Abu Bakar Baasyir born 17 Aug. 1938 in Jombang. East Java, Indonesia; b) Abu Bakar Bashir born 17 Aug. 1938 in Jombang. East Java, Indonesia; c) Abdus Samad; d) Abdus Somad', '04', 'Abdus Somad', 'ABDUS SOMAD', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('201', '20170807', '����췢[2017]106��', '1: ABU BAKAR 2: BAASYIR 3: na 4: na', 'a) Abu Bakar Baasyir born 17 Aug. 1938 in Jombang. East Java, Indonesia; b) Abu Bakar Bashir born 17 Aug. 1938 in Jombang. East Java, Indonesia; c) Abdus Samad; d) Abdus Somad', '04', 'Abdus Samad', 'ABDUS SAMAD', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('202', '20170807', '����췢[2017]106��', '1: ABU BAKAR 2: BAASYIR 3: na 4: na', 'a) Abu Bakar Baasyir born 17 Aug. 1938 in Jombang. East Java, Indonesia; b) Abu Bakar Bashir born 17 Aug. 1938 in Jombang. East Java, Indonesia; c) Abdus Samad; d) Abdus Somad', '04', 'Abu Bakar Bashir', 'ABU BAKAR BASHIR', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('203', '20170807', '����췢[2017]106��', '1: ABU BAKAR 2: BAASYIR 3: na 4: na', 'a) Abu Bakar Baasyir born 17 Aug. 1938 in Jombang. East Java, Indonesia; b) Abu Bakar Bashir born 17 Aug. 1938 in Jombang. East Java, Indonesia; c) Abdus Samad; d) Abdus Somad', '04', 'Abu Bakar Baasyir', 'ABU BAKAR BAASYIR', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('204', '20170807', '����췢[2017]106��', '1: ABU BAKR 2: AL-JAZIRI 3: na 4: na ', 'a) Yasir Al-Jazari', '02', 'ABU BAKR AL-JAZIRI', 'ABU BAKR AL-JAZIRI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('205', '20170807', '����췢[2017]106��', '1: ABU BAKR 2: AL-JAZIRI 3: na 4: na ', 'a) Yasir Al-Jazari', '03', 'Yasir Al-Jazari', 'YASIR AL-JAZARI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('206', '20170807', '����췢[2017]106��', '1: ABU MOHAMMED 2: AL-JAWLANI 3: na 4: na', 'a) Abu Mohamed al-Jawiani (Abu Muhammad al-Jawlani, Abu Mohammed al-Julani, Abu Mohammed al-Golani, Abu Muhammad al-Golani, Abu Muhammad Aljawlani, Muhammad al-Jawiani ( transliterations of original script name)); b) Amjad Muzaffar Hussein Ali al-Naimi born 1980 in Syrian Arab Republic (Mother''s name: Fatma Ali Majour. Address: Mosul, Souq al-Nabi Yunis)', '02', 'ABU MOHAMMED', 'ABU MOHAMMED', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('207', '20170807', '����췢[2017]106��', '1: ABU MOHAMMED 2: AL-JAWLANI 3: na 4: na', 'a) Abu Mohamed al-Jawiani (Abu Muhammad al-Jawlani, Abu Mohammed al-Julani, Abu Mohammed al-Golani, Abu Muhammad al-Golani, Abu Muhammad Aljawlani, Muhammad al-Jawiani ( transliterations of original script name)); b) Amjad Muzaffar Hussein Ali al-Naimi born 1980 in Syrian Arab Republic (Mother''s name: Fatma Ali Majour. Address: Mosul, Souq al-Nabi Yunis)', '04', 'Abu Mohamed al-Jawiani (Abu Muhammad al-Jawlani, Abu Mohammed al-Julani, Abu Mohammed al-Golani, Abu Muhammad al-Golani, Abu Muhammad Aljawlani, Muhammad al-Jawiani ( transliterations of original script name))', 'ABU MOHAMED AL-JAWIANI (ABU MUHAMMAD AL-JAWLANI, ABU MOHAMMED AL-JULANI, ABU MOHAMMED AL-GOLANI, ABU MUHAMMAD AL-GOLANI, ABU MUHAMMAD ALJAWLANI, MUHAMMAD AL-JAWIANI ( TRANSLITERATIONS OF ORIGINAL SCRIPT NAME))', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('208', '20170807', '����췢[2017]106��', '1: ABU MOHAMMED 2: AL-JAWLANI 3: na 4: na', 'a) Abu Mohamed al-Jawiani (Abu Muhammad al-Jawlani, Abu Mohammed al-Julani, Abu Mohammed al-Golani, Abu Muhammad al-Golani, Abu Muhammad Aljawlani, Muhammad al-Jawiani ( transliterations of original script name)); b) Amjad Muzaffar Hussein Ali al-Naimi born 1980 in Syrian Arab Republic (Mother''s name: Fatma Ali Majour. Address: Mosul, Souq al-Nabi Yunis)', '04', 'Abu Mohamed al-Jawiani', 'ABU MOHAMED AL-JAWIANI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('209', '20170807', '����췢[2017]106��', '1: ABU MOHAMMED 2: AL-JAWLANI 3: na 4: na', 'a) Abu Mohamed al-Jawiani (Abu Muhammad al-Jawlani, Abu Mohammed al-Julani, Abu Mohammed al-Golani, Abu Muhammad al-Golani, Abu Muhammad Aljawlani, Muhammad al-Jawiani ( transliterations of original script name)); b) Amjad Muzaffar Hussein Ali al-Naimi born 1980 in Syrian Arab Republic (Mother''s name: Fatma Ali Majour. Address: Mosul, Souq al-Nabi Yunis)', '04', 'Abu Muhammad al-Jawlani', 'ABU MUHAMMAD AL-JAWLANI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('210', '20170807', '����췢[2017]106��', '1: ABU MOHAMMED 2: AL-JAWLANI 3: na 4: na', 'a) Abu Mohamed al-Jawiani (Abu Muhammad al-Jawlani, Abu Mohammed al-Julani, Abu Mohammed al-Golani, Abu Muhammad al-Golani, Abu Muhammad Aljawlani, Muhammad al-Jawiani ( transliterations of original script name)); b) Amjad Muzaffar Hussein Ali al-Naimi born 1980 in Syrian Arab Republic (Mother''s name: Fatma Ali Majour. Address: Mosul, Souq al-Nabi Yunis)', '04', 'Abu Mohammed al-Julani', 'ABU MOHAMMED AL-JULANI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('211', '20170807', '����췢[2017]106��', '1: ABU MOHAMMED 2: AL-JAWLANI 3: na 4: na', 'a) Abu Mohamed al-Jawiani (Abu Muhammad al-Jawlani, Abu Mohammed al-Julani, Abu Mohammed al-Golani, Abu Muhammad al-Golani, Abu Muhammad Aljawlani, Muhammad al-Jawiani ( transliterations of original script name)); b) Amjad Muzaffar Hussein Ali al-Naimi born 1980 in Syrian Arab Republic (Mother''s name: Fatma Ali Majour. Address: Mosul, Souq al-Nabi Yunis)', '04', 'Abu Mohammed al-Golani', 'ABU MOHAMMED AL-GOLANI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('212', '20170807', '����췢[2017]106��', '1: ABU MOHAMMED 2: AL-JAWLANI 3: na 4: na', 'a) Abu Mohamed al-Jawiani (Abu Muhammad al-Jawlani, Abu Mohammed al-Julani, Abu Mohammed al-Golani, Abu Muhammad al-Golani, Abu Muhammad Aljawlani, Muhammad al-Jawiani ( transliterations of original script name)); b) Amjad Muzaffar Hussein Ali al-Naimi born 1980 in Syrian Arab Republic (Mother''s name: Fatma Ali Majour. Address: Mosul, Souq al-Nabi Yunis)', '04', 'Abu Muhammad al-Golani', 'ABU MUHAMMAD AL-GOLANI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('213', '20170807', '����췢[2017]106��', '1: ABU MOHAMMED 2: AL-JAWLANI 3: na 4: na', 'a) Abu Mohamed al-Jawiani (Abu Muhammad al-Jawlani, Abu Mohammed al-Julani, Abu Mohammed al-Golani, Abu Muhammad al-Golani, Abu Muhammad Aljawlani, Muhammad al-Jawiani ( transliterations of original script name)); b) Amjad Muzaffar Hussein Ali al-Naimi born 1980 in Syrian Arab Republic (Mother''s name: Fatma Ali Majour. Address: Mosul, Souq al-Nabi Yunis)', '04', 'Abu Muhammad Aljawlani, Muhammad al-Jawiani', 'ABU MUHAMMAD ALJAWLANI, MUHAMMAD AL-JAWIANI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('214', '20170807', '����췢[2017]106��', '1: ABU MOHAMMED 2: AL-JAWLANI 3: na 4: na', 'a) Abu Mohamed al-Jawiani (Abu Muhammad al-Jawlani, Abu Mohammed al-Julani, Abu Mohammed al-Golani, Abu Muhammad al-Golani, Abu Muhammad Aljawlani, Muhammad al-Jawiani ( transliterations of original script name)); b) Amjad Muzaffar Hussein Ali al-Naimi born 1980 in Syrian Arab Republic (Mother''s name: Fatma Ali Majour. Address: Mosul, Souq al-Nabi Yunis)', '04', 'Abu Muhammad Aljawlani', 'ABU MUHAMMAD ALJAWLANI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('215', '20170807', '����췢[2017]106��', '1: ABU MOHAMMED 2: AL-JAWLANI 3: na 4: na', 'a) Abu Mohamed al-Jawiani (Abu Muhammad al-Jawlani, Abu Mohammed al-Julani, Abu Mohammed al-Golani, Abu Muhammad al-Golani, Abu Muhammad Aljawlani, Muhammad al-Jawiani ( transliterations of original script name)); b) Amjad Muzaffar Hussein Ali al-Naimi born 1980 in Syrian Arab Republic (Mother''s name: Fatma Ali Majour. Address: Mosul, Souq al-Nabi Yunis)', '04', 'Muhammad al-Jawiani', 'MUHAMMAD AL-JAWIANI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('216', '20170807', '����췢[2017]106��', '1: ABU MOHAMMED 2: AL-JAWLANI 3: na 4: na', 'a) Abu Mohamed al-Jawiani (Abu Muhammad al-Jawlani, Abu Mohammed al-Julani, Abu Mohammed al-Golani, Abu Muhammad al-Golani, Abu Muhammad Aljawlani, Muhammad al-Jawiani ( transliterations of original script name)); b) Amjad Muzaffar Hussein Ali al-Naimi born 1980 in Syrian Arab Republic (Mother''s name: Fatma Ali Majour. Address: Mosul, Souq al-Nabi Yunis)', '04', 'Fatma Ali Majour', 'FATMA ALI MAJOUR', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('217', '20170807', '����췢[2017]106��', '1: ABU MOHAMMED 2: AL-JAWLANI 3: na 4: na', 'a) Abu Mohamed al-Jawiani (Abu Muhammad al-Jawlani, Abu Mohammed al-Julani, Abu Mohammed al-Golani, Abu Muhammad al-Golani, Abu Muhammad Aljawlani, Muhammad al-Jawiani ( transliterations of original script name)); b) Amjad Muzaffar Hussein Ali al-Naimi born 1980 in Syrian Arab Republic (Mother''s name: Fatma Ali Majour. Address: Mosul, Souq al-Nabi Yunis)', '04', 'Muhammad al-Jawiani', 'MUHAMMAD AL-JAWIANI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('218', '20170807', '����췢[2017]106��', '1: ABU MOHAMMED 2: AL-JAWLANI 3: na 4: na', 'a) Abu Mohamed al-Jawiani (Abu Muhammad al-Jawlani, Abu Mohammed al-Julani, Abu Mohammed al-Golani, Abu Muhammad al-Golani, Abu Muhammad Aljawlani, Muhammad al-Jawiani ( transliterations of original script name)); b) Amjad Muzaffar Hussein Ali al-Naimi born 1980 in Syrian Arab Republic (Mother''s name: Fatma Ali Majour. Address: Mosul, Souq al-Nabi Yunis)', '04', 'Amjad Muzaffar Hussein Ali al-Naimi', 'AMJAD MUZAFFAR HUSSEIN ALI AL-NAIMI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('219', '20170807', '����췢[2017]106��', '1: ABU UBAYDAH 2: YUSUF 3: AL-ANABI 4: na', 'a) Abou Obeida Youssef Al-Annabi; b) Abu-Ubaydah Yusuf Al-lnabi', '02', 'ABU UBAYDAH YUSUF', 'ABU UBAYDAH YUSUF', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('220', '20170807', '����췢[2017]106��', '1: ABU UBAYDAH 2: YUSUF 3: AL-ANABI 4: na', 'a) Abou Obeida Youssef Al-Annabi; b) Abu-Ubaydah Yusuf Al-lnabi', '04', 'Abu-Ubaydah Yusuf Al-lnabi', 'ABU-UBAYDAH YUSUF AL-LNABI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('221', '20170807', '����췢[2017]106��', '1: ABU UBAYDAH 2: YUSUF 3: AL-ANABI 4: na', 'a) Abou Obeida Youssef Al-Annabi; b) Abu-Ubaydah Yusuf Al-lnabi', '04', 'Abou Obeida Youssef Al-Annabi', 'ABOU OBEIDA YOUSSEF AL-ANNABI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('222', '20170807', '����췢[2017]106��', '1: ABUBAKAR 2: MOHAMMED 3: SHEKAU 4: na', 'a) Abubakar Shekau', '02', 'ABUBAKAR MOHAMMED', 'ABUBAKAR MOHAMMED', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('223', '20170807', '����췢[2017]106��', '1: ABUBAKAR 2: MOHAMMED 3: SHEKAU 4: na', 'a) Abubakar Shekau', '03', 'Abubakar Shekau', 'ABUBAKAR SHEKAU', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('224', '20170807', '����췢[2017]106��', '1: ADEL 2: BEN AL-AZHAR 3: BEN YOUSSEF 4: HAMDI', 'a) Adel ben al-Azhar ben Youssef ben Soltane born 14 Jul. 1970 in Tunis, Tunisia', '02', 'ADEL BEN AL-AZHAR', 'ADEL BEN AL-AZHAR', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('225', '20170807', '����췢[2017]106��', '1: ADEL 2: BEN AL-AZHAR 3: BEN YOUSSEF 4: HAMDI', 'a) Adel ben al-Azhar ben Youssef ben Soltane born 14 Jul. 1970 in Tunis, Tunisia', '03', 'Adel ben al-Azhar ben Youssef ben Soltane born 14 Jul. 1970 in Tunis, Tunisia', 'ADEL BEN AL-AZHAR BEN YOUSSEF BEN SOLTANE BORN 14 JUL. 1970 IN TUNIS, TUNISIA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('226', '20170807', '����췢[2017]106��', '1: ADEM 2: YILMAZ 3: na 4: na', null, '02', 'ADEM YILMAZ', 'ADEM YILMAZ', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('227', '20170807', '����췢[2017]106��', '1: ADIL 2: MUHAMMAD 3: MAHMUD 4: ABD AL-KHALIQ', 'a) Adel Mohamed Mahmoud Abdul Khaliq; b) Adel Mohamed Mahmood Abdul Khaled', '02', 'ADIL MUHAMMAD', 'ADIL MUHAMMAD', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('228', '20170807', '����췢[2017]106��', '1: ADIL 2: MUHAMMAD 3: MAHMUD 4: ABD AL-KHALIQ', 'a) Adel Mohamed Mahmoud Abdul Khaliq; b) Adel Mohamed Mahmood Abdul Khaled', '04', 'Adel Mohamed Mahmoud Abdul Khaliq', 'ADEL MOHAMED MAHMOUD ABDUL KHALIQ', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('229', '20170807', '����췢[2017]106��', '1: ADIL 2: MUHAMMAD 3: MAHMUD 4: ABD AL-KHALIQ', 'a) Adel Mohamed Mahmoud Abdul Khaliq; b) Adel Mohamed Mahmood Abdul Khaled', '04', 'Adel Mohamed Mahmood Abdul Khaled', 'ADEL MOHAMED MAHMOOD ABDUL KHALED', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('230', '20170807', '����췢[2017]106��', '1: AGUS 2: DWIKARNA 3: na 4: na', null, '02', 'AGUS DWIKARNA', 'AGUS DWIKARNA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('231', '20170807', '����췢[2017]106��', '1: AHMAD 2: ZERFAOUI 3: na 4: na', 'a) Abdullah; b) Abdalla; c) Smail; d) Abu Khaoula; e) Abu Cholder; f) Nuhr', '02', 'AHMAD ZERFAOUI', 'AHMAD ZERFAOUI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('232', '20170807', '����췢[2017]106��', '1: AHMAD 2: ZERFAOUI 3: na 4: na', 'a) Abdullah; b) Abdalla; c) Smail; d) Abu Khaoula; e) Abu Cholder; f) Nuhr', '04', 'Abdullah', 'ABDULLAH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('233', '20170807', '����췢[2017]106��', '1: AHMAD 2: ZERFAOUI 3: na 4: na', 'a) Abdullah; b) Abdalla; c) Smail; d) Abu Khaoula; e) Abu Cholder; f) Nuhr', '04', 'Nuhr', 'NUHR', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('234', '20170807', '����췢[2017]106��', '1: AHMAD 2: ZERFAOUI 3: na 4: na', 'a) Abdullah; b) Abdalla; c) Smail; d) Abu Khaoula; e) Abu Cholder; f) Nuhr', '04', 'Abdalla', 'ABDALLA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('235', '20170807', '����췢[2017]106��', '1: AHMAD 2: ZERFAOUI 3: na 4: na', 'a) Abdullah; b) Abdalla; c) Smail; d) Abu Khaoula; e) Abu Cholder; f) Nuhr', '04', 'Smail', 'SMAIL', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('236', '20170807', '����췢[2017]106��', '1: AHMAD 2: ZERFAOUI 3: na 4: na', 'a) Abdullah; b) Abdalla; c) Smail; d) Abu Khaoula; e) Abu Cholder; f) Nuhr', '04', 'Abu Khaoula', 'ABU KHAOULA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('237', '20170807', '����췢[2017]106��', '1: AHMAD 2: ZERFAOUI 3: na 4: na', 'a) Abdullah; b) Abdalla; c) Smail; d) Abu Khaoula; e) Abu Cholder; f) Nuhr', '04', 'Abu Cholder', 'ABU CHOLDER', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('238', '20170807', '����췢[2017]106��', '1: AHMED 2: ABDULLAH 3: SALEH AL-KHAZMARI 4: AL-ZAHRANI', 'a) Abu Maryam al-Zahrani; b) Abu Maryam al-Saudi; c) Ahmed Abdullah S al-Zahrani; d) Ahmad Abdullah Salih al-Zahrani; e) Abu Maryam al-Azadi; f) Ahmed bin Abdullah Saleh bin al-Zahrani; g) Ahmed Abdullah Saleh al-Zahrani al-Khozmri', '02', 'AHMED ABDULLAH', 'AHMED ABDULLAH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('239', '20170807', '����췢[2017]106��', '1: AHMED 2: ABDULLAH 3: SALEH AL-KHAZMARI 4: AL-ZAHRANI', 'a) Abu Maryam al-Zahrani; b) Abu Maryam al-Saudi; c) Ahmed Abdullah S al-Zahrani; d) Ahmad Abdullah Salih al-Zahrani; e) Abu Maryam al-Azadi; f) Ahmed bin Abdullah Saleh bin al-Zahrani; g) Ahmed Abdullah Saleh al-Zahrani al-Khozmri', '04', 'Abu Maryam al-Zahrani', 'ABU MARYAM AL-ZAHRANI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('240', '20170807', '����췢[2017]106��', '1: AHMED 2: ABDULLAH 3: SALEH AL-KHAZMARI 4: AL-ZAHRANI', 'a) Abu Maryam al-Zahrani; b) Abu Maryam al-Saudi; c) Ahmed Abdullah S al-Zahrani; d) Ahmad Abdullah Salih al-Zahrani; e) Abu Maryam al-Azadi; f) Ahmed bin Abdullah Saleh bin al-Zahrani; g) Ahmed Abdullah Saleh al-Zahrani al-Khozmri', '04', 'Ahmed Abdullah S al-Zahrani', 'AHMED ABDULLAH S AL-ZAHRANI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('241', '20170807', '����췢[2017]106��', '1: AHMED 2: ABDULLAH 3: SALEH AL-KHAZMARI 4: AL-ZAHRANI', 'a) Abu Maryam al-Zahrani; b) Abu Maryam al-Saudi; c) Ahmed Abdullah S al-Zahrani; d) Ahmad Abdullah Salih al-Zahrani; e) Abu Maryam al-Azadi; f) Ahmed bin Abdullah Saleh bin al-Zahrani; g) Ahmed Abdullah Saleh al-Zahrani al-Khozmri', '04', 'Ahmad Abdullah Salih al-Zahrani', 'AHMAD ABDULLAH SALIH AL-ZAHRANI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('242', '20170807', '����췢[2017]106��', '1: AHMED 2: ABDULLAH 3: SALEH AL-KHAZMARI 4: AL-ZAHRANI', 'a) Abu Maryam al-Zahrani; b) Abu Maryam al-Saudi; c) Ahmed Abdullah S al-Zahrani; d) Ahmad Abdullah Salih al-Zahrani; e) Abu Maryam al-Azadi; f) Ahmed bin Abdullah Saleh bin al-Zahrani; g) Ahmed Abdullah Saleh al-Zahrani al-Khozmri', '04', 'Abu Maryam al-Azadi', 'ABU MARYAM AL-AZADI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('243', '20170807', '����췢[2017]106��', '1: AHMED 2: ABDULLAH 3: SALEH AL-KHAZMARI 4: AL-ZAHRANI', 'a) Abu Maryam al-Zahrani; b) Abu Maryam al-Saudi; c) Ahmed Abdullah S al-Zahrani; d) Ahmad Abdullah Salih al-Zahrani; e) Abu Maryam al-Azadi; f) Ahmed bin Abdullah Saleh bin al-Zahrani; g) Ahmed Abdullah Saleh al-Zahrani al-Khozmri', '04', 'Ahmed bin Abdullah Saleh bin al-Zahrani', 'AHMED BIN ABDULLAH SALEH BIN AL-ZAHRANI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('244', '20170807', '����췢[2017]106��', '1: AHMED 2: ABDULLAH 3: SALEH AL-KHAZMARI 4: AL-ZAHRANI', 'a) Abu Maryam al-Zahrani; b) Abu Maryam al-Saudi; c) Ahmed Abdullah S al-Zahrani; d) Ahmad Abdullah Salih al-Zahrani; e) Abu Maryam al-Azadi; f) Ahmed bin Abdullah Saleh bin al-Zahrani; g) Ahmed Abdullah Saleh al-Zahrani al-Khozmri', '04', 'Ahmed Abdullah Saleh al-Zahrani al-Khozmri', 'AHMED ABDULLAH SALEH AL-ZAHRANI AL-KHOZMRI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('245', '20170807', '����췢[2017]106��', '1: AHMED 2: ABDULLAH 3: SALEH AL-KHAZMARI 4: AL-ZAHRANI', 'a) Abu Maryam al-Zahrani; b) Abu Maryam al-Saudi; c) Ahmed Abdullah S al-Zahrani; d) Ahmad Abdullah Salih al-Zahrani; e) Abu Maryam al-Azadi; f) Ahmed bin Abdullah Saleh bin al-Zahrani; g) Ahmed Abdullah Saleh al-Zahrani al-Khozmri', '04', 'Abu Maryam al-Saudi', 'ABU MARYAM AL-SAUDI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('246', '20170807', '����췢[2017]106��', '1: AHMED 2: DEGHDEGH 3: na 4: na', 'a) Abd El Illah; b) Abdellillah dit Abdellah Ahmed dit Said ', '02', 'AHMED DEGHDEGH', 'AHMED DEGHDEGH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('247', '20170807', '����췢[2017]106��', '1: AHMED 2: DEGHDEGH 3: na 4: na', 'a) Abd El Illah; b) Abdellillah dit Abdellah Ahmed dit Said ', '04', 'Abdellillah dit Abdellah Ahmed dit Said', 'ABDELLILLAH DIT ABDELLAH AHMED DIT SAID', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('248', '20170807', '����췢[2017]106��', '1: AHMED 2: DEGHDEGH 3: na 4: na', 'a) Abd El Illah; b) Abdellillah dit Abdellah Ahmed dit Said ', '04', 'Abd El Illah', 'ABD EL ILLAH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('249', '20170807', '����췢[2017]106��', '1: AHMED 2: KHALFAN 3: GHAILANI 4: na', 'a) Ahmad, Abu Bakr; b) Ahmed, Abubakar; c) Ahmed, Abubakar K.; d) Ahmed, Abubakar Khalfan; e) Ahmed, Abubakary K. f) Ahmed, Ahmed Khalfan; g) Ali, Ahmed Khalfan; h) Ghailani, Abubakary Khalfan Ahmed; i) Ghailani, Ahmed; j) Ghilani, Ahmad Khalafan; k) Hussein, Mahafudh Abubakar Ahmed Abdallah; l) Khaifan, Ahmed; m) Mohammed, Shariff Omar; n) Haythem al-Kini', '02', 'AHMED KHALFAN', 'AHMED KHALFAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('250', '20170807', '����췢[2017]106��', '1: AHMED 2: KHALFAN 3: GHAILANI 4: na', 'a) Ahmad, Abu Bakr; b) Ahmed, Abubakar; c) Ahmed, Abubakar K.; d) Ahmed, Abubakar Khalfan; e) Ahmed, Abubakary K. f) Ahmed, Ahmed Khalfan; g) Ali, Ahmed Khalfan; h) Ghailani, Abubakary Khalfan Ahmed; i) Ghailani, Ahmed; j) Ghilani, Ahmad Khalafan; k) Hussein, Mahafudh Abubakar Ahmed Abdallah; l) Khaifan, Ahmed; m) Mohammed, Shariff Omar; n) Haythem al-Kini', '04', 'Ahmad, Abu Bakr', 'AHMAD, ABU BAKR', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('251', '20170807', '����췢[2017]106��', '1: AHMED 2: KHALFAN 3: GHAILANI 4: na', 'a) Ahmad, Abu Bakr; b) Ahmed, Abubakar; c) Ahmed, Abubakar K.; d) Ahmed, Abubakar Khalfan; e) Ahmed, Abubakary K. f) Ahmed, Ahmed Khalfan; g) Ali, Ahmed Khalfan; h) Ghailani, Abubakary Khalfan Ahmed; i) Ghailani, Ahmed; j) Ghilani, Ahmad Khalafan; k) Hussein, Mahafudh Abubakar Ahmed Abdallah; l) Khaifan, Ahmed; m) Mohammed, Shariff Omar; n) Haythem al-Kini', '04', 'Ahmad', 'AHMAD', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('252', '20170807', '����췢[2017]106��', '1: AHMED 2: KHALFAN 3: GHAILANI 4: na', 'a) Ahmad, Abu Bakr; b) Ahmed, Abubakar; c) Ahmed, Abubakar K.; d) Ahmed, Abubakar Khalfan; e) Ahmed, Abubakary K. f) Ahmed, Ahmed Khalfan; g) Ali, Ahmed Khalfan; h) Ghailani, Abubakary Khalfan Ahmed; i) Ghailani, Ahmed; j) Ghilani, Ahmad Khalafan; k) Hussein, Mahafudh Abubakar Ahmed Abdallah; l) Khaifan, Ahmed; m) Mohammed, Shariff Omar; n) Haythem al-Kini', '04', 'Abu Bakr', 'ABU BAKR', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('253', '20170807', '����췢[2017]106��', '1: AHMED 2: KHALFAN 3: GHAILANI 4: na', 'a) Ahmad, Abu Bakr; b) Ahmed, Abubakar; c) Ahmed, Abubakar K.; d) Ahmed, Abubakar Khalfan; e) Ahmed, Abubakary K. f) Ahmed, Ahmed Khalfan; g) Ali, Ahmed Khalfan; h) Ghailani, Abubakary Khalfan Ahmed; i) Ghailani, Ahmed; j) Ghilani, Ahmad Khalafan; k) Hussein, Mahafudh Abubakar Ahmed Abdallah; l) Khaifan, Ahmed; m) Mohammed, Shariff Omar; n) Haythem al-Kini', '04', 'Ahmed, Abubakar', 'AHMED, ABUBAKAR', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('254', '20170807', '����췢[2017]106��', '1: AHMED 2: KHALFAN 3: GHAILANI 4: na', 'a) Ahmad, Abu Bakr; b) Ahmed, Abubakar; c) Ahmed, Abubakar K.; d) Ahmed, Abubakar Khalfan; e) Ahmed, Abubakary K. f) Ahmed, Ahmed Khalfan; g) Ali, Ahmed Khalfan; h) Ghailani, Abubakary Khalfan Ahmed; i) Ghailani, Ahmed; j) Ghilani, Ahmad Khalafan; k) Hussein, Mahafudh Abubakar Ahmed Abdallah; l) Khaifan, Ahmed; m) Mohammed, Shariff Omar; n) Haythem al-Kini', '04', 'Ahmed', 'AHMED', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('255', '20170807', '����췢[2017]106��', '1: AHMED 2: KHALFAN 3: GHAILANI 4: na', 'a) Ahmad, Abu Bakr; b) Ahmed, Abubakar; c) Ahmed, Abubakar K.; d) Ahmed, Abubakar Khalfan; e) Ahmed, Abubakary K. f) Ahmed, Ahmed Khalfan; g) Ali, Ahmed Khalfan; h) Ghailani, Abubakary Khalfan Ahmed; i) Ghailani, Ahmed; j) Ghilani, Ahmad Khalafan; k) Hussein, Mahafudh Abubakar Ahmed Abdallah; l) Khaifan, Ahmed; m) Mohammed, Shariff Omar; n) Haythem al-Kini', '04', 'Abubakar', 'ABUBAKAR', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('256', '20170807', '����췢[2017]106��', '1: AHMED 2: KHALFAN 3: GHAILANI 4: na', 'a) Ahmad, Abu Bakr; b) Ahmed, Abubakar; c) Ahmed, Abubakar K.; d) Ahmed, Abubakar Khalfan; e) Ahmed, Abubakary K. f) Ahmed, Ahmed Khalfan; g) Ali, Ahmed Khalfan; h) Ghailani, Abubakary Khalfan Ahmed; i) Ghailani, Ahmed; j) Ghilani, Ahmad Khalafan; k) Hussein, Mahafudh Abubakar Ahmed Abdallah; l) Khaifan, Ahmed; m) Mohammed, Shariff Omar; n) Haythem al-Kini', '04', 'Ahmed, Abubakar Khalfan', 'AHMED, ABUBAKAR KHALFAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('257', '20170807', '����췢[2017]106��', '1: AHMED 2: KHALFAN 3: GHAILANI 4: na', 'a) Ahmad, Abu Bakr; b) Ahmed, Abubakar; c) Ahmed, Abubakar K.; d) Ahmed, Abubakar Khalfan; e) Ahmed, Abubakary K. f) Ahmed, Ahmed Khalfan; g) Ali, Ahmed Khalfan; h) Ghailani, Abubakary Khalfan Ahmed; i) Ghailani, Ahmed; j) Ghilani, Ahmad Khalafan; k) Hussein, Mahafudh Abubakar Ahmed Abdallah; l) Khaifan, Ahmed; m) Mohammed, Shariff Omar; n) Haythem al-Kini', '04', 'Ahmed', 'AHMED', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('258', '20170807', '����췢[2017]106��', '1: AHMED 2: KHALFAN 3: GHAILANI 4: na', 'a) Ahmad, Abu Bakr; b) Ahmed, Abubakar; c) Ahmed, Abubakar K.; d) Ahmed, Abubakar Khalfan; e) Ahmed, Abubakary K. f) Ahmed, Ahmed Khalfan; g) Ali, Ahmed Khalfan; h) Ghailani, Abubakary Khalfan Ahmed; i) Ghailani, Ahmed; j) Ghilani, Ahmad Khalafan; k) Hussein, Mahafudh Abubakar Ahmed Abdallah; l) Khaifan, Ahmed; m) Mohammed, Shariff Omar; n) Haythem al-Kini', '04', 'Abubakar Khalfan', 'ABUBAKAR KHALFAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('259', '20170807', '����췢[2017]106��', '1: AHMED 2: KHALFAN 3: GHAILANI 4: na', 'a) Ahmad, Abu Bakr; b) Ahmed, Abubakar; c) Ahmed, Abubakar K.; d) Ahmed, Abubakar Khalfan; e) Ahmed, Abubakary K. f) Ahmed, Ahmed Khalfan; g) Ali, Ahmed Khalfan; h) Ghailani, Abubakary Khalfan Ahmed; i) Ghailani, Ahmed; j) Ghilani, Ahmad Khalafan; k) Hussein, Mahafudh Abubakar Ahmed Abdallah; l) Khaifan, Ahmed; m) Mohammed, Shariff Omar; n) Haythem al-Kini', '04', 'Ahmed, Abubakary K.', 'AHMED, ABUBAKARY K.', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('260', '20170807', '����췢[2017]106��', '1: AHMED 2: KHALFAN 3: GHAILANI 4: na', 'a) Ahmad, Abu Bakr; b) Ahmed, Abubakar; c) Ahmed, Abubakar K.; d) Ahmed, Abubakar Khalfan; e) Ahmed, Abubakary K. f) Ahmed, Ahmed Khalfan; g) Ali, Ahmed Khalfan; h) Ghailani, Abubakary Khalfan Ahmed; i) Ghailani, Ahmed; j) Ghilani, Ahmad Khalafan; k) Hussein, Mahafudh Abubakar Ahmed Abdallah; l) Khaifan, Ahmed; m) Mohammed, Shariff Omar; n) Haythem al-Kini', '04', 'Ahmed', 'AHMED', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('261', '20170807', '����췢[2017]106��', '1: AHMED 2: KHALFAN 3: GHAILANI 4: na', 'a) Ahmad, Abu Bakr; b) Ahmed, Abubakar; c) Ahmed, Abubakar K.; d) Ahmed, Abubakar Khalfan; e) Ahmed, Abubakary K. f) Ahmed, Ahmed Khalfan; g) Ali, Ahmed Khalfan; h) Ghailani, Abubakary Khalfan Ahmed; i) Ghailani, Ahmed; j) Ghilani, Ahmad Khalafan; k) Hussein, Mahafudh Abubakar Ahmed Abdallah; l) Khaifan, Ahmed; m) Mohammed, Shariff Omar; n) Haythem al-Kini', '04', 'Abubakary K.', 'ABUBAKARY K.', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('262', '20170807', '����췢[2017]106��', '1: AHMED 2: KHALFAN 3: GHAILANI 4: na', 'a) Ahmad, Abu Bakr; b) Ahmed, Abubakar; c) Ahmed, Abubakar K.; d) Ahmed, Abubakar Khalfan; e) Ahmed, Abubakary K. f) Ahmed, Ahmed Khalfan; g) Ali, Ahmed Khalfan; h) Ghailani, Abubakary Khalfan Ahmed; i) Ghailani, Ahmed; j) Ghilani, Ahmad Khalafan; k) Hussein, Mahafudh Abubakar Ahmed Abdallah; l) Khaifan, Ahmed; m) Mohammed, Shariff Omar; n) Haythem al-Kini', '04', 'Ahmed, Ahmed Khalfan', 'AHMED, AHMED KHALFAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('263', '20170807', '����췢[2017]106��', '1: AHMED 2: KHALFAN 3: GHAILANI 4: na', 'a) Ahmad, Abu Bakr; b) Ahmed, Abubakar; c) Ahmed, Abubakar K.; d) Ahmed, Abubakar Khalfan; e) Ahmed, Abubakary K. f) Ahmed, Ahmed Khalfan; g) Ali, Ahmed Khalfan; h) Ghailani, Abubakary Khalfan Ahmed; i) Ghailani, Ahmed; j) Ghilani, Ahmad Khalafan; k) Hussein, Mahafudh Abubakar Ahmed Abdallah; l) Khaifan, Ahmed; m) Mohammed, Shariff Omar; n) Haythem al-Kini', '04', 'Ali, Ahmed Khalfan', 'ALI, AHMED KHALFAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('264', '20170807', '����췢[2017]106��', '1: AHMED 2: KHALFAN 3: GHAILANI 4: na', 'a) Ahmad, Abu Bakr; b) Ahmed, Abubakar; c) Ahmed, Abubakar K.; d) Ahmed, Abubakar Khalfan; e) Ahmed, Abubakary K. f) Ahmed, Ahmed Khalfan; g) Ali, Ahmed Khalfan; h) Ghailani, Abubakary Khalfan Ahmed; i) Ghailani, Ahmed; j) Ghilani, Ahmad Khalafan; k) Hussein, Mahafudh Abubakar Ahmed Abdallah; l) Khaifan, Ahmed; m) Mohammed, Shariff Omar; n) Haythem al-Kini', '04', 'Ali', 'ALI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('265', '20170807', '����췢[2017]106��', '1: AHMED 2: KHALFAN 3: GHAILANI 4: na', 'a) Ahmad, Abu Bakr; b) Ahmed, Abubakar; c) Ahmed, Abubakar K.; d) Ahmed, Abubakar Khalfan; e) Ahmed, Abubakary K. f) Ahmed, Ahmed Khalfan; g) Ali, Ahmed Khalfan; h) Ghailani, Abubakary Khalfan Ahmed; i) Ghailani, Ahmed; j) Ghilani, Ahmad Khalafan; k) Hussein, Mahafudh Abubakar Ahmed Abdallah; l) Khaifan, Ahmed; m) Mohammed, Shariff Omar; n) Haythem al-Kini', '04', 'Ahmed Khalfan', 'AHMED KHALFAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('266', '20170807', '����췢[2017]106��', '1: AHMED 2: KHALFAN 3: GHAILANI 4: na', 'a) Ahmad, Abu Bakr; b) Ahmed, Abubakar; c) Ahmed, Abubakar K.; d) Ahmed, Abubakar Khalfan; e) Ahmed, Abubakary K. f) Ahmed, Ahmed Khalfan; g) Ali, Ahmed Khalfan; h) Ghailani, Abubakary Khalfan Ahmed; i) Ghailani, Ahmed; j) Ghilani, Ahmad Khalafan; k) Hussein, Mahafudh Abubakar Ahmed Abdallah; l) Khaifan, Ahmed; m) Mohammed, Shariff Omar; n) Haythem al-Kini', '04', 'Ghailani, Abubakary Khalfan Ahmed', 'GHAILANI, ABUBAKARY KHALFAN AHMED', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('267', '20170807', '����췢[2017]106��', '1: AHMED 2: KHALFAN 3: GHAILANI 4: na', 'a) Ahmad, Abu Bakr; b) Ahmed, Abubakar; c) Ahmed, Abubakar K.; d) Ahmed, Abubakar Khalfan; e) Ahmed, Abubakary K. f) Ahmed, Ahmed Khalfan; g) Ali, Ahmed Khalfan; h) Ghailani, Abubakary Khalfan Ahmed; i) Ghailani, Ahmed; j) Ghilani, Ahmad Khalafan; k) Hussein, Mahafudh Abubakar Ahmed Abdallah; l) Khaifan, Ahmed; m) Mohammed, Shariff Omar; n) Haythem al-Kini', '04', 'Ghailani', 'GHAILANI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('268', '20170807', '����췢[2017]106��', '1: AHMED 2: KHALFAN 3: GHAILANI 4: na', 'a) Ahmad, Abu Bakr; b) Ahmed, Abubakar; c) Ahmed, Abubakar K.; d) Ahmed, Abubakar Khalfan; e) Ahmed, Abubakary K. f) Ahmed, Ahmed Khalfan; g) Ali, Ahmed Khalfan; h) Ghailani, Abubakary Khalfan Ahmed; i) Ghailani, Ahmed; j) Ghilani, Ahmad Khalafan; k) Hussein, Mahafudh Abubakar Ahmed Abdallah; l) Khaifan, Ahmed; m) Mohammed, Shariff Omar; n) Haythem al-Kini', '04', 'Abubakary Khalfan Ahmed', 'ABUBAKARY KHALFAN AHMED', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('269', '20170807', '����췢[2017]106��', '1: AHMED 2: KHALFAN 3: GHAILANI 4: na', 'a) Ahmad, Abu Bakr; b) Ahmed, Abubakar; c) Ahmed, Abubakar K.; d) Ahmed, Abubakar Khalfan; e) Ahmed, Abubakary K. f) Ahmed, Ahmed Khalfan; g) Ali, Ahmed Khalfan; h) Ghailani, Abubakary Khalfan Ahmed; i) Ghailani, Ahmed; j) Ghilani, Ahmad Khalafan; k) Hussein, Mahafudh Abubakar Ahmed Abdallah; l) Khaifan, Ahmed; m) Mohammed, Shariff Omar; n) Haythem al-Kini', '04', 'Ghailani, Ahmed', 'GHAILANI, AHMED', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('270', '20170807', '����췢[2017]106��', '1: AHMED 2: KHALFAN 3: GHAILANI 4: na', 'a) Ahmad, Abu Bakr; b) Ahmed, Abubakar; c) Ahmed, Abubakar K.; d) Ahmed, Abubakar Khalfan; e) Ahmed, Abubakary K. f) Ahmed, Ahmed Khalfan; g) Ali, Ahmed Khalfan; h) Ghailani, Abubakary Khalfan Ahmed; i) Ghailani, Ahmed; j) Ghilani, Ahmad Khalafan; k) Hussein, Mahafudh Abubakar Ahmed Abdallah; l) Khaifan, Ahmed; m) Mohammed, Shariff Omar; n) Haythem al-Kini', '04', 'Ghailani', 'GHAILANI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('271', '20170807', '����췢[2017]106��', '1: AHMED 2: KHALFAN 3: GHAILANI 4: na', 'a) Ahmad, Abu Bakr; b) Ahmed, Abubakar; c) Ahmed, Abubakar K.; d) Ahmed, Abubakar Khalfan; e) Ahmed, Abubakary K. f) Ahmed, Ahmed Khalfan; g) Ali, Ahmed Khalfan; h) Ghailani, Abubakary Khalfan Ahmed; i) Ghailani, Ahmed; j) Ghilani, Ahmad Khalafan; k) Hussein, Mahafudh Abubakar Ahmed Abdallah; l) Khaifan, Ahmed; m) Mohammed, Shariff Omar; n) Haythem al-Kini', '04', 'Ahmed', 'AHMED', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('272', '20170807', '����췢[2017]106��', '1: AHMED 2: KHALFAN 3: GHAILANI 4: na', 'a) Ahmad, Abu Bakr; b) Ahmed, Abubakar; c) Ahmed, Abubakar K.; d) Ahmed, Abubakar Khalfan; e) Ahmed, Abubakary K. f) Ahmed, Ahmed Khalfan; g) Ali, Ahmed Khalfan; h) Ghailani, Abubakary Khalfan Ahmed; i) Ghailani, Ahmed; j) Ghilani, Ahmad Khalafan; k) Hussein, Mahafudh Abubakar Ahmed Abdallah; l) Khaifan, Ahmed; m) Mohammed, Shariff Omar; n) Haythem al-Kini', '04', 'Ghilani, Ahmad Khalafan', 'GHILANI, AHMAD KHALAFAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('273', '20170807', '����췢[2017]106��', '1: AHMED 2: KHALFAN 3: GHAILANI 4: na', 'a) Ahmad, Abu Bakr; b) Ahmed, Abubakar; c) Ahmed, Abubakar K.; d) Ahmed, Abubakar Khalfan; e) Ahmed, Abubakary K. f) Ahmed, Ahmed Khalfan; g) Ali, Ahmed Khalfan; h) Ghailani, Abubakary Khalfan Ahmed; i) Ghailani, Ahmed; j) Ghilani, Ahmad Khalafan; k) Hussein, Mahafudh Abubakar Ahmed Abdallah; l) Khaifan, Ahmed; m) Mohammed, Shariff Omar; n) Haythem al-Kini', '04', 'Ghilani', 'GHILANI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('274', '20170807', '����췢[2017]106��', '1: AHMED 2: KHALFAN 3: GHAILANI 4: na', 'a) Ahmad, Abu Bakr; b) Ahmed, Abubakar; c) Ahmed, Abubakar K.; d) Ahmed, Abubakar Khalfan; e) Ahmed, Abubakary K. f) Ahmed, Ahmed Khalfan; g) Ali, Ahmed Khalfan; h) Ghailani, Abubakary Khalfan Ahmed; i) Ghailani, Ahmed; j) Ghilani, Ahmad Khalafan; k) Hussein, Mahafudh Abubakar Ahmed Abdallah; l) Khaifan, Ahmed; m) Mohammed, Shariff Omar; n) Haythem al-Kini', '04', 'Ahmad Khalafan', 'AHMAD KHALAFAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('275', '20170807', '����췢[2017]106��', '1: AHMED 2: KHALFAN 3: GHAILANI 4: na', 'a) Ahmad, Abu Bakr; b) Ahmed, Abubakar; c) Ahmed, Abubakar K.; d) Ahmed, Abubakar Khalfan; e) Ahmed, Abubakary K. f) Ahmed, Ahmed Khalfan; g) Ali, Ahmed Khalfan; h) Ghailani, Abubakary Khalfan Ahmed; i) Ghailani, Ahmed; j) Ghilani, Ahmad Khalafan; k) Hussein, Mahafudh Abubakar Ahmed Abdallah; l) Khaifan, Ahmed; m) Mohammed, Shariff Omar; n) Haythem al-Kini', '04', 'Hussein, Mahafudh Abubakar Ahmed Abdallah', 'HUSSEIN, MAHAFUDH ABUBAKAR AHMED ABDALLAH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('276', '20170807', '����췢[2017]106��', '1: AHMED 2: KHALFAN 3: GHAILANI 4: na', 'a) Ahmad, Abu Bakr; b) Ahmed, Abubakar; c) Ahmed, Abubakar K.; d) Ahmed, Abubakar Khalfan; e) Ahmed, Abubakary K. f) Ahmed, Ahmed Khalfan; g) Ali, Ahmed Khalfan; h) Ghailani, Abubakary Khalfan Ahmed; i) Ghailani, Ahmed; j) Ghilani, Ahmad Khalafan; k) Hussein, Mahafudh Abubakar Ahmed Abdallah; l) Khaifan, Ahmed; m) Mohammed, Shariff Omar; n) Haythem al-Kini', '04', 'Hussein', 'HUSSEIN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('277', '20170807', '����췢[2017]106��', '1: AHMED 2: KHALFAN 3: GHAILANI 4: na', 'a) Ahmad, Abu Bakr; b) Ahmed, Abubakar; c) Ahmed, Abubakar K.; d) Ahmed, Abubakar Khalfan; e) Ahmed, Abubakary K. f) Ahmed, Ahmed Khalfan; g) Ali, Ahmed Khalfan; h) Ghailani, Abubakary Khalfan Ahmed; i) Ghailani, Ahmed; j) Ghilani, Ahmad Khalafan; k) Hussein, Mahafudh Abubakar Ahmed Abdallah; l) Khaifan, Ahmed; m) Mohammed, Shariff Omar; n) Haythem al-Kini', '04', 'Mahafudh Abubakar Ahmed Abdallah', 'MAHAFUDH ABUBAKAR AHMED ABDALLAH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('278', '20170807', '����췢[2017]106��', '1: AHMED 2: KHALFAN 3: GHAILANI 4: na', 'a) Ahmad, Abu Bakr; b) Ahmed, Abubakar; c) Ahmed, Abubakar K.; d) Ahmed, Abubakar Khalfan; e) Ahmed, Abubakary K. f) Ahmed, Ahmed Khalfan; g) Ali, Ahmed Khalfan; h) Ghailani, Abubakary Khalfan Ahmed; i) Ghailani, Ahmed; j) Ghilani, Ahmad Khalafan; k) Hussein, Mahafudh Abubakar Ahmed Abdallah; l) Khaifan, Ahmed; m) Mohammed, Shariff Omar; n) Haythem al-Kini', '04', 'Khaifan, Ahmed', 'KHAIFAN, AHMED', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('279', '20170807', '����췢[2017]106��', '1: AHMED 2: KHALFAN 3: GHAILANI 4: na', 'a) Ahmad, Abu Bakr; b) Ahmed, Abubakar; c) Ahmed, Abubakar K.; d) Ahmed, Abubakar Khalfan; e) Ahmed, Abubakary K. f) Ahmed, Ahmed Khalfan; g) Ali, Ahmed Khalfan; h) Ghailani, Abubakary Khalfan Ahmed; i) Ghailani, Ahmed; j) Ghilani, Ahmad Khalafan; k) Hussein, Mahafudh Abubakar Ahmed Abdallah; l) Khaifan, Ahmed; m) Mohammed, Shariff Omar; n) Haythem al-Kini', '04', 'Khaifan', 'KHAIFAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('280', '20170807', '����췢[2017]106��', '1: AHMED 2: KHALFAN 3: GHAILANI 4: na', 'a) Ahmad, Abu Bakr; b) Ahmed, Abubakar; c) Ahmed, Abubakar K.; d) Ahmed, Abubakar Khalfan; e) Ahmed, Abubakary K. f) Ahmed, Ahmed Khalfan; g) Ali, Ahmed Khalfan; h) Ghailani, Abubakary Khalfan Ahmed; i) Ghailani, Ahmed; j) Ghilani, Ahmad Khalafan; k) Hussein, Mahafudh Abubakar Ahmed Abdallah; l) Khaifan, Ahmed; m) Mohammed, Shariff Omar; n) Haythem al-Kini', '04', 'Ahmed', 'AHMED', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('281', '20170807', '����췢[2017]106��', '1: AHMED 2: KHALFAN 3: GHAILANI 4: na', 'a) Ahmad, Abu Bakr; b) Ahmed, Abubakar; c) Ahmed, Abubakar K.; d) Ahmed, Abubakar Khalfan; e) Ahmed, Abubakary K. f) Ahmed, Ahmed Khalfan; g) Ali, Ahmed Khalfan; h) Ghailani, Abubakary Khalfan Ahmed; i) Ghailani, Ahmed; j) Ghilani, Ahmad Khalafan; k) Hussein, Mahafudh Abubakar Ahmed Abdallah; l) Khaifan, Ahmed; m) Mohammed, Shariff Omar; n) Haythem al-Kini', '04', 'Mohammed, Shariff Omar', 'MOHAMMED, SHARIFF OMAR', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('282', '20170807', '����췢[2017]106��', '1: AHMED 2: KHALFAN 3: GHAILANI 4: na', 'a) Ahmad, Abu Bakr; b) Ahmed, Abubakar; c) Ahmed, Abubakar K.; d) Ahmed, Abubakar Khalfan; e) Ahmed, Abubakary K. f) Ahmed, Ahmed Khalfan; g) Ali, Ahmed Khalfan; h) Ghailani, Abubakary Khalfan Ahmed; i) Ghailani, Ahmed; j) Ghilani, Ahmad Khalafan; k) Hussein, Mahafudh Abubakar Ahmed Abdallah; l) Khaifan, Ahmed; m) Mohammed, Shariff Omar; n) Haythem al-Kini', '04', 'Mohammed', 'MOHAMMED', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('283', '20170807', '����췢[2017]106��', '1: AHMED 2: KHALFAN 3: GHAILANI 4: na', 'a) Ahmad, Abu Bakr; b) Ahmed, Abubakar; c) Ahmed, Abubakar K.; d) Ahmed, Abubakar Khalfan; e) Ahmed, Abubakary K. f) Ahmed, Ahmed Khalfan; g) Ali, Ahmed Khalfan; h) Ghailani, Abubakary Khalfan Ahmed; i) Ghailani, Ahmed; j) Ghilani, Ahmad Khalafan; k) Hussein, Mahafudh Abubakar Ahmed Abdallah; l) Khaifan, Ahmed; m) Mohammed, Shariff Omar; n) Haythem al-Kini', '04', 'Shariff Omar', 'SHARIFF OMAR', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('284', '20170807', '����췢[2017]106��', '1: AHMED 2: KHALFAN 3: GHAILANI 4: na', 'a) Ahmad, Abu Bakr; b) Ahmed, Abubakar; c) Ahmed, Abubakar K.; d) Ahmed, Abubakar Khalfan; e) Ahmed, Abubakary K. f) Ahmed, Ahmed Khalfan; g) Ali, Ahmed Khalfan; h) Ghailani, Abubakary Khalfan Ahmed; i) Ghailani, Ahmed; j) Ghilani, Ahmad Khalafan; k) Hussein, Mahafudh Abubakar Ahmed Abdallah; l) Khaifan, Ahmed; m) Mohammed, Shariff Omar; n) Haythem al-Kini', '04', 'Haythem al-Kini', 'HAYTHEM AL-KINI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('285', '20170807', '����췢[2017]106��', '1: AIMAN 2: MUHAMMED 3: RABI 4: AL-ZAWAHIRI', 'a) Ayman Al-Zawahari; b) Ahmed Fuad Salim; c) Al Zawahry Alman Mohamed Rabi Abdel Muaz; d) Al Zawahiri Ayman; e) Abdul Qader Abdul Aziz Abdul Moez Al Doctor; f) Al Zawahry Aiman Mohamed Rabi; g) Al Zawahry Aiman Mohamed Rabie; h) Al Zawahry Aiman Mohamed Robi; i) Dhawahri Ayman; j) Eddaouahiri Ayman; k) Nur Al Deen Abu Mohammed; l) Ayman Al Zawahari; m) Ahmad Fuad Salim', '02', 'AIMAN MUHAMMED', 'AIMAN MUHAMMED', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('286', '20170807', '����췢[2017]106��', '1: AIMAN 2: MUHAMMED 3: RABI 4: AL-ZAWAHIRI', 'a) Ayman Al-Zawahari; b) Ahmed Fuad Salim; c) Al Zawahry Alman Mohamed Rabi Abdel Muaz; d) Al Zawahiri Ayman; e) Abdul Qader Abdul Aziz Abdul Moez Al Doctor; f) Al Zawahry Aiman Mohamed Rabi; g) Al Zawahry Aiman Mohamed Rabie; h) Al Zawahry Aiman Mohamed Robi; i) Dhawahri Ayman; j) Eddaouahiri Ayman; k) Nur Al Deen Abu Mohammed; l) Ayman Al Zawahari; m) Ahmad Fuad Salim', '04', 'Ayman Al Zawahari', 'AYMAN AL ZAWAHARI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('287', '20170807', '����췢[2017]106��', '1: AIMAN 2: MUHAMMED 3: RABI 4: AL-ZAWAHIRI', 'a) Ayman Al-Zawahari; b) Ahmed Fuad Salim; c) Al Zawahry Alman Mohamed Rabi Abdel Muaz; d) Al Zawahiri Ayman; e) Abdul Qader Abdul Aziz Abdul Moez Al Doctor; f) Al Zawahry Aiman Mohamed Rabi; g) Al Zawahry Aiman Mohamed Rabie; h) Al Zawahry Aiman Mohamed Robi; i) Dhawahri Ayman; j) Eddaouahiri Ayman; k) Nur Al Deen Abu Mohammed; l) Ayman Al Zawahari; m) Ahmad Fuad Salim', '04', 'Ahmad Fuad Salim', 'AHMAD FUAD SALIM', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('288', '20170807', '����췢[2017]106��', '1: AIMAN 2: MUHAMMED 3: RABI 4: AL-ZAWAHIRI', 'a) Ayman Al-Zawahari; b) Ahmed Fuad Salim; c) Al Zawahry Alman Mohamed Rabi Abdel Muaz; d) Al Zawahiri Ayman; e) Abdul Qader Abdul Aziz Abdul Moez Al Doctor; f) Al Zawahry Aiman Mohamed Rabi; g) Al Zawahry Aiman Mohamed Rabie; h) Al Zawahry Aiman Mohamed Robi; i) Dhawahri Ayman; j) Eddaouahiri Ayman; k) Nur Al Deen Abu Mohammed; l) Ayman Al Zawahari; m) Ahmad Fuad Salim', '04', 'Ayman Al-Zawahari', 'AYMAN AL-ZAWAHARI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('289', '20170807', '����췢[2017]106��', '1: AIMAN 2: MUHAMMED 3: RABI 4: AL-ZAWAHIRI', 'a) Ayman Al-Zawahari; b) Ahmed Fuad Salim; c) Al Zawahry Alman Mohamed Rabi Abdel Muaz; d) Al Zawahiri Ayman; e) Abdul Qader Abdul Aziz Abdul Moez Al Doctor; f) Al Zawahry Aiman Mohamed Rabi; g) Al Zawahry Aiman Mohamed Rabie; h) Al Zawahry Aiman Mohamed Robi; i) Dhawahri Ayman; j) Eddaouahiri Ayman; k) Nur Al Deen Abu Mohammed; l) Ayman Al Zawahari; m) Ahmad Fuad Salim', '04', 'Ahmed Fuad Salim', 'AHMED FUAD SALIM', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('290', '20170807', '����췢[2017]106��', '1: AIMAN 2: MUHAMMED 3: RABI 4: AL-ZAWAHIRI', 'a) Ayman Al-Zawahari; b) Ahmed Fuad Salim; c) Al Zawahry Alman Mohamed Rabi Abdel Muaz; d) Al Zawahiri Ayman; e) Abdul Qader Abdul Aziz Abdul Moez Al Doctor; f) Al Zawahry Aiman Mohamed Rabi; g) Al Zawahry Aiman Mohamed Rabie; h) Al Zawahry Aiman Mohamed Robi; i) Dhawahri Ayman; j) Eddaouahiri Ayman; k) Nur Al Deen Abu Mohammed; l) Ayman Al Zawahari; m) Ahmad Fuad Salim', '04', 'Al Zawahry Alman Mohamed Rabi Abdel Muaz', 'AL ZAWAHRY ALMAN MOHAMED RABI ABDEL MUAZ', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('291', '20170807', '����췢[2017]106��', '1: AIMAN 2: MUHAMMED 3: RABI 4: AL-ZAWAHIRI', 'a) Ayman Al-Zawahari; b) Ahmed Fuad Salim; c) Al Zawahry Alman Mohamed Rabi Abdel Muaz; d) Al Zawahiri Ayman; e) Abdul Qader Abdul Aziz Abdul Moez Al Doctor; f) Al Zawahry Aiman Mohamed Rabi; g) Al Zawahry Aiman Mohamed Rabie; h) Al Zawahry Aiman Mohamed Robi; i) Dhawahri Ayman; j) Eddaouahiri Ayman; k) Nur Al Deen Abu Mohammed; l) Ayman Al Zawahari; m) Ahmad Fuad Salim', '04', 'Al Zawahiri Ayman', 'AL ZAWAHIRI AYMAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('292', '20170807', '����췢[2017]106��', '1: AIMAN 2: MUHAMMED 3: RABI 4: AL-ZAWAHIRI', 'a) Ayman Al-Zawahari; b) Ahmed Fuad Salim; c) Al Zawahry Alman Mohamed Rabi Abdel Muaz; d) Al Zawahiri Ayman; e) Abdul Qader Abdul Aziz Abdul Moez Al Doctor; f) Al Zawahry Aiman Mohamed Rabi; g) Al Zawahry Aiman Mohamed Rabie; h) Al Zawahry Aiman Mohamed Robi; i) Dhawahri Ayman; j) Eddaouahiri Ayman; k) Nur Al Deen Abu Mohammed; l) Ayman Al Zawahari; m) Ahmad Fuad Salim', '04', 'Eddaouahiri Ayman', 'EDDAOUAHIRI AYMAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('293', '20170807', '����췢[2017]106��', '1: AIMAN 2: MUHAMMED 3: RABI 4: AL-ZAWAHIRI', 'a) Ayman Al-Zawahari; b) Ahmed Fuad Salim; c) Al Zawahry Alman Mohamed Rabi Abdel Muaz; d) Al Zawahiri Ayman; e) Abdul Qader Abdul Aziz Abdul Moez Al Doctor; f) Al Zawahry Aiman Mohamed Rabi; g) Al Zawahry Aiman Mohamed Rabie; h) Al Zawahry Aiman Mohamed Robi; i) Dhawahri Ayman; j) Eddaouahiri Ayman; k) Nur Al Deen Abu Mohammed; l) Ayman Al Zawahari; m) Ahmad Fuad Salim', '04', 'Al Zawahry Aiman Mohamed Rabi', 'AL ZAWAHRY AIMAN MOHAMED RABI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('294', '20170807', '����췢[2017]106��', '1: AIMAN 2: MUHAMMED 3: RABI 4: AL-ZAWAHIRI', 'a) Ayman Al-Zawahari; b) Ahmed Fuad Salim; c) Al Zawahry Alman Mohamed Rabi Abdel Muaz; d) Al Zawahiri Ayman; e) Abdul Qader Abdul Aziz Abdul Moez Al Doctor; f) Al Zawahry Aiman Mohamed Rabi; g) Al Zawahry Aiman Mohamed Rabie; h) Al Zawahry Aiman Mohamed Robi; i) Dhawahri Ayman; j) Eddaouahiri Ayman; k) Nur Al Deen Abu Mohammed; l) Ayman Al Zawahari; m) Ahmad Fuad Salim', '04', 'Al Zawahry Aiman Mohamed Rabie', 'AL ZAWAHRY AIMAN MOHAMED RABIE', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('295', '20170807', '����췢[2017]106��', '1: AIMAN 2: MUHAMMED 3: RABI 4: AL-ZAWAHIRI', 'a) Ayman Al-Zawahari; b) Ahmed Fuad Salim; c) Al Zawahry Alman Mohamed Rabi Abdel Muaz; d) Al Zawahiri Ayman; e) Abdul Qader Abdul Aziz Abdul Moez Al Doctor; f) Al Zawahry Aiman Mohamed Rabi; g) Al Zawahry Aiman Mohamed Rabie; h) Al Zawahry Aiman Mohamed Robi; i) Dhawahri Ayman; j) Eddaouahiri Ayman; k) Nur Al Deen Abu Mohammed; l) Ayman Al Zawahari; m) Ahmad Fuad Salim', '04', 'Dhawahri Ayman', 'DHAWAHRI AYMAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('296', '20170807', '����췢[2017]106��', '1: AIMAN 2: MUHAMMED 3: RABI 4: AL-ZAWAHIRI', 'a) Ayman Al-Zawahari; b) Ahmed Fuad Salim; c) Al Zawahry Alman Mohamed Rabi Abdel Muaz; d) Al Zawahiri Ayman; e) Abdul Qader Abdul Aziz Abdul Moez Al Doctor; f) Al Zawahry Aiman Mohamed Rabi; g) Al Zawahry Aiman Mohamed Rabie; h) Al Zawahry Aiman Mohamed Robi; i) Dhawahri Ayman; j) Eddaouahiri Ayman; k) Nur Al Deen Abu Mohammed; l) Ayman Al Zawahari; m) Ahmad Fuad Salim', '04', 'Al Zawahry Aiman Mohamed Robi', 'AL ZAWAHRY AIMAN MOHAMED ROBI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('297', '20170807', '����췢[2017]106��', '1: AIMAN 2: MUHAMMED 3: RABI 4: AL-ZAWAHIRI', 'a) Ayman Al-Zawahari; b) Ahmed Fuad Salim; c) Al Zawahry Alman Mohamed Rabi Abdel Muaz; d) Al Zawahiri Ayman; e) Abdul Qader Abdul Aziz Abdul Moez Al Doctor; f) Al Zawahry Aiman Mohamed Rabi; g) Al Zawahry Aiman Mohamed Rabie; h) Al Zawahry Aiman Mohamed Robi; i) Dhawahri Ayman; j) Eddaouahiri Ayman; k) Nur Al Deen Abu Mohammed; l) Ayman Al Zawahari; m) Ahmad Fuad Salim', '04', 'Nur Al Deen Abu Mohammed', 'NUR AL DEEN ABU MOHAMMED', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('298', '20170807', '����췢[2017]106��', '1: AIMAN 2: MUHAMMED 3: RABI 4: AL-ZAWAHIRI', 'a) Ayman Al-Zawahari; b) Ahmed Fuad Salim; c) Al Zawahry Alman Mohamed Rabi Abdel Muaz; d) Al Zawahiri Ayman; e) Abdul Qader Abdul Aziz Abdul Moez Al Doctor; f) Al Zawahry Aiman Mohamed Rabi; g) Al Zawahry Aiman Mohamed Rabie; h) Al Zawahry Aiman Mohamed Robi; i) Dhawahri Ayman; j) Eddaouahiri Ayman; k) Nur Al Deen Abu Mohammed; l) Ayman Al Zawahari; m) Ahmad Fuad Salim', '04', 'Abdul Qader Abdul Aziz Abdul Moez Al Doctor', 'ABDUL QADER ABDUL AZIZ ABDUL MOEZ AL DOCTOR', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('299', '20170807', '����췢[2017]106��', '1: AKHMED 2: RAJAPOVICH 3: CHATAEV 4: na', 'a) Akhmad Shishani; b) David Mayer; c) Elmir Sene', '02', 'AKHMED RAJAPOVICH', 'AKHMED RAJAPOVICH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('300', '20170807', '����췢[2017]106��', '1: AKHMED 2: RAJAPOVICH 3: CHATAEV 4: na', 'a) Akhmad Shishani; b) David Mayer; c) Elmir Sene', '04', 'David Mayer', 'DAVID MAYER', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('301', '20170807', '����췢[2017]106��', '1: AKHMED 2: RAJAPOVICH 3: CHATAEV 4: na', 'a) Akhmad Shishani; b) David Mayer; c) Elmir Sene', '04', 'Akhmad Shishani', 'AKHMAD SHISHANI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('302', '20170807', '����췢[2017]106��', '1: AKHMED 2: RAJAPOVICH 3: CHATAEV 4: na', 'a) Akhmad Shishani; b) David Mayer; c) Elmir Sene', '04', 'Elmir Sene', 'ELMIR SENE', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('303', '20170807', '����췢[2017]106��', '1: AKRAM 2: TURKI 3: HISHAN 4: AL-MAZIDIH', 'a) Akram Turki Al-Hishan ', '02', 'AKRAM TURKI', 'AKRAM TURKI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('304', '20170807', '����췢[2017]106��', '1: AKRAM 2: TURKI 3: HISHAN 4: AL-MAZIDIH', 'a) Akram Turki Al-Hishan ', '03', 'Akram Turki Al-Hishan', 'AKRAM TURKI AL-HISHAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('305', '20170807', '����췢[2017]106��', '1: AL-AZHAR 2: BEN KHALIFA 3: BEN AHMED 4: ROUINE', null, '02', 'AL-AZHAR BEN KHALIFA', 'AL-AZHAR BEN KHALIFA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('306', '20170807', '����췢[2017]106��', '1: AL-MOKHTAR 2: BEN MOHAMED 3: BEN AL-MOKHTAR 4: BOUCHOUCHA ', 'a) Bushusha Mokhtar', '02', 'AL-MOKHTAR BEN MOHAMED', 'AL-MOKHTAR BEN MOHAMED', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('307', '20170807', '����췢[2017]106��', '1: AL-MOKHTAR 2: BEN MOHAMED 3: BEN AL-MOKHTAR 4: BOUCHOUCHA ', 'a) Bushusha Mokhtar', '03', 'Bushusha Mokhtar', 'BUSHUSHA MOKHTAR', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('308', '20170807', '����췢[2017]106��', '1: ALI 2: BEN TAHER 3: BEN FALEH 4: OUNI HARZI', null, '02', 'ALI BEN TAHER', 'ALI BEN TAHER', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('309', '20170807', '����췢[2017]106��', '1: ALI 2: SAYYID 3: MUHAMED 4: MUSTAFA BAKRI', 'a) Ali Salim; b) Abd Al-Aziz al-Masri', '02', 'ALI SAYYID', 'ALI SAYYID', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('310', '20170807', '����췢[2017]106��', '1: ALI 2: SAYYID 3: MUHAMED 4: MUSTAFA BAKRI', 'a) Ali Salim; b) Abd Al-Aziz al-Masri', '04', 'Abd Al-Aziz al-Masri', 'ABD AL-AZIZ AL-MASRI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('311', '20170807', '����췢[2017]106��', '1: ALI 2: SAYYID 3: MUHAMED 4: MUSTAFA BAKRI', 'a) Ali Salim; b) Abd Al-Aziz al-Masri', '04', 'Ali Salim', 'ALI SALIM', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('312', '20170807', '����췢[2017]106��', '1: ALI MUSA 2: AL-SHAWAKH 3: na 4: na', 'a) Ali Musa al-Shawagh; b) Ali Musa al-Shawagh; c) Ali al-Hamoud al-Shawakh; d) Ibrahim al-Shawwakh; e) Muhammad Ali al-Shawakh', '02', 'ALI MUSA AL-SHAWAKH', 'ALI MUSA AL-SHAWAKH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('313', '20170807', '����췢[2017]106��', '1: ALI MUSA 2: AL-SHAWAKH 3: na 4: na', 'a) Ali Musa al-Shawagh; b) Ali Musa al-Shawagh; c) Ali al-Hamoud al-Shawakh; d) Ibrahim al-Shawwakh; e) Muhammad Ali al-Shawakh', '04', 'Ibrahim al-Shawwakh', 'IBRAHIM AL-SHAWWAKH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('314', '20170807', '����췢[2017]106��', '1: ALI MUSA 2: AL-SHAWAKH 3: na 4: na', 'a) Ali Musa al-Shawagh; b) Ali Musa al-Shawagh; c) Ali al-Hamoud al-Shawakh; d) Ibrahim al-Shawwakh; e) Muhammad Ali al-Shawakh', '04', 'Ali Musa al-Shawagh', 'ALI MUSA AL-SHAWAGH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('315', '20170807', '����췢[2017]106��', '1: ALI MUSA 2: AL-SHAWAKH 3: na 4: na', 'a) Ali Musa al-Shawagh; b) Ali Musa al-Shawagh; c) Ali al-Hamoud al-Shawakh; d) Ibrahim al-Shawwakh; e) Muhammad Ali al-Shawakh', '04', 'Ali Musa al-Shawagh', 'ALI MUSA AL-SHAWAGH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('316', '20170807', '����췢[2017]106��', '1: ALI MUSA 2: AL-SHAWAKH 3: na 4: na', 'a) Ali Musa al-Shawagh; b) Ali Musa al-Shawagh; c) Ali al-Hamoud al-Shawakh; d) Ibrahim al-Shawwakh; e) Muhammad Ali al-Shawakh', '04', 'Muhammad Ali al-Shawakh', 'MUHAMMAD ALI AL-SHAWAKH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('317', '20170807', '����췢[2017]106��', '1: ALI MUSA 2: AL-SHAWAKH 3: na 4: na', 'a) Ali Musa al-Shawagh; b) Ali Musa al-Shawagh; c) Ali al-Hamoud al-Shawakh; d) Ibrahim al-Shawwakh; e) Muhammad Ali al-Shawakh', '04', 'Ali al-Hamoud al-Shawakh', 'ALI AL-HAMOUD AL-SHAWAKH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('318', '20170807', '����췢[2017]106��', '1: ALY 2: SOLIMAN 3: MASSOUD 4: ABDUL SAYED', 'a) Ibn El Qaim; b) Mohamed Osman', '02', 'ALY SOLIMAN', 'ALY SOLIMAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('319', '20170807', '����췢[2017]106��', '1: ALY 2: SOLIMAN 3: MASSOUD 4: ABDUL SAYED', 'a) Ibn El Qaim; b) Mohamed Osman', '04', 'Mohamed Osman', 'MOHAMED OSMAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('320', '20170807', '����췢[2017]106��', '1: ALY 2: SOLIMAN 3: MASSOUD 4: ABDUL SAYED', 'a) Ibn El Qaim; b) Mohamed Osman', '04', 'Ibn El Qaim', 'IBN EL QAIM', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('321', '20170807', '����췢[2017]106��', '1: AMIN 2: MUHAMMAD 3: UL HAQ 4: SAAM KHAN', 'a) Al-Haq, Amin; b) Amin, Muhammad', '02', 'AMIN MUHAMMAD', 'AMIN MUHAMMAD', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('322', '20170807', '����췢[2017]106��', '1: AMIN 2: MUHAMMAD 3: UL HAQ 4: SAAM KHAN', 'a) Al-Haq, Amin; b) Amin, Muhammad', '04', 'Amin, Muhammad', 'AMIN, MUHAMMAD', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('323', '20170807', '����췢[2017]106��', '1: AMIN 2: MUHAMMAD 3: UL HAQ 4: SAAM KHAN', 'a) Al-Haq, Amin; b) Amin, Muhammad', '04', 'Al-Haq, Amin', 'AL-HAQ, AMIN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('324', '20170807', '����췢[2017]106��', '1: AMOR 2: MOHAMED 3: GHEDEIR 4: na', 'a) Abdelhamid Abou Zeid; b) Youcef Adel; c) Abou Abdellah; d) Abid Hammadou born 12 Dec. 1965 in Touggourt, Wilaya (province) of Ouargla, Algeria', '02', 'AMOR MOHAMED', 'AMOR MOHAMED', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('325', '20170807', '����췢[2017]106��', '1: AMOR 2: MOHAMED 3: GHEDEIR 4: na', 'a) Abdelhamid Abou Zeid; b) Youcef Adel; c) Abou Abdellah; d) Abid Hammadou born 12 Dec. 1965 in Touggourt, Wilaya (province) of Ouargla, Algeria', '04', 'Abou Abdellah', 'ABOU ABDELLAH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('326', '20170807', '����췢[2017]106��', '1: AMOR 2: MOHAMED 3: GHEDEIR 4: na', 'a) Abdelhamid Abou Zeid; b) Youcef Adel; c) Abou Abdellah; d) Abid Hammadou born 12 Dec. 1965 in Touggourt, Wilaya (province) of Ouargla, Algeria', '04', 'Abid Hammadou', 'ABID HAMMADOU', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('327', '20170807', '����췢[2017]106��', '1: AMOR 2: MOHAMED 3: GHEDEIR 4: na', 'a) Abdelhamid Abou Zeid; b) Youcef Adel; c) Abou Abdellah; d) Abid Hammadou born 12 Dec. 1965 in Touggourt, Wilaya (province) of Ouargla, Algeria', '04', 'Youcef Adel', 'YOUCEF ADEL', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('328', '20170807', '����췢[2017]106��', '1: AMOR 2: MOHAMED 3: GHEDEIR 4: na', 'a) Abdelhamid Abou Zeid; b) Youcef Adel; c) Abou Abdellah; d) Abid Hammadou born 12 Dec. 1965 in Touggourt, Wilaya (province) of Ouargla, Algeria', '04', 'Abdelhamid Abou Zeid', 'ABDELHAMID ABOU ZEID', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('329', '20170807', '����췢[2017]106��', '1: AMRU 2: AL-ABSI 3; na 4: na ', 'a) Amr al Absi; b) Abu al Athir Amr al Absi', '02', 'AMRU AL-ABSI', 'AMRU AL-ABSI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('330', '20170807', '����췢[2017]106��', '1: AMRU 2: AL-ABSI 3; na 4: na ', 'a) Amr al Absi; b) Abu al Athir Amr al Absi', '04', 'Amr al Absi', 'AMR AL ABSI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('331', '20170807', '����췢[2017]106��', '1: AMRU 2: AL-ABSI 3; na 4: na ', 'a) Amr al Absi; b) Abu al Athir Amr al Absi', '04', 'Abu al Athir Amr al Absi', 'ABU AL ATHIR AMR AL ABSI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('332', '20170807', '����췢[2017]106��', '1: ANAS 2: HASAN 3: KHATTAB 4: na', 'a) Samir Ahmed al-Khayat', '02', 'ANAS HASAN', 'ANAS HASAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('333', '20170807', '����췢[2017]106��', '1: ANAS 2: HASAN 3: KHATTAB 4: na', 'a) Samir Ahmed al-Khayat', '03', 'Samir Ahmed al-Khayat', 'SAMIR AHMED AL-KHAYAT', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('334', '20170807', '����췢[2017]106��', '1: ANDERS 2: CAMEROON 3: OSTENSVIG 4: DALE', null, '02', 'ANDERS CAMEROON', 'ANDERS CAMEROON', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('335', '20170807', '����췢[2017]106��', '1: ANGELO 2: RAMIREZ 3: TRINIDAD 4: na', 'a) Calib Trinidad; b) Kalib Trinidad', '02', 'ANGELO RAMIREZ', 'ANGELO RAMIREZ', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('336', '20170807', '����췢[2017]106��', '1: ANGELO 2: RAMIREZ 3: TRINIDAD 4: na', 'a) Calib Trinidad; b) Kalib Trinidad', '04', 'Calib Trinidad', 'CALIB TRINIDAD', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('337', '20170807', '����췢[2017]106��', '1: ANGELO 2: RAMIREZ 3: TRINIDAD 4: na', 'a) Calib Trinidad; b) Kalib Trinidad', '04', 'Kalib Trinidad', 'KALIB TRINIDAD', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('338', '20170807', '����췢[2017]106��', '1: ANGGA 2: DIMAS 3: PERSHADA 4: na', 'a) Angga Dimas Persada born 4 Mar. 1985 in Jakarta, Indonesia; b) Angga Dimas Persadha born 4 Mar. 1985 in Jakarta, Indonesia; c) Angga Dimas Prasondha born 4 Mar. 1985 in Jakarta, Indonesia', '02', 'ANGGA DIMAS', 'ANGGA DIMAS', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('339', '20170807', '����췢[2017]106��', '1: ANGGA 2: DIMAS 3: PERSHADA 4: na', 'a) Angga Dimas Persada born 4 Mar. 1985 in Jakarta, Indonesia; b) Angga Dimas Persadha born 4 Mar. 1985 in Jakarta, Indonesia; c) Angga Dimas Prasondha born 4 Mar. 1985 in Jakarta, Indonesia', '04', 'Angga Dimas Prasondha', 'ANGGA DIMAS PRASONDHA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('340', '20170807', '����췢[2017]106��', '1: ANGGA 2: DIMAS 3: PERSHADA 4: na', 'a) Angga Dimas Persada born 4 Mar. 1985 in Jakarta, Indonesia; b) Angga Dimas Persadha born 4 Mar. 1985 in Jakarta, Indonesia; c) Angga Dimas Prasondha born 4 Mar. 1985 in Jakarta, Indonesia', '04', 'Angga Dimas Persadha', 'ANGGA DIMAS PERSADHA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('341', '20170807', '����췢[2017]106��', '1: ANGGA 2: DIMAS 3: PERSHADA 4: na', 'a) Angga Dimas Persada born 4 Mar. 1985 in Jakarta, Indonesia; b) Angga Dimas Persadha born 4 Mar. 1985 in Jakarta, Indonesia; c) Angga Dimas Prasondha born 4 Mar. 1985 in Jakarta, Indonesia', '04', 'Angga Dimas Persada', 'ANGGA DIMAS PERSADA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('342', '20170807', '����췢[2017]106��', '1: ANWAR 2: NASSER 3: ABDULLA 4: AL-AULAQI', 'a) Anwar al-Aulaqi; b) Anwar al-Awlaki; c) Anwar al-Awlaqi; d) Anwar Nasser Aulaqi; e) Anwar Nasser Abdullah Aulaqi; f) Anwar Nasser Abdulla Aulaql', '02', 'ANWAR NASSER', 'ANWAR NASSER', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('343', '20170807', '����췢[2017]106��', '1: ANWAR 2: NASSER 3: ABDULLA 4: AL-AULAQI', 'a) Anwar al-Aulaqi; b) Anwar al-Awlaki; c) Anwar al-Awlaqi; d) Anwar Nasser Aulaqi; e) Anwar Nasser Abdullah Aulaqi; f) Anwar Nasser Abdulla Aulaql', '04', 'Anwar Nasser Abdulla Aulaql', 'ANWAR NASSER ABDULLA AULAQL', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('344', '20170807', '����췢[2017]106��', '1: ANWAR 2: NASSER 3: ABDULLA 4: AL-AULAQI', 'a) Anwar al-Aulaqi; b) Anwar al-Awlaki; c) Anwar al-Awlaqi; d) Anwar Nasser Aulaqi; e) Anwar Nasser Abdullah Aulaqi; f) Anwar Nasser Abdulla Aulaql', '04', 'Anwar Nasser Abdullah Aulaqi', 'ANWAR NASSER ABDULLAH AULAQI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('345', '20170807', '����췢[2017]106��', '1: ANWAR 2: NASSER 3: ABDULLA 4: AL-AULAQI', 'a) Anwar al-Aulaqi; b) Anwar al-Awlaki; c) Anwar al-Awlaqi; d) Anwar Nasser Aulaqi; e) Anwar Nasser Abdullah Aulaqi; f) Anwar Nasser Abdulla Aulaql', '04', 'Anwar Nasser Aulaqi', 'ANWAR NASSER AULAQI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('346', '20170807', '����췢[2017]106��', '1: ANWAR 2: NASSER 3: ABDULLA 4: AL-AULAQI', 'a) Anwar al-Aulaqi; b) Anwar al-Awlaki; c) Anwar al-Awlaqi; d) Anwar Nasser Aulaqi; e) Anwar Nasser Abdullah Aulaqi; f) Anwar Nasser Abdulla Aulaql', '04', 'Anwar al-Awlaqi', 'ANWAR AL-AWLAQI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('347', '20170807', '����췢[2017]106��', '1: ANWAR 2: NASSER 3: ABDULLA 4: AL-AULAQI', 'a) Anwar al-Aulaqi; b) Anwar al-Awlaki; c) Anwar al-Awlaqi; d) Anwar Nasser Aulaqi; e) Anwar Nasser Abdullah Aulaqi; f) Anwar Nasser Abdulla Aulaql', '04', 'Anwar al-Awlaki', 'ANWAR AL-AWLAKI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('348', '20170807', '����췢[2017]106��', '1: ANWAR 2: NASSER 3: ABDULLA 4: AL-AULAQI', 'a) Anwar al-Aulaqi; b) Anwar al-Awlaki; c) Anwar al-Awlaqi; d) Anwar Nasser Aulaqi; e) Anwar Nasser Abdullah Aulaqi; f) Anwar Nasser Abdulla Aulaql', '04', 'Anwar al-Aulaqi', 'ANWAR AL-AULAQI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('349', '20170807', '����췢[2017]106��', '1: AQSA 2: MAHMOOD 3: na 4: na', null, '02', 'AQSA MAHMOOD', 'AQSA MAHMOOD', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('350', '20170807', '����췢[2017]106��', '1: ARIF 2: QASMANI 3: na 4: na', 'a) Muhammad Arif Qasmani; b) Muhammad Arif Qasmani; c) Mohammad Arif Qasmani; d) Arif Umer; e) Qasmani Baba; f) Memon Baba; g) Baba Ji', '02', 'ARIF QASMANI', 'ARIF QASMANI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('351', '20170807', '����췢[2017]106��', '1: ARIF 2: QASMANI 3: na 4: na', 'a) Muhammad Arif Qasmani; b) Muhammad Arif Qasmani; c) Mohammad Arif Qasmani; d) Arif Umer; e) Qasmani Baba; f) Memon Baba; g) Baba Ji', '04', 'Muhammad Arif Qasmani', 'MUHAMMAD ARIF QASMANI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('352', '20170807', '����췢[2017]106��', '1: ARIF 2: QASMANI 3: na 4: na', 'a) Muhammad Arif Qasmani; b) Muhammad Arif Qasmani; c) Mohammad Arif Qasmani; d) Arif Umer; e) Qasmani Baba; f) Memon Baba; g) Baba Ji', '04', 'Mohammad Arif Qasmani', 'MOHAMMAD ARIF QASMANI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('353', '20170807', '����췢[2017]106��', '1: ARIF 2: QASMANI 3: na 4: na', 'a) Muhammad Arif Qasmani; b) Muhammad Arif Qasmani; c) Mohammad Arif Qasmani; d) Arif Umer; e) Qasmani Baba; f) Memon Baba; g) Baba Ji', '04', 'Memon Baba', 'MEMON BABA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('354', '20170807', '����췢[2017]106��', '1: ARIF 2: QASMANI 3: na 4: na', 'a) Muhammad Arif Qasmani; b) Muhammad Arif Qasmani; c) Mohammad Arif Qasmani; d) Arif Umer; e) Qasmani Baba; f) Memon Baba; g) Baba Ji', '04', 'Arif Umer', 'ARIF UMER', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('355', '20170807', '����췢[2017]106��', '1: ARIF 2: QASMANI 3: na 4: na', 'a) Muhammad Arif Qasmani; b) Muhammad Arif Qasmani; c) Mohammad Arif Qasmani; d) Arif Umer; e) Qasmani Baba; f) Memon Baba; g) Baba Ji', '04', 'Qasmani Baba', 'QASMANI BABA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('356', '20170807', '����췢[2017]106��', '1: ARIF 2: QASMANI 3: na 4: na', 'a) Muhammad Arif Qasmani; b) Muhammad Arif Qasmani; c) Mohammad Arif Qasmani; d) Arif Umer; e) Qasmani Baba; f) Memon Baba; g) Baba Ji', '04', 'Muhammad Arif Qasmani', 'MUHAMMAD ARIF QASMANI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('357', '20170807', '����췢[2017]106��', '1: ARIF 2: QASMANI 3: na 4: na', 'a) Muhammad Arif Qasmani; b) Muhammad Arif Qasmani; c) Mohammad Arif Qasmani; d) Arif Umer; e) Qasmani Baba; f) Memon Baba; g) Baba Ji', '04', 'Baba Ji', 'BABA JI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('358', '20170807', '����췢[2017]106��', '1: ARIS 2: MUNANDAR 3: na 4: NA', null, '02', 'ARIS MUNANDAR', 'ARIS MUNANDAR', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('359', '20170807', '����췢[2017]106��', '1: ASEEL 2: MUTHANA 3: na 4: na', null, '02', 'ASEEL MUTHANA', 'ASEEL MUTHANA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('360', '20170807', '����췢[2017]106��', '1: ASHRAF 2: MUHAMMAD 3: YUSUF 4: ''UTHMAN ''ABD AL-SALAM', 'a) Ashraf Muhammad Yusif ''Uthman ''Abd-al-Salam; b) Ashraf Muhammad Yusuf ''Abd-al-Salam; c) Ashraf Muhammad Yusif ''Abd al-Salam', '02', 'ASHRAF MUHAMMAD', 'ASHRAF MUHAMMAD', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('361', '20170807', '����췢[2017]106��', '1: ASHRAF 2: MUHAMMAD 3: YUSUF 4: ''UTHMAN ''ABD AL-SALAM', 'a) Ashraf Muhammad Yusif ''Uthman ''Abd-al-Salam; b) Ashraf Muhammad Yusuf ''Abd-al-Salam; c) Ashraf Muhammad Yusif ''Abd al-Salam', '04', 'Ashraf Muhammad Yusuf ''Abd-al-Salam', 'ASHRAF MUHAMMAD YUSUF ''ABD-AL-SALAM', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('362', '20170807', '����췢[2017]106��', '1: ASHRAF 2: MUHAMMAD 3: YUSUF 4: ''UTHMAN ''ABD AL-SALAM', 'a) Ashraf Muhammad Yusif ''Uthman ''Abd-al-Salam; b) Ashraf Muhammad Yusuf ''Abd-al-Salam; c) Ashraf Muhammad Yusif ''Abd al-Salam', '04', 'Ashraf Muhammad Yusif ''Uthman ''Abd-al-Salam', 'ASHRAF MUHAMMAD YUSIF ''UTHMAN ''ABD-AL-SALAM', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('363', '20170807', '����췢[2017]106��', '1: ASHRAF 2: MUHAMMAD 3: YUSUF 4: ''UTHMAN ''ABD AL-SALAM', 'a) Ashraf Muhammad Yusif ''Uthman ''Abd-al-Salam; b) Ashraf Muhammad Yusuf ''Abd-al-Salam; c) Ashraf Muhammad Yusif ''Abd al-Salam', '04', 'Ashraf Muhammad Yusif ''Abd al-Salam', 'ASHRAF MUHAMMAD YUSIF ''ABD AL-SALAM', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('364', '20170807', '����췢[2017]106��', '1: ASLAN 2: AVGAZAROVICH 3: BYUTUKAEV 4: na', null, '02', 'ASLAN AVGAZAROVICH', 'ASLAN AVGAZAROVICH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('365', '20170807', '����췢[2017]106��', '1: AYRAT 2: NASIMOVICH 3: VAKHITOV 4: na', 'a) Salman Bulgarskiy', '02', 'AYRAT NASIMOVICH', 'AYRAT NASIMOVICH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('366', '20170807', '����췢[2017]106��', '1: AYRAT 2: NASIMOVICH 3: VAKHITOV 4: na', 'a) Salman Bulgarskiy', '03', 'Salman Bulgarskiy', 'SALMAN BULGARSKIY', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('367', '20170807', '����췢[2017]106��', '1: AYYUB 2: BASHIR 3: na 4: na', 'a) Alhaj Qari Ayub Bashar; b) Qari Muhammad Ayub', '02', 'AYYUB BASHIR', 'AYYUB BASHIR', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('368', '20170807', '����췢[2017]106��', '1: AYYUB 2: BASHIR 3: na 4: na', 'a) Alhaj Qari Ayub Bashar; b) Qari Muhammad Ayub', '04', 'Alhaj Qari Ayub Bashar', 'ALHAJ QARI AYUB BASHAR', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('369', '20170807', '����췢[2017]106��', '1: AYYUB 2: BASHIR 3: na 4: na', 'a) Alhaj Qari Ayub Bashar; b) Qari Muhammad Ayub', '04', 'Qari Muhammad Ayub', 'QARI MUHAMMAD AYUB', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('370', '20170807', '����췢[2017]106��', '1: AZZAM 2: ABDULLAH 3: ZUREIK 4: AL-MAULID AL-SUBHI', 'a) Mansur al-Harbi; b) Azzam al-Subhi; c) Azam Abdallah Razeeq al Mouled Alsbhua; d) Abu Muslem al-Maky; e) Abu Suliman al-Harbi; f) Abu Abdalla al-Harbi; g) Azam A.R. Alsbhua', '02', 'AZZAM ABDULLAH', 'AZZAM ABDULLAH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('371', '20170807', '����췢[2017]106��', '1: AZZAM 2: ABDULLAH 3: ZUREIK 4: AL-MAULID AL-SUBHI', 'a) Mansur al-Harbi; b) Azzam al-Subhi; c) Azam Abdallah Razeeq al Mouled Alsbhua; d) Abu Muslem al-Maky; e) Abu Suliman al-Harbi; f) Abu Abdalla al-Harbi; g) Azam A.R. Alsbhua', '04', 'Azam Abdallah Razeeq al Mouled Alsbhua', 'AZAM ABDALLAH RAZEEQ AL MOULED ALSBHUA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('372', '20170807', '����췢[2017]106��', '1: AZZAM 2: ABDULLAH 3: ZUREIK 4: AL-MAULID AL-SUBHI', 'a) Mansur al-Harbi; b) Azzam al-Subhi; c) Azam Abdallah Razeeq al Mouled Alsbhua; d) Abu Muslem al-Maky; e) Abu Suliman al-Harbi; f) Abu Abdalla al-Harbi; g) Azam A.R. Alsbhua', '04', 'Abu Suliman al-Harbi', 'ABU SULIMAN AL-HARBI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('373', '20170807', '����췢[2017]106��', '1: AZZAM 2: ABDULLAH 3: ZUREIK 4: AL-MAULID AL-SUBHI', 'a) Mansur al-Harbi; b) Azzam al-Subhi; c) Azam Abdallah Razeeq al Mouled Alsbhua; d) Abu Muslem al-Maky; e) Abu Suliman al-Harbi; f) Abu Abdalla al-Harbi; g) Azam A.R. Alsbhua', '04', 'Abu Muslem al-Maky', 'ABU MUSLEM AL-MAKY', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('374', '20170807', '����췢[2017]106��', '1: AZZAM 2: ABDULLAH 3: ZUREIK 4: AL-MAULID AL-SUBHI', 'a) Mansur al-Harbi; b) Azzam al-Subhi; c) Azam Abdallah Razeeq al Mouled Alsbhua; d) Abu Muslem al-Maky; e) Abu Suliman al-Harbi; f) Abu Abdalla al-Harbi; g) Azam A.R. Alsbhua', '04', 'Azam A.R. Alsbhua', 'AZAM A.R. ALSBHUA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('375', '20170807', '����췢[2017]106��', '1: AZZAM 2: ABDULLAH 3: ZUREIK 4: AL-MAULID AL-SUBHI', 'a) Mansur al-Harbi; b) Azzam al-Subhi; c) Azam Abdallah Razeeq al Mouled Alsbhua; d) Abu Muslem al-Maky; e) Abu Suliman al-Harbi; f) Abu Abdalla al-Harbi; g) Azam A.R. Alsbhua', '04', 'Mansur al-Harbi', 'MANSUR AL-HARBI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('376', '20170807', '����췢[2017]106��', '1: AZZAM 2: ABDULLAH 3: ZUREIK 4: AL-MAULID AL-SUBHI', 'a) Mansur al-Harbi; b) Azzam al-Subhi; c) Azam Abdallah Razeeq al Mouled Alsbhua; d) Abu Muslem al-Maky; e) Abu Suliman al-Harbi; f) Abu Abdalla al-Harbi; g) Azam A.R. Alsbhua', '04', 'Azzam al-Subhi', 'AZZAM AL-SUBHI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('377', '20170807', '����췢[2017]106��', '1: AZZAM 2: ABDULLAH 3: ZUREIK 4: AL-MAULID AL-SUBHI', 'a) Mansur al-Harbi; b) Azzam al-Subhi; c) Azam Abdallah Razeeq al Mouled Alsbhua; d) Abu Muslem al-Maky; e) Abu Suliman al-Harbi; f) Abu Abdalla al-Harbi; g) Azam A.R. Alsbhua', '04', 'Abu Abdalla al-Harbi', 'ABU ABDALLA AL-HARBI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('378', '20170807', '����췢[2017]106��', '1: BAMBANG 2: SUKIRNO 3: na 4: na', null, '02', 'BAMBANG SUKIRNO', 'BAMBANG SUKIRNO', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('379', '20170807', '����췢[2017]106��', '1: BASSAM 2: AHMAD 3: AL-HASRI 4: na', 'a) Bassam Ahmad Husari', '02', 'BASSAM AHMAD', 'BASSAM AHMAD', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('380', '20170807', '����췢[2017]106��', '1: BASSAM 2: AHMAD 3: AL-HASRI 4: na', 'a) Bassam Ahmad Husari', '03', 'Bassam Ahmad Husari', 'BASSAM AHMAD HUSARI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('381', '20170807', '����췢[2017]106��', '1: BILAL 2: BIN MARWAN 3: na 4: na', null, '02', 'BILAL BIN MARWAN', 'BILAL BIN MARWAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('382', '20170807', '����췢[2017]106��', '1: BOUBAKER 2: BEN HABIB 3: BEN AL-HAKIM 4: na', 'a) Boubakeur el-Hakim; b) Boubaker el Hakim', '02', 'BOUBAKER BEN HABIB', 'BOUBAKER BEN HABIB', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('383', '20170807', '����췢[2017]106��', '1: BOUBAKER 2: BEN HABIB 3: BEN AL-HAKIM 4: na', 'a) Boubakeur el-Hakim; b) Boubaker el Hakim', '04', 'Boubakeur el-Hakim', 'BOUBAKEUR EL-HAKIM', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('384', '20170807', '����췢[2017]106��', '1: BOUBAKER 2: BEN HABIB 3: BEN AL-HAKIM 4: na', 'a) Boubakeur el-Hakim; b) Boubaker el Hakim', '04', 'Boubaker el Hakim', 'BOUBAKER EL HAKIM', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('385', '20170807', '����췢[2017]106��', '1: DAWOOD 2: IBRAHIM 3: KASKAR 4: na', 'a) Dawood Ebrahim; b) Sheikh Dawood Hassan; c) Abdul Hamis Abdul Aziz; d) Anis Ibrahim; e) Aziz Dilip; f) Daud Hasan Shaikh Ibrahim Kaskar; g) Daud Ibrahim Memon Kaskar; h) Dawood Hasan Ibrahim Kaskar; i) Dawood Ibrahim Memon; j) Dawood Sabri; k) Kaskar Dawood Hasan; l) Shaikh Mohd Ismail Abdul Rehman; m) Dowood Hassam Shaikh Ibrahim; n) Dawood Bhai', '02', 'DAWOOD IBRAHIM', 'DAWOOD IBRAHIM', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('386', '20170807', '����췢[2017]106��', '1: DAWOOD 2: IBRAHIM 3: KASKAR 4: na', 'a) Dawood Ebrahim; b) Sheikh Dawood Hassan; c) Abdul Hamis Abdul Aziz; d) Anis Ibrahim; e) Aziz Dilip; f) Daud Hasan Shaikh Ibrahim Kaskar; g) Daud Ibrahim Memon Kaskar; h) Dawood Hasan Ibrahim Kaskar; i) Dawood Ibrahim Memon; j) Dawood Sabri; k) Kaskar Dawood Hasan; l) Shaikh Mohd Ismail Abdul Rehman; m) Dowood Hassam Shaikh Ibrahim; n) Dawood Bhai', '04', 'Dawood Ebrahim', 'DAWOOD EBRAHIM', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('387', '20170807', '����췢[2017]106��', '1: DAWOOD 2: IBRAHIM 3: KASKAR 4: na', 'a) Dawood Ebrahim; b) Sheikh Dawood Hassan; c) Abdul Hamis Abdul Aziz; d) Anis Ibrahim; e) Aziz Dilip; f) Daud Hasan Shaikh Ibrahim Kaskar; g) Daud Ibrahim Memon Kaskar; h) Dawood Hasan Ibrahim Kaskar; i) Dawood Ibrahim Memon; j) Dawood Sabri; k) Kaskar Dawood Hasan; l) Shaikh Mohd Ismail Abdul Rehman; m) Dowood Hassam Shaikh Ibrahim; n) Dawood Bhai', '04', 'Shaikh Mohd Ismail Abdul Rehman', 'SHAIKH MOHD ISMAIL ABDUL REHMAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('388', '20170807', '����췢[2017]106��', '1: DAWOOD 2: IBRAHIM 3: KASKAR 4: na', 'a) Dawood Ebrahim; b) Sheikh Dawood Hassan; c) Abdul Hamis Abdul Aziz; d) Anis Ibrahim; e) Aziz Dilip; f) Daud Hasan Shaikh Ibrahim Kaskar; g) Daud Ibrahim Memon Kaskar; h) Dawood Hasan Ibrahim Kaskar; i) Dawood Ibrahim Memon; j) Dawood Sabri; k) Kaskar Dawood Hasan; l) Shaikh Mohd Ismail Abdul Rehman; m) Dowood Hassam Shaikh Ibrahim; n) Dawood Bhai', '04', 'Kaskar Dawood Hasan', 'KASKAR DAWOOD HASAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('389', '20170807', '����췢[2017]106��', '1: DAWOOD 2: IBRAHIM 3: KASKAR 4: na', 'a) Dawood Ebrahim; b) Sheikh Dawood Hassan; c) Abdul Hamis Abdul Aziz; d) Anis Ibrahim; e) Aziz Dilip; f) Daud Hasan Shaikh Ibrahim Kaskar; g) Daud Ibrahim Memon Kaskar; h) Dawood Hasan Ibrahim Kaskar; i) Dawood Ibrahim Memon; j) Dawood Sabri; k) Kaskar Dawood Hasan; l) Shaikh Mohd Ismail Abdul Rehman; m) Dowood Hassam Shaikh Ibrahim; n) Dawood Bhai', '04', 'Dawood Ibrahim Memon', 'DAWOOD IBRAHIM MEMON', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('390', '20170807', '����췢[2017]106��', '1: DAWOOD 2: IBRAHIM 3: KASKAR 4: na', 'a) Dawood Ebrahim; b) Sheikh Dawood Hassan; c) Abdul Hamis Abdul Aziz; d) Anis Ibrahim; e) Aziz Dilip; f) Daud Hasan Shaikh Ibrahim Kaskar; g) Daud Ibrahim Memon Kaskar; h) Dawood Hasan Ibrahim Kaskar; i) Dawood Ibrahim Memon; j) Dawood Sabri; k) Kaskar Dawood Hasan; l) Shaikh Mohd Ismail Abdul Rehman; m) Dowood Hassam Shaikh Ibrahim; n) Dawood Bhai', '04', 'Dawood Bhai', 'DAWOOD BHAI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('391', '20170807', '����췢[2017]106��', '1: DAWOOD 2: IBRAHIM 3: KASKAR 4: na', 'a) Dawood Ebrahim; b) Sheikh Dawood Hassan; c) Abdul Hamis Abdul Aziz; d) Anis Ibrahim; e) Aziz Dilip; f) Daud Hasan Shaikh Ibrahim Kaskar; g) Daud Ibrahim Memon Kaskar; h) Dawood Hasan Ibrahim Kaskar; i) Dawood Ibrahim Memon; j) Dawood Sabri; k) Kaskar Dawood Hasan; l) Shaikh Mohd Ismail Abdul Rehman; m) Dowood Hassam Shaikh Ibrahim; n) Dawood Bhai', '04', 'Dowood Hassam Shaikh Ibrahim', 'DOWOOD HASSAM SHAIKH IBRAHIM', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('392', '20170807', '����췢[2017]106��', '1: DAWOOD 2: IBRAHIM 3: KASKAR 4: na', 'a) Dawood Ebrahim; b) Sheikh Dawood Hassan; c) Abdul Hamis Abdul Aziz; d) Anis Ibrahim; e) Aziz Dilip; f) Daud Hasan Shaikh Ibrahim Kaskar; g) Daud Ibrahim Memon Kaskar; h) Dawood Hasan Ibrahim Kaskar; i) Dawood Ibrahim Memon; j) Dawood Sabri; k) Kaskar Dawood Hasan; l) Shaikh Mohd Ismail Abdul Rehman; m) Dowood Hassam Shaikh Ibrahim; n) Dawood Bhai', '04', 'Sheikh Dawood Hassan', 'SHEIKH DAWOOD HASSAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('393', '20170807', '����췢[2017]106��', '1: DAWOOD 2: IBRAHIM 3: KASKAR 4: na', 'a) Dawood Ebrahim; b) Sheikh Dawood Hassan; c) Abdul Hamis Abdul Aziz; d) Anis Ibrahim; e) Aziz Dilip; f) Daud Hasan Shaikh Ibrahim Kaskar; g) Daud Ibrahim Memon Kaskar; h) Dawood Hasan Ibrahim Kaskar; i) Dawood Ibrahim Memon; j) Dawood Sabri; k) Kaskar Dawood Hasan; l) Shaikh Mohd Ismail Abdul Rehman; m) Dowood Hassam Shaikh Ibrahim; n) Dawood Bhai', '04', 'Dawood Sabri', 'DAWOOD SABRI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('394', '20170807', '����췢[2017]106��', '1: DAWOOD 2: IBRAHIM 3: KASKAR 4: na', 'a) Dawood Ebrahim; b) Sheikh Dawood Hassan; c) Abdul Hamis Abdul Aziz; d) Anis Ibrahim; e) Aziz Dilip; f) Daud Hasan Shaikh Ibrahim Kaskar; g) Daud Ibrahim Memon Kaskar; h) Dawood Hasan Ibrahim Kaskar; i) Dawood Ibrahim Memon; j) Dawood Sabri; k) Kaskar Dawood Hasan; l) Shaikh Mohd Ismail Abdul Rehman; m) Dowood Hassam Shaikh Ibrahim; n) Dawood Bhai', '04', 'Dawood Hasan Ibrahim Kaskar', 'DAWOOD HASAN IBRAHIM KASKAR', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('395', '20170807', '����췢[2017]106��', '1: DAWOOD 2: IBRAHIM 3: KASKAR 4: na', 'a) Dawood Ebrahim; b) Sheikh Dawood Hassan; c) Abdul Hamis Abdul Aziz; d) Anis Ibrahim; e) Aziz Dilip; f) Daud Hasan Shaikh Ibrahim Kaskar; g) Daud Ibrahim Memon Kaskar; h) Dawood Hasan Ibrahim Kaskar; i) Dawood Ibrahim Memon; j) Dawood Sabri; k) Kaskar Dawood Hasan; l) Shaikh Mohd Ismail Abdul Rehman; m) Dowood Hassam Shaikh Ibrahim; n) Dawood Bhai', '04', 'Daud Ibrahim Memon Kaskar', 'DAUD IBRAHIM MEMON KASKAR', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('396', '20170807', '����췢[2017]106��', '1: DAWOOD 2: IBRAHIM 3: KASKAR 4: na', 'a) Dawood Ebrahim; b) Sheikh Dawood Hassan; c) Abdul Hamis Abdul Aziz; d) Anis Ibrahim; e) Aziz Dilip; f) Daud Hasan Shaikh Ibrahim Kaskar; g) Daud Ibrahim Memon Kaskar; h) Dawood Hasan Ibrahim Kaskar; i) Dawood Ibrahim Memon; j) Dawood Sabri; k) Kaskar Dawood Hasan; l) Shaikh Mohd Ismail Abdul Rehman; m) Dowood Hassam Shaikh Ibrahim; n) Dawood Bhai', '04', 'Daud Hasan Shaikh Ibrahim Kaskar', 'DAUD HASAN SHAIKH IBRAHIM KASKAR', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('397', '20170807', '����췢[2017]106��', '1: DAWOOD 2: IBRAHIM 3: KASKAR 4: na', 'a) Dawood Ebrahim; b) Sheikh Dawood Hassan; c) Abdul Hamis Abdul Aziz; d) Anis Ibrahim; e) Aziz Dilip; f) Daud Hasan Shaikh Ibrahim Kaskar; g) Daud Ibrahim Memon Kaskar; h) Dawood Hasan Ibrahim Kaskar; i) Dawood Ibrahim Memon; j) Dawood Sabri; k) Kaskar Dawood Hasan; l) Shaikh Mohd Ismail Abdul Rehman; m) Dowood Hassam Shaikh Ibrahim; n) Dawood Bhai', '04', 'Aziz Dilip', 'AZIZ DILIP', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('398', '20170807', '����췢[2017]106��', '1: DAWOOD 2: IBRAHIM 3: KASKAR 4: na', 'a) Dawood Ebrahim; b) Sheikh Dawood Hassan; c) Abdul Hamis Abdul Aziz; d) Anis Ibrahim; e) Aziz Dilip; f) Daud Hasan Shaikh Ibrahim Kaskar; g) Daud Ibrahim Memon Kaskar; h) Dawood Hasan Ibrahim Kaskar; i) Dawood Ibrahim Memon; j) Dawood Sabri; k) Kaskar Dawood Hasan; l) Shaikh Mohd Ismail Abdul Rehman; m) Dowood Hassam Shaikh Ibrahim; n) Dawood Bhai', '04', 'Anis Ibrahim', 'ANIS IBRAHIM', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('399', '20170807', '����췢[2017]106��', '1: DAWOOD 2: IBRAHIM 3: KASKAR 4: na', 'a) Dawood Ebrahim; b) Sheikh Dawood Hassan; c) Abdul Hamis Abdul Aziz; d) Anis Ibrahim; e) Aziz Dilip; f) Daud Hasan Shaikh Ibrahim Kaskar; g) Daud Ibrahim Memon Kaskar; h) Dawood Hasan Ibrahim Kaskar; i) Dawood Ibrahim Memon; j) Dawood Sabri; k) Kaskar Dawood Hasan; l) Shaikh Mohd Ismail Abdul Rehman; m) Dowood Hassam Shaikh Ibrahim; n) Dawood Bhai', '04', 'Abdul Hamis Abdul Aziz', 'ABDUL HAMIS ABDUL AZIZ', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('400', '20170807', '����췢[2017]106��', '1: DENIS 2: MAMADOU 3: GERHARD 4: CUSPERT', null, '02', 'DENIS MAMADOU', 'DENIS MAMADOU', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('401', '20170807', '����췢[2017]106��', '1: DHOU 2: EL-AICH 3: na 4: na', 'a) Abdel Hak', '02', 'DHOU EL-AICH', 'DHOU EL-AICH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('402', '20170807', '����췢[2017]106��', '1: DHOU 2: EL-AICH 3: na 4: na', 'a) Abdel Hak', '03', 'Abdel Hak', 'ABDEL HAK', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('403', '20170807', '����췢[2017]106��', '1: DINNO AMOR 2: ROSALEJOS 3: PAREJA 4: na', 'a) Johnny Pareja; b) Khalil Pareja', '02', 'DINNO AMOR ROSALEJOS', 'DINNO AMOR ROSALEJOS', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('404', '20170807', '����췢[2017]106��', '1: DINNO AMOR 2: ROSALEJOS 3: PAREJA 4: na', 'a) Johnny Pareja; b) Khalil Pareja', '04', 'Johnny Pareja', 'JOHNNY PAREJA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('405', '20170807', '����췢[2017]106��', '1: DINNO AMOR 2: ROSALEJOS 3: PAREJA 4: na', 'a) Johnny Pareja; b) Khalil Pareja', '04', 'Khalil Pareja', 'KHALIL PAREJA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('406', '20170807', '����췢[2017]106��', '1: DJAMEL 2: AKKACHA 3: na 4: na', 'a) Yahia Abou el Hoummam; b) Yahia Abou el Hammam', '02', 'DJAMEL AKKACHA', 'DJAMEL AKKACHA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('407', '20170807', '����췢[2017]106��', '1: DJAMEL 2: AKKACHA 3: na 4: na', 'a) Yahia Abou el Hoummam; b) Yahia Abou el Hammam', '04', 'Yahia Abou el Hoummam', 'YAHIA ABOU EL HOUMMAM', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('408', '20170807', '����췢[2017]106��', '1: DJAMEL 2: AKKACHA 3: na 4: na', 'a) Yahia Abou el Hoummam; b) Yahia Abou el Hammam', '04', 'Yahia Abou el Hammam', 'YAHIA ABOU EL HAMMAM', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('409', '20170807', '����췢[2017]106��', '1: DJAMEL 2: LOUNICI 3: na 4: na', 'a) Jamal Lounici', '02', 'DJAMEL LOUNICI', 'DJAMEL LOUNICI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('410', '20170807', '����췢[2017]106��', '1: DJAMEL 2: LOUNICI 3: na 4: na', 'a) Jamal Lounici', '03', 'Jamal Lounici', 'JAMAL LOUNICI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('411', '20170807', '����췢[2017]106��', '1: DJAMEL 2: MOUSTFA 3: na 4: na', 'a) Kalad Belkasam born 31 Dec. 1979; b) Mostafa Djamel born 31 Dec. 1979 in Maskara, Algeria; c) Mostefa Djamel born 26 Sep. 1973 in Mahdia, Algeria; d) Mustafa Djamel born 31 Dec. 1979 in Mascara, Algeria; e) Balkasam Kalad born 26 Aug. 1973 in Algiers, Algeria; f) Bekasam Kalad born 26 Aug. 1973 in Algiers, Algeria; g) Belkasam Kalad born 26 Aug. 1973 in Algiers, Algeria; h) Damel Mostafa born 31 Dec. 1979 in ALgiers, Algeria; i) Djamal Mostafa born 31 Dec. 1979 in Maskara, Algeria; j) Djamal Mostafa born 10 Jun. 1982; k) Djamel Mostafa born 31 Dec. 1979 in Maskara, Algeria; l) Djamel Mostafa born 31 Dec. 1979 in Algiers, Algeria; m) Fjamel Moustfa born 28 Sep. 1973 in Tiaret Algeria; n) Djamel Mustafa born 31 Dec. 1979; o) Ali Barkani born 22 Aug. 1973 in Morocco; p) Djamel Mustafa born 31 Dec. 1979 in Mascara, Algeria', '02', 'DJAMEL MOUSTFA', 'DJAMEL MOUSTFA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('412', '20170807', '����췢[2017]106��', '1: DJAMEL 2: MOUSTFA 3: na 4: na', 'a) Kalad Belkasam born 31 Dec. 1979; b) Mostafa Djamel born 31 Dec. 1979 in Maskara, Algeria; c) Mostefa Djamel born 26 Sep. 1973 in Mahdia, Algeria; d) Mustafa Djamel born 31 Dec. 1979 in Mascara, Algeria; e) Balkasam Kalad born 26 Aug. 1973 in Algiers, Algeria; f) Bekasam Kalad born 26 Aug. 1973 in Algiers, Algeria; g) Belkasam Kalad born 26 Aug. 1973 in Algiers, Algeria; h) Damel Mostafa born 31 Dec. 1979 in ALgiers, Algeria; i) Djamal Mostafa born 31 Dec. 1979 in Maskara, Algeria; j) Djamal Mostafa born 10 Jun. 1982; k) Djamel Mostafa born 31 Dec. 1979 in Maskara, Algeria; l) Djamel Mostafa born 31 Dec. 1979 in Algiers, Algeria; m) Fjamel Moustfa born 28 Sep. 1973 in Tiaret Algeria; n) Djamel Mustafa born 31 Dec. 1979; o) Ali Barkani born 22 Aug. 1973 in Morocco; p) Djamel Mustafa born 31 Dec. 1979 in Mascara, Algeria', '04', 'Balkasam Kalad', 'BALKASAM KALAD', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('413', '20170807', '����췢[2017]106��', '1: DJAMEL 2: MOUSTFA 3: na 4: na', 'a) Kalad Belkasam born 31 Dec. 1979; b) Mostafa Djamel born 31 Dec. 1979 in Maskara, Algeria; c) Mostefa Djamel born 26 Sep. 1973 in Mahdia, Algeria; d) Mustafa Djamel born 31 Dec. 1979 in Mascara, Algeria; e) Balkasam Kalad born 26 Aug. 1973 in Algiers, Algeria; f) Bekasam Kalad born 26 Aug. 1973 in Algiers, Algeria; g) Belkasam Kalad born 26 Aug. 1973 in Algiers, Algeria; h) Damel Mostafa born 31 Dec. 1979 in ALgiers, Algeria; i) Djamal Mostafa born 31 Dec. 1979 in Maskara, Algeria; j) Djamal Mostafa born 10 Jun. 1982; k) Djamel Mostafa born 31 Dec. 1979 in Maskara, Algeria; l) Djamel Mostafa born 31 Dec. 1979 in Algiers, Algeria; m) Fjamel Moustfa born 28 Sep. 1973 in Tiaret Algeria; n) Djamel Mustafa born 31 Dec. 1979; o) Ali Barkani born 22 Aug. 1973 in Morocco; p) Djamel Mustafa born 31 Dec. 1979 in Mascara, Algeria', '04', 'Bekasam Kalad', 'BEKASAM KALAD', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('414', '20170807', '����췢[2017]106��', '1: DJAMEL 2: MOUSTFA 3: na 4: na', 'a) Kalad Belkasam born 31 Dec. 1979; b) Mostafa Djamel born 31 Dec. 1979 in Maskara, Algeria; c) Mostefa Djamel born 26 Sep. 1973 in Mahdia, Algeria; d) Mustafa Djamel born 31 Dec. 1979 in Mascara, Algeria; e) Balkasam Kalad born 26 Aug. 1973 in Algiers, Algeria; f) Bekasam Kalad born 26 Aug. 1973 in Algiers, Algeria; g) Belkasam Kalad born 26 Aug. 1973 in Algiers, Algeria; h) Damel Mostafa born 31 Dec. 1979 in ALgiers, Algeria; i) Djamal Mostafa born 31 Dec. 1979 in Maskara, Algeria; j) Djamal Mostafa born 10 Jun. 1982; k) Djamel Mostafa born 31 Dec. 1979 in Maskara, Algeria; l) Djamel Mostafa born 31 Dec. 1979 in Algiers, Algeria; m) Fjamel Moustfa born 28 Sep. 1973 in Tiaret Algeria; n) Djamel Mustafa born 31 Dec. 1979; o) Ali Barkani born 22 Aug. 1973 in Morocco; p) Djamel Mustafa born 31 Dec. 1979 in Mascara, Algeria', '04', 'Belkasam Kalad', 'BELKASAM KALAD', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('415', '20170807', '����췢[2017]106��', '1: DJAMEL 2: MOUSTFA 3: na 4: na', 'a) Kalad Belkasam born 31 Dec. 1979; b) Mostafa Djamel born 31 Dec. 1979 in Maskara, Algeria; c) Mostefa Djamel born 26 Sep. 1973 in Mahdia, Algeria; d) Mustafa Djamel born 31 Dec. 1979 in Mascara, Algeria; e) Balkasam Kalad born 26 Aug. 1973 in Algiers, Algeria; f) Bekasam Kalad born 26 Aug. 1973 in Algiers, Algeria; g) Belkasam Kalad born 26 Aug. 1973 in Algiers, Algeria; h) Damel Mostafa born 31 Dec. 1979 in ALgiers, Algeria; i) Djamal Mostafa born 31 Dec. 1979 in Maskara, Algeria; j) Djamal Mostafa born 10 Jun. 1982; k) Djamel Mostafa born 31 Dec. 1979 in Maskara, Algeria; l) Djamel Mostafa born 31 Dec. 1979 in Algiers, Algeria; m) Fjamel Moustfa born 28 Sep. 1973 in Tiaret Algeria; n) Djamel Mustafa born 31 Dec. 1979; o) Ali Barkani born 22 Aug. 1973 in Morocco; p) Djamel Mustafa born 31 Dec. 1979 in Mascara, Algeria', '04', 'Damel Mostafa', 'DAMEL MOSTAFA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('416', '20170807', '����췢[2017]106��', '1: DJAMEL 2: MOUSTFA 3: na 4: na', 'a) Kalad Belkasam born 31 Dec. 1979; b) Mostafa Djamel born 31 Dec. 1979 in Maskara, Algeria; c) Mostefa Djamel born 26 Sep. 1973 in Mahdia, Algeria; d) Mustafa Djamel born 31 Dec. 1979 in Mascara, Algeria; e) Balkasam Kalad born 26 Aug. 1973 in Algiers, Algeria; f) Bekasam Kalad born 26 Aug. 1973 in Algiers, Algeria; g) Belkasam Kalad born 26 Aug. 1973 in Algiers, Algeria; h) Damel Mostafa born 31 Dec. 1979 in ALgiers, Algeria; i) Djamal Mostafa born 31 Dec. 1979 in Maskara, Algeria; j) Djamal Mostafa born 10 Jun. 1982; k) Djamel Mostafa born 31 Dec. 1979 in Maskara, Algeria; l) Djamel Mostafa born 31 Dec. 1979 in Algiers, Algeria; m) Fjamel Moustfa born 28 Sep. 1973 in Tiaret Algeria; n) Djamel Mustafa born 31 Dec. 1979; o) Ali Barkani born 22 Aug. 1973 in Morocco; p) Djamel Mustafa born 31 Dec. 1979 in Mascara, Algeria', '04', 'Djamal Mostafa', 'DJAMAL MOSTAFA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('417', '20170807', '����췢[2017]106��', '1: DJAMEL 2: MOUSTFA 3: na 4: na', 'a) Kalad Belkasam born 31 Dec. 1979; b) Mostafa Djamel born 31 Dec. 1979 in Maskara, Algeria; c) Mostefa Djamel born 26 Sep. 1973 in Mahdia, Algeria; d) Mustafa Djamel born 31 Dec. 1979 in Mascara, Algeria; e) Balkasam Kalad born 26 Aug. 1973 in Algiers, Algeria; f) Bekasam Kalad born 26 Aug. 1973 in Algiers, Algeria; g) Belkasam Kalad born 26 Aug. 1973 in Algiers, Algeria; h) Damel Mostafa born 31 Dec. 1979 in ALgiers, Algeria; i) Djamal Mostafa born 31 Dec. 1979 in Maskara, Algeria; j) Djamal Mostafa born 10 Jun. 1982; k) Djamel Mostafa born 31 Dec. 1979 in Maskara, Algeria; l) Djamel Mostafa born 31 Dec. 1979 in Algiers, Algeria; m) Fjamel Moustfa born 28 Sep. 1973 in Tiaret Algeria; n) Djamel Mustafa born 31 Dec. 1979; o) Ali Barkani born 22 Aug. 1973 in Morocco; p) Djamel Mustafa born 31 Dec. 1979 in Mascara, Algeria', '04', 'Djamal Mostafa', 'DJAMAL MOSTAFA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('418', '20170807', '����췢[2017]106��', '1: DJAMEL 2: MOUSTFA 3: na 4: na', 'a) Kalad Belkasam born 31 Dec. 1979; b) Mostafa Djamel born 31 Dec. 1979 in Maskara, Algeria; c) Mostefa Djamel born 26 Sep. 1973 in Mahdia, Algeria; d) Mustafa Djamel born 31 Dec. 1979 in Mascara, Algeria; e) Balkasam Kalad born 26 Aug. 1973 in Algiers, Algeria; f) Bekasam Kalad born 26 Aug. 1973 in Algiers, Algeria; g) Belkasam Kalad born 26 Aug. 1973 in Algiers, Algeria; h) Damel Mostafa born 31 Dec. 1979 in ALgiers, Algeria; i) Djamal Mostafa born 31 Dec. 1979 in Maskara, Algeria; j) Djamal Mostafa born 10 Jun. 1982; k) Djamel Mostafa born 31 Dec. 1979 in Maskara, Algeria; l) Djamel Mostafa born 31 Dec. 1979 in Algiers, Algeria; m) Fjamel Moustfa born 28 Sep. 1973 in Tiaret Algeria; n) Djamel Mustafa born 31 Dec. 1979; o) Ali Barkani born 22 Aug. 1973 in Morocco; p) Djamel Mustafa born 31 Dec. 1979 in Mascara, Algeria', '04', 'Mustafa Djamel', 'MUSTAFA DJAMEL', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('419', '20170807', '����췢[2017]106��', '1: DJAMEL 2: MOUSTFA 3: na 4: na', 'a) Kalad Belkasam born 31 Dec. 1979; b) Mostafa Djamel born 31 Dec. 1979 in Maskara, Algeria; c) Mostefa Djamel born 26 Sep. 1973 in Mahdia, Algeria; d) Mustafa Djamel born 31 Dec. 1979 in Mascara, Algeria; e) Balkasam Kalad born 26 Aug. 1973 in Algiers, Algeria; f) Bekasam Kalad born 26 Aug. 1973 in Algiers, Algeria; g) Belkasam Kalad born 26 Aug. 1973 in Algiers, Algeria; h) Damel Mostafa born 31 Dec. 1979 in ALgiers, Algeria; i) Djamal Mostafa born 31 Dec. 1979 in Maskara, Algeria; j) Djamal Mostafa born 10 Jun. 1982; k) Djamel Mostafa born 31 Dec. 1979 in Maskara, Algeria; l) Djamel Mostafa born 31 Dec. 1979 in Algiers, Algeria; m) Fjamel Moustfa born 28 Sep. 1973 in Tiaret Algeria; n) Djamel Mustafa born 31 Dec. 1979; o) Ali Barkani born 22 Aug. 1973 in Morocco; p) Djamel Mustafa born 31 Dec. 1979 in Mascara, Algeria', '04', 'Mostefa Djamel', 'MOSTEFA DJAMEL', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('420', '20170807', '����췢[2017]106��', '1: DJAMEL 2: MOUSTFA 3: na 4: na', 'a) Kalad Belkasam born 31 Dec. 1979; b) Mostafa Djamel born 31 Dec. 1979 in Maskara, Algeria; c) Mostefa Djamel born 26 Sep. 1973 in Mahdia, Algeria; d) Mustafa Djamel born 31 Dec. 1979 in Mascara, Algeria; e) Balkasam Kalad born 26 Aug. 1973 in Algiers, Algeria; f) Bekasam Kalad born 26 Aug. 1973 in Algiers, Algeria; g) Belkasam Kalad born 26 Aug. 1973 in Algiers, Algeria; h) Damel Mostafa born 31 Dec. 1979 in ALgiers, Algeria; i) Djamal Mostafa born 31 Dec. 1979 in Maskara, Algeria; j) Djamal Mostafa born 10 Jun. 1982; k) Djamel Mostafa born 31 Dec. 1979 in Maskara, Algeria; l) Djamel Mostafa born 31 Dec. 1979 in Algiers, Algeria; m) Fjamel Moustfa born 28 Sep. 1973 in Tiaret Algeria; n) Djamel Mustafa born 31 Dec. 1979; o) Ali Barkani born 22 Aug. 1973 in Morocco; p) Djamel Mustafa born 31 Dec. 1979 in Mascara, Algeria', '04', 'Mostafa Djamel', 'MOSTAFA DJAMEL', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('421', '20170807', '����췢[2017]106��', '1: DJAMEL 2: MOUSTFA 3: na 4: na', 'a) Kalad Belkasam born 31 Dec. 1979; b) Mostafa Djamel born 31 Dec. 1979 in Maskara, Algeria; c) Mostefa Djamel born 26 Sep. 1973 in Mahdia, Algeria; d) Mustafa Djamel born 31 Dec. 1979 in Mascara, Algeria; e) Balkasam Kalad born 26 Aug. 1973 in Algiers, Algeria; f) Bekasam Kalad born 26 Aug. 1973 in Algiers, Algeria; g) Belkasam Kalad born 26 Aug. 1973 in Algiers, Algeria; h) Damel Mostafa born 31 Dec. 1979 in ALgiers, Algeria; i) Djamal Mostafa born 31 Dec. 1979 in Maskara, Algeria; j) Djamal Mostafa born 10 Jun. 1982; k) Djamel Mostafa born 31 Dec. 1979 in Maskara, Algeria; l) Djamel Mostafa born 31 Dec. 1979 in Algiers, Algeria; m) Fjamel Moustfa born 28 Sep. 1973 in Tiaret Algeria; n) Djamel Mustafa born 31 Dec. 1979; o) Ali Barkani born 22 Aug. 1973 in Morocco; p) Djamel Mustafa born 31 Dec. 1979 in Mascara, Algeria', '04', 'Kalad Belkasam', 'KALAD BELKASAM', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('422', '20170807', '����췢[2017]106��', '1: DJAMEL 2: MOUSTFA 3: na 4: na', 'a) Kalad Belkasam born 31 Dec. 1979; b) Mostafa Djamel born 31 Dec. 1979 in Maskara, Algeria; c) Mostefa Djamel born 26 Sep. 1973 in Mahdia, Algeria; d) Mustafa Djamel born 31 Dec. 1979 in Mascara, Algeria; e) Balkasam Kalad born 26 Aug. 1973 in Algiers, Algeria; f) Bekasam Kalad born 26 Aug. 1973 in Algiers, Algeria; g) Belkasam Kalad born 26 Aug. 1973 in Algiers, Algeria; h) Damel Mostafa born 31 Dec. 1979 in ALgiers, Algeria; i) Djamal Mostafa born 31 Dec. 1979 in Maskara, Algeria; j) Djamal Mostafa born 10 Jun. 1982; k) Djamel Mostafa born 31 Dec. 1979 in Maskara, Algeria; l) Djamel Mostafa born 31 Dec. 1979 in Algiers, Algeria; m) Fjamel Moustfa born 28 Sep. 1973 in Tiaret Algeria; n) Djamel Mustafa born 31 Dec. 1979; o) Ali Barkani born 22 Aug. 1973 in Morocco; p) Djamel Mustafa born 31 Dec. 1979 in Mascara, Algeria', '04', 'Djamel Mostafa', 'DJAMEL MOSTAFA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('423', '20170807', '����췢[2017]106��', '1: DJAMEL 2: MOUSTFA 3: na 4: na', 'a) Kalad Belkasam born 31 Dec. 1979; b) Mostafa Djamel born 31 Dec. 1979 in Maskara, Algeria; c) Mostefa Djamel born 26 Sep. 1973 in Mahdia, Algeria; d) Mustafa Djamel born 31 Dec. 1979 in Mascara, Algeria; e) Balkasam Kalad born 26 Aug. 1973 in Algiers, Algeria; f) Bekasam Kalad born 26 Aug. 1973 in Algiers, Algeria; g) Belkasam Kalad born 26 Aug. 1973 in Algiers, Algeria; h) Damel Mostafa born 31 Dec. 1979 in ALgiers, Algeria; i) Djamal Mostafa born 31 Dec. 1979 in Maskara, Algeria; j) Djamal Mostafa born 10 Jun. 1982; k) Djamel Mostafa born 31 Dec. 1979 in Maskara, Algeria; l) Djamel Mostafa born 31 Dec. 1979 in Algiers, Algeria; m) Fjamel Moustfa born 28 Sep. 1973 in Tiaret Algeria; n) Djamel Mustafa born 31 Dec. 1979; o) Ali Barkani born 22 Aug. 1973 in Morocco; p) Djamel Mustafa born 31 Dec. 1979 in Mascara, Algeria', '04', 'Djamel Mostafa', 'DJAMEL MOSTAFA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('424', '20170807', '����췢[2017]106��', '1: DJAMEL 2: MOUSTFA 3: na 4: na', 'a) Kalad Belkasam born 31 Dec. 1979; b) Mostafa Djamel born 31 Dec. 1979 in Maskara, Algeria; c) Mostefa Djamel born 26 Sep. 1973 in Mahdia, Algeria; d) Mustafa Djamel born 31 Dec. 1979 in Mascara, Algeria; e) Balkasam Kalad born 26 Aug. 1973 in Algiers, Algeria; f) Bekasam Kalad born 26 Aug. 1973 in Algiers, Algeria; g) Belkasam Kalad born 26 Aug. 1973 in Algiers, Algeria; h) Damel Mostafa born 31 Dec. 1979 in ALgiers, Algeria; i) Djamal Mostafa born 31 Dec. 1979 in Maskara, Algeria; j) Djamal Mostafa born 10 Jun. 1982; k) Djamel Mostafa born 31 Dec. 1979 in Maskara, Algeria; l) Djamel Mostafa born 31 Dec. 1979 in Algiers, Algeria; m) Fjamel Moustfa born 28 Sep. 1973 in Tiaret Algeria; n) Djamel Mustafa born 31 Dec. 1979; o) Ali Barkani born 22 Aug. 1973 in Morocco; p) Djamel Mustafa born 31 Dec. 1979 in Mascara, Algeria', '04', 'Fjamel Moustfa', 'FJAMEL MOUSTFA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('425', '20170807', '����췢[2017]106��', '1: DJAMEL 2: MOUSTFA 3: na 4: na', 'a) Kalad Belkasam born 31 Dec. 1979; b) Mostafa Djamel born 31 Dec. 1979 in Maskara, Algeria; c) Mostefa Djamel born 26 Sep. 1973 in Mahdia, Algeria; d) Mustafa Djamel born 31 Dec. 1979 in Mascara, Algeria; e) Balkasam Kalad born 26 Aug. 1973 in Algiers, Algeria; f) Bekasam Kalad born 26 Aug. 1973 in Algiers, Algeria; g) Belkasam Kalad born 26 Aug. 1973 in Algiers, Algeria; h) Damel Mostafa born 31 Dec. 1979 in ALgiers, Algeria; i) Djamal Mostafa born 31 Dec. 1979 in Maskara, Algeria; j) Djamal Mostafa born 10 Jun. 1982; k) Djamel Mostafa born 31 Dec. 1979 in Maskara, Algeria; l) Djamel Mostafa born 31 Dec. 1979 in Algiers, Algeria; m) Fjamel Moustfa born 28 Sep. 1973 in Tiaret Algeria; n) Djamel Mustafa born 31 Dec. 1979; o) Ali Barkani born 22 Aug. 1973 in Morocco; p) Djamel Mustafa born 31 Dec. 1979 in Mascara, Algeria', '04', 'Ali Barkani', 'ALI BARKANI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('426', '20170807', '����췢[2017]106��', '1: DJAMEL 2: MOUSTFA 3: na 4: na', 'a) Kalad Belkasam born 31 Dec. 1979; b) Mostafa Djamel born 31 Dec. 1979 in Maskara, Algeria; c) Mostefa Djamel born 26 Sep. 1973 in Mahdia, Algeria; d) Mustafa Djamel born 31 Dec. 1979 in Mascara, Algeria; e) Balkasam Kalad born 26 Aug. 1973 in Algiers, Algeria; f) Bekasam Kalad born 26 Aug. 1973 in Algiers, Algeria; g) Belkasam Kalad born 26 Aug. 1973 in Algiers, Algeria; h) Damel Mostafa born 31 Dec. 1979 in ALgiers, Algeria; i) Djamal Mostafa born 31 Dec. 1979 in Maskara, Algeria; j) Djamal Mostafa born 10 Jun. 1982; k) Djamel Mostafa born 31 Dec. 1979 in Maskara, Algeria; l) Djamel Mostafa born 31 Dec. 1979 in Algiers, Algeria; m) Fjamel Moustfa born 28 Sep. 1973 in Tiaret Algeria; n) Djamel Mustafa born 31 Dec. 1979; o) Ali Barkani born 22 Aug. 1973 in Morocco; p) Djamel Mustafa born 31 Dec. 1979 in Mascara, Algeria', '04', 'Djamel Mustafa', 'DJAMEL MUSTAFA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('427', '20170807', '����췢[2017]106��', '1: DJAMEL 2: MOUSTFA 3: na 4: na', 'a) Kalad Belkasam born 31 Dec. 1979; b) Mostafa Djamel born 31 Dec. 1979 in Maskara, Algeria; c) Mostefa Djamel born 26 Sep. 1973 in Mahdia, Algeria; d) Mustafa Djamel born 31 Dec. 1979 in Mascara, Algeria; e) Balkasam Kalad born 26 Aug. 1973 in Algiers, Algeria; f) Bekasam Kalad born 26 Aug. 1973 in Algiers, Algeria; g) Belkasam Kalad born 26 Aug. 1973 in Algiers, Algeria; h) Damel Mostafa born 31 Dec. 1979 in ALgiers, Algeria; i) Djamal Mostafa born 31 Dec. 1979 in Maskara, Algeria; j) Djamal Mostafa born 10 Jun. 1982; k) Djamel Mostafa born 31 Dec. 1979 in Maskara, Algeria; l) Djamel Mostafa born 31 Dec. 1979 in Algiers, Algeria; m) Fjamel Moustfa born 28 Sep. 1973 in Tiaret Algeria; n) Djamel Mustafa born 31 Dec. 1979; o) Ali Barkani born 22 Aug. 1973 in Morocco; p) Djamel Mustafa born 31 Dec. 1979 in Mascara, Algeria', '04', 'Djamel Mustafa', 'DJAMEL MUSTAFA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('428', '20170807', '����췢[2017]106��', '1: DOKU 2: KHAMATOVICH 3: UMAROV 4: na', 'a) Lom-ali Butayev (Butaev) born 1955; b) Dokka Umarov born 13 Apr. 1964; c) Dokka Umarov born 13 Apr. 1965', '02', 'DOKU KHAMATOVICH', 'DOKU KHAMATOVICH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('429', '20170807', '����췢[2017]106��', '1: DOKU 2: KHAMATOVICH 3: UMAROV 4: na', 'a) Lom-ali Butayev (Butaev) born 1955; b) Dokka Umarov born 13 Apr. 1964; c) Dokka Umarov born 13 Apr. 1965', '04', 'Lom-ali Butayev (Butaev)', 'LOM-ALI BUTAYEV (BUTAEV)', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('430', '20170807', '����췢[2017]106��', '1: DOKU 2: KHAMATOVICH 3: UMAROV 4: na', 'a) Lom-ali Butayev (Butaev) born 1955; b) Dokka Umarov born 13 Apr. 1964; c) Dokka Umarov born 13 Apr. 1965', '04', 'Lom-ali Butayev', 'LOM-ALI BUTAYEV', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('431', '20170807', '����췢[2017]106��', '1: DOKU 2: KHAMATOVICH 3: UMAROV 4: na', 'a) Lom-ali Butayev (Butaev) born 1955; b) Dokka Umarov born 13 Apr. 1964; c) Dokka Umarov born 13 Apr. 1965', '04', 'Butaev', 'BUTAEV', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('432', '20170807', '����췢[2017]106��', '1: DOKU 2: KHAMATOVICH 3: UMAROV 4: na', 'a) Lom-ali Butayev (Butaev) born 1955; b) Dokka Umarov born 13 Apr. 1964; c) Dokka Umarov born 13 Apr. 1965', '04', 'Dokka Umarov', 'DOKKA UMAROV', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('433', '20170807', '����췢[2017]106��', '1: DOKU 2: KHAMATOVICH 3: UMAROV 4: na', 'a) Lom-ali Butayev (Butaev) born 1955; b) Dokka Umarov born 13 Apr. 1964; c) Dokka Umarov born 13 Apr. 1965', '04', 'Dokka Umarov', 'DOKKA UMAROV', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('434', '20170807', '����췢[2017]106��', '1: EMILIE 2: EDWIGE 3: KONIG 4: na', null, '02', 'EMILIE EDWIGE', 'EMILIE EDWIGE', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('435', '20170807', '����췢[2017]106��', '1: EMRAH 2: ERDOGAN 3: na 4: na', null, '02', 'EMRAH ERDOGAN', 'EMRAH ERDOGAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('436', '20170807', '����췢[2017]106��', '1: FARHAD 2: KANABI 3: AHMAD 4: na', 'a) Kaua Omar Achmed; b) Kawa Hamawandi; c) Kawa Omar Ahmed', '02', 'FARHAD KANABI', 'FARHAD KANABI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('437', '20170807', '����췢[2017]106��', '1: FARHAD 2: KANABI 3: AHMAD 4: na', 'a) Kaua Omar Achmed; b) Kawa Hamawandi; c) Kawa Omar Ahmed', '04', 'Kawa Hamawandi', 'KAWA HAMAWANDI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('438', '20170807', '����췢[2017]106��', '1: FARHAD 2: KANABI 3: AHMAD 4: na', 'a) Kaua Omar Achmed; b) Kawa Hamawandi; c) Kawa Omar Ahmed', '04', 'Kawa Omar Ahmed', 'KAWA OMAR AHMED', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('439', '20170807', '����췢[2017]106��', '1: FARHAD 2: KANABI 3: AHMAD 4: na', 'a) Kaua Omar Achmed; b) Kawa Hamawandi; c) Kawa Omar Ahmed', '04', 'Kaua Omar Achmed', 'KAUA OMAR ACHMED', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('440', '20170807', '����췢[2017]106��', '1: FAYCAL 2: BOUGHANEMI 3: na 4: na', 'a) Faical Boughanmi; b) Faysal al-Bughanimi', '02', 'FAYCAL BOUGHANEMI', 'FAYCAL BOUGHANEMI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('441', '20170807', '����췢[2017]106��', '1: FAYCAL 2: BOUGHANEMI 3: na 4: na', 'a) Faical Boughanmi; b) Faysal al-Bughanimi', '04', 'Faysal al-Bughanimi', 'FAYSAL AL-BUGHANIMI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('442', '20170807', '����췢[2017]106��', '1: FAYCAL 2: BOUGHANEMI 3: na 4: na', 'a) Faical Boughanmi; b) Faysal al-Bughanimi', '04', 'Faical Boughanmi', 'FAICAL BOUGHANMI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('443', '20170807', '����췢[2017]106��', '1: FAYSAL 2:AHMAD 3: BIN ALI 4: AL-ZAHRANI', 'a) Faisai Ahmed Alzahrani', '02', 'FAYSAL 2:AHMAD', 'FAYSAL 2:AHMAD', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('444', '20170807', '����췢[2017]106��', '1: FAYSAL 2:AHMAD 3: BIN ALI 4: AL-ZAHRANI', 'a) Faisai Ahmed Alzahrani', '03', 'Faisai Ahmed Alzahrani', 'FAISAI AHMED ALZAHRANI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('445', '20170807', '����췢[2017]106��', '1: FAZAL 2: RAHIM 3: na 4: na', 'a) Fazel Rahim; Fazil Rahim; b) Fazil Rahman', '02', 'FAZAL RAHIM', 'FAZAL RAHIM', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('446', '20170807', '����췢[2017]106��', '1: FAZAL 2: RAHIM 3: na 4: na', 'a) Fazel Rahim; Fazil Rahim; b) Fazil Rahman', '04', 'Fazel Rahim', 'FAZEL RAHIM', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('447', '20170807', '����췢[2017]106��', '1: FAZAL 2: RAHIM 3: na 4: na', 'a) Fazel Rahim; Fazil Rahim; b) Fazil Rahman', '04', 'Fazil Rahman', 'FAZIL RAHMAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('448', '20170807', '����췢[2017]106��', '1: FAZEEL-A-TUL 2: SHAYKH ABU MOHAMMED 3: AMEEN 4: AL-PESHAWARI', 'a) Shaykh Aminullah; b) Shelk Aminullah; c) Abu Mohammad Aminullah Peshawari; d) Abu Mohammad Amin Bishawri; e) Abu Mohammad Shaykh Aminullah Al-Bishauri; f) Shaykh Abu Mohammed Ameen al-Peshawari; g) Shaykh Aminullah Al-Peshawari', '02', 'FAZEEL-A-TUL SHAYKH ABU MOHAMMED', 'FAZEEL-A-TUL SHAYKH ABU MOHAMMED', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('449', '20170807', '����췢[2017]106��', '1: FAZEEL-A-TUL 2: SHAYKH ABU MOHAMMED 3: AMEEN 4: AL-PESHAWARI', 'a) Shaykh Aminullah; b) Shelk Aminullah; c) Abu Mohammad Aminullah Peshawari; d) Abu Mohammad Amin Bishawri; e) Abu Mohammad Shaykh Aminullah Al-Bishauri; f) Shaykh Abu Mohammed Ameen al-Peshawari; g) Shaykh Aminullah Al-Peshawari', '04', 'Shaykh Aminullah Al-Peshawari', 'SHAYKH AMINULLAH AL-PESHAWARI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('450', '20170807', '����췢[2017]106��', '1: FAZEEL-A-TUL 2: SHAYKH ABU MOHAMMED 3: AMEEN 4: AL-PESHAWARI', 'a) Shaykh Aminullah; b) Shelk Aminullah; c) Abu Mohammad Aminullah Peshawari; d) Abu Mohammad Amin Bishawri; e) Abu Mohammad Shaykh Aminullah Al-Bishauri; f) Shaykh Abu Mohammed Ameen al-Peshawari; g) Shaykh Aminullah Al-Peshawari', '04', 'Shaykh Aminullah', 'SHAYKH AMINULLAH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('451', '20170807', '����췢[2017]106��', '1: FAZEEL-A-TUL 2: SHAYKH ABU MOHAMMED 3: AMEEN 4: AL-PESHAWARI', 'a) Shaykh Aminullah; b) Shelk Aminullah; c) Abu Mohammad Aminullah Peshawari; d) Abu Mohammad Amin Bishawri; e) Abu Mohammad Shaykh Aminullah Al-Bishauri; f) Shaykh Abu Mohammed Ameen al-Peshawari; g) Shaykh Aminullah Al-Peshawari', '04', 'Abu Mohammad Aminullah Peshawari', 'ABU MOHAMMAD AMINULLAH PESHAWARI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('452', '20170807', '����췢[2017]106��', '1: FAZEEL-A-TUL 2: SHAYKH ABU MOHAMMED 3: AMEEN 4: AL-PESHAWARI', 'a) Shaykh Aminullah; b) Shelk Aminullah; c) Abu Mohammad Aminullah Peshawari; d) Abu Mohammad Amin Bishawri; e) Abu Mohammad Shaykh Aminullah Al-Bishauri; f) Shaykh Abu Mohammed Ameen al-Peshawari; g) Shaykh Aminullah Al-Peshawari', '04', 'Shaykh Abu Mohammed Ameen al-Peshawari', 'SHAYKH ABU MOHAMMED AMEEN AL-PESHAWARI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('453', '20170807', '����췢[2017]106��', '1: FAZEEL-A-TUL 2: SHAYKH ABU MOHAMMED 3: AMEEN 4: AL-PESHAWARI', 'a) Shaykh Aminullah; b) Shelk Aminullah; c) Abu Mohammad Aminullah Peshawari; d) Abu Mohammad Amin Bishawri; e) Abu Mohammad Shaykh Aminullah Al-Bishauri; f) Shaykh Abu Mohammed Ameen al-Peshawari; g) Shaykh Aminullah Al-Peshawari', '04', 'Abu Mohammad Shaykh Aminullah Al-Bishauri', 'ABU MOHAMMAD SHAYKH AMINULLAH AL-BISHAURI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('454', '20170807', '����췢[2017]106��', '1: FAZEEL-A-TUL 2: SHAYKH ABU MOHAMMED 3: AMEEN 4: AL-PESHAWARI', 'a) Shaykh Aminullah; b) Shelk Aminullah; c) Abu Mohammad Aminullah Peshawari; d) Abu Mohammad Amin Bishawri; e) Abu Mohammad Shaykh Aminullah Al-Bishauri; f) Shaykh Abu Mohammed Ameen al-Peshawari; g) Shaykh Aminullah Al-Peshawari', '04', 'Abu Mohammad Amin Bishawri', 'ABU MOHAMMAD AMIN BISHAWRI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('455', '20170807', '����췢[2017]106��', '1: FAZEEL-A-TUL 2: SHAYKH ABU MOHAMMED 3: AMEEN 4: AL-PESHAWARI', 'a) Shaykh Aminullah; b) Shelk Aminullah; c) Abu Mohammad Aminullah Peshawari; d) Abu Mohammad Amin Bishawri; e) Abu Mohammad Shaykh Aminullah Al-Bishauri; f) Shaykh Abu Mohammed Ameen al-Peshawari; g) Shaykh Aminullah Al-Peshawari', '04', 'Shelk Aminullah', 'SHELK AMINULLAH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('456', '20170807', '����췢[2017]106��', '1: FELICIANO 2: SEMBORIO 3: DELOS REYES JR. 4: na', 'a) Abubakar Abdillah; b) Abdul Abdillah', '02', 'FELICIANO SEMBORIO', 'FELICIANO SEMBORIO', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('457', '20170807', '����췢[2017]106��', '1: FELICIANO 2: SEMBORIO 3: DELOS REYES JR. 4: na', 'a) Abubakar Abdillah; b) Abdul Abdillah', '04', 'Abdul Abdillah', 'ABDUL ABDILLAH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('458', '20170807', '����췢[2017]106��', '1: FELICIANO 2: SEMBORIO 3: DELOS REYES JR. 4: na', 'a) Abubakar Abdillah; b) Abdul Abdillah', '04', 'Abubakar Abdillah', 'ABUBAKAR ABDILLAH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('459', '20170807', '����췢[2017]106��', '1: FETHI 2: BEN HASSEN 3: BEN SALEM 4: AL-HADDAD', 'a) Fethi ben Assen Haddad; b) Fathy Hassan al Haddad', '02', 'FETHI BEN HASSEN', 'FETHI BEN HASSEN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('460', '20170807', '����췢[2017]106��', '1: FETHI 2: BEN HASSEN 3: BEN SALEM 4: AL-HADDAD', 'a) Fethi ben Assen Haddad; b) Fathy Hassan al Haddad', '04', 'Fathy Hassan al Haddad', 'FATHY HASSAN AL HADDAD', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('461', '20170807', '����췢[2017]106��', '1: FETHI 2: BEN HASSEN 3: BEN SALEM 4: AL-HADDAD', 'a) Fethi ben Assen Haddad; b) Fathy Hassan al Haddad', '04', 'Fethi ben Assen Haddad', 'FETHI BEN ASSEN HADDAD', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('462', '20170807', '����췢[2017]106��', '1: GHALIB 2: ABDULLAH 3: AL-ZAIDI 4: na', 'a) Ghalib Abdallah al-Zaydi; b) Ghalib Abdallah Ali al-Zaydi', '02', 'GHALIB ABDULLAH', 'GHALIB ABDULLAH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('463', '20170807', '����췢[2017]106��', '1: GHALIB 2: ABDULLAH 3: AL-ZAIDI 4: na', 'a) Ghalib Abdallah al-Zaydi; b) Ghalib Abdallah Ali al-Zaydi', '04', 'Ghalib Abdallah Ali al-Zaydi', 'GHALIB ABDALLAH ALI AL-ZAYDI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('464', '20170807', '����췢[2017]106��', '1: GHALIB 2: ABDULLAH 3: AL-ZAIDI 4: na', 'a) Ghalib Abdallah al-Zaydi; b) Ghalib Abdallah Ali al-Zaydi', '04', 'Ghalib Abdallah al-Zaydi', 'GHALIB ABDALLAH AL-ZAYDI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('465', '20170807', '����췢[2017]106��', '1: GHAZY 2: FEZZA 3: HISHAN 4: AL-MAZIDIH', 'a) Ghazy Fezzaa Hishan; b) Mushari Abd Aziz Saleh Shlash', '02', 'GHAZY FEZZA', 'GHAZY FEZZA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('466', '20170807', '����췢[2017]106��', '1: GHAZY 2: FEZZA 3: HISHAN 4: AL-MAZIDIH', 'a) Ghazy Fezzaa Hishan; b) Mushari Abd Aziz Saleh Shlash', '04', 'Ghazy Fezzaa Hishan', 'GHAZY FEZZAA HISHAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('467', '20170807', '����췢[2017]106��', '1: GHAZY 2: FEZZA 3: HISHAN 4: AL-MAZIDIH', 'a) Ghazy Fezzaa Hishan; b) Mushari Abd Aziz Saleh Shlash', '04', 'Mushari Abd Aziz Saleh Shlash', 'MUSHARI ABD AZIZ SALEH SHLASH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('468', '20170807', '����췢[2017]106��', '1: GULMUROD 2: KHALIMOV 3: na 4: na ', null, '02', 'GULMUROD KHALIMOV', 'GULMUROD KHALIMOV', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('469', '20170807', '����췢[2017]106��', '1: GUN GUN 2: RUSMAN 3: GUNAWAN 4: na', 'a) Gunawan, Rusman; b) Abd Al-Hadi; c) Abdul Hadid; d) Abdul Karim; e) Bukhori; f) Bukhory', '02', 'GUN GUN RUSMAN', 'GUN GUN RUSMAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('470', '20170807', '����췢[2017]106��', '1: GUN GUN 2: RUSMAN 3: GUNAWAN 4: na', 'a) Gunawan, Rusman; b) Abd Al-Hadi; c) Abdul Hadid; d) Abdul Karim; e) Bukhori; f) Bukhory', '04', 'Bukhory', 'BUKHORY', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('471', '20170807', '����췢[2017]106��', '1: GUN GUN 2: RUSMAN 3: GUNAWAN 4: na', 'a) Gunawan, Rusman; b) Abd Al-Hadi; c) Abdul Hadid; d) Abdul Karim; e) Bukhori; f) Bukhory', '04', 'Bukhori', 'BUKHORI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('472', '20170807', '����췢[2017]106��', '1: GUN GUN 2: RUSMAN 3: GUNAWAN 4: na', 'a) Gunawan, Rusman; b) Abd Al-Hadi; c) Abdul Hadid; d) Abdul Karim; e) Bukhori; f) Bukhory', '04', 'Abdul Karim', 'ABDUL KARIM', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('473', '20170807', '����췢[2017]106��', '1: GUN GUN 2: RUSMAN 3: GUNAWAN 4: na', 'a) Gunawan, Rusman; b) Abd Al-Hadi; c) Abdul Hadid; d) Abdul Karim; e) Bukhori; f) Bukhory', '04', 'Gunawan, Rusman', 'GUNAWAN, RUSMAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('474', '20170807', '����췢[2017]106��', '1: GUN GUN 2: RUSMAN 3: GUNAWAN 4: na', 'a) Gunawan, Rusman; b) Abd Al-Hadi; c) Abdul Hadid; d) Abdul Karim; e) Bukhori; f) Bukhory', '04', 'Abdul Hadid', 'ABDUL HADID', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('475', '20170807', '����췢[2017]106��', '1: GUN GUN 2: RUSMAN 3: GUNAWAN 4: na', 'a) Gunawan, Rusman; b) Abd Al-Hadi; c) Abdul Hadid; d) Abdul Karim; e) Bukhori; f) Bukhory', '04', 'Abd Al-Hadi', 'ABD AL-HADI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('476', '20170807', '����췢[2017]106��', '1: HABIB 2: BEN 3: AHMED 4: AL-LOUBIRI', 'a) Al-Habib ben Ahmad ben al- Tayib al-Lubiri', '02', 'HABIB BEN', 'HABIB BEN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('477', '20170807', '����췢[2017]106��', '1: HABIB 2: BEN 3: AHMED 4: AL-LOUBIRI', 'a) Al-Habib ben Ahmad ben al- Tayib al-Lubiri', '03', 'Al-Habib ben Ahmad ben al- Tayib al-Lubiri', 'AL-HABIB BEN AHMAD BEN AL- TAYIB AL-LUBIRI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('478', '20170807', '����췢[2017]106��', '1: HACENE 2: ALLANE 3: na 4: na', 'a) Hassan the Old; b) Al Sheikh Abdelhay; c) Boulahia; d) Abu al-Foutouh; e) Cheib Ahcene', '02', 'HACENE ALLANE', 'HACENE ALLANE', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('479', '20170807', '����췢[2017]106��', '1: HACENE 2: ALLANE 3: na 4: na', 'a) Hassan the Old; b) Al Sheikh Abdelhay; c) Boulahia; d) Abu al-Foutouh; e) Cheib Ahcene', '04', 'Abu al-Foutouh', 'ABU AL-FOUTOUH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('480', '20170807', '����췢[2017]106��', '1: HACENE 2: ALLANE 3: na 4: na', 'a) Hassan the Old; b) Al Sheikh Abdelhay; c) Boulahia; d) Abu al-Foutouh; e) Cheib Ahcene', '04', 'Hassan the Old', 'HASSAN THE OLD', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('481', '20170807', '����췢[2017]106��', '1: HACENE 2: ALLANE 3: na 4: na', 'a) Hassan the Old; b) Al Sheikh Abdelhay; c) Boulahia; d) Abu al-Foutouh; e) Cheib Ahcene', '04', 'Al Sheikh Abdelhay', 'AL SHEIKH ABDELHAY', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('482', '20170807', '����췢[2017]106��', '1: HACENE 2: ALLANE 3: na 4: na', 'a) Hassan the Old; b) Al Sheikh Abdelhay; c) Boulahia; d) Abu al-Foutouh; e) Cheib Ahcene', '04', 'Cheib Ahcene', 'CHEIB AHCENE', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('483', '20170807', '����췢[2017]106��', '1: HACENE 2: ALLANE 3: na 4: na', 'a) Hassan the Old; b) Al Sheikh Abdelhay; c) Boulahia; d) Abu al-Foutouh; e) Cheib Ahcene', '04', 'Boulahia', 'BOULAHIA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('484', '20170807', '����췢[2017]106��', '1: HAFIZ 2: ABDUL SALAM 3: BHUTTAVI 4: na', 'a) Hafiz Abdul Salam Bhattvl; b) Hafiz Abdusalam Budvi; c) Hafiz Abdussalaam Bhutvi; d) Abdul Salam Budvi; e) Abdul Salam Bhattwi; f) Abdul Salam Bhutvi; g) Mullah Abdul Salaam Bhattvi; h) Molvi Abdursalam Bhattvi', '02', 'HAFIZ ABDUL SALAM', 'HAFIZ ABDUL SALAM', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('485', '20170807', '����췢[2017]106��', '1: HAFIZ 2: ABDUL SALAM 3: BHUTTAVI 4: na', 'a) Hafiz Abdul Salam Bhattvl; b) Hafiz Abdusalam Budvi; c) Hafiz Abdussalaam Bhutvi; d) Abdul Salam Budvi; e) Abdul Salam Bhattwi; f) Abdul Salam Bhutvi; g) Mullah Abdul Salaam Bhattvi; h) Molvi Abdursalam Bhattvi', '04', 'Abdul Salam Bhutvi', 'ABDUL SALAM BHUTVI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('486', '20170807', '����췢[2017]106��', '1: HAFIZ 2: ABDUL SALAM 3: BHUTTAVI 4: na', 'a) Hafiz Abdul Salam Bhattvl; b) Hafiz Abdusalam Budvi; c) Hafiz Abdussalaam Bhutvi; d) Abdul Salam Budvi; e) Abdul Salam Bhattwi; f) Abdul Salam Bhutvi; g) Mullah Abdul Salaam Bhattvi; h) Molvi Abdursalam Bhattvi', '04', 'Hafiz Abdul Salam Bhattvl', 'HAFIZ ABDUL SALAM BHATTVL', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('487', '20170807', '����췢[2017]106��', '1: HAFIZ 2: ABDUL SALAM 3: BHUTTAVI 4: na', 'a) Hafiz Abdul Salam Bhattvl; b) Hafiz Abdusalam Budvi; c) Hafiz Abdussalaam Bhutvi; d) Abdul Salam Budvi; e) Abdul Salam Bhattwi; f) Abdul Salam Bhutvi; g) Mullah Abdul Salaam Bhattvi; h) Molvi Abdursalam Bhattvi', '04', 'Abdul Salam Budvi', 'ABDUL SALAM BUDVI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('488', '20170807', '����췢[2017]106��', '1: HAFIZ 2: ABDUL SALAM 3: BHUTTAVI 4: na', 'a) Hafiz Abdul Salam Bhattvl; b) Hafiz Abdusalam Budvi; c) Hafiz Abdussalaam Bhutvi; d) Abdul Salam Budvi; e) Abdul Salam Bhattwi; f) Abdul Salam Bhutvi; g) Mullah Abdul Salaam Bhattvi; h) Molvi Abdursalam Bhattvi', '04', 'Abdul Salam Bhattwi', 'ABDUL SALAM BHATTWI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('489', '20170807', '����췢[2017]106��', '1: HAFIZ 2: ABDUL SALAM 3: BHUTTAVI 4: na', 'a) Hafiz Abdul Salam Bhattvl; b) Hafiz Abdusalam Budvi; c) Hafiz Abdussalaam Bhutvi; d) Abdul Salam Budvi; e) Abdul Salam Bhattwi; f) Abdul Salam Bhutvi; g) Mullah Abdul Salaam Bhattvi; h) Molvi Abdursalam Bhattvi', '04', 'Molvi Abdursalam Bhattvi', 'MOLVI ABDURSALAM BHATTVI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('490', '20170807', '����췢[2017]106��', '1: HAFIZ 2: ABDUL SALAM 3: BHUTTAVI 4: na', 'a) Hafiz Abdul Salam Bhattvl; b) Hafiz Abdusalam Budvi; c) Hafiz Abdussalaam Bhutvi; d) Abdul Salam Budvi; e) Abdul Salam Bhattwi; f) Abdul Salam Bhutvi; g) Mullah Abdul Salaam Bhattvi; h) Molvi Abdursalam Bhattvi', '04', 'Hafiz Abdussalaam Bhutvi', 'HAFIZ ABDUSSALAAM BHUTVI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('491', '20170807', '����췢[2017]106��', '1: HAFIZ 2: ABDUL SALAM 3: BHUTTAVI 4: na', 'a) Hafiz Abdul Salam Bhattvl; b) Hafiz Abdusalam Budvi; c) Hafiz Abdussalaam Bhutvi; d) Abdul Salam Budvi; e) Abdul Salam Bhattwi; f) Abdul Salam Bhutvi; g) Mullah Abdul Salaam Bhattvi; h) Molvi Abdursalam Bhattvi', '04', 'Hafiz Abdusalam Budvi', 'HAFIZ ABDUSALAM BUDVI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('492', '20170807', '����췢[2017]106��', '1: HAFIZ 2: ABDUL SALAM 3: BHUTTAVI 4: na', 'a) Hafiz Abdul Salam Bhattvl; b) Hafiz Abdusalam Budvi; c) Hafiz Abdussalaam Bhutvi; d) Abdul Salam Budvi; e) Abdul Salam Bhattwi; f) Abdul Salam Bhutvi; g) Mullah Abdul Salaam Bhattvi; h) Molvi Abdursalam Bhattvi', '04', 'Mullah Abdul Salaam Bhattvi', 'MULLAH ABDUL SALAAM BHATTVI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('493', '20170807', '����췢[2017]106��', '1: HAFIZ 2: MUHAMMAD 3: SAEED 4: na', 'a) Hafiz Mohammad Sahib; b) Hafiz Mohammad Sayid; c) Hafiz Muhammad; d) Hafiz  Saeed; e) Hafez Mohammad Saeed; f) Hafiz Mohammad Sayeed; g) Tata Mohammad Syeed; h) Mohammad Sayed; i) Muhammad Saeed', '02', 'HAFIZ MUHAMMAD', 'HAFIZ MUHAMMAD', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('494', '20170807', '����췢[2017]106��', '1: HAFIZ 2: MUHAMMAD 3: SAEED 4: na', 'a) Hafiz Mohammad Sahib; b) Hafiz Mohammad Sayid; c) Hafiz Muhammad; d) Hafiz  Saeed; e) Hafez Mohammad Saeed; f) Hafiz Mohammad Sayeed; g) Tata Mohammad Syeed; h) Mohammad Sayed; i) Muhammad Saeed', '04', 'Hafiz Mohammad Sayeed', 'HAFIZ MOHAMMAD SAYEED', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('495', '20170807', '����췢[2017]106��', '1: HAFIZ 2: MUHAMMAD 3: SAEED 4: na', 'a) Hafiz Mohammad Sahib; b) Hafiz Mohammad Sayid; c) Hafiz Muhammad; d) Hafiz  Saeed; e) Hafez Mohammad Saeed; f) Hafiz Mohammad Sayeed; g) Tata Mohammad Syeed; h) Mohammad Sayed; i) Muhammad Saeed', '04', 'Tata Mohammad Syeed', 'TATA MOHAMMAD SYEED', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('496', '20170807', '����췢[2017]106��', '1: HAFIZ 2: MUHAMMAD 3: SAEED 4: na', 'a) Hafiz Mohammad Sahib; b) Hafiz Mohammad Sayid; c) Hafiz Muhammad; d) Hafiz  Saeed; e) Hafez Mohammad Saeed; f) Hafiz Mohammad Sayeed; g) Tata Mohammad Syeed; h) Mohammad Sayed; i) Muhammad Saeed', '04', 'Muhammad Saeed', 'MUHAMMAD SAEED', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('497', '20170807', '����췢[2017]106��', '1: HAFIZ 2: MUHAMMAD 3: SAEED 4: na', 'a) Hafiz Mohammad Sahib; b) Hafiz Mohammad Sayid; c) Hafiz Muhammad; d) Hafiz  Saeed; e) Hafez Mohammad Saeed; f) Hafiz Mohammad Sayeed; g) Tata Mohammad Syeed; h) Mohammad Sayed; i) Muhammad Saeed', '04', 'Tata Mohammad Syeed', 'TATA MOHAMMAD SYEED', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('498', '20170807', '����췢[2017]106��', '1: HAFIZ 2: MUHAMMAD 3: SAEED 4: na', 'a) Hafiz Mohammad Sahib; b) Hafiz Mohammad Sayid; c) Hafiz Muhammad; d) Hafiz  Saeed; e) Hafez Mohammad Saeed; f) Hafiz Mohammad Sayeed; g) Tata Mohammad Syeed; h) Mohammad Sayed; i) Muhammad Saeed', '04', 'Hafez Mohammad Saeed', 'HAFEZ MOHAMMAD SAEED', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('499', '20170807', '����췢[2017]106��', '1: HAFIZ 2: MUHAMMAD 3: SAEED 4: na', 'a) Hafiz Mohammad Sahib; b) Hafiz Mohammad Sayid; c) Hafiz Muhammad; d) Hafiz  Saeed; e) Hafez Mohammad Saeed; f) Hafiz Mohammad Sayeed; g) Tata Mohammad Syeed; h) Mohammad Sayed; i) Muhammad Saeed', '04', 'Hafiz  Saeed', 'HAFIZ  SAEED', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('500', '20170807', '����췢[2017]106��', '1: HAFIZ 2: MUHAMMAD 3: SAEED 4: na', 'a) Hafiz Mohammad Sahib; b) Hafiz Mohammad Sayid; c) Hafiz Muhammad; d) Hafiz  Saeed; e) Hafez Mohammad Saeed; f) Hafiz Mohammad Sayeed; g) Tata Mohammad Syeed; h) Mohammad Sayed; i) Muhammad Saeed', '04', 'Hafiz Mohammad Sahib', 'HAFIZ MOHAMMAD SAHIB', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('501', '20170807', '����췢[2017]106��', '1: HAFIZ 2: MUHAMMAD 3: SAEED 4: na', 'a) Hafiz Mohammad Sahib; b) Hafiz Mohammad Sayid; c) Hafiz Muhammad; d) Hafiz  Saeed; e) Hafez Mohammad Saeed; f) Hafiz Mohammad Sayeed; g) Tata Mohammad Syeed; h) Mohammad Sayed; i) Muhammad Saeed', '04', 'Hafiz Mohammad Sayid', 'HAFIZ MOHAMMAD SAYID', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('502', '20170807', '����췢[2017]106��', '1: HAFIZ 2: MUHAMMAD 3: SAEED 4: na', 'a) Hafiz Mohammad Sahib; b) Hafiz Mohammad Sayid; c) Hafiz Muhammad; d) Hafiz  Saeed; e) Hafez Mohammad Saeed; f) Hafiz Mohammad Sayeed; g) Tata Mohammad Syeed; h) Mohammad Sayed; i) Muhammad Saeed', '04', 'Hafiz Muhammad', 'HAFIZ MUHAMMAD', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('503', '20170807', '����췢[2017]106��', '1: HAJI 2: MUHAMMAD 3: ASHRAF 4: na', 'a) Haji M. Ashraf; b) Muhammad Ashraf Manshah; c) Muhammad Ashraf Munsha', '02', 'HAJI MUHAMMAD', 'HAJI MUHAMMAD', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('504', '20170807', '����췢[2017]106��', '1: HAJI 2: MUHAMMAD 3: ASHRAF 4: na', 'a) Haji M. Ashraf; b) Muhammad Ashraf Manshah; c) Muhammad Ashraf Munsha', '04', 'Muhammad Ashraf Manshah', 'MUHAMMAD ASHRAF MANSHAH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('505', '20170807', '����췢[2017]106��', '1: HAJI 2: MUHAMMAD 3: ASHRAF 4: na', 'a) Haji M. Ashraf; b) Muhammad Ashraf Manshah; c) Muhammad Ashraf Munsha', '04', 'Muhammad Ashraf Munsha', 'MUHAMMAD ASHRAF MUNSHA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('506', '20170807', '����췢[2017]106��', '1: HAJI 2: MUHAMMAD 3: ASHRAF 4: na', 'a) Haji M. Ashraf; b) Muhammad Ashraf Manshah; c) Muhammad Ashraf Munsha', '04', 'Haji M. Ashraf', 'HAJI M. ASHRAF', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('507', '20170807', '����췢[2017]106��', '1: HAJJAJ 2: BIN 3: FAHD 4: AL AJMI', 'a) Hijai Fahid Hijaj Muhammad Sahib al-Ajmi; b) Hicac Fehid Hicac Muhammed Sebib al-Acmi; c) Hajjaj bin-Fahad al-Ajmi; d) Sheikh Hajaj al-Ajami; e) Hajaj al-Ajami; f) Ajaj Ajami', '02', 'HAJJAJ BIN', 'HAJJAJ BIN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('508', '20170807', '����췢[2017]106��', '1: HAJJAJ 2: BIN 3: FAHD 4: AL AJMI', 'a) Hijai Fahid Hijaj Muhammad Sahib al-Ajmi; b) Hicac Fehid Hicac Muhammed Sebib al-Acmi; c) Hajjaj bin-Fahad al-Ajmi; d) Sheikh Hajaj al-Ajami; e) Hajaj al-Ajami; f) Ajaj Ajami', '04', 'Hajaj al-Ajami', 'HAJAJ AL-AJAMI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('509', '20170807', '����췢[2017]106��', '1: HAJJAJ 2: BIN 3: FAHD 4: AL AJMI', 'a) Hijai Fahid Hijaj Muhammad Sahib al-Ajmi; b) Hicac Fehid Hicac Muhammed Sebib al-Acmi; c) Hajjaj bin-Fahad al-Ajmi; d) Sheikh Hajaj al-Ajami; e) Hajaj al-Ajami; f) Ajaj Ajami', '04', 'Hajjaj bin-Fahad al-Ajmi', 'HAJJAJ BIN-FAHAD AL-AJMI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('510', '20170807', '����췢[2017]106��', '1: HAJJAJ 2: BIN 3: FAHD 4: AL AJMI', 'a) Hijai Fahid Hijaj Muhammad Sahib al-Ajmi; b) Hicac Fehid Hicac Muhammed Sebib al-Acmi; c) Hajjaj bin-Fahad al-Ajmi; d) Sheikh Hajaj al-Ajami; e) Hajaj al-Ajami; f) Ajaj Ajami', '04', 'Sheikh Hajaj al-Ajami', 'SHEIKH HAJAJ AL-AJAMI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('511', '20170807', '����췢[2017]106��', '1: HAJJAJ 2: BIN 3: FAHD 4: AL AJMI', 'a) Hijai Fahid Hijaj Muhammad Sahib al-Ajmi; b) Hicac Fehid Hicac Muhammed Sebib al-Acmi; c) Hajjaj bin-Fahad al-Ajmi; d) Sheikh Hajaj al-Ajami; e) Hajaj al-Ajami; f) Ajaj Ajami', '04', 'Ajaj Ajami', 'AJAJ AJAMI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('512', '20170807', '����췢[2017]106��', '1: HAJJAJ 2: BIN 3: FAHD 4: AL AJMI', 'a) Hijai Fahid Hijaj Muhammad Sahib al-Ajmi; b) Hicac Fehid Hicac Muhammed Sebib al-Acmi; c) Hajjaj bin-Fahad al-Ajmi; d) Sheikh Hajaj al-Ajami; e) Hajaj al-Ajami; f) Ajaj Ajami', '04', 'Hicac Fehid Hicac Muhammed Sebib al-Acmi', 'HICAC FEHID HICAC MUHAMMED SEBIB AL-ACMI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('513', '20170807', '����췢[2017]106��', '1: HAJJAJ 2: BIN 3: FAHD 4: AL AJMI', 'a) Hijai Fahid Hijaj Muhammad Sahib al-Ajmi; b) Hicac Fehid Hicac Muhammed Sebib al-Acmi; c) Hajjaj bin-Fahad al-Ajmi; d) Sheikh Hajaj al-Ajami; e) Hajaj al-Ajami; f) Ajaj Ajami', '04', 'Hijai Fahid Hijaj Muhammad Sahib al-Ajmi', 'HIJAI FAHID HIJAJ MUHAMMAD SAHIB AL-AJMI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('514', '20170807', '����췢[2017]106��', '1: HAMAD 2: AWAD 3: DAHI SARHAN 4: AL-SHAMMARI', null, '02', 'HAMAD AWAD', 'HAMAD AWAD', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('515', '20170807', '����췢[2017]106��', '1: HAMADA 2: OULD MOHAMED EL KHAIRY 3: na 4: na', 'a) Hamada Ould Mohamed Lemine Ould Mohamed el Khairy; b) Ould Kheirou; c) Hamed el Khairy', '02', 'HAMADA OULD MOHAMED EL KHAIRY', 'HAMADA OULD MOHAMED EL KHAIRY', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('516', '20170807', '����췢[2017]106��', '1: HAMADA 2: OULD MOHAMED EL KHAIRY 3: na 4: na', 'a) Hamada Ould Mohamed Lemine Ould Mohamed el Khairy; b) Ould Kheirou; c) Hamed el Khairy', '04', 'Hamada Ould Mohamed Lemine Ould Mohamed el Khairy', 'HAMADA OULD MOHAMED LEMINE OULD MOHAMED EL KHAIRY', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('517', '20170807', '����췢[2017]106��', '1: HAMADA 2: OULD MOHAMED EL KHAIRY 3: na 4: na', 'a) Hamada Ould Mohamed Lemine Ould Mohamed el Khairy; b) Ould Kheirou; c) Hamed el Khairy', '04', 'Hamed el Khairy', 'HAMED EL KHAIRY', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('518', '20170807', '����췢[2017]106��', '1: HAMADA 2: OULD MOHAMED EL KHAIRY 3: na 4: na', 'a) Hamada Ould Mohamed Lemine Ould Mohamed el Khairy; b) Ould Kheirou; c) Hamed el Khairy', '04', 'Ould Kheirou', 'OULD KHEIROU', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('519', '20170807', '����췢[2017]106��', '1: HAMADI 2: BEN ABDUL 3: BEN ALI 4: BOUYEHIA', 'a) Gamel Mohamed born 25 May 1966 in Morocco; b) Abd el Wanis Abd Gawwad Abd el Latif Bahaa born 9 May 1986 in Egypt; c) Mahmoud Hamid', '02', 'HAMADI BEN ABDUL', 'HAMADI BEN ABDUL', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('520', '20170807', '����췢[2017]106��', '1: HAMADI 2: BEN ABDUL 3: BEN ALI 4: BOUYEHIA', 'a) Gamel Mohamed born 25 May 1966 in Morocco; b) Abd el Wanis Abd Gawwad Abd el Latif Bahaa born 9 May 1986 in Egypt; c) Mahmoud Hamid', '04', 'Mahmoud Hamid', 'MAHMOUD HAMID', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('521', '20170807', '����췢[2017]106��', '1: HAMADI 2: BEN ABDUL 3: BEN ALI 4: BOUYEHIA', 'a) Gamel Mohamed born 25 May 1966 in Morocco; b) Abd el Wanis Abd Gawwad Abd el Latif Bahaa born 9 May 1986 in Egypt; c) Mahmoud Hamid', '04', 'Gamel Mohamed', 'GAMEL MOHAMED', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('522', '20170807', '����췢[2017]106��', '1: HAMADI 2: BEN ABDUL 3: BEN ALI 4: BOUYEHIA', 'a) Gamel Mohamed born 25 May 1966 in Morocco; b) Abd el Wanis Abd Gawwad Abd el Latif Bahaa born 9 May 1986 in Egypt; c) Mahmoud Hamid', '04', 'Abd el Wanis Abd Gawwad Abd el Latif Bahaa', 'ABD EL WANIS ABD GAWWAD ABD EL LATIF BAHAA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('523', '20170807', '����췢[2017]106��', '1: HAMID 2: ABDALLAH 3: AHMAD 4: AL-ALI', 'a) Dr. Hamed Abdullah Al-Ali; b) Hamed Al-Ali; c) Hamed bin Abdallah Al-Ali; d) Hamid Abdallah Al-Ali; e) Hamid Abdallah Ahmad Al-Ali; f) Hamid bin Abdallah Ahmed Al-Ali; g) Hamid Abdallah Ahmed Al-Ali', '02', 'HAMID ABDALLAH', 'HAMID ABDALLAH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('524', '20170807', '����췢[2017]106��', '1: HAMID 2: ABDALLAH 3: AHMAD 4: AL-ALI', 'a) Dr. Hamed Abdullah Al-Ali; b) Hamed Al-Ali; c) Hamed bin Abdallah Al-Ali; d) Hamid Abdallah Al-Ali; e) Hamid Abdallah Ahmad Al-Ali; f) Hamid bin Abdallah Ahmed Al-Ali; g) Hamid Abdallah Ahmed Al-Ali', '04', 'Hamid Abdallah Ahmad Al-Ali', 'HAMID ABDALLAH AHMAD AL-ALI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('525', '20170807', '����췢[2017]106��', '1: HAMID 2: ABDALLAH 3: AHMAD 4: AL-ALI', 'a) Dr. Hamed Abdullah Al-Ali; b) Hamed Al-Ali; c) Hamed bin Abdallah Al-Ali; d) Hamid Abdallah Al-Ali; e) Hamid Abdallah Ahmad Al-Ali; f) Hamid bin Abdallah Ahmed Al-Ali; g) Hamid Abdallah Ahmed Al-Ali', '04', 'Hamid bin Abdallah Ahmed Al-Ali', 'HAMID BIN ABDALLAH AHMED AL-ALI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('526', '20170807', '����췢[2017]106��', '1: HAMID 2: ABDALLAH 3: AHMAD 4: AL-ALI', 'a) Dr. Hamed Abdullah Al-Ali; b) Hamed Al-Ali; c) Hamed bin Abdallah Al-Ali; d) Hamid Abdallah Al-Ali; e) Hamid Abdallah Ahmad Al-Ali; f) Hamid bin Abdallah Ahmed Al-Ali; g) Hamid Abdallah Ahmed Al-Ali', '04', 'Hamid Abdallah Ahmed Al-Ali', 'HAMID ABDALLAH AHMED AL-ALI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('527', '20170807', '����췢[2017]106��', '1: HAMID 2: ABDALLAH 3: AHMAD 4: AL-ALI', 'a) Dr. Hamed Abdullah Al-Ali; b) Hamed Al-Ali; c) Hamed bin Abdallah Al-Ali; d) Hamid Abdallah Al-Ali; e) Hamid Abdallah Ahmad Al-Ali; f) Hamid bin Abdallah Ahmed Al-Ali; g) Hamid Abdallah Ahmed Al-Ali', '04', 'Dr. Hamed Abdullah Al-Ali', 'DR. HAMED ABDULLAH AL-ALI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('528', '20170807', '����췢[2017]106��', '1: HAMID 2: ABDALLAH 3: AHMAD 4: AL-ALI', 'a) Dr. Hamed Abdullah Al-Ali; b) Hamed Al-Ali; c) Hamed bin Abdallah Al-Ali; d) Hamid Abdallah Al-Ali; e) Hamid Abdallah Ahmad Al-Ali; f) Hamid bin Abdallah Ahmed Al-Ali; g) Hamid Abdallah Ahmed Al-Ali', '04', 'Hamed Al-Ali', 'HAMED AL-ALI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('529', '20170807', '����췢[2017]106��', '1: HAMID 2: ABDALLAH 3: AHMAD 4: AL-ALI', 'a) Dr. Hamed Abdullah Al-Ali; b) Hamed Al-Ali; c) Hamed bin Abdallah Al-Ali; d) Hamid Abdallah Al-Ali; e) Hamid Abdallah Ahmad Al-Ali; f) Hamid bin Abdallah Ahmed Al-Ali; g) Hamid Abdallah Ahmed Al-Ali', '04', 'Hamed bin Abdallah Al-Ali', 'HAMED BIN ABDALLAH AL-ALI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('530', '20170807', '����췢[2017]106��', '1: HAMID 2: ABDALLAH 3: AHMAD 4: AL-ALI', 'a) Dr. Hamed Abdullah Al-Ali; b) Hamed Al-Ali; c) Hamed bin Abdallah Al-Ali; d) Hamid Abdallah Al-Ali; e) Hamid Abdallah Ahmad Al-Ali; f) Hamid bin Abdallah Ahmed Al-Ali; g) Hamid Abdallah Ahmed Al-Ali', '04', 'Hamid Abdallah Al-Ali', 'HAMID ABDALLAH AL-ALI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('531', '20170807', '����췢[2017]106��', '1: HAMID 2: HAMAD 3: HAMID 4: AL-ALI', null, '02', 'HAMID HAMAD', 'HAMID HAMAD', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('532', '20170807', '����췢[2017]106��', '1: HANI 2: AL-SAYYID 3: AL-SEBAI 4: YUSIF', 'a) Hani Yousef Al-Sebai; b) Hani Youssef; c) Hany Youseff; d) Hani Yusef; e) Hani al-Sayyid Al-Sabai; f) Hani al-Sayyid El Sebai; g) Hani al-Sayyid Al Sibai; h) Hani al-Sayyid El Sabaay; i) El-Sababt; j) Abu Tusnin; k) Abu Akram; l) Hani El Sayyed Elsebai Yusef; m) Abu Karim; n) Hany Elsayed Youssef', '02', 'HANI AL-SAYYID', 'HANI AL-SAYYID', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('533', '20170807', '����췢[2017]106��', '1: HANI 2: AL-SAYYID 3: AL-SEBAI 4: YUSIF', 'a) Hani Yousef Al-Sebai; b) Hani Youssef; c) Hany Youseff; d) Hani Yusef; e) Hani al-Sayyid Al-Sabai; f) Hani al-Sayyid El Sebai; g) Hani al-Sayyid Al Sibai; h) Hani al-Sayyid El Sabaay; i) El-Sababt; j) Abu Tusnin; k) Abu Akram; l) Hani El Sayyed Elsebai Yusef; m) Abu Karim; n) Hany Elsayed Youssef', '04', 'Hany Elsayed Youssef', 'HANY ELSAYED YOUSSEF', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('534', '20170807', '����췢[2017]106��', '1: HANI 2: AL-SAYYID 3: AL-SEBAI 4: YUSIF', 'a) Hani Yousef Al-Sebai; b) Hani Youssef; c) Hany Youseff; d) Hani Yusef; e) Hani al-Sayyid Al-Sabai; f) Hani al-Sayyid El Sebai; g) Hani al-Sayyid Al Sibai; h) Hani al-Sayyid El Sabaay; i) El-Sababt; j) Abu Tusnin; k) Abu Akram; l) Hani El Sayyed Elsebai Yusef; m) Abu Karim; n) Hany Elsayed Youssef', '04', 'Hani Yusef', 'HANI YUSEF', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('535', '20170807', '����췢[2017]106��', '1: HANI 2: AL-SAYYID 3: AL-SEBAI 4: YUSIF', 'a) Hani Yousef Al-Sebai; b) Hani Youssef; c) Hany Youseff; d) Hani Yusef; e) Hani al-Sayyid Al-Sabai; f) Hani al-Sayyid El Sebai; g) Hani al-Sayyid Al Sibai; h) Hani al-Sayyid El Sabaay; i) El-Sababt; j) Abu Tusnin; k) Abu Akram; l) Hani El Sayyed Elsebai Yusef; m) Abu Karim; n) Hany Elsayed Youssef', '04', 'Hani Yousef Al-Sebai', 'HANI YOUSEF AL-SEBAI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('536', '20170807', '����췢[2017]106��', '1: HANI 2: AL-SAYYID 3: AL-SEBAI 4: YUSIF', 'a) Hani Yousef Al-Sebai; b) Hani Youssef; c) Hany Youseff; d) Hani Yusef; e) Hani al-Sayyid Al-Sabai; f) Hani al-Sayyid El Sebai; g) Hani al-Sayyid Al Sibai; h) Hani al-Sayyid El Sabaay; i) El-Sababt; j) Abu Tusnin; k) Abu Akram; l) Hani El Sayyed Elsebai Yusef; m) Abu Karim; n) Hany Elsayed Youssef', '04', 'Hani Youssef', 'HANI YOUSSEF', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('537', '20170807', '����췢[2017]106��', '1: HANI 2: AL-SAYYID 3: AL-SEBAI 4: YUSIF', 'a) Hani Yousef Al-Sebai; b) Hani Youssef; c) Hany Youseff; d) Hani Yusef; e) Hani al-Sayyid Al-Sabai; f) Hani al-Sayyid El Sebai; g) Hani al-Sayyid Al Sibai; h) Hani al-Sayyid El Sabaay; i) El-Sababt; j) Abu Tusnin; k) Abu Akram; l) Hani El Sayyed Elsebai Yusef; m) Abu Karim; n) Hany Elsayed Youssef', '04', 'Hany Youseff', 'HANY YOUSEFF', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('538', '20170807', '����췢[2017]106��', '1: HANI 2: AL-SAYYID 3: AL-SEBAI 4: YUSIF', 'a) Hani Yousef Al-Sebai; b) Hani Youssef; c) Hany Youseff; d) Hani Yusef; e) Hani al-Sayyid Al-Sabai; f) Hani al-Sayyid El Sebai; g) Hani al-Sayyid Al Sibai; h) Hani al-Sayyid El Sabaay; i) El-Sababt; j) Abu Tusnin; k) Abu Akram; l) Hani El Sayyed Elsebai Yusef; m) Abu Karim; n) Hany Elsayed Youssef', '04', 'Hani al-Sayyid Al-Sabai', 'HANI AL-SAYYID AL-SABAI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('539', '20170807', '����췢[2017]106��', '1: HANI 2: AL-SAYYID 3: AL-SEBAI 4: YUSIF', 'a) Hani Yousef Al-Sebai; b) Hani Youssef; c) Hany Youseff; d) Hani Yusef; e) Hani al-Sayyid Al-Sabai; f) Hani al-Sayyid El Sebai; g) Hani al-Sayyid Al Sibai; h) Hani al-Sayyid El Sabaay; i) El-Sababt; j) Abu Tusnin; k) Abu Akram; l) Hani El Sayyed Elsebai Yusef; m) Abu Karim; n) Hany Elsayed Youssef', '04', 'Hani al-Sayyid El Sebai', 'HANI AL-SAYYID EL SEBAI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('540', '20170807', '����췢[2017]106��', '1: HANI 2: AL-SAYYID 3: AL-SEBAI 4: YUSIF', 'a) Hani Yousef Al-Sebai; b) Hani Youssef; c) Hany Youseff; d) Hani Yusef; e) Hani al-Sayyid Al-Sabai; f) Hani al-Sayyid El Sebai; g) Hani al-Sayyid Al Sibai; h) Hani al-Sayyid El Sabaay; i) El-Sababt; j) Abu Tusnin; k) Abu Akram; l) Hani El Sayyed Elsebai Yusef; m) Abu Karim; n) Hany Elsayed Youssef', '04', 'Hani al-Sayyid Al Sibai', 'HANI AL-SAYYID AL SIBAI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('541', '20170807', '����췢[2017]106��', '1: HANI 2: AL-SAYYID 3: AL-SEBAI 4: YUSIF', 'a) Hani Yousef Al-Sebai; b) Hani Youssef; c) Hany Youseff; d) Hani Yusef; e) Hani al-Sayyid Al-Sabai; f) Hani al-Sayyid El Sebai; g) Hani al-Sayyid Al Sibai; h) Hani al-Sayyid El Sabaay; i) El-Sababt; j) Abu Tusnin; k) Abu Akram; l) Hani El Sayyed Elsebai Yusef; m) Abu Karim; n) Hany Elsayed Youssef', '04', 'Hani al-Sayyid El Sabaay', 'HANI AL-SAYYID EL SABAAY', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('542', '20170807', '����췢[2017]106��', '1: HANI 2: AL-SAYYID 3: AL-SEBAI 4: YUSIF', 'a) Hani Yousef Al-Sebai; b) Hani Youssef; c) Hany Youseff; d) Hani Yusef; e) Hani al-Sayyid Al-Sabai; f) Hani al-Sayyid El Sebai; g) Hani al-Sayyid Al Sibai; h) Hani al-Sayyid El Sabaay; i) El-Sababt; j) Abu Tusnin; k) Abu Akram; l) Hani El Sayyed Elsebai Yusef; m) Abu Karim; n) Hany Elsayed Youssef', '04', 'El-Sababt', 'EL-SABABT', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('543', '20170807', '����췢[2017]106��', '1: HANI 2: AL-SAYYID 3: AL-SEBAI 4: YUSIF', 'a) Hani Yousef Al-Sebai; b) Hani Youssef; c) Hany Youseff; d) Hani Yusef; e) Hani al-Sayyid Al-Sabai; f) Hani al-Sayyid El Sebai; g) Hani al-Sayyid Al Sibai; h) Hani al-Sayyid El Sabaay; i) El-Sababt; j) Abu Tusnin; k) Abu Akram; l) Hani El Sayyed Elsebai Yusef; m) Abu Karim; n) Hany Elsayed Youssef', '04', 'Abu Tusnin', 'ABU TUSNIN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('544', '20170807', '����췢[2017]106��', '1: HANI 2: AL-SAYYID 3: AL-SEBAI 4: YUSIF', 'a) Hani Yousef Al-Sebai; b) Hani Youssef; c) Hany Youseff; d) Hani Yusef; e) Hani al-Sayyid Al-Sabai; f) Hani al-Sayyid El Sebai; g) Hani al-Sayyid Al Sibai; h) Hani al-Sayyid El Sabaay; i) El-Sababt; j) Abu Tusnin; k) Abu Akram; l) Hani El Sayyed Elsebai Yusef; m) Abu Karim; n) Hany Elsayed Youssef', '04', 'Abu Akram', 'ABU AKRAM', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('545', '20170807', '����췢[2017]106��', '1: HANI 2: AL-SAYYID 3: AL-SEBAI 4: YUSIF', 'a) Hani Yousef Al-Sebai; b) Hani Youssef; c) Hany Youseff; d) Hani Yusef; e) Hani al-Sayyid Al-Sabai; f) Hani al-Sayyid El Sebai; g) Hani al-Sayyid Al Sibai; h) Hani al-Sayyid El Sabaay; i) El-Sababt; j) Abu Tusnin; k) Abu Akram; l) Hani El Sayyed Elsebai Yusef; m) Abu Karim; n) Hany Elsayed Youssef', '04', 'Hani El Sayyed Elsebai Yusef', 'HANI EL SAYYED ELSEBAI YUSEF', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('546', '20170807', '����췢[2017]106��', '1: HANI 2: AL-SAYYID 3: AL-SEBAI 4: YUSIF', 'a) Hani Yousef Al-Sebai; b) Hani Youssef; c) Hany Youseff; d) Hani Yusef; e) Hani al-Sayyid Al-Sabai; f) Hani al-Sayyid El Sebai; g) Hani al-Sayyid Al Sibai; h) Hani al-Sayyid El Sabaay; i) El-Sababt; j) Abu Tusnin; k) Abu Akram; l) Hani El Sayyed Elsebai Yusef; m) Abu Karim; n) Hany Elsayed Youssef', '04', 'Abu Karim', 'ABU KARIM', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('547', '20170807', '����췢[2017]106��', '1: HASAN 2: AL-SALAHAYN 3: SALIH 4: AL-SHAARI', 'a) Husayn al-Salihin Salih al-Shairi', '02', 'HASAN AL-SALAHAYN', 'HASAN AL-SALAHAYN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('548', '20170807', '����췢[2017]106��', '1: HASAN 2: AL-SALAHAYN 3: SALIH 4: AL-SHAARI', 'a) Husayn al-Salihin Salih al-Shairi', '03', 'Husayn al-Salihin Salih al-Shairi', 'HUSAYN AL-SALIHIN SALIH AL-SHAIRI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('549', '20170807', '����췢[2017]106��', '1: HASSAN 2: ABDULLAH 3: HERSI 4: AL-TURKI', 'a) Hassan Turki; b) Hassen Abdelle Fihiye; c) Shelkh Hassan Abdullah Fahaih; d) Hassan Al-Turki; e) Hassan Abdillahi Hersi Turki; f) Sheikh Hassan Turki; g) Xasan Cabdilaahi Xirsi; h) Xasan Cabdulle Xirsi', '02', 'HASSAN ABDULLAH', 'HASSAN ABDULLAH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('550', '20170807', '����췢[2017]106��', '1: HASSAN 2: ABDULLAH 3: HERSI 4: AL-TURKI', 'a) Hassan Turki; b) Hassen Abdelle Fihiye; c) Shelkh Hassan Abdullah Fahaih; d) Hassan Al-Turki; e) Hassan Abdillahi Hersi Turki; f) Sheikh Hassan Turki; g) Xasan Cabdilaahi Xirsi; h) Xasan Cabdulle Xirsi', '04', 'Hassan Al-Turki', 'HASSAN AL-TURKI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('551', '20170807', '����췢[2017]106��', '1: HASSAN 2: ABDULLAH 3: HERSI 4: AL-TURKI', 'a) Hassan Turki; b) Hassen Abdelle Fihiye; c) Shelkh Hassan Abdullah Fahaih; d) Hassan Al-Turki; e) Hassan Abdillahi Hersi Turki; f) Sheikh Hassan Turki; g) Xasan Cabdilaahi Xirsi; h) Xasan Cabdulle Xirsi', '04', 'Hassan Abdillahi Hersi Turki', 'HASSAN ABDILLAHI HERSI TURKI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('552', '20170807', '����췢[2017]106��', '1: HASSAN 2: ABDULLAH 3: HERSI 4: AL-TURKI', 'a) Hassan Turki; b) Hassen Abdelle Fihiye; c) Shelkh Hassan Abdullah Fahaih; d) Hassan Al-Turki; e) Hassan Abdillahi Hersi Turki; f) Sheikh Hassan Turki; g) Xasan Cabdilaahi Xirsi; h) Xasan Cabdulle Xirsi', '04', 'Xasan Cabdulle Xirsi', 'XASAN CABDULLE XIRSI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('553', '20170807', '����췢[2017]106��', '1: HASSAN 2: ABDULLAH 3: HERSI 4: AL-TURKI', 'a) Hassan Turki; b) Hassen Abdelle Fihiye; c) Shelkh Hassan Abdullah Fahaih; d) Hassan Al-Turki; e) Hassan Abdillahi Hersi Turki; f) Sheikh Hassan Turki; g) Xasan Cabdilaahi Xirsi; h) Xasan Cabdulle Xirsi', '04', 'Shelkh Hassan Abdullah Fahaih', 'SHELKH HASSAN ABDULLAH FAHAIH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('554', '20170807', '����췢[2017]106��', '1: HASSAN 2: ABDULLAH 3: HERSI 4: AL-TURKI', 'a) Hassan Turki; b) Hassen Abdelle Fihiye; c) Shelkh Hassan Abdullah Fahaih; d) Hassan Al-Turki; e) Hassan Abdillahi Hersi Turki; f) Sheikh Hassan Turki; g) Xasan Cabdilaahi Xirsi; h) Xasan Cabdulle Xirsi', '04', 'Sheikh Hassan Turki', 'SHEIKH HASSAN TURKI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('555', '20170807', '����췢[2017]106��', '1: HASSAN 2: ABDULLAH 3: HERSI 4: AL-TURKI', 'a) Hassan Turki; b) Hassen Abdelle Fihiye; c) Shelkh Hassan Abdullah Fahaih; d) Hassan Al-Turki; e) Hassan Abdillahi Hersi Turki; f) Sheikh Hassan Turki; g) Xasan Cabdilaahi Xirsi; h) Xasan Cabdulle Xirsi', '04', 'Hassen Abdelle Fihiye', 'HASSEN ABDELLE FIHIYE', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('556', '20170807', '����췢[2017]106��', '1: HASSAN 2: ABDULLAH 3: HERSI 4: AL-TURKI', 'a) Hassan Turki; b) Hassen Abdelle Fihiye; c) Shelkh Hassan Abdullah Fahaih; d) Hassan Al-Turki; e) Hassan Abdillahi Hersi Turki; f) Sheikh Hassan Turki; g) Xasan Cabdilaahi Xirsi; h) Xasan Cabdulle Xirsi', '04', 'Hassan Turki', 'HASSAN TURKI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('557', '20170807', '����췢[2017]106��', '1: HASSAN 2: ABDULLAH 3: HERSI 4: AL-TURKI', 'a) Hassan Turki; b) Hassen Abdelle Fihiye; c) Shelkh Hassan Abdullah Fahaih; d) Hassan Al-Turki; e) Hassan Abdillahi Hersi Turki; f) Sheikh Hassan Turki; g) Xasan Cabdilaahi Xirsi; h) Xasan Cabdulle Xirsi', '04', 'Xasan Cabdilaahi Xirsi', 'XASAN CABDILAAHI XIRSI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('558', '20170807', '����췢[2017]106��', '1: HASSAN 2: DAHIR 3: AWEYS 4: na', 'a) Ali Sheikh Hassan Dahir Aweys; b) Awes Shaykh Hassan Dahir; c) Hassen Dahir Aweyes; d) Ahmed Dahir Aweys; e) Mohammed Hassan Ibrahim; f) Aweys Hassan Dahir; g) Hassan Tahir Oais; h) Hassan Tahir Uways; i) Hassan Dahir Awes', '02', 'HASSAN DAHIR', 'HASSAN DAHIR', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('559', '20170807', '����췢[2017]106��', '1: HASSAN 2: DAHIR 3: AWEYS 4: na', 'a) Ali Sheikh Hassan Dahir Aweys; b) Awes Shaykh Hassan Dahir; c) Hassen Dahir Aweyes; d) Ahmed Dahir Aweys; e) Mohammed Hassan Ibrahim; f) Aweys Hassan Dahir; g) Hassan Tahir Oais; h) Hassan Tahir Uways; i) Hassan Dahir Awes', '04', 'Aweys Hassan Dahir', 'AWEYS HASSAN DAHIR', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('560', '20170807', '����췢[2017]106��', '1: HASSAN 2: DAHIR 3: AWEYS 4: na', 'a) Ali Sheikh Hassan Dahir Aweys; b) Awes Shaykh Hassan Dahir; c) Hassen Dahir Aweyes; d) Ahmed Dahir Aweys; e) Mohammed Hassan Ibrahim; f) Aweys Hassan Dahir; g) Hassan Tahir Oais; h) Hassan Tahir Uways; i) Hassan Dahir Awes', '04', 'Ahmed Dahir Aweys', 'AHMED DAHIR AWEYS', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('561', '20170807', '����췢[2017]106��', '1: HASSAN 2: DAHIR 3: AWEYS 4: na', 'a) Ali Sheikh Hassan Dahir Aweys; b) Awes Shaykh Hassan Dahir; c) Hassen Dahir Aweyes; d) Ahmed Dahir Aweys; e) Mohammed Hassan Ibrahim; f) Aweys Hassan Dahir; g) Hassan Tahir Oais; h) Hassan Tahir Uways; i) Hassan Dahir Awes', '04', 'Mohammed Hassan Ibrahim', 'MOHAMMED HASSAN IBRAHIM', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('562', '20170807', '����췢[2017]106��', '1: HASSAN 2: DAHIR 3: AWEYS 4: na', 'a) Ali Sheikh Hassan Dahir Aweys; b) Awes Shaykh Hassan Dahir; c) Hassen Dahir Aweyes; d) Ahmed Dahir Aweys; e) Mohammed Hassan Ibrahim; f) Aweys Hassan Dahir; g) Hassan Tahir Oais; h) Hassan Tahir Uways; i) Hassan Dahir Awes', '04', 'Hassen Dahir Aweyes', 'HASSEN DAHIR AWEYES', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('563', '20170807', '����췢[2017]106��', '1: HASSAN 2: DAHIR 3: AWEYS 4: na', 'a) Ali Sheikh Hassan Dahir Aweys; b) Awes Shaykh Hassan Dahir; c) Hassen Dahir Aweyes; d) Ahmed Dahir Aweys; e) Mohammed Hassan Ibrahim; f) Aweys Hassan Dahir; g) Hassan Tahir Oais; h) Hassan Tahir Uways; i) Hassan Dahir Awes', '04', 'Awes Shaykh Hassan Dahir', 'AWES SHAYKH HASSAN DAHIR', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('564', '20170807', '����췢[2017]106��', '1: HASSAN 2: DAHIR 3: AWEYS 4: na', 'a) Ali Sheikh Hassan Dahir Aweys; b) Awes Shaykh Hassan Dahir; c) Hassen Dahir Aweyes; d) Ahmed Dahir Aweys; e) Mohammed Hassan Ibrahim; f) Aweys Hassan Dahir; g) Hassan Tahir Oais; h) Hassan Tahir Uways; i) Hassan Dahir Awes', '04', 'Ali Sheikh Hassan Dahir Aweys', 'ALI SHEIKH HASSAN DAHIR AWEYS', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('565', '20170807', '����췢[2017]106��', '1: HASSAN 2: DAHIR 3: AWEYS 4: na', 'a) Ali Sheikh Hassan Dahir Aweys; b) Awes Shaykh Hassan Dahir; c) Hassen Dahir Aweyes; d) Ahmed Dahir Aweys; e) Mohammed Hassan Ibrahim; f) Aweys Hassan Dahir; g) Hassan Tahir Oais; h) Hassan Tahir Uways; i) Hassan Dahir Awes', '04', 'Hassan Dahir Awes', 'HASSAN DAHIR AWES', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('566', '20170807', '����췢[2017]106��', '1: HASSAN 2: DAHIR 3: AWEYS 4: na', 'a) Ali Sheikh Hassan Dahir Aweys; b) Awes Shaykh Hassan Dahir; c) Hassen Dahir Aweyes; d) Ahmed Dahir Aweys; e) Mohammed Hassan Ibrahim; f) Aweys Hassan Dahir; g) Hassan Tahir Oais; h) Hassan Tahir Uways; i) Hassan Dahir Awes', '04', 'Hassan Tahir Uways', 'HASSAN TAHIR UWAYS', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('567', '20170807', '����췢[2017]106��', '1: HASSAN 2: DAHIR 3: AWEYS 4: na', 'a) Ali Sheikh Hassan Dahir Aweys; b) Awes Shaykh Hassan Dahir; c) Hassen Dahir Aweyes; d) Ahmed Dahir Aweys; e) Mohammed Hassan Ibrahim; f) Aweys Hassan Dahir; g) Hassan Tahir Oais; h) Hassan Tahir Uways; i) Hassan Dahir Awes', '04', 'Hassan Tahir Oais', 'HASSAN TAHIR OAIS', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('568', '20170807', '����췢[2017]106��', '1: HILARION 2: DEL ROSARIO 3: SANTOS III 4: na', 'a) Akmad Santos; b) Ahmed Islam; c) Ahmad Isalam Santos; d) Abu Hamsa; e) Hilarion Santos III; f) Abu Abdullah Santos; g) Faisal Santos', '02', 'HILARION DEL ROSARIO', 'HILARION DEL ROSARIO', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('569', '20170807', '����췢[2017]106��', '1: HILARION 2: DEL ROSARIO 3: SANTOS III 4: na', 'a) Akmad Santos; b) Ahmed Islam; c) Ahmad Isalam Santos; d) Abu Hamsa; e) Hilarion Santos III; f) Abu Abdullah Santos; g) Faisal Santos', '04', 'Faisal Santos', 'FAISAL SANTOS', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('570', '20170807', '����췢[2017]106��', '1: HILARION 2: DEL ROSARIO 3: SANTOS III 4: na', 'a) Akmad Santos; b) Ahmed Islam; c) Ahmad Isalam Santos; d) Abu Hamsa; e) Hilarion Santos III; f) Abu Abdullah Santos; g) Faisal Santos', '04', 'Ahmad Isalam Santos', 'AHMAD ISALAM SANTOS', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('571', '20170807', '����췢[2017]106��', '1: HILARION 2: DEL ROSARIO 3: SANTOS III 4: na', 'a) Akmad Santos; b) Ahmed Islam; c) Ahmad Isalam Santos; d) Abu Hamsa; e) Hilarion Santos III; f) Abu Abdullah Santos; g) Faisal Santos', '04', 'Ahmed Islam', 'AHMED ISLAM', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('572', '20170807', '����췢[2017]106��', '1: HILARION 2: DEL ROSARIO 3: SANTOS III 4: na', 'a) Akmad Santos; b) Ahmed Islam; c) Ahmad Isalam Santos; d) Abu Hamsa; e) Hilarion Santos III; f) Abu Abdullah Santos; g) Faisal Santos', '04', 'Hilarion Santos III', 'HILARION SANTOS III', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('573', '20170807', '����췢[2017]106��', '1: HILARION 2: DEL ROSARIO 3: SANTOS III 4: na', 'a) Akmad Santos; b) Ahmed Islam; c) Ahmad Isalam Santos; d) Abu Hamsa; e) Hilarion Santos III; f) Abu Abdullah Santos; g) Faisal Santos', '04', 'Abu Hamsa', 'ABU HAMSA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('574', '20170807', '����췢[2017]106��', '1: HILARION 2: DEL ROSARIO 3: SANTOS III 4: na', 'a) Akmad Santos; b) Ahmed Islam; c) Ahmad Isalam Santos; d) Abu Hamsa; e) Hilarion Santos III; f) Abu Abdullah Santos; g) Faisal Santos', '04', 'Akmad Santos', 'AKMAD SANTOS', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('575', '20170807', '����췢[2017]106��', '1: HILARION 2: DEL ROSARIO 3: SANTOS III 4: na', 'a) Akmad Santos; b) Ahmed Islam; c) Ahmad Isalam Santos; d) Abu Hamsa; e) Hilarion Santos III; f) Abu Abdullah Santos; g) Faisal Santos', '04', 'Abu Abdullah Santos', 'ABU ABDULLAH SANTOS', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('576', '20170807', '����췢[2017]106��', '1: HUSAYN 2: JUAYTHINI 3: na 4: na', 'a) Hussain Mohammed Hussein Aljeithni; b) Husayn Muhammad al-Juaythini; c) Husayn Muhammad Husayn al-Juaythini; d) Husayn Muhamad Husayn al- Juaythini; e) Husayn Muhammad Husayn Juaythini', '02', 'HUSAYN JUAYTHINI', 'HUSAYN JUAYTHINI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('577', '20170807', '����췢[2017]106��', '1: HUSAYN 2: JUAYTHINI 3: na 4: na', 'a) Hussain Mohammed Hussein Aljeithni; b) Husayn Muhammad al-Juaythini; c) Husayn Muhammad Husayn al-Juaythini; d) Husayn Muhamad Husayn al- Juaythini; e) Husayn Muhammad Husayn Juaythini', '04', 'Hussain Mohammed Hussein Aljeithni', 'HUSSAIN MOHAMMED HUSSEIN ALJEITHNI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('578', '20170807', '����췢[2017]106��', '1: HUSAYN 2: JUAYTHINI 3: na 4: na', 'a) Hussain Mohammed Hussein Aljeithni; b) Husayn Muhammad al-Juaythini; c) Husayn Muhammad Husayn al-Juaythini; d) Husayn Muhamad Husayn al- Juaythini; e) Husayn Muhammad Husayn Juaythini', '04', 'Husayn Muhammad al-Juaythini', 'HUSAYN MUHAMMAD AL-JUAYTHINI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('579', '20170807', '����췢[2017]106��', '1: HUSAYN 2: JUAYTHINI 3: na 4: na', 'a) Hussain Mohammed Hussein Aljeithni; b) Husayn Muhammad al-Juaythini; c) Husayn Muhammad Husayn al-Juaythini; d) Husayn Muhamad Husayn al- Juaythini; e) Husayn Muhammad Husayn Juaythini', '04', 'Husayn Muhamad Husayn al- Juaythini', 'HUSAYN MUHAMAD HUSAYN AL- JUAYTHINI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('580', '20170807', '����췢[2017]106��', '1: HUSAYN 2: JUAYTHINI 3: na 4: na', 'a) Hussain Mohammed Hussein Aljeithni; b) Husayn Muhammad al-Juaythini; c) Husayn Muhammad Husayn al-Juaythini; d) Husayn Muhamad Husayn al- Juaythini; e) Husayn Muhammad Husayn Juaythini', '04', 'Husayn Muhammad Husayn Juaythini', 'HUSAYN MUHAMMAD HUSAYN JUAYTHINI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('581', '20170807', '����췢[2017]106��', '1: HUSAYN 2: JUAYTHINI 3: na 4: na', 'a) Hussain Mohammed Hussein Aljeithni; b) Husayn Muhammad al-Juaythini; c) Husayn Muhammad Husayn al-Juaythini; d) Husayn Muhamad Husayn al- Juaythini; e) Husayn Muhammad Husayn Juaythini', '04', 'Husayn Muhammad Husayn al-Juaythini', 'HUSAYN MUHAMMAD HUSAYN AL-JUAYTHINI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('582', '20170807', '����췢[2017]106��', '1: IBRAHIM 2: ALI 3: ABU BAKR 4: TANTOUSH', 'a) Abd al-Muhsin; b) Ibrahim Ali Muhammad Abu Bakr; c) Abdul Rahman; d) Abu Anas; e) Ibrahim Abubaker Tantouche; f) Ibrahim Abubaker Tantoush; g) Abd al-Muhsi; h) Abd al-Rahman; i) Abdel Ilah Sabri', '02', 'IBRAHIM ALI', 'IBRAHIM ALI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('583', '20170807', '����췢[2017]106��', '1: IBRAHIM 2: ALI 3: ABU BAKR 4: TANTOUSH', 'a) Abd al-Muhsin; b) Ibrahim Ali Muhammad Abu Bakr; c) Abdul Rahman; d) Abu Anas; e) Ibrahim Abubaker Tantouche; f) Ibrahim Abubaker Tantoush; g) Abd al-Muhsi; h) Abd al-Rahman; i) Abdel Ilah Sabri', '04', 'Ibrahim Abubaker Tantouche', 'IBRAHIM ABUBAKER TANTOUCHE', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('584', '20170807', '����췢[2017]106��', '1: IBRAHIM 2: ALI 3: ABU BAKR 4: TANTOUSH', 'a) Abd al-Muhsin; b) Ibrahim Ali Muhammad Abu Bakr; c) Abdul Rahman; d) Abu Anas; e) Ibrahim Abubaker Tantouche; f) Ibrahim Abubaker Tantoush; g) Abd al-Muhsi; h) Abd al-Rahman; i) Abdel Ilah Sabri', '04', 'Ibrahim Abubaker Tantoush', 'IBRAHIM ABUBAKER TANTOUSH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('585', '20170807', '����췢[2017]106��', '1: IBRAHIM 2: ALI 3: ABU BAKR 4: TANTOUSH', 'a) Abd al-Muhsin; b) Ibrahim Ali Muhammad Abu Bakr; c) Abdul Rahman; d) Abu Anas; e) Ibrahim Abubaker Tantouche; f) Ibrahim Abubaker Tantoush; g) Abd al-Muhsi; h) Abd al-Rahman; i) Abdel Ilah Sabri', '04', 'Abd al-Rahman', 'ABD AL-RAHMAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('586', '20170807', '����췢[2017]106��', '1: IBRAHIM 2: ALI 3: ABU BAKR 4: TANTOUSH', 'a) Abd al-Muhsin; b) Ibrahim Ali Muhammad Abu Bakr; c) Abdul Rahman; d) Abu Anas; e) Ibrahim Abubaker Tantouche; f) Ibrahim Abubaker Tantoush; g) Abd al-Muhsi; h) Abd al-Rahman; i) Abdel Ilah Sabri', '04', 'Abu Anas', 'ABU ANAS', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('587', '20170807', '����췢[2017]106��', '1: IBRAHIM 2: ALI 3: ABU BAKR 4: TANTOUSH', 'a) Abd al-Muhsin; b) Ibrahim Ali Muhammad Abu Bakr; c) Abdul Rahman; d) Abu Anas; e) Ibrahim Abubaker Tantouche; f) Ibrahim Abubaker Tantoush; g) Abd al-Muhsi; h) Abd al-Rahman; i) Abdel Ilah Sabri', '04', 'Ibrahim Ali Muhammad Abu Bakr', 'IBRAHIM ALI MUHAMMAD ABU BAKR', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('588', '20170807', '����췢[2017]106��', '1: IBRAHIM 2: ALI 3: ABU BAKR 4: TANTOUSH', 'a) Abd al-Muhsin; b) Ibrahim Ali Muhammad Abu Bakr; c) Abdul Rahman; d) Abu Anas; e) Ibrahim Abubaker Tantouche; f) Ibrahim Abubaker Tantoush; g) Abd al-Muhsi; h) Abd al-Rahman; i) Abdel Ilah Sabri', '04', 'Abdul Rahman', 'ABDUL RAHMAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('589', '20170807', '����췢[2017]106��', '1: IBRAHIM 2: ALI 3: ABU BAKR 4: TANTOUSH', 'a) Abd al-Muhsin; b) Ibrahim Ali Muhammad Abu Bakr; c) Abdul Rahman; d) Abu Anas; e) Ibrahim Abubaker Tantouche; f) Ibrahim Abubaker Tantoush; g) Abd al-Muhsi; h) Abd al-Rahman; i) Abdel Ilah Sabri', '04', 'Abd al-Muhsi', 'ABD AL-MUHSI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('590', '20170807', '����췢[2017]106��', '1: IBRAHIM 2: ALI 3: ABU BAKR 4: TANTOUSH', 'a) Abd al-Muhsin; b) Ibrahim Ali Muhammad Abu Bakr; c) Abdul Rahman; d) Abu Anas; e) Ibrahim Abubaker Tantouche; f) Ibrahim Abubaker Tantoush; g) Abd al-Muhsi; h) Abd al-Rahman; i) Abdel Ilah Sabri', '04', 'Abdel Ilah Sabri', 'ABDEL ILAH SABRI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('591', '20170807', '����췢[2017]106��', '1: IBRAHIM 2: ALI 3: ABU BAKR 4: TANTOUSH', 'a) Abd al-Muhsin; b) Ibrahim Ali Muhammad Abu Bakr; c) Abdul Rahman; d) Abu Anas; e) Ibrahim Abubaker Tantouche; f) Ibrahim Abubaker Tantoush; g) Abd al-Muhsi; h) Abd al-Rahman; i) Abdel Ilah Sabri', '04', 'Abd al-Muhsin', 'ABD AL-MUHSIN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('592', '20170807', '����췢[2017]106��', '1: IBRAHIM 2: AWWAD 3: IBRAHIM 4: ALI AL-BADRI AL-SAMARRAI', 'a) Dr. Ibrahim Awwad Ibrahim Ali al-Badri al-Samarrai (born in 1971 in Samarra, Iraq (Ibrahim Awad Ibrahim al-Badri al-Samarrai; Ibrahim Awad Ibrahim al-Samarrai; Dr. Ibrahim Awwad Ibrahim al-Samarra))', '02', 'IBRAHIM AWWAD', 'IBRAHIM AWWAD', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('593', '20170807', '����췢[2017]106��', '1: IBRAHIM 2: AWWAD 3: IBRAHIM 4: ALI AL-BADRI AL-SAMARRAI', 'a) Dr. Ibrahim Awwad Ibrahim Ali al-Badri al-Samarrai (born in 1971 in Samarra, Iraq (Ibrahim Awad Ibrahim al-Badri al-Samarrai; Ibrahim Awad Ibrahim al-Samarrai; Dr. Ibrahim Awwad Ibrahim al-Samarra))', '03', 'Dr. Ibrahim Awwad Ibrahim Ali al-Badri al-Samarrai (born in 1971 in Samarra, Iraq (Ibrahim Awad Ibrahim al-Badri al-Samarrai; Ibrahim Awad Ibrahim al-Samarrai; Dr. Ibrahim Awwad Ibrahim al-Samarra))', 'DR. IBRAHIM AWWAD IBRAHIM ALI AL-BADRI AL-SAMARRAI (BORN IN 1971 IN SAMARRA, IRAQ (IBRAHIM AWAD IBRAHIM AL-BADRI AL-SAMARRAI; IBRAHIM AWAD IBRAHIM AL-SAMARRAI; DR. IBRAHIM AWWAD IBRAHIM AL-SAMARRA))', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('594', '20170807', '����췢[2017]106��', '1: IBRAHIM 2: HASSAN 3: TALI 4: AL-ASIRI', 'a) Ibrahim Hassan Tali Asiri; b) Ibrahim Hasan Talea Aseeri; c) Ibrahim Hassan al-Asiri; d) Ibrahim Hasan Tali Asiri; e) Ibrahim Hassan Tali Assiri; f) Ibrahim Hasan Tali A Asiri; g) Ibrahim Hasan Tali al-Asiri; h) Ibrahim al-Asiri; i) Ibrahim Hassan Al Asiri', '02', 'IBRAHIM HASSAN', 'IBRAHIM HASSAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('595', '20170807', '����췢[2017]106��', '1: IBRAHIM 2: HASSAN 3: TALI 4: AL-ASIRI', 'a) Ibrahim Hassan Tali Asiri; b) Ibrahim Hasan Talea Aseeri; c) Ibrahim Hassan al-Asiri; d) Ibrahim Hasan Tali Asiri; e) Ibrahim Hassan Tali Assiri; f) Ibrahim Hasan Tali A Asiri; g) Ibrahim Hasan Tali al-Asiri; h) Ibrahim al-Asiri; i) Ibrahim Hassan Al Asiri', '04', 'Ibrahim Hasan Tali al-Asiri', 'IBRAHIM HASAN TALI AL-ASIRI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('596', '20170807', '����췢[2017]106��', '1: IBRAHIM 2: HASSAN 3: TALI 4: AL-ASIRI', 'a) Ibrahim Hassan Tali Asiri; b) Ibrahim Hasan Talea Aseeri; c) Ibrahim Hassan al-Asiri; d) Ibrahim Hasan Tali Asiri; e) Ibrahim Hassan Tali Assiri; f) Ibrahim Hasan Tali A Asiri; g) Ibrahim Hasan Tali al-Asiri; h) Ibrahim al-Asiri; i) Ibrahim Hassan Al Asiri', '04', 'Ibrahim al-Asiri', 'IBRAHIM AL-ASIRI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('597', '20170807', '����췢[2017]106��', '1: IBRAHIM 2: HASSAN 3: TALI 4: AL-ASIRI', 'a) Ibrahim Hassan Tali Asiri; b) Ibrahim Hasan Talea Aseeri; c) Ibrahim Hassan al-Asiri; d) Ibrahim Hasan Tali Asiri; e) Ibrahim Hassan Tali Assiri; f) Ibrahim Hasan Tali A Asiri; g) Ibrahim Hasan Tali al-Asiri; h) Ibrahim al-Asiri; i) Ibrahim Hassan Al Asiri', '04', 'Ibrahim Hassan Al Asiri', 'IBRAHIM HASSAN AL ASIRI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('598', '20170807', '����췢[2017]106��', '1: IBRAHIM 2: HASSAN 3: TALI 4: AL-ASIRI', 'a) Ibrahim Hassan Tali Asiri; b) Ibrahim Hasan Talea Aseeri; c) Ibrahim Hassan al-Asiri; d) Ibrahim Hasan Tali Asiri; e) Ibrahim Hassan Tali Assiri; f) Ibrahim Hasan Tali A Asiri; g) Ibrahim Hasan Tali al-Asiri; h) Ibrahim al-Asiri; i) Ibrahim Hassan Al Asiri', '04', 'Ibrahim Hassan al-Asiri', 'IBRAHIM HASSAN AL-ASIRI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('599', '20170807', '����췢[2017]106��', '1: IBRAHIM 2: HASSAN 3: TALI 4: AL-ASIRI', 'a) Ibrahim Hassan Tali Asiri; b) Ibrahim Hasan Talea Aseeri; c) Ibrahim Hassan al-Asiri; d) Ibrahim Hasan Tali Asiri; e) Ibrahim Hassan Tali Assiri; f) Ibrahim Hasan Tali A Asiri; g) Ibrahim Hasan Tali al-Asiri; h) Ibrahim al-Asiri; i) Ibrahim Hassan Al Asiri', '04', 'Ibrahim Hasan Talea Aseeri', 'IBRAHIM HASAN TALEA ASEERI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('600', '20170807', '����췢[2017]106��', '1: IBRAHIM 2: HASSAN 3: TALI 4: AL-ASIRI', 'a) Ibrahim Hassan Tali Asiri; b) Ibrahim Hasan Talea Aseeri; c) Ibrahim Hassan al-Asiri; d) Ibrahim Hasan Tali Asiri; e) Ibrahim Hassan Tali Assiri; f) Ibrahim Hasan Tali A Asiri; g) Ibrahim Hasan Tali al-Asiri; h) Ibrahim al-Asiri; i) Ibrahim Hassan Al Asiri', '04', 'Ibrahim Hassan Tali Asiri', 'IBRAHIM HASSAN TALI ASIRI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('601', '20170807', '����췢[2017]106��', '1: IBRAHIM 2: HASSAN 3: TALI 4: AL-ASIRI', 'a) Ibrahim Hassan Tali Asiri; b) Ibrahim Hasan Talea Aseeri; c) Ibrahim Hassan al-Asiri; d) Ibrahim Hasan Tali Asiri; e) Ibrahim Hassan Tali Assiri; f) Ibrahim Hasan Tali A Asiri; g) Ibrahim Hasan Tali al-Asiri; h) Ibrahim al-Asiri; i) Ibrahim Hassan Al Asiri', '04', 'Ibrahim Hasan Tali A Asiri', 'IBRAHIM HASAN TALI A ASIRI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('602', '20170807', '����췢[2017]106��', '1: IBRAHIM 2: HASSAN 3: TALI 4: AL-ASIRI', 'a) Ibrahim Hassan Tali Asiri; b) Ibrahim Hasan Talea Aseeri; c) Ibrahim Hassan al-Asiri; d) Ibrahim Hasan Tali Asiri; e) Ibrahim Hassan Tali Assiri; f) Ibrahim Hasan Tali A Asiri; g) Ibrahim Hasan Tali al-Asiri; h) Ibrahim al-Asiri; i) Ibrahim Hassan Al Asiri', '04', 'Ibrahim Hasan Tali Asiri', 'IBRAHIM HASAN TALI ASIRI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('603', '20170807', '����췢[2017]106��', '1: IBRAHIM 2: HASSAN 3: TALI 4: AL-ASIRI', 'a) Ibrahim Hassan Tali Asiri; b) Ibrahim Hasan Talea Aseeri; c) Ibrahim Hassan al-Asiri; d) Ibrahim Hasan Tali Asiri; e) Ibrahim Hassan Tali Assiri; f) Ibrahim Hasan Tali A Asiri; g) Ibrahim Hasan Tali al-Asiri; h) Ibrahim al-Asiri; i) Ibrahim Hassan Al Asiri', '04', 'Ibrahim Hassan Tali Assiri', 'IBRAHIM HASSAN TALI ASSIRI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('604', '20170807', '����췢[2017]106��', '1: IBRAHIM 2: ISA HAJJI 3: MUHAMMAD 4: AL-BAKR', 'a) Ibrahim Issa Haji Muhammad al-Bakar; b) Ibrahim Isa Haji al-Bakr; c) Ibrahim Issa Hijji Mohd Albaker; d) Ibrahim Issa Hijji Muhammad al-Baker; e) lbrahim Issa al-Bakar; f) Ibrahim al-Bakr', '02', 'IBRAHIM ISA HAJJI', 'IBRAHIM ISA HAJJI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('605', '20170807', '����췢[2017]106��', '1: IBRAHIM 2: ISA HAJJI 3: MUHAMMAD 4: AL-BAKR', 'a) Ibrahim Issa Haji Muhammad al-Bakar; b) Ibrahim Isa Haji al-Bakr; c) Ibrahim Issa Hijji Mohd Albaker; d) Ibrahim Issa Hijji Muhammad al-Baker; e) lbrahim Issa al-Bakar; f) Ibrahim al-Bakr', '04', 'Ibrahim Issa Hijji Muhammad al-Baker', 'IBRAHIM ISSA HIJJI MUHAMMAD AL-BAKER', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('606', '20170807', '����췢[2017]106��', '1: IBRAHIM 2: ISA HAJJI 3: MUHAMMAD 4: AL-BAKR', 'a) Ibrahim Issa Haji Muhammad al-Bakar; b) Ibrahim Isa Haji al-Bakr; c) Ibrahim Issa Hijji Mohd Albaker; d) Ibrahim Issa Hijji Muhammad al-Baker; e) lbrahim Issa al-Bakar; f) Ibrahim al-Bakr', '04', 'Ibrahim al-Bakr', 'IBRAHIM AL-BAKR', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('607', '20170807', '����췢[2017]106��', '1: IBRAHIM 2: ISA HAJJI 3: MUHAMMAD 4: AL-BAKR', 'a) Ibrahim Issa Haji Muhammad al-Bakar; b) Ibrahim Isa Haji al-Bakr; c) Ibrahim Issa Hijji Mohd Albaker; d) Ibrahim Issa Hijji Muhammad al-Baker; e) lbrahim Issa al-Bakar; f) Ibrahim al-Bakr', '04', 'Ibrahim Issa Haji Muhammad al-Bakar', 'IBRAHIM ISSA HAJI MUHAMMAD AL-BAKAR', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('608', '20170807', '����췢[2017]106��', '1: IBRAHIM 2: ISA HAJJI 3: MUHAMMAD 4: AL-BAKR', 'a) Ibrahim Issa Haji Muhammad al-Bakar; b) Ibrahim Isa Haji al-Bakr; c) Ibrahim Issa Hijji Mohd Albaker; d) Ibrahim Issa Hijji Muhammad al-Baker; e) lbrahim Issa al-Bakar; f) Ibrahim al-Bakr', '04', 'Ibrahim Isa Haji al-Bakr', 'IBRAHIM ISA HAJI AL-BAKR', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('609', '20170807', '����췢[2017]106��', '1: IBRAHIM 2: ISA HAJJI 3: MUHAMMAD 4: AL-BAKR', 'a) Ibrahim Issa Haji Muhammad al-Bakar; b) Ibrahim Isa Haji al-Bakr; c) Ibrahim Issa Hijji Mohd Albaker; d) Ibrahim Issa Hijji Muhammad al-Baker; e) lbrahim Issa al-Bakar; f) Ibrahim al-Bakr', '04', 'Ibrahim Issa Hijji Mohd Albaker', 'IBRAHIM ISSA HIJJI MOHD ALBAKER', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('610', '20170807', '����췢[2017]106��', '1: IBRAHIM 2: ISA HAJJI 3: MUHAMMAD 4: AL-BAKR', 'a) Ibrahim Issa Haji Muhammad al-Bakar; b) Ibrahim Isa Haji al-Bakr; c) Ibrahim Issa Hijji Mohd Albaker; d) Ibrahim Issa Hijji Muhammad al-Baker; e) lbrahim Issa al-Bakar; f) Ibrahim al-Bakr', '04', 'lbrahim Issa al-Bakar', 'LBRAHIM ISSA AL-BAKAR', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('611', '20170807', '����췢[2017]106��', '1: IBRAHIM 2: MOHAMED KHALIL 3: na 4: na', 'a) Khalil Ibrahim Jassem born 2 May 1972 in Baghdad, Iraq; b) Khalil Ibrahim Mohammad born 3 Jul. 1975 in Mosul, Iraq; c) Khalil Ibrahim Al Zafiri (born 1972); d) Khalil born 2 May 1975; e) Khalil Ibrahim al-Zahiri born 2 Jul. 1975 in Mosul', '02', 'IBRAHIM MOHAMED KHALIL', 'IBRAHIM MOHAMED KHALIL', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('612', '20170807', '����췢[2017]106��', '1: IBRAHIM 2: MOHAMED KHALIL 3: na 4: na', 'a) Khalil Ibrahim Jassem born 2 May 1972 in Baghdad, Iraq; b) Khalil Ibrahim Mohammad born 3 Jul. 1975 in Mosul, Iraq; c) Khalil Ibrahim Al Zafiri (born 1972); d) Khalil born 2 May 1975; e) Khalil Ibrahim al-Zahiri born 2 Jul. 1975 in Mosul', '04', 'Khalil Ibrahim al-Zahiri', 'KHALIL IBRAHIM AL-ZAHIRI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('613', '20170807', '����췢[2017]106��', '1: IBRAHIM 2: MOHAMED KHALIL 3: na 4: na', 'a) Khalil Ibrahim Jassem born 2 May 1972 in Baghdad, Iraq; b) Khalil Ibrahim Mohammad born 3 Jul. 1975 in Mosul, Iraq; c) Khalil Ibrahim Al Zafiri (born 1972); d) Khalil born 2 May 1975; e) Khalil Ibrahim al-Zahiri born 2 Jul. 1975 in Mosul', '04', 'Khalil Ibrahim Al Zafiri', 'KHALIL IBRAHIM AL ZAFIRI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('614', '20170807', '����췢[2017]106��', '1: IBRAHIM 2: MOHAMED KHALIL 3: na 4: na', 'a) Khalil Ibrahim Jassem born 2 May 1972 in Baghdad, Iraq; b) Khalil Ibrahim Mohammad born 3 Jul. 1975 in Mosul, Iraq; c) Khalil Ibrahim Al Zafiri (born 1972); d) Khalil born 2 May 1975; e) Khalil Ibrahim al-Zahiri born 2 Jul. 1975 in Mosul', '04', 'Khalil Ibrahim Mohammad', 'KHALIL IBRAHIM MOHAMMAD', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('615', '20170807', '����췢[2017]106��', '1: IBRAHIM 2: MOHAMED KHALIL 3: na 4: na', 'a) Khalil Ibrahim Jassem born 2 May 1972 in Baghdad, Iraq; b) Khalil Ibrahim Mohammad born 3 Jul. 1975 in Mosul, Iraq; c) Khalil Ibrahim Al Zafiri (born 1972); d) Khalil born 2 May 1975; e) Khalil Ibrahim al-Zahiri born 2 Jul. 1975 in Mosul', '04', 'Khalil', 'KHALIL', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('616', '20170807', '����췢[2017]106��', '1: IBRAHIM 2: MOHAMED KHALIL 3: na 4: na', 'a) Khalil Ibrahim Jassem born 2 May 1972 in Baghdad, Iraq; b) Khalil Ibrahim Mohammad born 3 Jul. 1975 in Mosul, Iraq; c) Khalil Ibrahim Al Zafiri (born 1972); d) Khalil born 2 May 1975; e) Khalil Ibrahim al-Zahiri born 2 Jul. 1975 in Mosul', '04', 'Khalil Ibrahim Jassem', 'KHALIL IBRAHIM JASSEM', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('617', '20170807', '����췢[2017]106��', '1: IBRAHIM 2: SULEIMAN 3: HAMAD 4: AL-HABLAIN', 'a) Barahim Suliman H. al Hblian', '02', 'IBRAHIM SULEIMAN', 'IBRAHIM SULEIMAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('618', '20170807', '����췢[2017]106��', '1: IBRAHIM 2: SULEIMAN 3: HAMAD 4: AL-HABLAIN', 'a) Barahim Suliman H. al Hblian', '03', 'Barahim Suliman H. al Hblian', 'BARAHIM SULIMAN H. AL HBLIAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('619', '20170807', '����췢[2017]106��', '1: IMAD 2: BEN BECHIR 3: BEN HAMDA 4: AL-JAMMALI', null, '02', 'IMAD BEN BECHIR', 'IMAD BEN BECHIR', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('620', '20170807', '����췢[2017]106��', '1: IMED 2: BEN MEKKI 3: ZARKAOUI 4: na', 'a) Dour Nadre born 15 Jan. 1974 in Morocco; b) Dour Nadre born 15 Jan. 1973 in Morocco; c) Daour Nadre born 31 Mar. 1975 in Algeria; d) Imad ben al-Mekki ben al-Akhdar al-Zarkaoui', '02', 'IMED BEN MEKKI', 'IMED BEN MEKKI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('621', '20170807', '����췢[2017]106��', '1: IMED 2: BEN MEKKI 3: ZARKAOUI 4: na', 'a) Dour Nadre born 15 Jan. 1974 in Morocco; b) Dour Nadre born 15 Jan. 1973 in Morocco; c) Daour Nadre born 31 Mar. 1975 in Algeria; d) Imad ben al-Mekki ben al-Akhdar al-Zarkaoui', '04', 'Daour Nadre', 'DAOUR NADRE', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('622', '20170807', '����췢[2017]106��', '1: IMED 2: BEN MEKKI 3: ZARKAOUI 4: na', 'a) Dour Nadre born 15 Jan. 1974 in Morocco; b) Dour Nadre born 15 Jan. 1973 in Morocco; c) Daour Nadre born 31 Mar. 1975 in Algeria; d) Imad ben al-Mekki ben al-Akhdar al-Zarkaoui', '04', 'Dour Nadre', 'DOUR NADRE', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('623', '20170807', '����췢[2017]106��', '1: IMED 2: BEN MEKKI 3: ZARKAOUI 4: na', 'a) Dour Nadre born 15 Jan. 1974 in Morocco; b) Dour Nadre born 15 Jan. 1973 in Morocco; c) Daour Nadre born 31 Mar. 1975 in Algeria; d) Imad ben al-Mekki ben al-Akhdar al-Zarkaoui', '04', 'Imad ben al-Mekki ben al-Akhdar al-Zarkaoui', 'IMAD BEN AL-MEKKI BEN AL-AKHDAR AL-ZARKAOUI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('624', '20170807', '����췢[2017]106��', '1: ISAM 2: ALI 3: MOHAMED 4: ALOUCHE', 'a) Mansour Thaer born 21 Mar. 1974 in Baghdad. Iraq', '02', 'ISAM ALI 3: MOHAMED', 'ISAM ALI 3: MOHAMED', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('625', '20170807', '����췢[2017]106��', '1: ISAM 2: ALI 3: MOHAMED 4: ALOUCHE', 'a) Mansour Thaer born 21 Mar. 1974 in Baghdad. Iraq', '03', 'Mansour Thaer born 21 Mar. 1974 in Baghdad. Iraq', 'MANSOUR THAER BORN 21 MAR. 1974 IN BAGHDAD. IRAQ', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('626', '20170807', '����췢[2017]106��', '1: ISLAM 2: SEIT-UMAROVICH 3: ATABIEV 4: na', null, '02', 'ISLAM SEIT-UMAROVICH', 'ISLAM SEIT-UMAROVICH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('627', '20170807', '����췢[2017]106��', '1: ISNILON 2: TOTONI 3: HAPILON 4: na', 'a) Isnilon Hapilun; b) Isnilun Hapilun; c) Abu Musab; d) Salahudin; e) Tuan Isnilon', '02', 'ISNILON TOTONI', 'ISNILON TOTONI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('628', '20170807', '����췢[2017]106��', '1: ISNILON 2: TOTONI 3: HAPILON 4: na', 'a) Isnilon Hapilun; b) Isnilun Hapilun; c) Abu Musab; d) Salahudin; e) Tuan Isnilon', '04', 'Isnilon Hapilun', 'ISNILON HAPILUN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('629', '20170807', '����췢[2017]106��', '1: ISNILON 2: TOTONI 3: HAPILON 4: na', 'a) Isnilon Hapilun; b) Isnilun Hapilun; c) Abu Musab; d) Salahudin; e) Tuan Isnilon', '04', 'Isnilun Hapilun', 'ISNILUN HAPILUN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('630', '20170807', '����췢[2017]106��', '1: ISNILON 2: TOTONI 3: HAPILON 4: na', 'a) Isnilon Hapilun; b) Isnilun Hapilun; c) Abu Musab; d) Salahudin; e) Tuan Isnilon', '04', 'Salahudin', 'SALAHUDIN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('631', '20170807', '����췢[2017]106��', '1: ISNILON 2: TOTONI 3: HAPILON 4: na', 'a) Isnilon Hapilun; b) Isnilun Hapilun; c) Abu Musab; d) Salahudin; e) Tuan Isnilon', '04', 'Tuan Isnilon', 'TUAN ISNILON', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('632', '20170807', '����췢[2017]106��', '1: ISNILON 2: TOTONI 3: HAPILON 4: na', 'a) Isnilon Hapilun; b) Isnilun Hapilun; c) Abu Musab; d) Salahudin; e) Tuan Isnilon', '04', 'Abu Musab', 'ABU MUSAB', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('633', '20170807', '����췢[2017]106��', '1: IYAD 2: AG GHALI 3: na 4: na', 'Sidi Mohamed Arhali', '02', 'IYAD AG GHALI', 'IYAD AG GHALI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('634', '20170807', '����췢[2017]106��', '1: IYAD 2: AG GHALI 3: na 4: na', 'Sidi Mohamed Arhali', '03', 'Sidi Mohamed Arhali', 'SIDI MOHAMED ARHALI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('635', '20170807', '����췢[2017]106��', '1: IYAD 2: NAZMI 3: SALIH 4: KHALIL', 'a) Ayyad Nazmi Salih Khalil; b) Eyad Nazmi Saleh Khalil', '02', 'IYAD NAZMI', 'IYAD NAZMI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('636', '20170807', '����췢[2017]106��', '1: IYAD 2: NAZMI 3: SALIH 4: KHALIL', 'a) Ayyad Nazmi Salih Khalil; b) Eyad Nazmi Saleh Khalil', '04', 'Eyad Nazmi Saleh Khalil', 'EYAD NAZMI SALEH KHALIL', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('637', '20170807', '����췢[2017]106��', '1: IYAD 2: NAZMI 3: SALIH 4: KHALIL', 'a) Ayyad Nazmi Salih Khalil; b) Eyad Nazmi Saleh Khalil', '04', 'Ayyad Nazmi Salih Khalil', 'AYYAD NAZMI SALIH KHALIL', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('638', '20170807', '����췢[2017]106��', '1: JABER 2: ABDALLAH 3: JABER 4: AHMAD AL-JALAHMAH', 'a) Jaber Al-Jalamah; b) Abu Muhammad Al-Jalahmah; c) Jabir Ahmad Jalahmah; d) Jabir Abdallah Jabir Ahmad Al-Jalamah; e) Jabir Al-Jalhami', '02', 'JABER ABDALLAH', 'JABER ABDALLAH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('639', '20170807', '����췢[2017]106��', '1: JABER 2: ABDALLAH 3: JABER 4: AHMAD AL-JALAHMAH', 'a) Jaber Al-Jalamah; b) Abu Muhammad Al-Jalahmah; c) Jabir Ahmad Jalahmah; d) Jabir Abdallah Jabir Ahmad Al-Jalamah; e) Jabir Al-Jalhami', '04', 'Jabir Abdallah Jabir Ahmad Al-Jalamah', 'JABIR ABDALLAH JABIR AHMAD AL-JALAMAH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('640', '20170807', '����췢[2017]106��', '1: JABER 2: ABDALLAH 3: JABER 4: AHMAD AL-JALAHMAH', 'a) Jaber Al-Jalamah; b) Abu Muhammad Al-Jalahmah; c) Jabir Ahmad Jalahmah; d) Jabir Abdallah Jabir Ahmad Al-Jalamah; e) Jabir Al-Jalhami', '04', 'Jabir Ahmad Jalahmah', 'JABIR AHMAD JALAHMAH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('641', '20170807', '����췢[2017]106��', '1: JABER 2: ABDALLAH 3: JABER 4: AHMAD AL-JALAHMAH', 'a) Jaber Al-Jalamah; b) Abu Muhammad Al-Jalahmah; c) Jabir Ahmad Jalahmah; d) Jabir Abdallah Jabir Ahmad Al-Jalamah; e) Jabir Al-Jalhami', '04', 'Abu Muhammad Al-Jalahmah', 'ABU MUHAMMAD AL-JALAHMAH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('642', '20170807', '����췢[2017]106��', '1: JABER 2: ABDALLAH 3: JABER 4: AHMAD AL-JALAHMAH', 'a) Jaber Al-Jalamah; b) Abu Muhammad Al-Jalahmah; c) Jabir Ahmad Jalahmah; d) Jabir Abdallah Jabir Ahmad Al-Jalamah; e) Jabir Al-Jalhami', '04', 'Jabir Al-Jalhami', 'JABIR AL-JALHAMI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('643', '20170807', '����췢[2017]106��', '1: JABER 2: ABDALLAH 3: JABER 4: AHMAD AL-JALAHMAH', 'a) Jaber Al-Jalamah; b) Abu Muhammad Al-Jalahmah; c) Jabir Ahmad Jalahmah; d) Jabir Abdallah Jabir Ahmad Al-Jalamah; e) Jabir Al-Jalhami', '04', 'Jaber Al-Jalamah', 'JABER AL-JALAMAH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('644', '20170807', '����췢[2017]106��', '1: JAMAL 2: HOUSNI 3: na 4: na', 'a) Djamel II marocchino; b) Jamal Al Maghrebi; c) Hicham', '02', 'JAMAL HOUSNI', 'JAMAL HOUSNI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('645', '20170807', '����췢[2017]106��', '1: JAMAL 2: HOUSNI 3: na 4: na', 'a) Djamel II marocchino; b) Jamal Al Maghrebi; c) Hicham', '04', 'Hicham', 'HICHAM', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('646', '20170807', '����췢[2017]106��', '1: JAMAL 2: HOUSNI 3: na 4: na', 'a) Djamel II marocchino; b) Jamal Al Maghrebi; c) Hicham', '04', 'Djamel II marocchino', 'DJAMEL II MAROCCHINO', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('647', '20170807', '����췢[2017]106��', '1: JAMAL 2: HOUSNI 3: na 4: na', 'a) Djamel II marocchino; b) Jamal Al Maghrebi; c) Hicham', '04', 'Jamal Al Maghrebi', 'JAMAL AL MAGHREBI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('648', '20170807', '����췢[2017]106��', '1: KAMAL 2: BEN MAOELDI 3: BEN HASSAN 4: AL-HAMRAOUI', 'a) Hamroui Kamel ben Mouldi; b) Hamraoui Kamel born 21 Nov. 1977 in Morocco; c) Hamraoui Kamel born 21 Nov. 1977 in Tunisia; d) Hamraoui Kamel born 21 Oct. 1977 in Tunisia', '02', 'KAMAL BEN MAOELDI', 'KAMAL BEN MAOELDI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('649', '20170807', '����췢[2017]106��', '1: KAMAL 2: BEN MAOELDI 3: BEN HASSAN 4: AL-HAMRAOUI', 'a) Hamroui Kamel ben Mouldi; b) Hamraoui Kamel born 21 Nov. 1977 in Morocco; c) Hamraoui Kamel born 21 Nov. 1977 in Tunisia; d) Hamraoui Kamel born 21 Oct. 1977 in Tunisia', '04', 'Hamraoui Kamel', 'HAMRAOUI KAMEL', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('650', '20170807', '����췢[2017]106��', '1: KAMAL 2: BEN MAOELDI 3: BEN HASSAN 4: AL-HAMRAOUI', 'a) Hamroui Kamel ben Mouldi; b) Hamraoui Kamel born 21 Nov. 1977 in Morocco; c) Hamraoui Kamel born 21 Nov. 1977 in Tunisia; d) Hamraoui Kamel born 21 Oct. 1977 in Tunisia', '04', 'Hamraoui Kamel', 'HAMRAOUI KAMEL', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('651', '20170807', '����췢[2017]106��', '1: KAMAL 2: BEN MAOELDI 3: BEN HASSAN 4: AL-HAMRAOUI', 'a) Hamroui Kamel ben Mouldi; b) Hamraoui Kamel born 21 Nov. 1977 in Morocco; c) Hamraoui Kamel born 21 Nov. 1977 in Tunisia; d) Hamraoui Kamel born 21 Oct. 1977 in Tunisia', '04', 'Hamroui Kamel ben Mouldi', 'HAMROUI KAMEL BEN MOULDI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('652', '20170807', '����췢[2017]106��', '1: KAMAL 2: BEN MAOELDI 3: BEN HASSAN 4: AL-HAMRAOUI', 'a) Hamroui Kamel ben Mouldi; b) Hamraoui Kamel born 21 Nov. 1977 in Morocco; c) Hamraoui Kamel born 21 Nov. 1977 in Tunisia; d) Hamraoui Kamel born 21 Oct. 1977 in Tunisia', '04', 'Hamraoui Kamel', 'HAMRAOUI KAMEL', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('653', '20170807', '����췢[2017]106��', '1: KAMEL 2: DJERMANE 3: na 4: na', 'a) Bilal; b) Adel; c) Fodhil; d) Abou Abdeljalil', '02', 'KAMEL DJERMANE', 'KAMEL DJERMANE', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('654', '20170807', '����췢[2017]106��', '1: KAMEL 2: DJERMANE 3: na 4: na', 'a) Bilal; b) Adel; c) Fodhil; d) Abou Abdeljalil', '04', 'Bilal', 'BILAL', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('655', '20170807', '����췢[2017]106��', '1: KAMEL 2: DJERMANE 3: na 4: na', 'a) Bilal; b) Adel; c) Fodhil; d) Abou Abdeljalil', '04', 'Abou Abdeljalil', 'ABOU ABDELJALIL', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('656', '20170807', '����췢[2017]106��', '1: KAMEL 2: DJERMANE 3: na 4: na', 'a) Bilal; b) Adel; c) Fodhil; d) Abou Abdeljalil', '04', 'Fodhil', 'FODHIL', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('657', '20170807', '����췢[2017]106��', '1: KAMEL 2: DJERMANE 3: na 4: na', 'a) Bilal; b) Adel; c) Fodhil; d) Abou Abdeljalil', '04', 'Adel', 'ADEL', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('658', '20170807', '����췢[2017]106��', '1: KEVIN 2: GUIAVARCH 3: na 4: na', null, '02', 'KEVIN GUIAVARCH', 'KEVIN GUIAVARCH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('659', '20170807', '����췢[2017]106��', '1: KHALID 2: ABD AL-RAHMAN 3: HAMD 4: AL-FAWAZ', 'a) Khaled Al-Fauwaz; b) Khaled A. Al-Fauwaz; c) Khalid Al-Fawwaz; d) Khalik Al Fawwaz; e) Khaled Al-Fawwaz; f) Khaled Al Fawwaz; g) Khalid Abdulrahman H. Al Fawaz', '02', 'KHALID ABD AL-RAHMAN', 'KHALID ABD AL-RAHMAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('660', '20170807', '����췢[2017]106��', '1: KHALID 2: ABD AL-RAHMAN 3: HAMD 4: AL-FAWAZ', 'a) Khaled Al-Fauwaz; b) Khaled A. Al-Fauwaz; c) Khalid Al-Fawwaz; d) Khalik Al Fawwaz; e) Khaled Al-Fawwaz; f) Khaled Al Fawwaz; g) Khalid Abdulrahman H. Al Fawaz', '04', 'Khaled Al Fawwaz', 'KHALED AL FAWWAZ', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('661', '20170807', '����췢[2017]106��', '1: KHALID 2: ABD AL-RAHMAN 3: HAMD 4: AL-FAWAZ', 'a) Khaled Al-Fauwaz; b) Khaled A. Al-Fauwaz; c) Khalid Al-Fawwaz; d) Khalik Al Fawwaz; e) Khaled Al-Fawwaz; f) Khaled Al Fawwaz; g) Khalid Abdulrahman H. Al Fawaz', '04', 'Khalid Abdulrahman', 'KHALID ABDULRAHMAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('662', '20170807', '����췢[2017]106��', '1: KHALID 2: ABD AL-RAHMAN 3: HAMD 4: AL-FAWAZ', 'a) Khaled Al-Fauwaz; b) Khaled A. Al-Fauwaz; c) Khalid Al-Fawwaz; d) Khalik Al Fawwaz; e) Khaled Al-Fawwaz; f) Khaled Al Fawwaz; g) Khalid Abdulrahman H. Al Fawaz', '04', 'Al Fawaz', 'AL FAWAZ', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('663', '20170807', '����췢[2017]106��', '1: KHALID 2: ABD AL-RAHMAN 3: HAMD 4: AL-FAWAZ', 'a) Khaled Al-Fauwaz; b) Khaled A. Al-Fauwaz; c) Khalid Al-Fawwaz; d) Khalik Al Fawwaz; e) Khaled Al-Fawwaz; f) Khaled Al Fawwaz; g) Khalid Abdulrahman H. Al Fawaz', '04', 'Khalid Al-Fawwaz', 'KHALID AL-FAWWAZ', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('664', '20170807', '����췢[2017]106��', '1: KHALID 2: ABD AL-RAHMAN 3: HAMD 4: AL-FAWAZ', 'a) Khaled Al-Fauwaz; b) Khaled A. Al-Fauwaz; c) Khalid Al-Fawwaz; d) Khalik Al Fawwaz; e) Khaled Al-Fawwaz; f) Khaled Al Fawwaz; g) Khalid Abdulrahman H. Al Fawaz', '04', 'Khaled A. Al-Fauwaz', 'KHALED A. AL-FAUWAZ', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('665', '20170807', '����췢[2017]106��', '1: KHALID 2: ABD AL-RAHMAN 3: HAMD 4: AL-FAWAZ', 'a) Khaled Al-Fauwaz; b) Khaled A. Al-Fauwaz; c) Khalid Al-Fawwaz; d) Khalik Al Fawwaz; e) Khaled Al-Fawwaz; f) Khaled Al Fawwaz; g) Khalid Abdulrahman H. Al Fawaz', '04', 'Khaled Al-Fawwaz', 'KHALED AL-FAWWAZ', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('666', '20170807', '����췢[2017]106��', '1: KHALID 2: ABD AL-RAHMAN 3: HAMD 4: AL-FAWAZ', 'a) Khaled Al-Fauwaz; b) Khaled A. Al-Fauwaz; c) Khalid Al-Fawwaz; d) Khalik Al Fawwaz; e) Khaled Al-Fawwaz; f) Khaled Al Fawwaz; g) Khalid Abdulrahman H. Al Fawaz', '04', 'Khalik Al Fawwaz', 'KHALIK AL FAWWAZ', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('667', '20170807', '����췢[2017]106��', '1: KHALID 2: ABD AL-RAHMAN 3: HAMD 4: AL-FAWAZ', 'a) Khaled Al-Fauwaz; b) Khaled A. Al-Fauwaz; c) Khalid Al-Fawwaz; d) Khalik Al Fawwaz; e) Khaled Al-Fawwaz; f) Khaled Al Fawwaz; g) Khalid Abdulrahman H. Al Fawaz', '04', 'Khaled Al-Fauwaz', 'KHALED AL-FAUWAZ', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('668', '20170807', '����췢[2017]106��', '1: KHALIFA 2: MUHAMMAD 3: TURKI 4: AL-SUBAIY', 'a) Khalifa Mohd Turki Alsubaie; b) Khalifa Mohd Turki al-Subaie; c) Khalifa Al-Subayi; d) Khalifa Turki bin Muhammad bin al-Suaiy', '02', 'KHALIFA MUHAMMAD', 'KHALIFA MUHAMMAD', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('669', '20170807', '����췢[2017]106��', '1: KHALIFA 2: MUHAMMAD 3: TURKI 4: AL-SUBAIY', 'a) Khalifa Mohd Turki Alsubaie; b) Khalifa Mohd Turki al-Subaie; c) Khalifa Al-Subayi; d) Khalifa Turki bin Muhammad bin al-Suaiy', '04', 'Khalifa Turki bin Muhammad bin al-Suaiy', 'KHALIFA TURKI BIN MUHAMMAD BIN AL-SUAIY', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('670', '20170807', '����췢[2017]106��', '1: KHALIFA 2: MUHAMMAD 3: TURKI 4: AL-SUBAIY', 'a) Khalifa Mohd Turki Alsubaie; b) Khalifa Mohd Turki al-Subaie; c) Khalifa Al-Subayi; d) Khalifa Turki bin Muhammad bin al-Suaiy', '04', 'Khalifa Mohd Turki al-Subaie', 'KHALIFA MOHD TURKI AL-SUBAIE', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('671', '20170807', '����췢[2017]106��', '1: KHALIFA 2: MUHAMMAD 3: TURKI 4: AL-SUBAIY', 'a) Khalifa Mohd Turki Alsubaie; b) Khalifa Mohd Turki al-Subaie; c) Khalifa Al-Subayi; d) Khalifa Turki bin Muhammad bin al-Suaiy', '04', 'Khalifa Mohd Turki Alsubaie', 'KHALIFA MOHD TURKI ALSUBAIE', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('672', '20170807', '����췢[2017]106��', '1: KHALIFA 2: MUHAMMAD 3: TURKI 4: AL-SUBAIY', 'a) Khalifa Mohd Turki Alsubaie; b) Khalifa Mohd Turki al-Subaie; c) Khalifa Al-Subayi; d) Khalifa Turki bin Muhammad bin al-Suaiy', '04', 'Khalifa Al-Subayi', 'KHALIFA AL-SUBAYI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('673', '20170807', '����췢[2017]106��', '1: KHALIL 2: BEN AHMED 3: BEN MOHAMED 4: JARRAYA', 'a) Khalil Yarraya; b) Ben Narvan Abdel Aziz born 15 Aug. 1970 in Sereka; c) Abdel Aziz Ben Narvan born 15 Aug. 1970 in Sereka', '02', 'KHALIL BEN AHMED', 'KHALIL BEN AHMED', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('674', '20170807', '����췢[2017]106��', '1: KHALIL 2: BEN AHMED 3: BEN MOHAMED 4: JARRAYA', 'a) Khalil Yarraya; b) Ben Narvan Abdel Aziz born 15 Aug. 1970 in Sereka; c) Abdel Aziz Ben Narvan born 15 Aug. 1970 in Sereka', '04', 'Khalil Yarraya', 'KHALIL YARRAYA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('675', '20170807', '����췢[2017]106��', '1: KHALIL 2: BEN AHMED 3: BEN MOHAMED 4: JARRAYA', 'a) Khalil Yarraya; b) Ben Narvan Abdel Aziz born 15 Aug. 1970 in Sereka; c) Abdel Aziz Ben Narvan born 15 Aug. 1970 in Sereka', '04', 'Ben Narvan Abdel Aziz', 'BEN NARVAN ABDEL AZIZ', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('676', '20170807', '����췢[2017]106��', '1: KHALIL 2: BEN AHMED 3: BEN MOHAMED 4: JARRAYA', 'a) Khalil Yarraya; b) Ben Narvan Abdel Aziz born 15 Aug. 1970 in Sereka; c) Abdel Aziz Ben Narvan born 15 Aug. 1970 in Sereka', '04', 'Abdel Aziz Ben Narvan', 'ABDEL AZIZ BEN NARVAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('677', '20170807', '����췢[2017]106��', '1: LAVDRIM 2: MUHAXHERI 3: na 4: na', null, '02', 'LAVDRIM MUHAXHERI', 'LAVDRIM MUHAXHERI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('678', '20170807', '����췢[2017]106��', '1: LIONEL 2: DUMONT 3: na 4: na', 'a) Jacques Brougere; b) Abu Hamza; c) Di Karlo Antonio; d) Merlin Oliver Christian Rene; e) Arfauni Imad Ben Yousset Hamza; f) Iman Ben Yussuf Arfaj; g) Abou Hamza; h) Arfauni Imad', '02', 'LIONEL DUMONT', 'LIONEL DUMONT', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('679', '20170807', '����췢[2017]106��', '1: LIONEL 2: DUMONT 3: na 4: na', 'a) Jacques Brougere; b) Abu Hamza; c) Di Karlo Antonio; d) Merlin Oliver Christian Rene; e) Arfauni Imad Ben Yousset Hamza; f) Iman Ben Yussuf Arfaj; g) Abou Hamza; h) Arfauni Imad', '04', 'Arfauni Imad', 'ARFAUNI IMAD', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('680', '20170807', '����췢[2017]106��', '1: LIONEL 2: DUMONT 3: na 4: na', 'a) Jacques Brougere; b) Abu Hamza; c) Di Karlo Antonio; d) Merlin Oliver Christian Rene; e) Arfauni Imad Ben Yousset Hamza; f) Iman Ben Yussuf Arfaj; g) Abou Hamza; h) Arfauni Imad', '04', 'Di Karlo Antonio', 'DI KARLO ANTONIO', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('681', '20170807', '����췢[2017]106��', '1: LIONEL 2: DUMONT 3: na 4: na', 'a) Jacques Brougere; b) Abu Hamza; c) Di Karlo Antonio; d) Merlin Oliver Christian Rene; e) Arfauni Imad Ben Yousset Hamza; f) Iman Ben Yussuf Arfaj; g) Abou Hamza; h) Arfauni Imad', '04', 'Merlin Oliver Christian Rene', 'MERLIN OLIVER CHRISTIAN RENE', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('682', '20170807', '����췢[2017]106��', '1: LIONEL 2: DUMONT 3: na 4: na', 'a) Jacques Brougere; b) Abu Hamza; c) Di Karlo Antonio; d) Merlin Oliver Christian Rene; e) Arfauni Imad Ben Yousset Hamza; f) Iman Ben Yussuf Arfaj; g) Abou Hamza; h) Arfauni Imad', '04', 'Arfauni Imad Ben Yousset Hamza', 'ARFAUNI IMAD BEN YOUSSET HAMZA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('683', '20170807', '����췢[2017]106��', '1: LIONEL 2: DUMONT 3: na 4: na', 'a) Jacques Brougere; b) Abu Hamza; c) Di Karlo Antonio; d) Merlin Oliver Christian Rene; e) Arfauni Imad Ben Yousset Hamza; f) Iman Ben Yussuf Arfaj; g) Abou Hamza; h) Arfauni Imad', '04', 'Abou Hamza', 'ABOU HAMZA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('684', '20170807', '����췢[2017]106��', '1: LIONEL 2: DUMONT 3: na 4: na', 'a) Jacques Brougere; b) Abu Hamza; c) Di Karlo Antonio; d) Merlin Oliver Christian Rene; e) Arfauni Imad Ben Yousset Hamza; f) Iman Ben Yussuf Arfaj; g) Abou Hamza; h) Arfauni Imad', '04', 'Jacques Brougere', 'JACQUES BROUGERE', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('685', '20170807', '����췢[2017]106��', '1: LIONEL 2: DUMONT 3: na 4: na', 'a) Jacques Brougere; b) Abu Hamza; c) Di Karlo Antonio; d) Merlin Oliver Christian Rene; e) Arfauni Imad Ben Yousset Hamza; f) Iman Ben Yussuf Arfaj; g) Abou Hamza; h) Arfauni Imad', '04', 'Iman Ben Yussuf Arfaj', 'IMAN BEN YUSSUF ARFAJ', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('686', '20170807', '����췢[2017]106��', '1: LIONEL 2: DUMONT 3: na 4: na', 'a) Jacques Brougere; b) Abu Hamza; c) Di Karlo Antonio; d) Merlin Oliver Christian Rene; e) Arfauni Imad Ben Yousset Hamza; f) Iman Ben Yussuf Arfaj; g) Abou Hamza; h) Arfauni Imad', '04', 'Abu Hamza', 'ABU HAMZA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('687', '20170807', '����췢[2017]106��', '1: MAGHOMED 2: MAGHOMEDZAKIROVICH 3: ABDURAKHMANOV 4: na', null, '02', 'MAGHOMED MAGHOMEDZAKIROVICH', 'MAGHOMED MAGHOMEDZAKIROVICH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('688', '20170807', '����췢[2017]106��', '1: MAHFOUZ 2: OULD 3: AL-WALID 4:na', 'a) Abu Hafs the Mauritanian; b) Khalid Al-Shanqltl; c) Mafouz Walad Al-Walid', '02', 'MAHFOUZ OULD', 'MAHFOUZ OULD', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('689', '20170807', '����췢[2017]106��', '1: MAHFOUZ 2: OULD 3: AL-WALID 4:na', 'a) Abu Hafs the Mauritanian; b) Khalid Al-Shanqltl; c) Mafouz Walad Al-Walid', '04', 'Abu Hafs the Mauritanian', 'ABU HAFS THE MAURITANIAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('690', '20170807', '����췢[2017]106��', '1: MAHFOUZ 2: OULD 3: AL-WALID 4:na', 'a) Abu Hafs the Mauritanian; b) Khalid Al-Shanqltl; c) Mafouz Walad Al-Walid', '04', 'Khalid Al-Shanqltl', 'KHALID AL-SHANQLTL', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('691', '20170807', '����췢[2017]106��', '1: MAHFOUZ 2: OULD 3: AL-WALID 4:na', 'a) Abu Hafs the Mauritanian; b) Khalid Al-Shanqltl; c) Mafouz Walad Al-Walid', '04', 'Mafouz Walad Al-Walid', 'MAFOUZ WALAD AL-WALID', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('692', '20170807', '����췢[2017]106��', '1: MAHMOOD 2: SULTAN 3: BASHIR-UD-DIN 4: na', 'a) Mahmood Sultan Bashiruddin; b) Mehmood, Dr. Bashir Uddin; c) Mekmud, Sultan Baishiruddin', '02', 'MAHMOOD SULTAN', 'MAHMOOD SULTAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('693', '20170807', '����췢[2017]106��', '1: MAHMOOD 2: SULTAN 3: BASHIR-UD-DIN 4: na', 'a) Mahmood Sultan Bashiruddin; b) Mehmood, Dr. Bashir Uddin; c) Mekmud, Sultan Baishiruddin', '04', 'Mehmood, Dr. Bashir Uddin', 'MEHMOOD, DR. BASHIR UDDIN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('694', '20170807', '����췢[2017]106��', '1: MAHMOOD 2: SULTAN 3: BASHIR-UD-DIN 4: na', 'a) Mahmood Sultan Bashiruddin; b) Mehmood, Dr. Bashir Uddin; c) Mekmud, Sultan Baishiruddin', '04', 'Mahmood Sultan Bashiruddin', 'MAHMOOD SULTAN BASHIRUDDIN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('695', '20170807', '����췢[2017]106��', '1: MAHMOOD 2: SULTAN 3: BASHIR-UD-DIN 4: na', 'a) Mahmood Sultan Bashiruddin; b) Mehmood, Dr. Bashir Uddin; c) Mekmud, Sultan Baishiruddin', '04', 'Mekmud, Sultan Baishiruddin', 'MEKMUD, SULTAN BAISHIRUDDIN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('696', '20170807', '����췢[2017]106��', '1: MAHMOUD 2: MOHAMMAD 3: AHMED 4: BAHAZIQ', 'a) Bahaziq Mahmoud; b) Abu Abd al-Aziz; c) Abu Abdul Aziz; d) Shaykh Sahib', '02', 'MAHMOUD MOHAMMAD', 'MAHMOUD MOHAMMAD', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('697', '20170807', '����췢[2017]106��', '1: MAHMOUD 2: MOHAMMAD 3: AHMED 4: BAHAZIQ', 'a) Bahaziq Mahmoud; b) Abu Abd al-Aziz; c) Abu Abdul Aziz; d) Shaykh Sahib', '04', 'Shaykh Sahib', 'SHAYKH SAHIB', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('698', '20170807', '����췢[2017]106��', '1: MAHMOUD 2: MOHAMMAD 3: AHMED 4: BAHAZIQ', 'a) Bahaziq Mahmoud; b) Abu Abd al-Aziz; c) Abu Abdul Aziz; d) Shaykh Sahib', '04', 'Bahaziq Mahmoud', 'BAHAZIQ MAHMOUD', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('699', '20170807', '����췢[2017]106��', '1: MAHMOUD 2: MOHAMMAD 3: AHMED 4: BAHAZIQ', 'a) Bahaziq Mahmoud; b) Abu Abd al-Aziz; c) Abu Abdul Aziz; d) Shaykh Sahib', '04', 'Abu Abdul Aziz', 'ABU ABDUL AZIZ', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('700', '20170807', '����췢[2017]106��', '1: MAHMOUD 2: MOHAMMAD 3: AHMED 4: BAHAZIQ', 'a) Bahaziq Mahmoud; b) Abu Abd al-Aziz; c) Abu Abdul Aziz; d) Shaykh Sahib', '04', 'Abu Abd al-Aziz', 'ABU ABD AL-AZIZ', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('701', '20170807', '����췢[2017]106��', '1: MAJEED 2: ABDUL CHAUDHRY 3: na 4: na', 'a) Majeed Abdul; b) Majeed Chaudhry Abdul; c) Majid Abdul', '02', 'MAJEED ABDUL CHAUDHRY', 'MAJEED ABDUL CHAUDHRY', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('702', '20170807', '����췢[2017]106��', '1: MAJEED 2: ABDUL CHAUDHRY 3: na 4: na', 'a) Majeed Abdul; b) Majeed Chaudhry Abdul; c) Majid Abdul', '04', 'Majeed Abdul', 'MAJEED ABDUL', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('703', '20170807', '����췢[2017]106��', '1: MAJEED 2: ABDUL CHAUDHRY 3: na 4: na', 'a) Majeed Abdul; b) Majeed Chaudhry Abdul; c) Majid Abdul', '04', 'Majid Abdul', 'MAJID ABDUL', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('704', '20170807', '����췢[2017]106��', '1: MAJEED 2: ABDUL CHAUDHRY 3: na 4: na', 'a) Majeed Abdul; b) Majeed Chaudhry Abdul; c) Majid Abdul', '04', 'Majeed Chaudhry Abdul', 'MAJEED CHAUDHRY ABDUL', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('705', '20170807', '����췢[2017]106��', '1: MALIK 2: MUHAMMAD 3: ISHAQ 4: na', 'a) Malik Ishaq', '02', 'MALIK MUHAMMAD', 'MALIK MUHAMMAD', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('706', '20170807', '����췢[2017]106��', '1: MALIK 2: MUHAMMAD 3: ISHAQ 4: na', 'a) Malik Ishaq', '03', 'Malik Ishaq', 'MALIK ISHAQ', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('707', '20170807', '����췢[2017]106��', '1: MATI UR-REHMAN 2: ALI MUHAMMAD 3: na 4: na', 'a) Mati-ur Rehman; b) Mati ur Rehman; c) Matiur Rahman; d) Matiur Rehman; e) Matti al-Rehman; f) Abdul Samad; g) Samad Sial; h) Abdul Samad Sial; i) Ustad Talha; j) Qari Mushtaq', '02', 'MATI UR-REHMAN ALI MUHAMMAD', 'MATI UR-REHMAN ALI MUHAMMAD', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('708', '20170807', '����췢[2017]106��', '1: MATI UR-REHMAN 2: ALI MUHAMMAD 3: na 4: na', 'a) Mati-ur Rehman; b) Mati ur Rehman; c) Matiur Rahman; d) Matiur Rehman; e) Matti al-Rehman; f) Abdul Samad; g) Samad Sial; h) Abdul Samad Sial; i) Ustad Talha; j) Qari Mushtaq', '04', 'Samad Sial', 'SAMAD SIAL', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('709', '20170807', '����췢[2017]106��', '1: MATI UR-REHMAN 2: ALI MUHAMMAD 3: na 4: na', 'a) Mati-ur Rehman; b) Mati ur Rehman; c) Matiur Rahman; d) Matiur Rehman; e) Matti al-Rehman; f) Abdul Samad; g) Samad Sial; h) Abdul Samad Sial; i) Ustad Talha; j) Qari Mushtaq', '04', 'Ustad Talha', 'USTAD TALHA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('710', '20170807', '����췢[2017]106��', '1: MATI UR-REHMAN 2: ALI MUHAMMAD 3: na 4: na', 'a) Mati-ur Rehman; b) Mati ur Rehman; c) Matiur Rahman; d) Matiur Rehman; e) Matti al-Rehman; f) Abdul Samad; g) Samad Sial; h) Abdul Samad Sial; i) Ustad Talha; j) Qari Mushtaq', '04', 'Mati-ur Rehman', 'MATI-UR REHMAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('711', '20170807', '����췢[2017]106��', '1: MATI UR-REHMAN 2: ALI MUHAMMAD 3: na 4: na', 'a) Mati-ur Rehman; b) Mati ur Rehman; c) Matiur Rahman; d) Matiur Rehman; e) Matti al-Rehman; f) Abdul Samad; g) Samad Sial; h) Abdul Samad Sial; i) Ustad Talha; j) Qari Mushtaq', '04', 'Qari Mushtaq', 'QARI MUSHTAQ', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('712', '20170807', '����췢[2017]106��', '1: MATI UR-REHMAN 2: ALI MUHAMMAD 3: na 4: na', 'a) Mati-ur Rehman; b) Mati ur Rehman; c) Matiur Rahman; d) Matiur Rehman; e) Matti al-Rehman; f) Abdul Samad; g) Samad Sial; h) Abdul Samad Sial; i) Ustad Talha; j) Qari Mushtaq', '04', 'Abdul Samad Sial', 'ABDUL SAMAD SIAL', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('713', '20170807', '����췢[2017]106��', '1: MATI UR-REHMAN 2: ALI MUHAMMAD 3: na 4: na', 'a) Mati-ur Rehman; b) Mati ur Rehman; c) Matiur Rahman; d) Matiur Rehman; e) Matti al-Rehman; f) Abdul Samad; g) Samad Sial; h) Abdul Samad Sial; i) Ustad Talha; j) Qari Mushtaq', '04', 'Matti al-Rehman', 'MATTI AL-REHMAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('714', '20170807', '����췢[2017]106��', '1: MATI UR-REHMAN 2: ALI MUHAMMAD 3: na 4: na', 'a) Mati-ur Rehman; b) Mati ur Rehman; c) Matiur Rahman; d) Matiur Rehman; e) Matti al-Rehman; f) Abdul Samad; g) Samad Sial; h) Abdul Samad Sial; i) Ustad Talha; j) Qari Mushtaq', '04', 'Abdul Samad', 'ABDUL SAMAD', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('715', '20170807', '����췢[2017]106��', '1: MATI UR-REHMAN 2: ALI MUHAMMAD 3: na 4: na', 'a) Mati-ur Rehman; b) Mati ur Rehman; c) Matiur Rahman; d) Matiur Rehman; e) Matti al-Rehman; f) Abdul Samad; g) Samad Sial; h) Abdul Samad Sial; i) Ustad Talha; j) Qari Mushtaq', '04', 'Matiur Rehman', 'MATIUR REHMAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('716', '20170807', '����췢[2017]106��', '1: MATI UR-REHMAN 2: ALI MUHAMMAD 3: na 4: na', 'a) Mati-ur Rehman; b) Mati ur Rehman; c) Matiur Rahman; d) Matiur Rehman; e) Matti al-Rehman; f) Abdul Samad; g) Samad Sial; h) Abdul Samad Sial; i) Ustad Talha; j) Qari Mushtaq', '04', 'Matiur Rahman', 'MATIUR RAHMAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('717', '20170807', '����췢[2017]106��', '1: MATI UR-REHMAN 2: ALI MUHAMMAD 3: na 4: na', 'a) Mati-ur Rehman; b) Mati ur Rehman; c) Matiur Rahman; d) Matiur Rehman; e) Matti al-Rehman; f) Abdul Samad; g) Samad Sial; h) Abdul Samad Sial; i) Ustad Talha; j) Qari Mushtaq', '04', 'Mati ur Rehman', 'MATI UR REHMAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('718', '20170807', '����췢[2017]106��', '1: MAULANA 2: FAZLULLAH 3: na 4: na', 'a) Mullah Fazlullah; b) Fazal Hayat', '02', 'MAULANA FAZLULLAH', 'MAULANA FAZLULLAH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('719', '20170807', '����췢[2017]106��', '1: MAULANA 2: FAZLULLAH 3: na 4: na', 'a) Mullah Fazlullah; b) Fazal Hayat', '04', 'Mullah Fazlullah', 'MULLAH FAZLULLAH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('720', '20170807', '����췢[2017]106��', '1: MAULANA 2: FAZLULLAH 3: na 4: na', 'a) Mullah Fazlullah; b) Fazal Hayat', '04', 'Fazal Hayat', 'FAZAL HAYAT', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('721', '20170807', '����췢[2017]106��', '1: MAXAMED 2: CABDULLAAH 3: CIISE 4: na', 'a) Maxamed Cabdullaahi Ciise; b) Maxammed Cabdullaahi; c) Cabdullsh Mayamed', '02', 'MAXAMED CABDULLAAH', 'MAXAMED CABDULLAAH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('722', '20170807', '����췢[2017]106��', '1: MAXAMED 2: CABDULLAAH 3: CIISE 4: na', 'a) Maxamed Cabdullaahi Ciise; b) Maxammed Cabdullaahi; c) Cabdullsh Mayamed', '04', 'Maxammed Cabdullaahi', 'MAXAMMED CABDULLAAHI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('723', '20170807', '����췢[2017]106��', '1: MAXAMED 2: CABDULLAAH 3: CIISE 4: na', 'a) Maxamed Cabdullaahi Ciise; b) Maxammed Cabdullaahi; c) Cabdullsh Mayamed', '04', 'Maxamed Cabdullaahi Ciise', 'MAXAMED CABDULLAAHI CIISE', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('724', '20170807', '����췢[2017]106��', '1: MAXAMED 2: CABDULLAAH 3: CIISE 4: na', 'a) Maxamed Cabdullaahi Ciise; b) Maxammed Cabdullaahi; c) Cabdullsh Mayamed', '04', 'Cabdullsh Mayamed', 'CABDULLSH MAYAMED', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('725', '20170807', '����췢[2017]106��', '1: MAXIME 2: HAUCHARD 3: na 4: na', null, '02', 'MAXIME HAUCHARD', 'MAXIME HAUCHARD', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('726', '20170807', '����췢[2017]106��', '1: MAYSAR ALI 2: MUSA 3: ABDALLAH 4: AL-JUBURI', 'a) Muyassir al-Jiburi; b) Muyassir Harara; c) Muyassir al-Shammari; d) Muhammad Khalid Hassan ', '02', 'MAYSAR ALI MUSA', 'MAYSAR ALI MUSA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('727', '20170807', '����췢[2017]106��', '1: MAYSAR ALI 2: MUSA 3: ABDALLAH 4: AL-JUBURI', 'a) Muyassir al-Jiburi; b) Muyassir Harara; c) Muyassir al-Shammari; d) Muhammad Khalid Hassan ', '04', 'Muyassir Harara', 'MUYASSIR HARARA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('728', '20170807', '����췢[2017]106��', '1: MAYSAR ALI 2: MUSA 3: ABDALLAH 4: AL-JUBURI', 'a) Muyassir al-Jiburi; b) Muyassir Harara; c) Muyassir al-Shammari; d) Muhammad Khalid Hassan ', '04', 'Muyassir al-Shammari', 'MUYASSIR AL-SHAMMARI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('729', '20170807', '����췢[2017]106��', '1: MAYSAR ALI 2: MUSA 3: ABDALLAH 4: AL-JUBURI', 'a) Muyassir al-Jiburi; b) Muyassir Harara; c) Muyassir al-Shammari; d) Muhammad Khalid Hassan ', '04', 'Muhammad Khalid Hassan', 'MUHAMMAD KHALID HASSAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('730', '20170807', '����췢[2017]106��', '1: MAYSAR ALI 2: MUSA 3: ABDALLAH 4: AL-JUBURI', 'a) Muyassir al-Jiburi; b) Muyassir Harara; c) Muyassir al-Shammari; d) Muhammad Khalid Hassan ', '04', 'Muyassir al-Jiburi', 'MUYASSIR AL-JIBURI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('731', '20170807', '����췢[2017]106��', '1: MAZEN 2: SALAH 3: MOHAMMED 4: na', 'a) Mazen Ali Hussein born 1 Jan. 1982 in Baghdad. Iraq; b) Issa Salah Muhamad born 1 Jan. 1980', '02', 'MAZEN SALAH', 'MAZEN SALAH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('732', '20170807', '����췢[2017]106��', '1: MAZEN 2: SALAH 3: MOHAMMED 4: na', 'a) Mazen Ali Hussein born 1 Jan. 1982 in Baghdad. Iraq; b) Issa Salah Muhamad born 1 Jan. 1980', '04', 'Issa Salah Muhamad', 'ISSA SALAH MUHAMAD', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('733', '20170807', '����췢[2017]106��', '1: MAZEN 2: SALAH 3: MOHAMMED 4: na', 'a) Mazen Ali Hussein born 1 Jan. 1982 in Baghdad. Iraq; b) Issa Salah Muhamad born 1 Jan. 1980', '04', 'Mazen Ali Hussein', 'MAZEN ALI HUSSEIN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('734', '20170807', '����췢[2017]106��', '1: MEHDI 2: BEN MOHAMED 3: BEN MOHAMED 4: KAMMOUN', null, '02', 'MEHDI BEN MOHAMED', 'MEHDI BEN MOHAMED', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('735', '20170807', '����췢[2017]106��', '1: MEHREZ 2: BEN MAHMOUD 3: BEN SASSI 4: AL-AMDOUNI', 'a) Fabio Fusco born 2 May 1968 in Naples, Italy; b) Fabio Fusco born 18 Dec. 1968 in Tunisia; c) Fabio Fusco born 25 May 1968 in Algeria; d) Mohamed Hassan; e) Meherez Hamdouni; f) Amdouni Mehrez ben Tah born 14 Jul. 1969 in Tunisia; g) Meherez ben Ahdoud ben Amdouni', '02', 'MEHREZ BEN MAHMOUD', 'MEHREZ BEN MAHMOUD', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('736', '20170807', '����췢[2017]106��', '1: MEHREZ 2: BEN MAHMOUD 3: BEN SASSI 4: AL-AMDOUNI', 'a) Fabio Fusco born 2 May 1968 in Naples, Italy; b) Fabio Fusco born 18 Dec. 1968 in Tunisia; c) Fabio Fusco born 25 May 1968 in Algeria; d) Mohamed Hassan; e) Meherez Hamdouni; f) Amdouni Mehrez ben Tah born 14 Jul. 1969 in Tunisia; g) Meherez ben Ahdoud ben Amdouni', '04', 'Fabio Fusco', 'FABIO FUSCO', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('737', '20170807', '����췢[2017]106��', '1: MEHREZ 2: BEN MAHMOUD 3: BEN SASSI 4: AL-AMDOUNI', 'a) Fabio Fusco born 2 May 1968 in Naples, Italy; b) Fabio Fusco born 18 Dec. 1968 in Tunisia; c) Fabio Fusco born 25 May 1968 in Algeria; d) Mohamed Hassan; e) Meherez Hamdouni; f) Amdouni Mehrez ben Tah born 14 Jul. 1969 in Tunisia; g) Meherez ben Ahdoud ben Amdouni', '04', 'Amdouni Mehrez ben Tah', 'AMDOUNI MEHREZ BEN TAH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('738', '20170807', '����췢[2017]106��', '1: MEHREZ 2: BEN MAHMOUD 3: BEN SASSI 4: AL-AMDOUNI', 'a) Fabio Fusco born 2 May 1968 in Naples, Italy; b) Fabio Fusco born 18 Dec. 1968 in Tunisia; c) Fabio Fusco born 25 May 1968 in Algeria; d) Mohamed Hassan; e) Meherez Hamdouni; f) Amdouni Mehrez ben Tah born 14 Jul. 1969 in Tunisia; g) Meherez ben Ahdoud ben Amdouni', '04', 'Meherez Hamdouni', 'MEHEREZ HAMDOUNI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('739', '20170807', '����췢[2017]106��', '1: MEHREZ 2: BEN MAHMOUD 3: BEN SASSI 4: AL-AMDOUNI', 'a) Fabio Fusco born 2 May 1968 in Naples, Italy; b) Fabio Fusco born 18 Dec. 1968 in Tunisia; c) Fabio Fusco born 25 May 1968 in Algeria; d) Mohamed Hassan; e) Meherez Hamdouni; f) Amdouni Mehrez ben Tah born 14 Jul. 1969 in Tunisia; g) Meherez ben Ahdoud ben Amdouni', '04', 'Mohamed Hassan', 'MOHAMED HASSAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('740', '20170807', '����췢[2017]106��', '1: MEHREZ 2: BEN MAHMOUD 3: BEN SASSI 4: AL-AMDOUNI', 'a) Fabio Fusco born 2 May 1968 in Naples, Italy; b) Fabio Fusco born 18 Dec. 1968 in Tunisia; c) Fabio Fusco born 25 May 1968 in Algeria; d) Mohamed Hassan; e) Meherez Hamdouni; f) Amdouni Mehrez ben Tah born 14 Jul. 1969 in Tunisia; g) Meherez ben Ahdoud ben Amdouni', '04', 'Fabio Fusco', 'FABIO FUSCO', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('741', '20170807', '����췢[2017]106��', '1: MEHREZ 2: BEN MAHMOUD 3: BEN SASSI 4: AL-AMDOUNI', 'a) Fabio Fusco born 2 May 1968 in Naples, Italy; b) Fabio Fusco born 18 Dec. 1968 in Tunisia; c) Fabio Fusco born 25 May 1968 in Algeria; d) Mohamed Hassan; e) Meherez Hamdouni; f) Amdouni Mehrez ben Tah born 14 Jul. 1969 in Tunisia; g) Meherez ben Ahdoud ben Amdouni', '04', 'Meherez ben Ahdoud ben Amdouni', 'MEHEREZ BEN AHDOUD BEN AMDOUNI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('742', '20170807', '����췢[2017]106��', '1: MEHREZ 2: BEN MAHMOUD 3: BEN SASSI 4: AL-AMDOUNI', 'a) Fabio Fusco born 2 May 1968 in Naples, Italy; b) Fabio Fusco born 18 Dec. 1968 in Tunisia; c) Fabio Fusco born 25 May 1968 in Algeria; d) Mohamed Hassan; e) Meherez Hamdouni; f) Amdouni Mehrez ben Tah born 14 Jul. 1969 in Tunisia; g) Meherez ben Ahdoud ben Amdouni', '04', 'Fabio Fusco', 'FABIO FUSCO', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('743', '20170807', '����췢[2017]106��', '1: MERAI 2: ABDEFATTAH 3: KHALIL 4: ZOGHBI', 'a) Mohamed Lebachir born 14 Jan. 1968 in Morocco; b) Meri Albdelfattah Zgbye born 4 Jun. 1960 in Bendasi, Libya; c) Zoghbai Merai Abdul Fattah; d) Lazrag Faraj born 13 Nov. 1960 in Libya; e) Larzg Ben Ila born 11 Aug. 1960 in Libya; f) Muhammed El Besir; g) Merai Zoghbai', '02', 'MERAI ABDEFATTAH', 'MERAI ABDEFATTAH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('744', '20170807', '����췢[2017]106��', '1: MERAI 2: ABDEFATTAH 3: KHALIL 4: ZOGHBI', 'a) Mohamed Lebachir born 14 Jan. 1968 in Morocco; b) Meri Albdelfattah Zgbye born 4 Jun. 1960 in Bendasi, Libya; c) Zoghbai Merai Abdul Fattah; d) Lazrag Faraj born 13 Nov. 1960 in Libya; e) Larzg Ben Ila born 11 Aug. 1960 in Libya; f) Muhammed El Besir; g) Merai Zoghbai', '04', 'Lazrag Faraj', 'LAZRAG FARAJ', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('745', '20170807', '����췢[2017]106��', '1: MERAI 2: ABDEFATTAH 3: KHALIL 4: ZOGHBI', 'a) Mohamed Lebachir born 14 Jan. 1968 in Morocco; b) Meri Albdelfattah Zgbye born 4 Jun. 1960 in Bendasi, Libya; c) Zoghbai Merai Abdul Fattah; d) Lazrag Faraj born 13 Nov. 1960 in Libya; e) Larzg Ben Ila born 11 Aug. 1960 in Libya; f) Muhammed El Besir; g) Merai Zoghbai', '04', 'Mohamed Lebachir', 'MOHAMED LEBACHIR', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('746', '20170807', '����췢[2017]106��', '1: MERAI 2: ABDEFATTAH 3: KHALIL 4: ZOGHBI', 'a) Mohamed Lebachir born 14 Jan. 1968 in Morocco; b) Meri Albdelfattah Zgbye born 4 Jun. 1960 in Bendasi, Libya; c) Zoghbai Merai Abdul Fattah; d) Lazrag Faraj born 13 Nov. 1960 in Libya; e) Larzg Ben Ila born 11 Aug. 1960 in Libya; f) Muhammed El Besir; g) Merai Zoghbai', '04', 'Merai Zoghbai', 'MERAI ZOGHBAI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('747', '20170807', '����췢[2017]106��', '1: MERAI 2: ABDEFATTAH 3: KHALIL 4: ZOGHBI', 'a) Mohamed Lebachir born 14 Jan. 1968 in Morocco; b) Meri Albdelfattah Zgbye born 4 Jun. 1960 in Bendasi, Libya; c) Zoghbai Merai Abdul Fattah; d) Lazrag Faraj born 13 Nov. 1960 in Libya; e) Larzg Ben Ila born 11 Aug. 1960 in Libya; f) Muhammed El Besir; g) Merai Zoghbai', '04', 'Zoghbai Merai Abdul Fattah', 'ZOGHBAI MERAI ABDUL FATTAH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('748', '20170807', '����췢[2017]106��', '1: MERAI 2: ABDEFATTAH 3: KHALIL 4: ZOGHBI', 'a) Mohamed Lebachir born 14 Jan. 1968 in Morocco; b) Meri Albdelfattah Zgbye born 4 Jun. 1960 in Bendasi, Libya; c) Zoghbai Merai Abdul Fattah; d) Lazrag Faraj born 13 Nov. 1960 in Libya; e) Larzg Ben Ila born 11 Aug. 1960 in Libya; f) Muhammed El Besir; g) Merai Zoghbai', '04', 'Meri Albdelfattah Zgbye', 'MERI ALBDELFATTAH ZGBYE', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('749', '20170807', '����췢[2017]106��', '1: MERAI 2: ABDEFATTAH 3: KHALIL 4: ZOGHBI', 'a) Mohamed Lebachir born 14 Jan. 1968 in Morocco; b) Meri Albdelfattah Zgbye born 4 Jun. 1960 in Bendasi, Libya; c) Zoghbai Merai Abdul Fattah; d) Lazrag Faraj born 13 Nov. 1960 in Libya; e) Larzg Ben Ila born 11 Aug. 1960 in Libya; f) Muhammed El Besir; g) Merai Zoghbai', '04', 'Larzg Ben Ila', 'LARZG BEN ILA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('750', '20170807', '����췢[2017]106��', '1: MERAI 2: ABDEFATTAH 3: KHALIL 4: ZOGHBI', 'a) Mohamed Lebachir born 14 Jan. 1968 in Morocco; b) Meri Albdelfattah Zgbye born 4 Jun. 1960 in Bendasi, Libya; c) Zoghbai Merai Abdul Fattah; d) Lazrag Faraj born 13 Nov. 1960 in Libya; e) Larzg Ben Ila born 11 Aug. 1960 in Libya; f) Muhammed El Besir; g) Merai Zoghbai', '04', 'Muhammed El Besir', 'MUHAMMED EL BESIR', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('751', '20170807', '����췢[2017]106��', '1: MEVLUT 2: KAR 3: na 4: na', 'a) Mevluet Kar ', '02', 'MEVLUT KAR', 'MEVLUT KAR', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('752', '20170807', '����췢[2017]106��', '1: MEVLUT 2: KAR 3: na 4: na', 'a) Mevluet Kar ', '03', 'Mevluet Kar', 'MEVLUET KAR', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('753', '20170807', '����췢[2017]106��', '1: MOCHAMMAD 2: ACHWAN 3: na 4: na', 'a) Muhammad Achwan; b) Muhammad Akhwan; c) Mochtar Achwan; d) Mochtar Akhwan; e) Mochtar Akwan', '02', 'MOCHAMMAD ACHWAN', 'MOCHAMMAD ACHWAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('754', '20170807', '����췢[2017]106��', '1: MOCHAMMAD 2: ACHWAN 3: na 4: na', 'a) Muhammad Achwan; b) Muhammad Akhwan; c) Mochtar Achwan; d) Mochtar Akhwan; e) Mochtar Akwan', '04', 'Mochtar Akhwan', 'MOCHTAR AKHWAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('755', '20170807', '����췢[2017]106��', '1: MOCHAMMAD 2: ACHWAN 3: na 4: na', 'a) Muhammad Achwan; b) Muhammad Akhwan; c) Mochtar Achwan; d) Mochtar Akhwan; e) Mochtar Akwan', '04', 'Muhammad Achwan', 'MUHAMMAD ACHWAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('756', '20170807', '����췢[2017]106��', '1: MOCHAMMAD 2: ACHWAN 3: na 4: na', 'a) Muhammad Achwan; b) Muhammad Akhwan; c) Mochtar Achwan; d) Mochtar Akhwan; e) Mochtar Akwan', '04', 'Mochtar Achwan', 'MOCHTAR ACHWAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('757', '20170807', '����췢[2017]106��', '1: MOCHAMMAD 2: ACHWAN 3: na 4: na', 'a) Muhammad Achwan; b) Muhammad Akhwan; c) Mochtar Achwan; d) Mochtar Akhwan; e) Mochtar Akwan', '04', 'Muhammad Akhwan', 'MUHAMMAD AKHWAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('758', '20170807', '����췢[2017]106��', '1: MOCHAMMAD 2: ACHWAN 3: na 4: na', 'a) Muhammad Achwan; b) Muhammad Akhwan; c) Mochtar Achwan; d) Mochtar Akhwan; e) Mochtar Akwan', '04', 'Mochtar Akwan', 'MOCHTAR AKWAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('759', '20170807', '����췢[2017]106��', '1: MOHAMAD 2: IQBAL 3: ABDURRAHMAN 4: na', 'a) Rahman, Mohamad Iqbal; b) A Rahman, Mohamad Iqbal; c) Abu Jibril Abdurrahman; d) Fikiruddin Muqti; e) Fihiruddin Muqti; f) Abdul Rahman, Mohamad Iqbal', '02', 'MOHAMAD IQBAL', 'MOHAMAD IQBAL', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('760', '20170807', '����췢[2017]106��', '1: MOHAMAD 2: IQBAL 3: ABDURRAHMAN 4: na', 'a) Rahman, Mohamad Iqbal; b) A Rahman, Mohamad Iqbal; c) Abu Jibril Abdurrahman; d) Fikiruddin Muqti; e) Fihiruddin Muqti; f) Abdul Rahman, Mohamad Iqbal', '04', 'Abu Jibril Abdurrahman', 'ABU JIBRIL ABDURRAHMAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('761', '20170807', '����췢[2017]106��', '1: MOHAMAD 2: IQBAL 3: ABDURRAHMAN 4: na', 'a) Rahman, Mohamad Iqbal; b) A Rahman, Mohamad Iqbal; c) Abu Jibril Abdurrahman; d) Fikiruddin Muqti; e) Fihiruddin Muqti; f) Abdul Rahman, Mohamad Iqbal', '04', 'Fikiruddin Muqti', 'FIKIRUDDIN MUQTI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('762', '20170807', '����췢[2017]106��', '1: MOHAMAD 2: IQBAL 3: ABDURRAHMAN 4: na', 'a) Rahman, Mohamad Iqbal; b) A Rahman, Mohamad Iqbal; c) Abu Jibril Abdurrahman; d) Fikiruddin Muqti; e) Fihiruddin Muqti; f) Abdul Rahman, Mohamad Iqbal', '04', 'Fihiruddin Muqti', 'FIHIRUDDIN MUQTI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('763', '20170807', '����췢[2017]106��', '1: MOHAMAD 2: IQBAL 3: ABDURRAHMAN 4: na', 'a) Rahman, Mohamad Iqbal; b) A Rahman, Mohamad Iqbal; c) Abu Jibril Abdurrahman; d) Fikiruddin Muqti; e) Fihiruddin Muqti; f) Abdul Rahman, Mohamad Iqbal', '04', 'Abdul Rahman, Mohamad Iqbal', 'ABDUL RAHMAN, MOHAMAD IQBAL', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('764', '20170807', '����췢[2017]106��', '1: MOHAMAD 2: IQBAL 3: ABDURRAHMAN 4: na', 'a) Rahman, Mohamad Iqbal; b) A Rahman, Mohamad Iqbal; c) Abu Jibril Abdurrahman; d) Fikiruddin Muqti; e) Fihiruddin Muqti; f) Abdul Rahman, Mohamad Iqbal', '04', 'Rahman, Mohamad Iqbal', 'RAHMAN, MOHAMAD IQBAL', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('765', '20170807', '����췢[2017]106��', '1: MOHAMAD 2: IQBAL 3: ABDURRAHMAN 4: na', 'a) Rahman, Mohamad Iqbal; b) A Rahman, Mohamad Iqbal; c) Abu Jibril Abdurrahman; d) Fikiruddin Muqti; e) Fihiruddin Muqti; f) Abdul Rahman, Mohamad Iqbal', '04', 'A Rahman, Mohamad Iqbal', 'A RAHMAN, MOHAMAD IQBAL', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('766', '20170807', '����췢[2017]106��', '1: MOHAMED 2: AMIN 3: MOSTAFA 4: na', null, '02', 'MOHAMED AMIN', 'MOHAMED AMIN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('767', '20170807', '����췢[2017]106��', '1: MOHAMED 2: BELKALEM 3: na 4: na', null, '02', 'MOHAMED BELKALEM', 'MOHAMED BELKALEM', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('768', '20170807', '����췢[2017]106��', '1: MOHAMED 2: BEN BELGACEM 3: BEN ABDALLAH 4: AL-AOUADI', 'a) Mohamed Ben Belkacem Aouadi; b) Fathi Hannachi', '02', 'MOHAMED BEN BELGACEM', 'MOHAMED BEN BELGACEM', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('769', '20170807', '����췢[2017]106��', '1: MOHAMED 2: BEN BELGACEM 3: BEN ABDALLAH 4: AL-AOUADI', 'a) Mohamed Ben Belkacem Aouadi; b) Fathi Hannachi', '04', 'Mohamed Ben Belkacem Aouadi', 'MOHAMED BEN BELKACEM AOUADI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('770', '20170807', '����췢[2017]106��', '1: MOHAMED 2: BEN BELGACEM 3: BEN ABDALLAH 4: AL-AOUADI', 'a) Mohamed Ben Belkacem Aouadi; b) Fathi Hannachi', '04', 'Fathi Hannachi', 'FATHI HANNACHI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('771', '20170807', '����췢[2017]106��', '1: MOHAMED 2: LAHBOUS 3: na 4: na', 'a) Mohamed Ennouini; b) Hassan; c) Hocine', '02', 'MOHAMED LAHBOUS', 'MOHAMED LAHBOUS', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('772', '20170807', '����췢[2017]106��', '1: MOHAMED 2: LAHBOUS 3: na 4: na', 'a) Mohamed Ennouini; b) Hassan; c) Hocine', '04', 'Hassan', 'HASSAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('773', '20170807', '����췢[2017]106��', '1: MOHAMED 2: LAHBOUS 3: na 4: na', 'a) Mohamed Ennouini; b) Hassan; c) Hocine', '04', 'Mohamed Ennouini', 'MOHAMED ENNOUINI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('774', '20170807', '����췢[2017]106��', '1: MOHAMED 2: LAHBOUS 3: na 4: na', 'a) Mohamed Ennouini; b) Hassan; c) Hocine', '04', 'Hocine', 'HOCINE', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('775', '20170807', '����췢[2017]106��', '1: MOHAMED 2: LAKHAL 3: na 4: na', 'a) Lased Ben Heni born 5 Feb. 1969 in Tripoli, Libya; b) Al-Asad Ben Hani born 5 Feb. 1969 in Tripoli, Libya; c) Mohamed Ben Belgacem Awani; d) Mohamed Aouani born 5 Feb. 1970 in Tunis, Tunisia', '02', 'MOHAMED LAKHAL', 'MOHAMED LAKHAL', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('776', '20170807', '����췢[2017]106��', '1: MOHAMED 2: LAKHAL 3: na 4: na', 'a) Lased Ben Heni born 5 Feb. 1969 in Tripoli, Libya; b) Al-Asad Ben Hani born 5 Feb. 1969 in Tripoli, Libya; c) Mohamed Ben Belgacem Awani; d) Mohamed Aouani born 5 Feb. 1970 in Tunis, Tunisia', '04', 'Lased Ben Heni', 'LASED BEN HENI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('777', '20170807', '����췢[2017]106��', '1: MOHAMED 2: LAKHAL 3: na 4: na', 'a) Lased Ben Heni born 5 Feb. 1969 in Tripoli, Libya; b) Al-Asad Ben Hani born 5 Feb. 1969 in Tripoli, Libya; c) Mohamed Ben Belgacem Awani; d) Mohamed Aouani born 5 Feb. 1970 in Tunis, Tunisia', '04', 'Al-Asad Ben Hani', 'AL-ASAD BEN HANI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('778', '20170807', '����췢[2017]106��', '1: MOHAMED 2: LAKHAL 3: na 4: na', 'a) Lased Ben Heni born 5 Feb. 1969 in Tripoli, Libya; b) Al-Asad Ben Hani born 5 Feb. 1969 in Tripoli, Libya; c) Mohamed Ben Belgacem Awani; d) Mohamed Aouani born 5 Feb. 1970 in Tunis, Tunisia', '04', 'Mohamed Aouani', 'MOHAMED AOUANI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('779', '20170807', '����췢[2017]106��', '1: MOHAMED 2: LAKHAL 3: na 4: na', 'a) Lased Ben Heni born 5 Feb. 1969 in Tripoli, Libya; b) Al-Asad Ben Hani born 5 Feb. 1969 in Tripoli, Libya; c) Mohamed Ben Belgacem Awani; d) Mohamed Aouani born 5 Feb. 1970 in Tunis, Tunisia', '04', 'Mohamed Ben Belgacem Awani', 'MOHAMED BEN BELGACEM AWANI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('780', '20170807', '����췢[2017]106��', '1: MOHAMMAD 2: HAMDI 3: MOHAMMAD 4: SADIQ AL-AHDAL', 'a) Al-Hamati, Muhammad; b) Muhammad Muhammad Abdullah Al-Ahdal; c) Mohamed Mohamed Abdullah Al-Ahdal', '02', 'MOHAMMAD HAMDI', 'MOHAMMAD HAMDI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('781', '20170807', '����췢[2017]106��', '1: MOHAMMAD 2: HAMDI 3: MOHAMMAD 4: SADIQ AL-AHDAL', 'a) Al-Hamati, Muhammad; b) Muhammad Muhammad Abdullah Al-Ahdal; c) Mohamed Mohamed Abdullah Al-Ahdal', '04', 'Al-Hamati, Muhammad', 'AL-HAMATI, MUHAMMAD', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('782', '20170807', '����췢[2017]106��', '1: MOHAMMAD 2: HAMDI 3: MOHAMMAD 4: SADIQ AL-AHDAL', 'a) Al-Hamati, Muhammad; b) Muhammad Muhammad Abdullah Al-Ahdal; c) Mohamed Mohamed Abdullah Al-Ahdal', '04', 'Muhammad Muhammad Abdullah Al-Ahdal', 'MUHAMMAD MUHAMMAD ABDULLAH AL-AHDAL', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('783', '20170807', '����췢[2017]106��', '1: MOHAMMAD 2: HAMDI 3: MOHAMMAD 4: SADIQ AL-AHDAL', 'a) Al-Hamati, Muhammad; b) Muhammad Muhammad Abdullah Al-Ahdal; c) Mohamed Mohamed Abdullah Al-Ahdal', '04', 'Mohamed Mohamed Abdullah Al-Ahdal', 'MOHAMED MOHAMED ABDULLAH AL-AHDAL', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('784', '20170807', '����췢[2017]106��', '1: MOHAMMAD 2: TAHIR 3: HAMMID 4: HUSSEIN', 'a) Abdelhamid Al Kurdi', '02', 'MOHAMMAD TAHIR', 'MOHAMMAD TAHIR', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('785', '20170807', '����췢[2017]106��', '1: MOHAMMAD 2: TAHIR 3: HAMMID 4: HUSSEIN', 'a) Abdelhamid Al Kurdi', '04', 'Abdelhamid Al Kurdi', 'ABDELHAMID AL KURDI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('786', '20170807', '����췢[2017]106��', '1: MOHAMMED 2: ABDEL-HALIM 3: HEMAIDA 4: SALEH', 'a) Muhammad Hameida Saleh; b) Muhammad Abd-al-Halim Humaydah; c) Faris Baluchistan', '02', 'MOHAMMED ABDEL-HALIM', 'MOHAMMED ABDEL-HALIM', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('787', '20170807', '����췢[2017]106��', '1: MOHAMMED 2: ABDEL-HALIM 3: HEMAIDA 4: SALEH', 'a) Muhammad Hameida Saleh; b) Muhammad Abd-al-Halim Humaydah; c) Faris Baluchistan', '04', 'Faris Baluchistan', 'FARIS BALUCHISTAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('788', '20170807', '����췢[2017]106��', '1: MOHAMMED 2: ABDEL-HALIM 3: HEMAIDA 4: SALEH', 'a) Muhammad Hameida Saleh; b) Muhammad Abd-al-Halim Humaydah; c) Faris Baluchistan', '04', 'Muhammad Abd-al-Halim Humaydah', 'MUHAMMAD ABD-AL-HALIM HUMAYDAH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('789', '20170807', '����췢[2017]106��', '1: MOHAMMED 2: ABDEL-HALIM 3: HEMAIDA 4: SALEH', 'a) Muhammad Hameida Saleh; b) Muhammad Abd-al-Halim Humaydah; c) Faris Baluchistan', '04', 'Muhammad Hameida Saleh', 'MUHAMMAD HAMEIDA SALEH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('790', '20170807', '����췢[2017]106��', '1: MOHAMMED 2: AL GHABRA 3: na 4: na', 'a) Mohammed El Ghabra; b) Danial Adam ', '02', 'MOHAMMED AL', 'MOHAMMED AL', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('791', '20170807', '����췢[2017]106��', '1: MOHAMMED 2: AL GHABRA 3: na 4: na', 'a) Mohammed El Ghabra; b) Danial Adam ', '04', 'Mohammed El Ghabra', 'MOHAMMED EL GHABRA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('792', '20170807', '����췢[2017]106��', '1: MOHAMMED 2: AL GHABRA 3: na 4: na', 'a) Mohammed El Ghabra; b) Danial Adam ', '04', 'Danial Adam', 'DANIAL ADAM', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('793', '20170807', '����췢[2017]106��', '1: MOHAMMED 2: TUFAIL 3: na 4: na', 'a) Tufail, S.M.; b) Tuffail, Sheik Mohammed', '02', 'MOHAMMED TUFAIL', 'MOHAMMED TUFAIL', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('794', '20170807', '����췢[2017]106��', '1: MOHAMMED 2: TUFAIL 3: na 4: na', 'a) Tufail, S.M.; b) Tuffail, Sheik Mohammed', '04', 'Tufail, S.M.', 'TUFAIL, S.M.', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('795', '20170807', '����췢[2017]106��', '1: MOHAMMED 2: TUFAIL 3: na 4: na', 'a) Tufail, S.M.; b) Tuffail, Sheik Mohammed', '04', 'Tuffail, Sheik Mohammed', 'TUFFAIL, SHEIK MOHAMMED', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('796', '20170807', '����췢[2017]106��', '1: MOHAMMED 2: YAHYA 3: MUJAHID 4: na', 'a) Mohammad Yahya Aziz', '02', 'MOHAMMED YAHYA', 'MOHAMMED YAHYA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('797', '20170807', '����췢[2017]106��', '1: MOHAMMED 2: YAHYA 3: MUJAHID 4: na', 'a) Mohammad Yahya Aziz', '04', 'Mohammad Yahya Aziz', 'MOHAMMAD YAHYA AZIZ', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('798', '20170807', '����췢[2017]106��', '1: MOKHTAR 2: BELMOKHTAR 3: na 4: na', 'a) Abou Abbes Khaled; b) Belaouar Khaled Abou El Abass; c) Belaouer Khaled Abou El Abass;d) Belmokhtar Khaled Abou El Abes; e) Khaled Abou El Abass; f) Khaled Abou El Abbes; g) Khaled Abou El Abes; h) Khaled Abulabbas Na Oor; i) Mukhtar Belmukhtar', '02', 'MOKHTAR BELMOKHTAR', 'MOKHTAR BELMOKHTAR', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('799', '20170807', '����췢[2017]106��', '1: MOKHTAR 2: BELMOKHTAR 3: na 4: na', 'a) Abou Abbes Khaled; b) Belaouar Khaled Abou El Abass; c) Belaouer Khaled Abou El Abass;d) Belmokhtar Khaled Abou El Abes; e) Khaled Abou El Abass; f) Khaled Abou El Abbes; g) Khaled Abou El Abes; h) Khaled Abulabbas Na Oor; i) Mukhtar Belmukhtar', '04', 'Belaouer Khaled Abou El Abass', 'BELAOUER KHALED ABOU EL ABASS', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('800', '20170807', '����췢[2017]106��', '1: MOKHTAR 2: BELMOKHTAR 3: na 4: na', 'a) Abou Abbes Khaled; b) Belaouar Khaled Abou El Abass; c) Belaouer Khaled Abou El Abass;d) Belmokhtar Khaled Abou El Abes; e) Khaled Abou El Abass; f) Khaled Abou El Abbes; g) Khaled Abou El Abes; h) Khaled Abulabbas Na Oor; i) Mukhtar Belmukhtar', '04', 'Belmokhtar Khaled Abou El Abes', 'BELMOKHTAR KHALED ABOU EL ABES', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('801', '20170807', '����췢[2017]106��', '1: MOKHTAR 2: BELMOKHTAR 3: na 4: na', 'a) Abou Abbes Khaled; b) Belaouar Khaled Abou El Abass; c) Belaouer Khaled Abou El Abass;d) Belmokhtar Khaled Abou El Abes; e) Khaled Abou El Abass; f) Khaled Abou El Abbes; g) Khaled Abou El Abes; h) Khaled Abulabbas Na Oor; i) Mukhtar Belmukhtar', '04', 'Khaled Abou El Abass', 'KHALED ABOU EL ABASS', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('802', '20170807', '����췢[2017]106��', '1: MOKHTAR 2: BELMOKHTAR 3: na 4: na', 'a) Abou Abbes Khaled; b) Belaouar Khaled Abou El Abass; c) Belaouer Khaled Abou El Abass;d) Belmokhtar Khaled Abou El Abes; e) Khaled Abou El Abass; f) Khaled Abou El Abbes; g) Khaled Abou El Abes; h) Khaled Abulabbas Na Oor; i) Mukhtar Belmukhtar', '04', 'Abou Abbes Khaled', 'ABOU ABBES KHALED', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('803', '20170807', '����췢[2017]106��', '1: MOKHTAR 2: BELMOKHTAR 3: na 4: na', 'a) Abou Abbes Khaled; b) Belaouar Khaled Abou El Abass; c) Belaouer Khaled Abou El Abass;d) Belmokhtar Khaled Abou El Abes; e) Khaled Abou El Abass; f) Khaled Abou El Abbes; g) Khaled Abou El Abes; h) Khaled Abulabbas Na Oor; i) Mukhtar Belmukhtar', '04', 'Khaled Abou El Abbes', 'KHALED ABOU EL ABBES', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('804', '20170807', '����췢[2017]106��', '1: MOKHTAR 2: BELMOKHTAR 3: na 4: na', 'a) Abou Abbes Khaled; b) Belaouar Khaled Abou El Abass; c) Belaouer Khaled Abou El Abass;d) Belmokhtar Khaled Abou El Abes; e) Khaled Abou El Abass; f) Khaled Abou El Abbes; g) Khaled Abou El Abes; h) Khaled Abulabbas Na Oor; i) Mukhtar Belmukhtar', '04', 'Mukhtar Belmukhtar', 'MUKHTAR BELMUKHTAR', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('805', '20170807', '����췢[2017]106��', '1: MOKHTAR 2: BELMOKHTAR 3: na 4: na', 'a) Abou Abbes Khaled; b) Belaouar Khaled Abou El Abass; c) Belaouer Khaled Abou El Abass;d) Belmokhtar Khaled Abou El Abes; e) Khaled Abou El Abass; f) Khaled Abou El Abbes; g) Khaled Abou El Abes; h) Khaled Abulabbas Na Oor; i) Mukhtar Belmukhtar', '04', 'Belaouar Khaled Abou El Abass', 'BELAOUAR KHALED ABOU EL ABASS', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('806', '20170807', '����췢[2017]106��', '1: MOKHTAR 2: BELMOKHTAR 3: na 4: na', 'a) Abou Abbes Khaled; b) Belaouar Khaled Abou El Abass; c) Belaouer Khaled Abou El Abass;d) Belmokhtar Khaled Abou El Abes; e) Khaled Abou El Abass; f) Khaled Abou El Abbes; g) Khaled Abou El Abes; h) Khaled Abulabbas Na Oor; i) Mukhtar Belmukhtar', '04', 'Khaled Abou El Abes', 'KHALED ABOU EL ABES', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('807', '20170807', '����췢[2017]106��', '1: MOKHTAR 2: BELMOKHTAR 3: na 4: na', 'a) Abou Abbes Khaled; b) Belaouar Khaled Abou El Abass; c) Belaouer Khaled Abou El Abass;d) Belmokhtar Khaled Abou El Abes; e) Khaled Abou El Abass; f) Khaled Abou El Abbes; g) Khaled Abou El Abes; h) Khaled Abulabbas Na Oor; i) Mukhtar Belmukhtar', '04', 'Khaled Abulabbas Na Oor', 'KHALED ABULABBAS NA OOR', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('808', '20170807', '����췢[2017]106��', '1: MONIR 2: CHOUKA 3: na 4: na ', null, '02', 'MONIR CHOUKA', 'MONIR CHOUKA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('809', '20170807', '����췢[2017]106��', '1: MORAD 2: LAABOUDI 3: na 4: na', null, '02', 'MORAD LAABOUDI', 'MORAD LAABOUDI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('810', '20170807', '����췢[2017]106��', '1: MOSTAFA 2: KAMEL 3: MOSTAFA 4: IBRAHIM', 'a) Mustafa Kamel Mustafa; b) Adam Ramsey Eaman; c) Kamel Mustapha Mustapha; d) Mustapha Kamel Mustapha; e) Abu Hamza; f) Mostafa Kamel Mostafa', '02', 'MOSTAFA KAMEL', 'MOSTAFA KAMEL', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('811', '20170807', '����췢[2017]106��', '1: MOSTAFA 2: KAMEL 3: MOSTAFA 4: IBRAHIM', 'a) Mustafa Kamel Mustafa; b) Adam Ramsey Eaman; c) Kamel Mustapha Mustapha; d) Mustapha Kamel Mustapha; e) Abu Hamza; f) Mostafa Kamel Mostafa', '04', 'Mohammad Sholeh Ibrahim', 'MOHAMMAD SHOLEH IBRAHIM', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('812', '20170807', '����췢[2017]106��', '1: MOSTAFA 2: KAMEL 3: MOSTAFA 4: IBRAHIM', 'a) Mustafa Kamel Mustafa; b) Adam Ramsey Eaman; c) Kamel Mustapha Mustapha; d) Mustapha Kamel Mustapha; e) Abu Hamza; f) Mostafa Kamel Mostafa', '04', 'Abu Hamza', 'ABU HAMZA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('813', '20170807', '����췢[2017]106��', '1: MOSTAFA 2: KAMEL 3: MOSTAFA 4: IBRAHIM', 'a) Mustafa Kamel Mustafa; b) Adam Ramsey Eaman; c) Kamel Mustapha Mustapha; d) Mustapha Kamel Mustapha; e) Abu Hamza; f) Mostafa Kamel Mostafa', '04', 'Mustapha Kamel Mustapha', 'MUSTAPHA KAMEL MUSTAPHA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('814', '20170807', '����췢[2017]106��', '1: MOSTAFA 2: KAMEL 3: MOSTAFA 4: IBRAHIM', 'a) Mustafa Kamel Mustafa; b) Adam Ramsey Eaman; c) Kamel Mustapha Mustapha; d) Mustapha Kamel Mustapha; e) Abu Hamza; f) Mostafa Kamel Mostafa', '04', 'Adam Ramsey Eaman', 'ADAM RAMSEY EAMAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('815', '20170807', '����췢[2017]106��', '1: MOSTAFA 2: KAMEL 3: MOSTAFA 4: IBRAHIM', 'a) Mustafa Kamel Mustafa; b) Adam Ramsey Eaman; c) Kamel Mustapha Mustapha; d) Mustapha Kamel Mustapha; e) Abu Hamza; f) Mostafa Kamel Mostafa', '04', 'Mustafa Kamel Mustafa', 'MUSTAFA KAMEL MUSTAFA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('816', '20170807', '����췢[2017]106��', '1: MOSTAFA 2: KAMEL 3: MOSTAFA 4: IBRAHIM', 'a) Mustafa Kamel Mustafa; b) Adam Ramsey Eaman; c) Kamel Mustapha Mustapha; d) Mustapha Kamel Mustapha; e) Abu Hamza; f) Mostafa Kamel Mostafa', '04', 'Mostafa Kamel Mostafa', 'MOSTAFA KAMEL MOSTAFA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('817', '20170807', '����췢[2017]106��', '1: MOSTAFA 2: KAMEL 3: MOSTAFA 4: IBRAHIM', 'a) Mustafa Kamel Mustafa; b) Adam Ramsey Eaman; c) Kamel Mustapha Mustapha; d) Mustapha Kamel Mustapha; e) Abu Hamza; f) Mostafa Kamel Mostafa', '04', 'Kamel Mustapha Mustapha', 'KAMEL MUSTAPHA MUSTAPHA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('818', '20170807', '����췢[2017]106��', '1: MOUNIR 2: BEN DHAOU 3: BEN BRAHIM 4: BEN HELAL', null, '02', 'MOUNIR BEN DHAOU', 'MOUNIR BEN DHAOU', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('819', '20170807', '����췢[2017]106��', '1: MOUNIR 2: EL MOTASSADEQ 3: na 4: na', 'a) Mounir el Moutassadep', '02', 'MOUNIR EL MOTASSADEQ', 'MOUNIR EL MOTASSADEQ', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('820', '20170807', '����췢[2017]106��', '1: MOUNIR 2: EL MOTASSADEQ 3: na 4: na', 'a) Mounir el Moutassadep', '03', 'Mounir el Moutassadep', 'MOUNIR EL MOUTASSADEP', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('821', '20170807', '����췢[2017]106��', '1: MOURAD 2: BEN ALI 3: BEN AL-BASHEER 4: AL-TRABELSI', 'a) Aboue Chiba Brahim born 2 Sep. 1966 in Libya; b) Arouri Taoufik born 2 Sep. 1964 in Tunisia; c) Ben Salah Adnan born 2 Apr. 1966 in Tunisia; d) Sassi Adel born 2 Sep. 1966 in Tunisia; e) Salam Kamel born 2 Feb. 1963 in Tunisia; f) Salah Adnan born 4 Feb. 1965 in Algeria; g) Arouri Faisei born 2 Mar. 1965 in Tunisia; h) Bentaib Amour born 9 Feb. 1965 in Morocco; i) Adan Salah born 1 Apr. 1966 in Tunisia; j) Hasnaoui Mellit (born in 1972 in Morocco); k) Arouri Taoufik ben Taieb born 9 Feb. 1964 in Tunisia; l) Abouechiba Brahim born 2 Sep. 1966 in Lebanon; m) Farid Arouri born 2 Jun. 1964 in Tunisia; n) Ben Magid born 2 Jun. 1966 in Lebanon; o) Maci Ssassi born 2 Jun. 1972 in Libya; p) Salah ben Anan born 2 Apr. 1966 in Tunisia; q) Hasnaui Mellit (born in 1972 in Morocco)', '02', 'MOURAD BEN ALI', 'MOURAD BEN ALI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('822', '20170807', '����췢[2017]106��', '1: MOURAD 2: BEN ALI 3: BEN AL-BASHEER 4: AL-TRABELSI', 'a) Aboue Chiba Brahim born 2 Sep. 1966 in Libya; b) Arouri Taoufik born 2 Sep. 1964 in Tunisia; c) Ben Salah Adnan born 2 Apr. 1966 in Tunisia; d) Sassi Adel born 2 Sep. 1966 in Tunisia; e) Salam Kamel born 2 Feb. 1963 in Tunisia; f) Salah Adnan born 4 Feb. 1965 in Algeria; g) Arouri Faisei born 2 Mar. 1965 in Tunisia; h) Bentaib Amour born 9 Feb. 1965 in Morocco; i) Adan Salah born 1 Apr. 1966 in Tunisia; j) Hasnaoui Mellit (born in 1972 in Morocco); k) Arouri Taoufik ben Taieb born 9 Feb. 1964 in Tunisia; l) Abouechiba Brahim born 2 Sep. 1966 in Lebanon; m) Farid Arouri born 2 Jun. 1964 in Tunisia; n) Ben Magid born 2 Jun. 1966 in Lebanon; o) Maci Ssassi born 2 Jun. 1972 in Libya; p) Salah ben Anan born 2 Apr. 1966 in Tunisia; q) Hasnaui Mellit (born in 1972 in Morocco)', '04', 'Hasnaui Mellit', 'HASNAUI MELLIT', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('823', '20170807', '����췢[2017]106��', '1: MOURAD 2: BEN ALI 3: BEN AL-BASHEER 4: AL-TRABELSI', 'a) Aboue Chiba Brahim born 2 Sep. 1966 in Libya; b) Arouri Taoufik born 2 Sep. 1964 in Tunisia; c) Ben Salah Adnan born 2 Apr. 1966 in Tunisia; d) Sassi Adel born 2 Sep. 1966 in Tunisia; e) Salam Kamel born 2 Feb. 1963 in Tunisia; f) Salah Adnan born 4 Feb. 1965 in Algeria; g) Arouri Faisei born 2 Mar. 1965 in Tunisia; h) Bentaib Amour born 9 Feb. 1965 in Morocco; i) Adan Salah born 1 Apr. 1966 in Tunisia; j) Hasnaoui Mellit (born in 1972 in Morocco); k) Arouri Taoufik ben Taieb born 9 Feb. 1964 in Tunisia; l) Abouechiba Brahim born 2 Sep. 1966 in Lebanon; m) Farid Arouri born 2 Jun. 1964 in Tunisia; n) Ben Magid born 2 Jun. 1966 in Lebanon; o) Maci Ssassi born 2 Jun. 1972 in Libya; p) Salah ben Anan born 2 Apr. 1966 in Tunisia; q) Hasnaui Mellit (born in 1972 in Morocco)', '04', 'Farid Arouri', 'FARID AROURI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('824', '20170807', '����췢[2017]106��', '1: MOURAD 2: BEN ALI 3: BEN AL-BASHEER 4: AL-TRABELSI', 'a) Aboue Chiba Brahim born 2 Sep. 1966 in Libya; b) Arouri Taoufik born 2 Sep. 1964 in Tunisia; c) Ben Salah Adnan born 2 Apr. 1966 in Tunisia; d) Sassi Adel born 2 Sep. 1966 in Tunisia; e) Salam Kamel born 2 Feb. 1963 in Tunisia; f) Salah Adnan born 4 Feb. 1965 in Algeria; g) Arouri Faisei born 2 Mar. 1965 in Tunisia; h) Bentaib Amour born 9 Feb. 1965 in Morocco; i) Adan Salah born 1 Apr. 1966 in Tunisia; j) Hasnaoui Mellit (born in 1972 in Morocco); k) Arouri Taoufik ben Taieb born 9 Feb. 1964 in Tunisia; l) Abouechiba Brahim born 2 Sep. 1966 in Lebanon; m) Farid Arouri born 2 Jun. 1964 in Tunisia; n) Ben Magid born 2 Jun. 1966 in Lebanon; o) Maci Ssassi born 2 Jun. 1972 in Libya; p) Salah ben Anan born 2 Apr. 1966 in Tunisia; q) Hasnaui Mellit (born in 1972 in Morocco)', '04', 'Aboue Chiba Brahim', 'ABOUE CHIBA BRAHIM', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('825', '20170807', '����췢[2017]106��', '1: MOURAD 2: BEN ALI 3: BEN AL-BASHEER 4: AL-TRABELSI', 'a) Aboue Chiba Brahim born 2 Sep. 1966 in Libya; b) Arouri Taoufik born 2 Sep. 1964 in Tunisia; c) Ben Salah Adnan born 2 Apr. 1966 in Tunisia; d) Sassi Adel born 2 Sep. 1966 in Tunisia; e) Salam Kamel born 2 Feb. 1963 in Tunisia; f) Salah Adnan born 4 Feb. 1965 in Algeria; g) Arouri Faisei born 2 Mar. 1965 in Tunisia; h) Bentaib Amour born 9 Feb. 1965 in Morocco; i) Adan Salah born 1 Apr. 1966 in Tunisia; j) Hasnaoui Mellit (born in 1972 in Morocco); k) Arouri Taoufik ben Taieb born 9 Feb. 1964 in Tunisia; l) Abouechiba Brahim born 2 Sep. 1966 in Lebanon; m) Farid Arouri born 2 Jun. 1964 in Tunisia; n) Ben Magid born 2 Jun. 1966 in Lebanon; o) Maci Ssassi born 2 Jun. 1972 in Libya; p) Salah ben Anan born 2 Apr. 1966 in Tunisia; q) Hasnaui Mellit (born in 1972 in Morocco)', '04', 'Arouri Taoufik', 'AROURI TAOUFIK', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('826', '20170807', '����췢[2017]106��', '1: MOURAD 2: BEN ALI 3: BEN AL-BASHEER 4: AL-TRABELSI', 'a) Aboue Chiba Brahim born 2 Sep. 1966 in Libya; b) Arouri Taoufik born 2 Sep. 1964 in Tunisia; c) Ben Salah Adnan born 2 Apr. 1966 in Tunisia; d) Sassi Adel born 2 Sep. 1966 in Tunisia; e) Salam Kamel born 2 Feb. 1963 in Tunisia; f) Salah Adnan born 4 Feb. 1965 in Algeria; g) Arouri Faisei born 2 Mar. 1965 in Tunisia; h) Bentaib Amour born 9 Feb. 1965 in Morocco; i) Adan Salah born 1 Apr. 1966 in Tunisia; j) Hasnaoui Mellit (born in 1972 in Morocco); k) Arouri Taoufik ben Taieb born 9 Feb. 1964 in Tunisia; l) Abouechiba Brahim born 2 Sep. 1966 in Lebanon; m) Farid Arouri born 2 Jun. 1964 in Tunisia; n) Ben Magid born 2 Jun. 1966 in Lebanon; o) Maci Ssassi born 2 Jun. 1972 in Libya; p) Salah ben Anan born 2 Apr. 1966 in Tunisia; q) Hasnaui Mellit (born in 1972 in Morocco)', '04', 'Ben Salah Adnan', 'BEN SALAH ADNAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('827', '20170807', '����췢[2017]106��', '1: MOURAD 2: BEN ALI 3: BEN AL-BASHEER 4: AL-TRABELSI', 'a) Aboue Chiba Brahim born 2 Sep. 1966 in Libya; b) Arouri Taoufik born 2 Sep. 1964 in Tunisia; c) Ben Salah Adnan born 2 Apr. 1966 in Tunisia; d) Sassi Adel born 2 Sep. 1966 in Tunisia; e) Salam Kamel born 2 Feb. 1963 in Tunisia; f) Salah Adnan born 4 Feb. 1965 in Algeria; g) Arouri Faisei born 2 Mar. 1965 in Tunisia; h) Bentaib Amour born 9 Feb. 1965 in Morocco; i) Adan Salah born 1 Apr. 1966 in Tunisia; j) Hasnaoui Mellit (born in 1972 in Morocco); k) Arouri Taoufik ben Taieb born 9 Feb. 1964 in Tunisia; l) Abouechiba Brahim born 2 Sep. 1966 in Lebanon; m) Farid Arouri born 2 Jun. 1964 in Tunisia; n) Ben Magid born 2 Jun. 1966 in Lebanon; o) Maci Ssassi born 2 Jun. 1972 in Libya; p) Salah ben Anan born 2 Apr. 1966 in Tunisia; q) Hasnaui Mellit (born in 1972 in Morocco)', '04', 'Sassi Adel', 'SASSI ADEL', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('828', '20170807', '����췢[2017]106��', '1: MOURAD 2: BEN ALI 3: BEN AL-BASHEER 4: AL-TRABELSI', 'a) Aboue Chiba Brahim born 2 Sep. 1966 in Libya; b) Arouri Taoufik born 2 Sep. 1964 in Tunisia; c) Ben Salah Adnan born 2 Apr. 1966 in Tunisia; d) Sassi Adel born 2 Sep. 1966 in Tunisia; e) Salam Kamel born 2 Feb. 1963 in Tunisia; f) Salah Adnan born 4 Feb. 1965 in Algeria; g) Arouri Faisei born 2 Mar. 1965 in Tunisia; h) Bentaib Amour born 9 Feb. 1965 in Morocco; i) Adan Salah born 1 Apr. 1966 in Tunisia; j) Hasnaoui Mellit (born in 1972 in Morocco); k) Arouri Taoufik ben Taieb born 9 Feb. 1964 in Tunisia; l) Abouechiba Brahim born 2 Sep. 1966 in Lebanon; m) Farid Arouri born 2 Jun. 1964 in Tunisia; n) Ben Magid born 2 Jun. 1966 in Lebanon; o) Maci Ssassi born 2 Jun. 1972 in Libya; p) Salah ben Anan born 2 Apr. 1966 in Tunisia; q) Hasnaui Mellit (born in 1972 in Morocco)', '04', 'Salam Kamel', 'SALAM KAMEL', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('829', '20170807', '����췢[2017]106��', '1: MOURAD 2: BEN ALI 3: BEN AL-BASHEER 4: AL-TRABELSI', 'a) Aboue Chiba Brahim born 2 Sep. 1966 in Libya; b) Arouri Taoufik born 2 Sep. 1964 in Tunisia; c) Ben Salah Adnan born 2 Apr. 1966 in Tunisia; d) Sassi Adel born 2 Sep. 1966 in Tunisia; e) Salam Kamel born 2 Feb. 1963 in Tunisia; f) Salah Adnan born 4 Feb. 1965 in Algeria; g) Arouri Faisei born 2 Mar. 1965 in Tunisia; h) Bentaib Amour born 9 Feb. 1965 in Morocco; i) Adan Salah born 1 Apr. 1966 in Tunisia; j) Hasnaoui Mellit (born in 1972 in Morocco); k) Arouri Taoufik ben Taieb born 9 Feb. 1964 in Tunisia; l) Abouechiba Brahim born 2 Sep. 1966 in Lebanon; m) Farid Arouri born 2 Jun. 1964 in Tunisia; n) Ben Magid born 2 Jun. 1966 in Lebanon; o) Maci Ssassi born 2 Jun. 1972 in Libya; p) Salah ben Anan born 2 Apr. 1966 in Tunisia; q) Hasnaui Mellit (born in 1972 in Morocco)', '04', 'Salah Adnan', 'SALAH ADNAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('830', '20170807', '����췢[2017]106��', '1: MOURAD 2: BEN ALI 3: BEN AL-BASHEER 4: AL-TRABELSI', 'a) Aboue Chiba Brahim born 2 Sep. 1966 in Libya; b) Arouri Taoufik born 2 Sep. 1964 in Tunisia; c) Ben Salah Adnan born 2 Apr. 1966 in Tunisia; d) Sassi Adel born 2 Sep. 1966 in Tunisia; e) Salam Kamel born 2 Feb. 1963 in Tunisia; f) Salah Adnan born 4 Feb. 1965 in Algeria; g) Arouri Faisei born 2 Mar. 1965 in Tunisia; h) Bentaib Amour born 9 Feb. 1965 in Morocco; i) Adan Salah born 1 Apr. 1966 in Tunisia; j) Hasnaoui Mellit (born in 1972 in Morocco); k) Arouri Taoufik ben Taieb born 9 Feb. 1964 in Tunisia; l) Abouechiba Brahim born 2 Sep. 1966 in Lebanon; m) Farid Arouri born 2 Jun. 1964 in Tunisia; n) Ben Magid born 2 Jun. 1966 in Lebanon; o) Maci Ssassi born 2 Jun. 1972 in Libya; p) Salah ben Anan born 2 Apr. 1966 in Tunisia; q) Hasnaui Mellit (born in 1972 in Morocco)', '04', 'Arouri Faisei', 'AROURI FAISEI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('831', '20170807', '����췢[2017]106��', '1: MOURAD 2: BEN ALI 3: BEN AL-BASHEER 4: AL-TRABELSI', 'a) Aboue Chiba Brahim born 2 Sep. 1966 in Libya; b) Arouri Taoufik born 2 Sep. 1964 in Tunisia; c) Ben Salah Adnan born 2 Apr. 1966 in Tunisia; d) Sassi Adel born 2 Sep. 1966 in Tunisia; e) Salam Kamel born 2 Feb. 1963 in Tunisia; f) Salah Adnan born 4 Feb. 1965 in Algeria; g) Arouri Faisei born 2 Mar. 1965 in Tunisia; h) Bentaib Amour born 9 Feb. 1965 in Morocco; i) Adan Salah born 1 Apr. 1966 in Tunisia; j) Hasnaoui Mellit (born in 1972 in Morocco); k) Arouri Taoufik ben Taieb born 9 Feb. 1964 in Tunisia; l) Abouechiba Brahim born 2 Sep. 1966 in Lebanon; m) Farid Arouri born 2 Jun. 1964 in Tunisia; n) Ben Magid born 2 Jun. 1966 in Lebanon; o) Maci Ssassi born 2 Jun. 1972 in Libya; p) Salah ben Anan born 2 Apr. 1966 in Tunisia; q) Hasnaui Mellit (born in 1972 in Morocco)', '04', 'Bentaib Amour', 'BENTAIB AMOUR', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('832', '20170807', '����췢[2017]106��', '1: MOURAD 2: BEN ALI 3: BEN AL-BASHEER 4: AL-TRABELSI', 'a) Aboue Chiba Brahim born 2 Sep. 1966 in Libya; b) Arouri Taoufik born 2 Sep. 1964 in Tunisia; c) Ben Salah Adnan born 2 Apr. 1966 in Tunisia; d) Sassi Adel born 2 Sep. 1966 in Tunisia; e) Salam Kamel born 2 Feb. 1963 in Tunisia; f) Salah Adnan born 4 Feb. 1965 in Algeria; g) Arouri Faisei born 2 Mar. 1965 in Tunisia; h) Bentaib Amour born 9 Feb. 1965 in Morocco; i) Adan Salah born 1 Apr. 1966 in Tunisia; j) Hasnaoui Mellit (born in 1972 in Morocco); k) Arouri Taoufik ben Taieb born 9 Feb. 1964 in Tunisia; l) Abouechiba Brahim born 2 Sep. 1966 in Lebanon; m) Farid Arouri born 2 Jun. 1964 in Tunisia; n) Ben Magid born 2 Jun. 1966 in Lebanon; o) Maci Ssassi born 2 Jun. 1972 in Libya; p) Salah ben Anan born 2 Apr. 1966 in Tunisia; q) Hasnaui Mellit (born in 1972 in Morocco)', '04', 'Adan Salah', 'ADAN SALAH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('833', '20170807', '����췢[2017]106��', '1: MOURAD 2: BEN ALI 3: BEN AL-BASHEER 4: AL-TRABELSI', 'a) Aboue Chiba Brahim born 2 Sep. 1966 in Libya; b) Arouri Taoufik born 2 Sep. 1964 in Tunisia; c) Ben Salah Adnan born 2 Apr. 1966 in Tunisia; d) Sassi Adel born 2 Sep. 1966 in Tunisia; e) Salam Kamel born 2 Feb. 1963 in Tunisia; f) Salah Adnan born 4 Feb. 1965 in Algeria; g) Arouri Faisei born 2 Mar. 1965 in Tunisia; h) Bentaib Amour born 9 Feb. 1965 in Morocco; i) Adan Salah born 1 Apr. 1966 in Tunisia; j) Hasnaoui Mellit (born in 1972 in Morocco); k) Arouri Taoufik ben Taieb born 9 Feb. 1964 in Tunisia; l) Abouechiba Brahim born 2 Sep. 1966 in Lebanon; m) Farid Arouri born 2 Jun. 1964 in Tunisia; n) Ben Magid born 2 Jun. 1966 in Lebanon; o) Maci Ssassi born 2 Jun. 1972 in Libya; p) Salah ben Anan born 2 Apr. 1966 in Tunisia; q) Hasnaui Mellit (born in 1972 in Morocco)', '04', 'Hasnaoui Mellit', 'HASNAOUI MELLIT', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('834', '20170807', '����췢[2017]106��', '1: MOURAD 2: BEN ALI 3: BEN AL-BASHEER 4: AL-TRABELSI', 'a) Aboue Chiba Brahim born 2 Sep. 1966 in Libya; b) Arouri Taoufik born 2 Sep. 1964 in Tunisia; c) Ben Salah Adnan born 2 Apr. 1966 in Tunisia; d) Sassi Adel born 2 Sep. 1966 in Tunisia; e) Salam Kamel born 2 Feb. 1963 in Tunisia; f) Salah Adnan born 4 Feb. 1965 in Algeria; g) Arouri Faisei born 2 Mar. 1965 in Tunisia; h) Bentaib Amour born 9 Feb. 1965 in Morocco; i) Adan Salah born 1 Apr. 1966 in Tunisia; j) Hasnaoui Mellit (born in 1972 in Morocco); k) Arouri Taoufik ben Taieb born 9 Feb. 1964 in Tunisia; l) Abouechiba Brahim born 2 Sep. 1966 in Lebanon; m) Farid Arouri born 2 Jun. 1964 in Tunisia; n) Ben Magid born 2 Jun. 1966 in Lebanon; o) Maci Ssassi born 2 Jun. 1972 in Libya; p) Salah ben Anan born 2 Apr. 1966 in Tunisia; q) Hasnaui Mellit (born in 1972 in Morocco)', '04', 'Arouri Taoufik ben Taieb', 'AROURI TAOUFIK BEN TAIEB', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('835', '20170807', '����췢[2017]106��', '1: MOURAD 2: BEN ALI 3: BEN AL-BASHEER 4: AL-TRABELSI', 'a) Aboue Chiba Brahim born 2 Sep. 1966 in Libya; b) Arouri Taoufik born 2 Sep. 1964 in Tunisia; c) Ben Salah Adnan born 2 Apr. 1966 in Tunisia; d) Sassi Adel born 2 Sep. 1966 in Tunisia; e) Salam Kamel born 2 Feb. 1963 in Tunisia; f) Salah Adnan born 4 Feb. 1965 in Algeria; g) Arouri Faisei born 2 Mar. 1965 in Tunisia; h) Bentaib Amour born 9 Feb. 1965 in Morocco; i) Adan Salah born 1 Apr. 1966 in Tunisia; j) Hasnaoui Mellit (born in 1972 in Morocco); k) Arouri Taoufik ben Taieb born 9 Feb. 1964 in Tunisia; l) Abouechiba Brahim born 2 Sep. 1966 in Lebanon; m) Farid Arouri born 2 Jun. 1964 in Tunisia; n) Ben Magid born 2 Jun. 1966 in Lebanon; o) Maci Ssassi born 2 Jun. 1972 in Libya; p) Salah ben Anan born 2 Apr. 1966 in Tunisia; q) Hasnaui Mellit (born in 1972 in Morocco)', '04', 'Abouechiba Brahim', 'ABOUECHIBA BRAHIM', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('836', '20170807', '����췢[2017]106��', '1: MOURAD 2: BEN ALI 3: BEN AL-BASHEER 4: AL-TRABELSI', 'a) Aboue Chiba Brahim born 2 Sep. 1966 in Libya; b) Arouri Taoufik born 2 Sep. 1964 in Tunisia; c) Ben Salah Adnan born 2 Apr. 1966 in Tunisia; d) Sassi Adel born 2 Sep. 1966 in Tunisia; e) Salam Kamel born 2 Feb. 1963 in Tunisia; f) Salah Adnan born 4 Feb. 1965 in Algeria; g) Arouri Faisei born 2 Mar. 1965 in Tunisia; h) Bentaib Amour born 9 Feb. 1965 in Morocco; i) Adan Salah born 1 Apr. 1966 in Tunisia; j) Hasnaoui Mellit (born in 1972 in Morocco); k) Arouri Taoufik ben Taieb born 9 Feb. 1964 in Tunisia; l) Abouechiba Brahim born 2 Sep. 1966 in Lebanon; m) Farid Arouri born 2 Jun. 1964 in Tunisia; n) Ben Magid born 2 Jun. 1966 in Lebanon; o) Maci Ssassi born 2 Jun. 1972 in Libya; p) Salah ben Anan born 2 Apr. 1966 in Tunisia; q) Hasnaui Mellit (born in 1972 in Morocco)', '04', 'Ben Magid', 'BEN MAGID', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('837', '20170807', '����췢[2017]106��', '1: MOURAD 2: BEN ALI 3: BEN AL-BASHEER 4: AL-TRABELSI', 'a) Aboue Chiba Brahim born 2 Sep. 1966 in Libya; b) Arouri Taoufik born 2 Sep. 1964 in Tunisia; c) Ben Salah Adnan born 2 Apr. 1966 in Tunisia; d) Sassi Adel born 2 Sep. 1966 in Tunisia; e) Salam Kamel born 2 Feb. 1963 in Tunisia; f) Salah Adnan born 4 Feb. 1965 in Algeria; g) Arouri Faisei born 2 Mar. 1965 in Tunisia; h) Bentaib Amour born 9 Feb. 1965 in Morocco; i) Adan Salah born 1 Apr. 1966 in Tunisia; j) Hasnaoui Mellit (born in 1972 in Morocco); k) Arouri Taoufik ben Taieb born 9 Feb. 1964 in Tunisia; l) Abouechiba Brahim born 2 Sep. 1966 in Lebanon; m) Farid Arouri born 2 Jun. 1964 in Tunisia; n) Ben Magid born 2 Jun. 1966 in Lebanon; o) Maci Ssassi born 2 Jun. 1972 in Libya; p) Salah ben Anan born 2 Apr. 1966 in Tunisia; q) Hasnaui Mellit (born in 1972 in Morocco)', '04', 'Maci Ssassi', 'MACI SSASSI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('838', '20170807', '����췢[2017]106��', '1: MOURAD 2: BEN ALI 3: BEN AL-BASHEER 4: AL-TRABELSI', 'a) Aboue Chiba Brahim born 2 Sep. 1966 in Libya; b) Arouri Taoufik born 2 Sep. 1964 in Tunisia; c) Ben Salah Adnan born 2 Apr. 1966 in Tunisia; d) Sassi Adel born 2 Sep. 1966 in Tunisia; e) Salam Kamel born 2 Feb. 1963 in Tunisia; f) Salah Adnan born 4 Feb. 1965 in Algeria; g) Arouri Faisei born 2 Mar. 1965 in Tunisia; h) Bentaib Amour born 9 Feb. 1965 in Morocco; i) Adan Salah born 1 Apr. 1966 in Tunisia; j) Hasnaoui Mellit (born in 1972 in Morocco); k) Arouri Taoufik ben Taieb born 9 Feb. 1964 in Tunisia; l) Abouechiba Brahim born 2 Sep. 1966 in Lebanon; m) Farid Arouri born 2 Jun. 1964 in Tunisia; n) Ben Magid born 2 Jun. 1966 in Lebanon; o) Maci Ssassi born 2 Jun. 1972 in Libya; p) Salah ben Anan born 2 Apr. 1966 in Tunisia; q) Hasnaui Mellit (born in 1972 in Morocco)', '04', 'Salah ben Anan', 'SALAH BEN ANAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('839', '20170807', '����췢[2017]106��', '1: MOUSSA 2: BEN OMAR 3: BEN ALI 4: ESSAADI', null, '02', 'MOUSSA BEN OMAR', 'MOUSSA BEN OMAR', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('840', '20170807', '����췢[2017]106��', '1: MUBARAK 2: MUSHAKHAS 3: SANAD 4: MUBARAK AL-BATHALI', 'a) Mubarak Mishkhis Sanad Al-Bathali; b) Mubarak Mishkhis Sanad Al Badhali; c) Mubarak Al-Bathali; d) Mubarak Mishkhas Sanad Al-Bathali; e) Mubarak Mishkhas Sanad Al-Bazali; f) Mobarak Meshkhas Sanad Al-Bthaly', '02', 'MUBARAK MUSHAKHAS', 'MUBARAK MUSHAKHAS', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('841', '20170807', '����췢[2017]106��', '1: MUBARAK 2: MUSHAKHAS 3: SANAD 4: MUBARAK AL-BATHALI', 'a) Mubarak Mishkhis Sanad Al-Bathali; b) Mubarak Mishkhis Sanad Al Badhali; c) Mubarak Al-Bathali; d) Mubarak Mishkhas Sanad Al-Bathali; e) Mubarak Mishkhas Sanad Al-Bazali; f) Mobarak Meshkhas Sanad Al-Bthaly', '04', 'Mobarak Meshkhas Sanad Al-Bthaly', 'MOBARAK MESHKHAS SANAD AL-BTHALY', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('842', '20170807', '����췢[2017]106��', '1: MUBARAK 2: MUSHAKHAS 3: SANAD 4: MUBARAK AL-BATHALI', 'a) Mubarak Mishkhis Sanad Al-Bathali; b) Mubarak Mishkhis Sanad Al Badhali; c) Mubarak Al-Bathali; d) Mubarak Mishkhas Sanad Al-Bathali; e) Mubarak Mishkhas Sanad Al-Bazali; f) Mobarak Meshkhas Sanad Al-Bthaly', '04', 'Mubarak Mishkhis Sanad Al-Bathali', 'MUBARAK MISHKHIS SANAD AL-BATHALI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('843', '20170807', '����췢[2017]106��', '1: MUBARAK 2: MUSHAKHAS 3: SANAD 4: MUBARAK AL-BATHALI', 'a) Mubarak Mishkhis Sanad Al-Bathali; b) Mubarak Mishkhis Sanad Al Badhali; c) Mubarak Al-Bathali; d) Mubarak Mishkhas Sanad Al-Bathali; e) Mubarak Mishkhas Sanad Al-Bazali; f) Mobarak Meshkhas Sanad Al-Bthaly', '04', 'Mubarak Mishkhis Sanad Al Badhali', 'MUBARAK MISHKHIS SANAD AL BADHALI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('844', '20170807', '����췢[2017]106��', '1: MUBARAK 2: MUSHAKHAS 3: SANAD 4: MUBARAK AL-BATHALI', 'a) Mubarak Mishkhis Sanad Al-Bathali; b) Mubarak Mishkhis Sanad Al Badhali; c) Mubarak Al-Bathali; d) Mubarak Mishkhas Sanad Al-Bathali; e) Mubarak Mishkhas Sanad Al-Bazali; f) Mobarak Meshkhas Sanad Al-Bthaly', '04', 'Mubarak Al-Bathali', 'MUBARAK AL-BATHALI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('845', '20170807', '����췢[2017]106��', '1: MUBARAK 2: MUSHAKHAS 3: SANAD 4: MUBARAK AL-BATHALI', 'a) Mubarak Mishkhis Sanad Al-Bathali; b) Mubarak Mishkhis Sanad Al Badhali; c) Mubarak Al-Bathali; d) Mubarak Mishkhas Sanad Al-Bathali; e) Mubarak Mishkhas Sanad Al-Bazali; f) Mobarak Meshkhas Sanad Al-Bthaly', '04', 'Mubarak Mishkhas Sanad Al-Bathali', 'MUBARAK MISHKHAS SANAD AL-BATHALI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('846', '20170807', '����췢[2017]106��', '1: MUBARAK 2: MUSHAKHAS 3: SANAD 4: MUBARAK AL-BATHALI', 'a) Mubarak Mishkhis Sanad Al-Bathali; b) Mubarak Mishkhis Sanad Al Badhali; c) Mubarak Al-Bathali; d) Mubarak Mishkhas Sanad Al-Bathali; e) Mubarak Mishkhas Sanad Al-Bazali; f) Mobarak Meshkhas Sanad Al-Bthaly', '04', 'Mubarak Mishkhas Sanad Al-Bazali', 'MUBARAK MISHKHAS SANAD AL-BAZALI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('847', '20170807', '����췢[2017]106��', '1: MUHAMMAD 2: JAMAL 3: ABD-AL RAHIM AHMAD 4: AL-KASHIF', 'a) Muhammad Jamal Abdo Al-Kashif; b) Muhammad Jamal Abdo Al Kashef; c) Muhammad Jamal Abd-Al Rahim Ahmad Al-Kashif; d) Muhammad Jamal Abd-Al Rahim Al-Kashif; e) Muhammad Jamal Abdu; f) Muhammad Jamal', '02', 'MUHAMMAD JAMAL', 'MUHAMMAD JAMAL', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('848', '20170807', '����췢[2017]106��', '1: MUHAMMAD 2: JAMAL 3: ABD-AL RAHIM AHMAD 4: AL-KASHIF', 'a) Muhammad Jamal Abdo Al-Kashif; b) Muhammad Jamal Abdo Al Kashef; c) Muhammad Jamal Abd-Al Rahim Ahmad Al-Kashif; d) Muhammad Jamal Abd-Al Rahim Al-Kashif; e) Muhammad Jamal Abdu; f) Muhammad Jamal', '04', 'Muhammad Jamal Abd-Al Rahim Al-Kashif', 'MUHAMMAD JAMAL ABD-AL RAHIM AL-KASHIF', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('849', '20170807', '����췢[2017]106��', '1: MUHAMMAD 2: JAMAL 3: ABD-AL RAHIM AHMAD 4: AL-KASHIF', 'a) Muhammad Jamal Abdo Al-Kashif; b) Muhammad Jamal Abdo Al Kashef; c) Muhammad Jamal Abd-Al Rahim Ahmad Al-Kashif; d) Muhammad Jamal Abd-Al Rahim Al-Kashif; e) Muhammad Jamal Abdu; f) Muhammad Jamal', '04', 'Muhammad Jamal Abdo Al Kashef', 'MUHAMMAD JAMAL ABDO AL KASHEF', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('850', '20170807', '����췢[2017]106��', '1: MUHAMMAD 2: JAMAL 3: ABD-AL RAHIM AHMAD 4: AL-KASHIF', 'a) Muhammad Jamal Abdo Al-Kashif; b) Muhammad Jamal Abdo Al Kashef; c) Muhammad Jamal Abd-Al Rahim Ahmad Al-Kashif; d) Muhammad Jamal Abd-Al Rahim Al-Kashif; e) Muhammad Jamal Abdu; f) Muhammad Jamal', '04', 'Muhammad Jamal Abd-Al Rahim Ahmad Al-Kashif', 'MUHAMMAD JAMAL ABD-AL RAHIM AHMAD AL-KASHIF', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('851', '20170807', '����췢[2017]106��', '1: MUHAMMAD 2: JAMAL 3: ABD-AL RAHIM AHMAD 4: AL-KASHIF', 'a) Muhammad Jamal Abdo Al-Kashif; b) Muhammad Jamal Abdo Al Kashef; c) Muhammad Jamal Abd-Al Rahim Ahmad Al-Kashif; d) Muhammad Jamal Abd-Al Rahim Al-Kashif; e) Muhammad Jamal Abdu; f) Muhammad Jamal', '04', 'Muhammad Jamal Abdo Al-Kashif', 'MUHAMMAD JAMAL ABDO AL-KASHIF', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('852', '20170807', '����췢[2017]106��', '1: MUHAMMAD 2: JAMAL 3: ABD-AL RAHIM AHMAD 4: AL-KASHIF', 'a) Muhammad Jamal Abdo Al-Kashif; b) Muhammad Jamal Abdo Al Kashef; c) Muhammad Jamal Abd-Al Rahim Ahmad Al-Kashif; d) Muhammad Jamal Abd-Al Rahim Al-Kashif; e) Muhammad Jamal Abdu; f) Muhammad Jamal', '04', 'Muhammad Jamal Abdu', 'MUHAMMAD JAMAL ABDU', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('853', '20170807', '����췢[2017]106��', '1: MUHAMMAD 2: JAMAL 3: ABD-AL RAHIM AHMAD 4: AL-KASHIF', 'a) Muhammad Jamal Abdo Al-Kashif; b) Muhammad Jamal Abdo Al Kashef; c) Muhammad Jamal Abd-Al Rahim Ahmad Al-Kashif; d) Muhammad Jamal Abd-Al Rahim Al-Kashif; e) Muhammad Jamal Abdu; f) Muhammad Jamal', '04', 'Muhammad Jamal', 'MUHAMMAD JAMAL', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('854', '20170807', '����췢[2017]106��', '1: MUHAMMAD 2: JIBRIL 3: ABDUL RAHMAN 4: na', null, '02', 'MUHAMMAD JIBRIL', 'MUHAMMAD JIBRIL', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('855', '20170807', '����췢[2017]106��', '1: MUHAMMAD 2: SHOLEH 3: IBRAHIM 4: na', 'a) Mohammad Sholeh Ibrahim; b) Muhammad Sholeh Ibrohim; c) Muhammad Soleh Ibrahim; d) Sholeh Ibrahim; e) Muh Sholeh Ibrahim', '02', 'MUHAMMAD SHOLEH', 'MUHAMMAD SHOLEH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('856', '20170807', '����췢[2017]106��', '1: MUHAMMAD 2: SHOLEH 3: IBRAHIM 4: na', 'a) Mohammad Sholeh Ibrahim; b) Muhammad Sholeh Ibrohim; c) Muhammad Soleh Ibrahim; d) Sholeh Ibrahim; e) Muh Sholeh Ibrahim', '04', 'Muh Sholeh Ibrahim', 'MUH SHOLEH IBRAHIM', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('857', '20170807', '����췢[2017]106��', '1: MUHAMMAD 2: SHOLEH 3: IBRAHIM 4: na', 'a) Mohammad Sholeh Ibrahim; b) Muhammad Sholeh Ibrohim; c) Muhammad Soleh Ibrahim; d) Sholeh Ibrahim; e) Muh Sholeh Ibrahim', '04', 'Muhammad Sholeh Ibrohim', 'MUHAMMAD SHOLEH IBROHIM', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('858', '20170807', '����췢[2017]106��', '1: MUHAMMAD 2: SHOLEH 3: IBRAHIM 4: na', 'a) Mohammad Sholeh Ibrahim; b) Muhammad Sholeh Ibrohim; c) Muhammad Soleh Ibrahim; d) Sholeh Ibrahim; e) Muh Sholeh Ibrahim', '04', 'Sholeh Ibrahim', 'SHOLEH IBRAHIM', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('859', '20170807', '����췢[2017]106��', '1: MUHAMMAD 2: SHOLEH 3: IBRAHIM 4: na', 'a) Mohammad Sholeh Ibrahim; b) Muhammad Sholeh Ibrohim; c) Muhammad Soleh Ibrahim; d) Sholeh Ibrahim; e) Muh Sholeh Ibrahim', '04', 'Muhammad Soleh Ibrahim', 'MUHAMMAD SOLEH IBRAHIM', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('860', '20170807', '����췢[2017]106��', '1: MUHANNAD 2: AL-NAJDI 3: na 4: na', 'a) Ali Manahi Ali al-Mahaydali al-Utaybi', '02', 'MUHANNAD AL-NAJDI', 'MUHANNAD AL-NAJDI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('861', '20170807', '����췢[2017]106��', '1: MUHANNAD 2: AL-NAJDI 3: na 4: na', 'a) Ali Manahi Ali al-Mahaydali al-Utaybi', '03', 'Ali Manahi Ali al-Mahaydali al-Utaybi', 'ALI MANAHI ALI AL-MAHAYDALI AL-UTAYBI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('862', '20170807', '����췢[2017]106��', '1: MUHSIN 2: FADHIL 3: AYED 4: ASHOUR AL-FADHLI', 'a) Muhsin Fadhil Ayyid al Fadhli; b) Muhsin Fadil Ayid Ashur al Fadhli; c) Abu Majid Samiyah; d) Abu Samia', '02', 'MUHSIN FADHIL', 'MUHSIN FADHIL', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('863', '20170807', '����췢[2017]106��', '1: MUHSIN 2: FADHIL 3: AYED 4: ASHOUR AL-FADHLI', 'a) Muhsin Fadhil Ayyid al Fadhli; b) Muhsin Fadil Ayid Ashur al Fadhli; c) Abu Majid Samiyah; d) Abu Samia', '04', 'Muhsin Fadhil Ayyid al Fadhli', 'MUHSIN FADHIL AYYID AL FADHLI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('864', '20170807', '����췢[2017]106��', '1: MUHSIN 2: FADHIL 3: AYED 4: ASHOUR AL-FADHLI', 'a) Muhsin Fadhil Ayyid al Fadhli; b) Muhsin Fadil Ayid Ashur al Fadhli; c) Abu Majid Samiyah; d) Abu Samia', '04', 'Abu Samia', 'ABU SAMIA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('865', '20170807', '����췢[2017]106��', '1: MUHSIN 2: FADHIL 3: AYED 4: ASHOUR AL-FADHLI', 'a) Muhsin Fadhil Ayyid al Fadhli; b) Muhsin Fadil Ayid Ashur al Fadhli; c) Abu Majid Samiyah; d) Abu Samia', '04', 'Abu Majid Samiyah', 'ABU MAJID SAMIYAH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('866', '20170807', '����췢[2017]106��', '1: MUHSIN 2: FADHIL 3: AYED 4: ASHOUR AL-FADHLI', 'a) Muhsin Fadhil Ayyid al Fadhli; b) Muhsin Fadil Ayid Ashur al Fadhli; c) Abu Majid Samiyah; d) Abu Samia', '04', 'Abu Samia', 'ABU SAMIA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('867', '20170807', '����췢[2017]106��', '1: MUHSIN 2: FADHIL 3: AYED 4: ASHOUR AL-FADHLI', 'a) Muhsin Fadhil Ayyid al Fadhli; b) Muhsin Fadil Ayid Ashur al Fadhli; c) Abu Majid Samiyah; d) Abu Samia', '04', 'Muhsin Fadil Ayid Ashur al Fadhli', 'MUHSIN FADIL AYID ASHUR AL FADHLI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('868', '20170807', '����췢[2017]106��', '1: MUSTAFA 2: HAJJI 3: MUHAMMAD 4: KHAN', 'a) Hassan Ghul; Hassan Gul; Hasan Gul; b) Khalid Mahmud', '02', 'MUSTAFA HAJJI', 'MUSTAFA HAJJI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('869', '20170807', '����췢[2017]106��', '1: MUSTAFA 2: HAJJI 3: MUHAMMAD 4: KHAN', 'a) Hassan Ghul; Hassan Gul; Hasan Gul; b) Khalid Mahmud', '04', 'Khalid Mahmud', 'KHALID MAHMUD', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('870', '20170807', '����췢[2017]106��', '1: MUSTAFA 2: HAJJI 3: MUHAMMAD 4: KHAN', 'a) Hassan Ghul; Hassan Gul; Hasan Gul; b) Khalid Mahmud', '04', 'Hasan Gul', 'HASAN GUL', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('871', '20170807', '����췢[2017]106��', '1: MUSTAFA 2: HAJJI 3: MUHAMMAD 4: KHAN', 'a) Hassan Ghul; Hassan Gul; Hasan Gul; b) Khalid Mahmud', '04', 'Hassan Ghul', 'HASSAN GHUL', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('872', '20170807', '����췢[2017]106��', '1: MUSTAFA 2: HAJJI 3: MUHAMMAD 4: KHAN', 'a) Hassan Ghul; Hassan Gul; Hasan Gul; b) Khalid Mahmud', '04', 'Hassan Gul', 'HASSAN GUL', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('873', '20170807', '����췢[2017]106��', '1: MUTASSIM 2: YAHYA 3: ALI 4: AL-RUMAYSH', null, '02', 'MUTASSIM YAHYA', 'MUTASSIM YAHYA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('874', '20170807', '����췢[2017]106��', '1: MUTHANNA 2: HARITH 3: AL-DARI 4: na ', 'a) Dr. Muthanna Al Dari; b) Muthana Harith Al Dari; c) Muthanna Harith Sulayman Al-Dari; d) Muthanna Harith Sulayman Al-Dhari; e) Muthanna Hareth Al-Dhari; f) Muthana Haris Al-Dhari; g) Doctor Muthanna Harith Sulayman Al Dari Al-Zawba; h) Muthanna Harith Sulayman Al-Dari Al-Zobai; i) Muthanna Harith Sulayman Al-Dari al-Zawbai; j) Muthanna Hareth al-Dari; k) Muthana Haris al-Dari; l) Doctor Muthanna al-Dari; m) Dr. Muthanna Harith al-Dari al-Zowbai', '02', 'MUTHANNA HARITH', 'MUTHANNA HARITH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('875', '20170807', '����췢[2017]106��', '1: MUTHANNA 2: HARITH 3: AL-DARI 4: na ', 'a) Dr. Muthanna Al Dari; b) Muthana Harith Al Dari; c) Muthanna Harith Sulayman Al-Dari; d) Muthanna Harith Sulayman Al-Dhari; e) Muthanna Hareth Al-Dhari; f) Muthana Haris Al-Dhari; g) Doctor Muthanna Harith Sulayman Al Dari Al-Zawba; h) Muthanna Harith Sulayman Al-Dari Al-Zobai; i) Muthanna Harith Sulayman Al-Dari al-Zawbai; j) Muthanna Hareth al-Dari; k) Muthana Haris al-Dari; l) Doctor Muthanna al-Dari; m) Dr. Muthanna Harith al-Dari al-Zowbai', '04', 'Muthanna Harith Sulayman Al-Dari al-Zawbai', 'MUTHANNA HARITH SULAYMAN AL-DARI AL-ZAWBAI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('876', '20170807', '����췢[2017]106��', '1: MUTHANNA 2: HARITH 3: AL-DARI 4: na ', 'a) Dr. Muthanna Al Dari; b) Muthana Harith Al Dari; c) Muthanna Harith Sulayman Al-Dari; d) Muthanna Harith Sulayman Al-Dhari; e) Muthanna Hareth Al-Dhari; f) Muthana Haris Al-Dhari; g) Doctor Muthanna Harith Sulayman Al Dari Al-Zawba; h) Muthanna Harith Sulayman Al-Dari Al-Zobai; i) Muthanna Harith Sulayman Al-Dari al-Zawbai; j) Muthanna Hareth al-Dari; k) Muthana Haris al-Dari; l) Doctor Muthanna al-Dari; m) Dr. Muthanna Harith al-Dari al-Zowbai', '04', 'Muthanna Harith Sulayman Al-Dari Al-Zobai', 'MUTHANNA HARITH SULAYMAN AL-DARI AL-ZOBAI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('877', '20170807', '����췢[2017]106��', '1: MUTHANNA 2: HARITH 3: AL-DARI 4: na ', 'a) Dr. Muthanna Al Dari; b) Muthana Harith Al Dari; c) Muthanna Harith Sulayman Al-Dari; d) Muthanna Harith Sulayman Al-Dhari; e) Muthanna Hareth Al-Dhari; f) Muthana Haris Al-Dhari; g) Doctor Muthanna Harith Sulayman Al Dari Al-Zawba; h) Muthanna Harith Sulayman Al-Dari Al-Zobai; i) Muthanna Harith Sulayman Al-Dari al-Zawbai; j) Muthanna Hareth al-Dari; k) Muthana Haris al-Dari; l) Doctor Muthanna al-Dari; m) Dr. Muthanna Harith al-Dari al-Zowbai', '04', 'Doctor Muthanna Harith Sulayman Al Dari Al-Zawba', 'DOCTOR MUTHANNA HARITH SULAYMAN AL DARI AL-ZAWBA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('878', '20170807', '����췢[2017]106��', '1: MUTHANNA 2: HARITH 3: AL-DARI 4: na ', 'a) Dr. Muthanna Al Dari; b) Muthana Harith Al Dari; c) Muthanna Harith Sulayman Al-Dari; d) Muthanna Harith Sulayman Al-Dhari; e) Muthanna Hareth Al-Dhari; f) Muthana Haris Al-Dhari; g) Doctor Muthanna Harith Sulayman Al Dari Al-Zawba; h) Muthanna Harith Sulayman Al-Dari Al-Zobai; i) Muthanna Harith Sulayman Al-Dari al-Zawbai; j) Muthanna Hareth al-Dari; k) Muthana Haris al-Dari; l) Doctor Muthanna al-Dari; m) Dr. Muthanna Harith al-Dari al-Zowbai', '04', 'Muthana Haris Al-Dhari', 'MUTHANA HARIS AL-DHARI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('879', '20170807', '����췢[2017]106��', '1: MUTHANNA 2: HARITH 3: AL-DARI 4: na ', 'a) Dr. Muthanna Al Dari; b) Muthana Harith Al Dari; c) Muthanna Harith Sulayman Al-Dari; d) Muthanna Harith Sulayman Al-Dhari; e) Muthanna Hareth Al-Dhari; f) Muthana Haris Al-Dhari; g) Doctor Muthanna Harith Sulayman Al Dari Al-Zawba; h) Muthanna Harith Sulayman Al-Dari Al-Zobai; i) Muthanna Harith Sulayman Al-Dari al-Zawbai; j) Muthanna Hareth al-Dari; k) Muthana Haris al-Dari; l) Doctor Muthanna al-Dari; m) Dr. Muthanna Harith al-Dari al-Zowbai', '04', 'Muthanna Harith Sulayman Al-Dhari', 'MUTHANNA HARITH SULAYMAN AL-DHARI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('880', '20170807', '����췢[2017]106��', '1: MUTHANNA 2: HARITH 3: AL-DARI 4: na ', 'a) Dr. Muthanna Al Dari; b) Muthana Harith Al Dari; c) Muthanna Harith Sulayman Al-Dari; d) Muthanna Harith Sulayman Al-Dhari; e) Muthanna Hareth Al-Dhari; f) Muthana Haris Al-Dhari; g) Doctor Muthanna Harith Sulayman Al Dari Al-Zawba; h) Muthanna Harith Sulayman Al-Dari Al-Zobai; i) Muthanna Harith Sulayman Al-Dari al-Zawbai; j) Muthanna Hareth al-Dari; k) Muthana Haris al-Dari; l) Doctor Muthanna al-Dari; m) Dr. Muthanna Harith al-Dari al-Zowbai', '04', 'Muthanna Harith Sulayman Al-Dari', 'MUTHANNA HARITH SULAYMAN AL-DARI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('881', '20170807', '����췢[2017]106��', '1: MUTHANNA 2: HARITH 3: AL-DARI 4: na ', 'a) Dr. Muthanna Al Dari; b) Muthana Harith Al Dari; c) Muthanna Harith Sulayman Al-Dari; d) Muthanna Harith Sulayman Al-Dhari; e) Muthanna Hareth Al-Dhari; f) Muthana Haris Al-Dhari; g) Doctor Muthanna Harith Sulayman Al Dari Al-Zawba; h) Muthanna Harith Sulayman Al-Dari Al-Zobai; i) Muthanna Harith Sulayman Al-Dari al-Zawbai; j) Muthanna Hareth al-Dari; k) Muthana Haris al-Dari; l) Doctor Muthanna al-Dari; m) Dr. Muthanna Harith al-Dari al-Zowbai', '04', 'Muthana Harith Al Dari', 'MUTHANA HARITH AL DARI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('882', '20170807', '����췢[2017]106��', '1: MUTHANNA 2: HARITH 3: AL-DARI 4: na ', 'a) Dr. Muthanna Al Dari; b) Muthana Harith Al Dari; c) Muthanna Harith Sulayman Al-Dari; d) Muthanna Harith Sulayman Al-Dhari; e) Muthanna Hareth Al-Dhari; f) Muthana Haris Al-Dhari; g) Doctor Muthanna Harith Sulayman Al Dari Al-Zawba; h) Muthanna Harith Sulayman Al-Dari Al-Zobai; i) Muthanna Harith Sulayman Al-Dari al-Zawbai; j) Muthanna Hareth al-Dari; k) Muthana Haris al-Dari; l) Doctor Muthanna al-Dari; m) Dr. Muthanna Harith al-Dari al-Zowbai', '04', 'Dr. Muthanna Al Dari', 'DR. MUTHANNA AL DARI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('883', '20170807', '����췢[2017]106��', '1: MUTHANNA 2: HARITH 3: AL-DARI 4: na ', 'a) Dr. Muthanna Al Dari; b) Muthana Harith Al Dari; c) Muthanna Harith Sulayman Al-Dari; d) Muthanna Harith Sulayman Al-Dhari; e) Muthanna Hareth Al-Dhari; f) Muthana Haris Al-Dhari; g) Doctor Muthanna Harith Sulayman Al Dari Al-Zawba; h) Muthanna Harith Sulayman Al-Dari Al-Zobai; i) Muthanna Harith Sulayman Al-Dari al-Zawbai; j) Muthanna Hareth al-Dari; k) Muthana Haris al-Dari; l) Doctor Muthanna al-Dari; m) Dr. Muthanna Harith al-Dari al-Zowbai', '04', 'Dr. Muthanna Harith al-Dari al-Zowbai', 'DR. MUTHANNA HARITH AL-DARI AL-ZOWBAI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('884', '20170807', '����췢[2017]106��', '1: MUTHANNA 2: HARITH 3: AL-DARI 4: na ', 'a) Dr. Muthanna Al Dari; b) Muthana Harith Al Dari; c) Muthanna Harith Sulayman Al-Dari; d) Muthanna Harith Sulayman Al-Dhari; e) Muthanna Hareth Al-Dhari; f) Muthana Haris Al-Dhari; g) Doctor Muthanna Harith Sulayman Al Dari Al-Zawba; h) Muthanna Harith Sulayman Al-Dari Al-Zobai; i) Muthanna Harith Sulayman Al-Dari al-Zawbai; j) Muthanna Hareth al-Dari; k) Muthana Haris al-Dari; l) Doctor Muthanna al-Dari; m) Dr. Muthanna Harith al-Dari al-Zowbai', '04', 'Muthanna Hareth Al-Dhari', 'MUTHANNA HARETH AL-DHARI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('885', '20170807', '����췢[2017]106��', '1: MUTHANNA 2: HARITH 3: AL-DARI 4: na ', 'a) Dr. Muthanna Al Dari; b) Muthana Harith Al Dari; c) Muthanna Harith Sulayman Al-Dari; d) Muthanna Harith Sulayman Al-Dhari; e) Muthanna Hareth Al-Dhari; f) Muthana Haris Al-Dhari; g) Doctor Muthanna Harith Sulayman Al Dari Al-Zawba; h) Muthanna Harith Sulayman Al-Dari Al-Zobai; i) Muthanna Harith Sulayman Al-Dari al-Zawbai; j) Muthanna Hareth al-Dari; k) Muthana Haris al-Dari; l) Doctor Muthanna al-Dari; m) Dr. Muthanna Harith al-Dari al-Zowbai', '04', 'Muthanna Hareth al-Dari', 'MUTHANNA HARETH AL-DARI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('886', '20170807', '����췢[2017]106��', '1: MUTHANNA 2: HARITH 3: AL-DARI 4: na ', 'a) Dr. Muthanna Al Dari; b) Muthana Harith Al Dari; c) Muthanna Harith Sulayman Al-Dari; d) Muthanna Harith Sulayman Al-Dhari; e) Muthanna Hareth Al-Dhari; f) Muthana Haris Al-Dhari; g) Doctor Muthanna Harith Sulayman Al Dari Al-Zawba; h) Muthanna Harith Sulayman Al-Dari Al-Zobai; i) Muthanna Harith Sulayman Al-Dari al-Zawbai; j) Muthanna Hareth al-Dari; k) Muthana Haris al-Dari; l) Doctor Muthanna al-Dari; m) Dr. Muthanna Harith al-Dari al-Zowbai', '04', 'Muthana Haris al-Dari', 'MUTHANA HARIS AL-DARI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('887', '20170807', '����췢[2017]106��', '1: MUTHANNA 2: HARITH 3: AL-DARI 4: na ', 'a) Dr. Muthanna Al Dari; b) Muthana Harith Al Dari; c) Muthanna Harith Sulayman Al-Dari; d) Muthanna Harith Sulayman Al-Dhari; e) Muthanna Hareth Al-Dhari; f) Muthana Haris Al-Dhari; g) Doctor Muthanna Harith Sulayman Al Dari Al-Zawba; h) Muthanna Harith Sulayman Al-Dari Al-Zobai; i) Muthanna Harith Sulayman Al-Dari al-Zawbai; j) Muthanna Hareth al-Dari; k) Muthana Haris al-Dari; l) Doctor Muthanna al-Dari; m) Dr. Muthanna Harith al-Dari al-Zowbai', '04', 'Doctor Muthanna al-Dari', 'DOCTOR MUTHANNA AL-DARI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('888', '20170807', '����췢[2017]106��', '1: NAJMUDDIN 2: FARAJ 3: AHMAD 4: na', 'a) Mullah Krekar; b) Fateh Najm Eddine Farraj; c) Faraj Ahmad Najmuddin', '02', 'NAJMUDDIN FARAJ', 'NAJMUDDIN FARAJ', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('889', '20170807', '����췢[2017]106��', '1: NAJMUDDIN 2: FARAJ 3: AHMAD 4: na', 'a) Mullah Krekar; b) Fateh Najm Eddine Farraj; c) Faraj Ahmad Najmuddin', '04', 'Fateh Najm Eddine Farraj', 'FATEH NAJM EDDINE FARRAJ', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('890', '20170807', '����췢[2017]106��', '1: NAJMUDDIN 2: FARAJ 3: AHMAD 4: na', 'a) Mullah Krekar; b) Fateh Najm Eddine Farraj; c) Faraj Ahmad Najmuddin', '04', 'Faraj Ahmad Najmuddin', 'FARAJ AHMAD NAJMUDDIN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('891', '20170807', '����췢[2017]106��', '1: NAJMUDDIN 2: FARAJ 3: AHMAD 4: na', 'a) Mullah Krekar; b) Fateh Najm Eddine Farraj; c) Faraj Ahmad Najmuddin', '04', 'Mullah Krekar', 'MULLAH KREKAR', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('892', '20170807', '����췢[2017]106��', '1: NASHWAN 2: ABD AL-RAZZAQ 3: ABD AL-BAQI 4: na', 'a) Abdal Al-Hadi Al-Iraqi; b) Abd Al-Hadi Al-Iraqi; c) Omar Uthman Mohammed; d) Abd al-Muhayman; e) Abu Ayub', '02', 'NASHWAN ABD AL-RAZZAQ', 'NASHWAN ABD AL-RAZZAQ', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('893', '20170807', '����췢[2017]106��', '1: NASHWAN 2: ABD AL-RAZZAQ 3: ABD AL-BAQI 4: na', 'a) Abdal Al-Hadi Al-Iraqi; b) Abd Al-Hadi Al-Iraqi; c) Omar Uthman Mohammed; d) Abd al-Muhayman; e) Abu Ayub', '04', 'Abdal Al-Hadi Al-Iraqi', 'ABDAL AL-HADI AL-IRAQI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('894', '20170807', '����췢[2017]106��', '1: NASHWAN 2: ABD AL-RAZZAQ 3: ABD AL-BAQI 4: na', 'a) Abdal Al-Hadi Al-Iraqi; b) Abd Al-Hadi Al-Iraqi; c) Omar Uthman Mohammed; d) Abd al-Muhayman; e) Abu Ayub', '04', 'Abd al-Muhayman', 'ABD AL-MUHAYMAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('895', '20170807', '����췢[2017]106��', '1: NASHWAN 2: ABD AL-RAZZAQ 3: ABD AL-BAQI 4: na', 'a) Abdal Al-Hadi Al-Iraqi; b) Abd Al-Hadi Al-Iraqi; c) Omar Uthman Mohammed; d) Abd al-Muhayman; e) Abu Ayub', '04', 'Omar Uthman Mohammed', 'OMAR UTHMAN MOHAMMED', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('896', '20170807', '����췢[2017]106��', '1: NASHWAN 2: ABD AL-RAZZAQ 3: ABD AL-BAQI 4: na', 'a) Abdal Al-Hadi Al-Iraqi; b) Abd Al-Hadi Al-Iraqi; c) Omar Uthman Mohammed; d) Abd al-Muhayman; e) Abu Ayub', '04', 'Abd Al-Hadi Al-Iraqi', 'ABD AL-HADI AL-IRAQI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('897', '20170807', '����췢[2017]106��', '1: NASHWAN 2: ABD AL-RAZZAQ 3: ABD AL-BAQI 4: na', 'a) Abdal Al-Hadi Al-Iraqi; b) Abd Al-Hadi Al-Iraqi; c) Omar Uthman Mohammed; d) Abd al-Muhayman; e) Abu Ayub', '04', 'Abu Ayub', 'ABU AYUB', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('898', '20170807', '����췢[2017]106��', '1: NASSER 2: AHMED 3: MUTHANA 4: na', 'a) Nasir Muthana', '02', 'NASSER AHMED', 'NASSER AHMED', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('899', '20170807', '����췢[2017]106��', '1: NASSER 2: AHMED 3: MUTHANA 4: na', 'a) Nasir Muthana', '03', 'Nasir Muthana', 'NASIR MUTHANA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('900', '20170807', '����췢[2017]106��', '1: NAYEF 2: SALAM 3: MUHAMMAD 4: UJAYM AL-HABABI', 'a) Nayf Salam Muhammad Ujaym al-Hababi', '02', 'NAYEF SALAM', 'NAYEF SALAM', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('901', '20170807', '����췢[2017]106��', '1: NAYEF 2: SALAM 3: MUHAMMAD 4: UJAYM AL-HABABI', 'a) Nayf Salam Muhammad Ujaym al-Hababi', '03', 'Nayf Salam Muhammad Ujaym al-Hababi', 'NAYF SALAM MUHAMMAD UJAYM AL-HABABI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('902', '20170807', '����췢[2017]106��', '1: NAYIF 2: SALIH 3: SALIM 4: AL-QAYSI', 'a) Naif Saleh Salem al Qaisi', '02', 'NAYIF SALIH', 'NAYIF SALIH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('903', '20170807', '����췢[2017]106��', '1: NAYIF 2: SALIH 3: SALIM 4: AL-QAYSI', 'a) Naif Saleh Salem al Qaisi', '04', 'Naif Saleh Salem al Qaisi', 'NAIF SALEH SALEM AL QAISI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('904', '20170807', '����췢[2017]106��', '1: NESSIM 2: BEN MOHAMED 3: AL-CHERIF BEN MOHAMED 4: SALEH AL-SAADI', 'a) Nassim Saadi; b) Dia el Haak George born 20 Nov. 1974 in Lebanon; c) Diael Haak George born 30 Nov. 1974 in Lebanon; d) El Dia Haak George born 30 Nov. 1974 in Algeria', '02', 'NESSIM BEN MOHAMED', 'NESSIM BEN MOHAMED', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('905', '20170807', '����췢[2017]106��', '1: NESSIM 2: BEN MOHAMED 3: AL-CHERIF BEN MOHAMED 4: SALEH AL-SAADI', 'a) Nassim Saadi; b) Dia el Haak George born 20 Nov. 1974 in Lebanon; c) Diael Haak George born 30 Nov. 1974 in Lebanon; d) El Dia Haak George born 30 Nov. 1974 in Algeria', '04', 'Dia el Haak George', 'DIA EL HAAK GEORGE', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('906', '20170807', '����췢[2017]106��', '1: NESSIM 2: BEN MOHAMED 3: AL-CHERIF BEN MOHAMED 4: SALEH AL-SAADI', 'a) Nassim Saadi; b) Dia el Haak George born 20 Nov. 1974 in Lebanon; c) Diael Haak George born 30 Nov. 1974 in Lebanon; d) El Dia Haak George born 30 Nov. 1974 in Algeria', '04', 'Diael Haak George', 'DIAEL HAAK GEORGE', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('907', '20170807', '����췢[2017]106��', '1: NESSIM 2: BEN MOHAMED 3: AL-CHERIF BEN MOHAMED 4: SALEH AL-SAADI', 'a) Nassim Saadi; b) Dia el Haak George born 20 Nov. 1974 in Lebanon; c) Diael Haak George born 30 Nov. 1974 in Lebanon; d) El Dia Haak George born 30 Nov. 1974 in Algeria', '04', 'Nassim Saadi', 'NASSIM SAADI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('908', '20170807', '����췢[2017]106��', '1: NESSIM 2: BEN MOHAMED 3: AL-CHERIF BEN MOHAMED 4: SALEH AL-SAADI', 'a) Nassim Saadi; b) Dia el Haak George born 20 Nov. 1974 in Lebanon; c) Diael Haak George born 30 Nov. 1974 in Lebanon; d) El Dia Haak George born 30 Nov. 1974 in Algeria', '04', 'El Dia Haak George', 'EL DIA HAAK GEORGE', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('909', '20170807', '����췢[2017]106��', '1: NESSIM 2: BEN ROMDHANE 3: SAHRAOUL 4: na', 'a) Dass; b) Nasim al-Sahrawi', '02', 'NESSIM BEN ROMDHANE', 'NESSIM BEN ROMDHANE', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('910', '20170807', '����췢[2017]106��', '1: NESSIM 2: BEN ROMDHANE 3: SAHRAOUL 4: na', 'a) Dass; b) Nasim al-Sahrawi', '04', 'Dass', 'DASS', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('911', '20170807', '����췢[2017]106��', '1: NESSIM 2: BEN ROMDHANE 3: SAHRAOUL 4: na', 'a) Dass; b) Nasim al-Sahrawi', '04', 'Nasim al-Sahrawi', 'NASIM AL-SAHRAWI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('912', '20170807', '����췢[2017]106��', '1: NOUREDDINE 2: BEN ALI 3: BEN BELKASSEM 4: AL-DRISSI', 'a) Drissi Noureddine', '02', 'NOUREDDINE BEN ALI', 'NOUREDDINE BEN ALI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('913', '20170807', '����췢[2017]106��', '1: NOUREDDINE 2: BEN ALI 3: BEN BELKASSEM 4: AL-DRISSI', 'a) Drissi Noureddine', '03', 'Drissi Noureddine', 'DRISSI NOUREDDINE', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('914', '20170807', '����췢[2017]106��', '1: NURJAMAN 2: RIDUAN 3: ISAMUDDIN 4: na', 'a) Hamball; b) Nurjaman; c) Isomuddin, Nurjaman Riduan; d) Hambali Bin Ending; e) Encep Nurjaman; f) Hambali Ending Hambali; g) Isamuddin Riduan; h) Isamudin Ridwan', '02', 'NURJAMAN RIDUAN', 'NURJAMAN RIDUAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('915', '20170807', '����췢[2017]106��', '1: NURJAMAN 2: RIDUAN 3: ISAMUDDIN 4: na', 'a) Hamball; b) Nurjaman; c) Isomuddin, Nurjaman Riduan; d) Hambali Bin Ending; e) Encep Nurjaman; f) Hambali Ending Hambali; g) Isamuddin Riduan; h) Isamudin Ridwan', '04', 'Isamuddin Riduan', 'ISAMUDDIN RIDUAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('916', '20170807', '����췢[2017]106��', '1: NURJAMAN 2: RIDUAN 3: ISAMUDDIN 4: na', 'a) Hamball; b) Nurjaman; c) Isomuddin, Nurjaman Riduan; d) Hambali Bin Ending; e) Encep Nurjaman; f) Hambali Ending Hambali; g) Isamuddin Riduan; h) Isamudin Ridwan', '04', 'Hamball', 'HAMBALL', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('917', '20170807', '����췢[2017]106��', '1: NURJAMAN 2: RIDUAN 3: ISAMUDDIN 4: na', 'a) Hamball; b) Nurjaman; c) Isomuddin, Nurjaman Riduan; d) Hambali Bin Ending; e) Encep Nurjaman; f) Hambali Ending Hambali; g) Isamuddin Riduan; h) Isamudin Ridwan', '04', 'Hambali Ending Hambali', 'HAMBALI ENDING HAMBALI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('918', '20170807', '����췢[2017]106��', '1: NURJAMAN 2: RIDUAN 3: ISAMUDDIN 4: na', 'a) Hamball; b) Nurjaman; c) Isomuddin, Nurjaman Riduan; d) Hambali Bin Ending; e) Encep Nurjaman; f) Hambali Ending Hambali; g) Isamuddin Riduan; h) Isamudin Ridwan', '04', 'Isomuddin, Nurjaman Riduan', 'ISOMUDDIN, NURJAMAN RIDUAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('919', '20170807', '����췢[2017]106��', '1: NURJAMAN 2: RIDUAN 3: ISAMUDDIN 4: na', 'a) Hamball; b) Nurjaman; c) Isomuddin, Nurjaman Riduan; d) Hambali Bin Ending; e) Encep Nurjaman; f) Hambali Ending Hambali; g) Isamuddin Riduan; h) Isamudin Ridwan', '04', 'Encep Nurjaman', 'ENCEP NURJAMAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('920', '20170807', '����췢[2017]106��', '1: NURJAMAN 2: RIDUAN 3: ISAMUDDIN 4: na', 'a) Hamball; b) Nurjaman; c) Isomuddin, Nurjaman Riduan; d) Hambali Bin Ending; e) Encep Nurjaman; f) Hambali Ending Hambali; g) Isamuddin Riduan; h) Isamudin Ridwan', '04', 'Hambali Bin Ending', 'HAMBALI BIN ENDING', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('921', '20170807', '����췢[2017]106��', '1: NURJAMAN 2: RIDUAN 3: ISAMUDDIN 4: na', 'a) Hamball; b) Nurjaman; c) Isomuddin, Nurjaman Riduan; d) Hambali Bin Ending; e) Encep Nurjaman; f) Hambali Ending Hambali; g) Isamuddin Riduan; h) Isamudin Ridwan', '04', 'Nurjaman', 'NURJAMAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('922', '20170807', '����췢[2017]106��', '1: NURJAMAN 2: RIDUAN 3: ISAMUDDIN 4: na', 'a) Hamball; b) Nurjaman; c) Isomuddin, Nurjaman Riduan; d) Hambali Bin Ending; e) Encep Nurjaman; f) Hambali Ending Hambali; g) Isamuddin Riduan; h) Isamudin Ridwan', '04', 'Isamudin Ridwan', 'ISAMUDIN RIDWAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('923', '20170807', '����췢[2017]106��', '1: NUSRET 2: IMAMOVIC 3: na 4: na', 'a) Nusret Sulejman Imamovic', '02', 'NUSRET IMAMOVIC', 'NUSRET IMAMOVIC', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('924', '20170807', '����췢[2017]106��', '1: NUSRET 2: IMAMOVIC 3: na 4: na', 'a) Nusret Sulejman Imamovic', '03', 'Nusret Sulejman Imamovic', 'NUSRET SULEJMAN IMAMOVIC', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('925', '20170807', '����췢[2017]106��', '1: OMAR 2: ALI 3: HUSSAIN 4: na', null, '02', 'OMAR ALI 3: HUSSAIN', 'OMAR ALI 3: HUSSAIN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('926', '20170807', '����췢[2017]106��', '1: OMAR 2: MAHMOUD 3: UTHMAN 4: na', 'a) Al-Samman Uthman; b) Umar Uthman; c) Omar Mohammed Othman', '02', 'OMAR MAHMOUD', 'OMAR MAHMOUD', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('927', '20170807', '����췢[2017]106��', '1: OMAR 2: MAHMOUD 3: UTHMAN 4: na', 'a) Al-Samman Uthman; b) Umar Uthman; c) Omar Mohammed Othman', '04', 'Omar Mohammed Othman', 'OMAR MOHAMMED OTHMAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('928', '20170807', '����췢[2017]106��', '1: OMAR 2: MAHMOUD 3: UTHMAN 4: na', 'a) Al-Samman Uthman; b) Umar Uthman; c) Omar Mohammed Othman', '04', 'Umar Uthman', 'UMAR UTHMAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('929', '20170807', '����췢[2017]106��', '1: OMAR 2: MAHMOUD 3: UTHMAN 4: na', 'a) Al-Samman Uthman; b) Umar Uthman; c) Omar Mohammed Othman', '04', 'Al-Samman Uthman', 'AL-SAMMAN UTHMAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('930', '20170807', '����췢[2017]106��', '1: OTHMAN 2: AHMED 3: OTHMAN 4: AL-GHAMDI', 'a) Othman al-Ghamdi born 27 May 1979 in Saudi Arabla; b) Uthman al-Ghamdi born 27 May 1979 in Saudi Arabia; c) Uthman al-Ghamidi born 27 May 1979 in Saudi Arabia; d) Othman bin Ahmed bin Othman Alghamdi; e) Othman Ahmed Othman Al Omairah (born in 1973 in Shabwa, Yemen, nationality: Yemeni); f) Uthman Ahmad Uthman al-Ghamdi; g) Othman Ahmed Othman al-Omirah', '02', 'OTHMAN AHMED', 'OTHMAN AHMED', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('931', '20170807', '����췢[2017]106��', '1: OTHMAN 2: AHMED 3: OTHMAN 4: AL-GHAMDI', 'a) Othman al-Ghamdi born 27 May 1979 in Saudi Arabla; b) Uthman al-Ghamdi born 27 May 1979 in Saudi Arabia; c) Uthman al-Ghamidi born 27 May 1979 in Saudi Arabia; d) Othman bin Ahmed bin Othman Alghamdi; e) Othman Ahmed Othman Al Omairah (born in 1973 in Shabwa, Yemen, nationality: Yemeni); f) Uthman Ahmad Uthman al-Ghamdi; g) Othman Ahmed Othman al-Omirah', '04', 'Othman Ahmed Othman al-Omirah', 'OTHMAN AHMED OTHMAN AL-OMIRAH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('932', '20170807', '����췢[2017]106��', '1: OTHMAN 2: AHMED 3: OTHMAN 4: AL-GHAMDI', 'a) Othman al-Ghamdi born 27 May 1979 in Saudi Arabla; b) Uthman al-Ghamdi born 27 May 1979 in Saudi Arabia; c) Uthman al-Ghamidi born 27 May 1979 in Saudi Arabia; d) Othman bin Ahmed bin Othman Alghamdi; e) Othman Ahmed Othman Al Omairah (born in 1973 in Shabwa, Yemen, nationality: Yemeni); f) Uthman Ahmad Uthman al-Ghamdi; g) Othman Ahmed Othman al-Omirah', '04', 'Uthman Ahmad Uthman al-Ghamdi', 'UTHMAN AHMAD UTHMAN AL-GHAMDI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('933', '20170807', '����췢[2017]106��', '1: OTHMAN 2: AHMED 3: OTHMAN 4: AL-GHAMDI', 'a) Othman al-Ghamdi born 27 May 1979 in Saudi Arabla; b) Uthman al-Ghamdi born 27 May 1979 in Saudi Arabia; c) Uthman al-Ghamidi born 27 May 1979 in Saudi Arabia; d) Othman bin Ahmed bin Othman Alghamdi; e) Othman Ahmed Othman Al Omairah (born in 1973 in Shabwa, Yemen, nationality: Yemeni); f) Uthman Ahmad Uthman al-Ghamdi; g) Othman Ahmed Othman al-Omirah', '04', 'Othman Ahmed Othman Al Omairah', 'OTHMAN AHMED OTHMAN AL OMAIRAH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('934', '20170807', '����췢[2017]106��', '1: OTHMAN 2: AHMED 3: OTHMAN 4: AL-GHAMDI', 'a) Othman al-Ghamdi born 27 May 1979 in Saudi Arabla; b) Uthman al-Ghamdi born 27 May 1979 in Saudi Arabia; c) Uthman al-Ghamidi born 27 May 1979 in Saudi Arabia; d) Othman bin Ahmed bin Othman Alghamdi; e) Othman Ahmed Othman Al Omairah (born in 1973 in Shabwa, Yemen, nationality: Yemeni); f) Uthman Ahmad Uthman al-Ghamdi; g) Othman Ahmed Othman al-Omirah', '04', 'Othman bin Ahmed bin Othman Alghamdi', 'OTHMAN BIN AHMED BIN OTHMAN ALGHAMDI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('935', '20170807', '����췢[2017]106��', '1: OTHMAN 2: AHMED 3: OTHMAN 4: AL-GHAMDI', 'a) Othman al-Ghamdi born 27 May 1979 in Saudi Arabla; b) Uthman al-Ghamdi born 27 May 1979 in Saudi Arabia; c) Uthman al-Ghamidi born 27 May 1979 in Saudi Arabia; d) Othman bin Ahmed bin Othman Alghamdi; e) Othman Ahmed Othman Al Omairah (born in 1973 in Shabwa, Yemen, nationality: Yemeni); f) Uthman Ahmad Uthman al-Ghamdi; g) Othman Ahmed Othman al-Omirah', '04', 'Uthman al-Ghamidi', 'UTHMAN AL-GHAMIDI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('936', '20170807', '����췢[2017]106��', '1: OTHMAN 2: AHMED 3: OTHMAN 4: AL-GHAMDI', 'a) Othman al-Ghamdi born 27 May 1979 in Saudi Arabla; b) Uthman al-Ghamdi born 27 May 1979 in Saudi Arabia; c) Uthman al-Ghamidi born 27 May 1979 in Saudi Arabia; d) Othman bin Ahmed bin Othman Alghamdi; e) Othman Ahmed Othman Al Omairah (born in 1973 in Shabwa, Yemen, nationality: Yemeni); f) Uthman Ahmad Uthman al-Ghamdi; g) Othman Ahmed Othman al-Omirah', '04', 'Othman al-Ghamdi', 'OTHMAN AL-GHAMDI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('937', '20170807', '����췢[2017]106��', '1: OTHMAN 2: AHMED 3: OTHMAN 4: AL-GHAMDI', 'a) Othman al-Ghamdi born 27 May 1979 in Saudi Arabla; b) Uthman al-Ghamdi born 27 May 1979 in Saudi Arabia; c) Uthman al-Ghamidi born 27 May 1979 in Saudi Arabia; d) Othman bin Ahmed bin Othman Alghamdi; e) Othman Ahmed Othman Al Omairah (born in 1973 in Shabwa, Yemen, nationality: Yemeni); f) Uthman Ahmad Uthman al-Ghamdi; g) Othman Ahmed Othman al-Omirah', '04', 'Uthman al-Ghamdi', 'UTHMAN AL-GHAMDI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('938', '20170807', '����췢[2017]106��', '1: OTHMAN 2: DERAMCHI 3: na 4: na', null, '02', 'OTHMAN DERAMCHI', 'OTHMAN DERAMCHI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('939', '20170807', '����췢[2017]106��', '1: OUMAR 2: DIABY 3: na 4: na', null, '02', 'OUMAR DIABY', 'OUMAR DIABY', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('940', '20170807', '����췢[2017]106��', '1: PARLINDUNGAN 2: SIREGAR 3: na 4: na', 'a) Siregar, Parlin; b) Siregar, Saleh Parlindungan', '02', 'PARLINDUNGAN SIREGAR', 'PARLINDUNGAN SIREGAR', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('941', '20170807', '����췢[2017]106��', '1: PARLINDUNGAN 2: SIREGAR 3: na 4: na', 'a) Siregar, Parlin; b) Siregar, Saleh Parlindungan', '04', 'Siregar, Parlin', 'SIREGAR, PARLIN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('942', '20170807', '����췢[2017]106��', '1: PARLINDUNGAN 2: SIREGAR 3: na 4: na', 'a) Siregar, Parlin; b) Siregar, Saleh Parlindungan', '04', 'Siregar, Saleh Parlindungan', 'SIREGAR, SALEH PARLINDUNGAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('943', '20170807', '����췢[2017]106��', '1: PETER 2: CHERIF 3: na 4: na ', null, '02', 'PETER CHERIF', 'PETER CHERIF', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('944', '20170807', '����췢[2017]106��', '1: PIO 2: ABOGNE 3: DE VERA 4: na', 'a) Ismael De Vera', '02', 'PIO ABOGNE', 'PIO ABOGNE', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('945', '20170807', '����췢[2017]106��', '1: PIO 2: ABOGNE 3: DE VERA 4: na', 'a) Ismael De Vera', '03', 'Ismael De Vera', 'ISMAEL DE VERA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('946', '20170807', '����췢[2017]106��', '1: QASIM 2: MOHAMED 3: MAHDI 4: AL-RIMI', 'a) Qasim Al-Rimi; b) Qasim al-Raymi; c) Qassim al-Raymi d) Qasim al-Rami; e) Qasim Mohammed Mahdi Al Remi; f) Qassim Mohammad Mahdi Al Rimi', '02', 'QASIM MOHAMED', 'QASIM MOHAMED', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('947', '20170807', '����췢[2017]106��', '1: QASIM 2: MOHAMED 3: MAHDI 4: AL-RIMI', 'a) Qasim Al-Rimi; b) Qasim al-Raymi; c) Qassim al-Raymi d) Qasim al-Rami; e) Qasim Mohammed Mahdi Al Remi; f) Qassim Mohammad Mahdi Al Rimi', '04', 'Qasim al-Raymi', 'QASIM AL-RAYMI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('948', '20170807', '����췢[2017]106��', '1: QASIM 2: MOHAMED 3: MAHDI 4: AL-RIMI', 'a) Qasim Al-Rimi; b) Qasim al-Raymi; c) Qassim al-Raymi d) Qasim al-Rami; e) Qasim Mohammed Mahdi Al Remi; f) Qassim Mohammad Mahdi Al Rimi', '04', 'Qassim al-Raymi', 'QASSIM AL-RAYMI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('949', '20170807', '����췢[2017]106��', '1: QASIM 2: MOHAMED 3: MAHDI 4: AL-RIMI', 'a) Qasim Al-Rimi; b) Qasim al-Raymi; c) Qassim al-Raymi d) Qasim al-Rami; e) Qasim Mohammed Mahdi Al Remi; f) Qassim Mohammad Mahdi Al Rimi', '04', 'Qasim Mohammed Mahdi Al Remi', 'QASIM MOHAMMED MAHDI AL REMI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('950', '20170807', '����췢[2017]106��', '1: QASIM 2: MOHAMED 3: MAHDI 4: AL-RIMI', 'a) Qasim Al-Rimi; b) Qasim al-Raymi; c) Qassim al-Raymi d) Qasim al-Rami; e) Qasim Mohammed Mahdi Al Remi; f) Qassim Mohammad Mahdi Al Rimi', '04', 'Qassim Mohammad Mahdi Al Rimi', 'QASSIM MOHAMMAD MAHDI AL RIMI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('951', '20170807', '����췢[2017]106��', '1: QASIM 2: MOHAMED 3: MAHDI 4: AL-RIMI', 'a) Qasim Al-Rimi; b) Qasim al-Raymi; c) Qassim al-Raymi d) Qasim al-Rami; e) Qasim Mohammed Mahdi Al Remi; f) Qassim Mohammad Mahdi Al Rimi', '04', 'Qasim Al-Rimi', 'QASIM AL-RIMI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('952', '20170807', '����췢[2017]106��', '1: QASIM 2: MOHAMED 3: MAHDI 4: AL-RIMI', 'a) Qasim Al-Rimi; b) Qasim al-Raymi; c) Qassim al-Raymi d) Qasim al-Rami; e) Qasim Mohammed Mahdi Al Remi; f) Qassim Mohammad Mahdi Al Rimi', '04', 'Qasim al-Rami', 'QASIM AL-RAMI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('953', '20170807', '����췢[2017]106��', '1: RADI 2: ABD EL SAMIE 3: ABOU EL YAZID 4: EL AYASHI', null, '02', 'RADI ABD EL SAMIE', 'RADI ABD EL SAMIE', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('954', '20170807', '����췢[2017]106��', '1: RADULAN 2: SAHIRON 3: na 4: na', 'a) Radullan Sahiron; b) Radulan Sahirun; c) Radulan Sejirun; d) Commander Putol', '02', 'RADULAN SAHIRON', 'RADULAN SAHIRON', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('955', '20170807', '����췢[2017]106��', '1: RADULAN 2: SAHIRON 3: na 4: na', 'a) Radullan Sahiron; b) Radulan Sahirun; c) Radulan Sejirun; d) Commander Putol', '04', 'Radulan Sejirun', 'RADULAN SEJIRUN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('956', '20170807', '����췢[2017]106��', '1: RADULAN 2: SAHIRON 3: na 4: na', 'a) Radullan Sahiron; b) Radulan Sahirun; c) Radulan Sejirun; d) Commander Putol', '04', 'Radullan Sahiron', 'RADULLAN SAHIRON', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('957', '20170807', '����췢[2017]106��', '1: RADULAN 2: SAHIRON 3: na 4: na', 'a) Radullan Sahiron; b) Radulan Sahirun; c) Radulan Sejirun; d) Commander Putol', '04', 'Commander Putol', 'COMMANDER PUTOL', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('958', '20170807', '����췢[2017]106��', '1: RADULAN 2: SAHIRON 3: na 4: na', 'a) Radullan Sahiron; b) Radulan Sahirun; c) Radulan Sejirun; d) Commander Putol', '04', 'Radulan Sahirun', 'RADULAN SAHIRUN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('959', '20170807', '����췢[2017]106��', '1: RAED 2: MUHAMMAD HASAN 3: MUHAMMAD 4: HIJAZI', 'a) Raed M. Hijazi; b) Riad Muhammad Hasan Muhammad Hijazi', '02', 'RAED MUHAMMAD HASAN', 'RAED MUHAMMAD HASAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('960', '20170807', '����췢[2017]106��', '1: RAED 2: MUHAMMAD HASAN 3: MUHAMMAD 4: HIJAZI', 'a) Raed M. Hijazi; b) Riad Muhammad Hasan Muhammad Hijazi', '04', 'Raed M. Hijazi', 'RAED M. HIJAZI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('961', '20170807', '����췢[2017]106��', '1: RAED 2: MUHAMMAD HASAN 3: MUHAMMAD 4: HIJAZI', 'a) Raed M. Hijazi; b) Riad Muhammad Hasan Muhammad Hijazi', '04', 'Riad Muhammad Hasan Muhammad Hijazi', 'RIAD MUHAMMAD HASAN MUHAMMAD HIJAZI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('962', '20170807', '����췢[2017]106��', '1: RAMZI 2: MOHAMED 3: ABDULLAH 4: BINALSHIBH', 'a) Binalsheidah Ramzi Mohamed Abdullah; b) Bin Al Shibh; c) Omar Ramzi Mohamed Abdellah; d) Mohamed Ali Abdullah Bawazir; e) Blnalshibn Ramzi Mohammed Abdullah; f) Ramzi Binalshib; g) Ramzi Mohamed Abdellah Omar Hassan Alassiri; h) Binalshibh Ramsi Mohamed Abdullah; i) Abu Ubaydah; j) Umar Muhammad Abdallah Ba Amar', '02', 'RAMZI MOHAMED 3: ABDULLAH', 'RAMZI MOHAMED 3: ABDULLAH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('963', '20170807', '����췢[2017]106��', '1: RAMZI 2: MOHAMED 3: ABDULLAH 4: BINALSHIBH', 'a) Binalsheidah Ramzi Mohamed Abdullah; b) Bin Al Shibh; c) Omar Ramzi Mohamed Abdellah; d) Mohamed Ali Abdullah Bawazir; e) Blnalshibn Ramzi Mohammed Abdullah; f) Ramzi Binalshib; g) Ramzi Mohamed Abdellah Omar Hassan Alassiri; h) Binalshibh Ramsi Mohamed Abdullah; i) Abu Ubaydah; j) Umar Muhammad Abdallah Ba Amar', '04', 'Ramzi Mohamed Abdellah Omar Hassan Alassiri', 'RAMZI MOHAMED ABDELLAH OMAR HASSAN ALASSIRI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('964', '20170807', '����췢[2017]106��', '1: RAMZI 2: MOHAMED 3: ABDULLAH 4: BINALSHIBH', 'a) Binalsheidah Ramzi Mohamed Abdullah; b) Bin Al Shibh; c) Omar Ramzi Mohamed Abdellah; d) Mohamed Ali Abdullah Bawazir; e) Blnalshibn Ramzi Mohammed Abdullah; f) Ramzi Binalshib; g) Ramzi Mohamed Abdellah Omar Hassan Alassiri; h) Binalshibh Ramsi Mohamed Abdullah; i) Abu Ubaydah; j) Umar Muhammad Abdallah Ba Amar', '04', 'Binalshibh Ramsi Mohamed Abdullah', 'BINALSHIBH RAMSI MOHAMED ABDULLAH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('965', '20170807', '����췢[2017]106��', '1: RAMZI 2: MOHAMED 3: ABDULLAH 4: BINALSHIBH', 'a) Binalsheidah Ramzi Mohamed Abdullah; b) Bin Al Shibh; c) Omar Ramzi Mohamed Abdellah; d) Mohamed Ali Abdullah Bawazir; e) Blnalshibn Ramzi Mohammed Abdullah; f) Ramzi Binalshib; g) Ramzi Mohamed Abdellah Omar Hassan Alassiri; h) Binalshibh Ramsi Mohamed Abdullah; i) Abu Ubaydah; j) Umar Muhammad Abdallah Ba Amar', '04', 'Abu Ubaydah', 'ABU UBAYDAH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('966', '20170807', '����췢[2017]106��', '1: RAMZI 2: MOHAMED 3: ABDULLAH 4: BINALSHIBH', 'a) Binalsheidah Ramzi Mohamed Abdullah; b) Bin Al Shibh; c) Omar Ramzi Mohamed Abdellah; d) Mohamed Ali Abdullah Bawazir; e) Blnalshibn Ramzi Mohammed Abdullah; f) Ramzi Binalshib; g) Ramzi Mohamed Abdellah Omar Hassan Alassiri; h) Binalshibh Ramsi Mohamed Abdullah; i) Abu Ubaydah; j) Umar Muhammad Abdallah Ba Amar', '04', 'Ramzi Binalshib', 'RAMZI BINALSHIB', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('967', '20170807', '����췢[2017]106��', '1: RAMZI 2: MOHAMED 3: ABDULLAH 4: BINALSHIBH', 'a) Binalsheidah Ramzi Mohamed Abdullah; b) Bin Al Shibh; c) Omar Ramzi Mohamed Abdellah; d) Mohamed Ali Abdullah Bawazir; e) Blnalshibn Ramzi Mohammed Abdullah; f) Ramzi Binalshib; g) Ramzi Mohamed Abdellah Omar Hassan Alassiri; h) Binalshibh Ramsi Mohamed Abdullah; i) Abu Ubaydah; j) Umar Muhammad Abdallah Ba Amar', '04', 'Omar Ramzi Mohamed Abdellah', 'OMAR RAMZI MOHAMED ABDELLAH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('968', '20170807', '����췢[2017]106��', '1: RAMZI 2: MOHAMED 3: ABDULLAH 4: BINALSHIBH', 'a) Binalsheidah Ramzi Mohamed Abdullah; b) Bin Al Shibh; c) Omar Ramzi Mohamed Abdellah; d) Mohamed Ali Abdullah Bawazir; e) Blnalshibn Ramzi Mohammed Abdullah; f) Ramzi Binalshib; g) Ramzi Mohamed Abdellah Omar Hassan Alassiri; h) Binalshibh Ramsi Mohamed Abdullah; i) Abu Ubaydah; j) Umar Muhammad Abdallah Ba Amar', '04', 'Mohamed Ali Abdullah Bawazir', 'MOHAMED ALI ABDULLAH BAWAZIR', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('969', '20170807', '����췢[2017]106��', '1: RAMZI 2: MOHAMED 3: ABDULLAH 4: BINALSHIBH', 'a) Binalsheidah Ramzi Mohamed Abdullah; b) Bin Al Shibh; c) Omar Ramzi Mohamed Abdellah; d) Mohamed Ali Abdullah Bawazir; e) Blnalshibn Ramzi Mohammed Abdullah; f) Ramzi Binalshib; g) Ramzi Mohamed Abdellah Omar Hassan Alassiri; h) Binalshibh Ramsi Mohamed Abdullah; i) Abu Ubaydah; j) Umar Muhammad Abdallah Ba Amar', '04', 'Blnalshibn Ramzi Mohammed Abdullah', 'BLNALSHIBN RAMZI MOHAMMED ABDULLAH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('970', '20170807', '����췢[2017]106��', '1: RAMZI 2: MOHAMED 3: ABDULLAH 4: BINALSHIBH', 'a) Binalsheidah Ramzi Mohamed Abdullah; b) Bin Al Shibh; c) Omar Ramzi Mohamed Abdellah; d) Mohamed Ali Abdullah Bawazir; e) Blnalshibn Ramzi Mohammed Abdullah; f) Ramzi Binalshib; g) Ramzi Mohamed Abdellah Omar Hassan Alassiri; h) Binalshibh Ramsi Mohamed Abdullah; i) Abu Ubaydah; j) Umar Muhammad Abdallah Ba Amar', '04', 'Umar Muhammad Abdallah Ba Amar', 'UMAR MUHAMMAD ABDALLAH BA AMAR', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('971', '20170807', '����췢[2017]106��', '1: RAMZI 2: MOHAMED 3: ABDULLAH 4: BINALSHIBH', 'a) Binalsheidah Ramzi Mohamed Abdullah; b) Bin Al Shibh; c) Omar Ramzi Mohamed Abdellah; d) Mohamed Ali Abdullah Bawazir; e) Blnalshibn Ramzi Mohammed Abdullah; f) Ramzi Binalshib; g) Ramzi Mohamed Abdellah Omar Hassan Alassiri; h) Binalshibh Ramsi Mohamed Abdullah; i) Abu Ubaydah; j) Umar Muhammad Abdallah Ba Amar', '04', 'Binalsheidah Ramzi Mohamed Abdullah', 'BINALSHEIDAH RAMZI MOHAMED ABDULLAH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('972', '20170807', '����췢[2017]106��', '1: RAMZI 2: MOHAMED 3: ABDULLAH 4: BINALSHIBH', 'a) Binalsheidah Ramzi Mohamed Abdullah; b) Bin Al Shibh; c) Omar Ramzi Mohamed Abdellah; d) Mohamed Ali Abdullah Bawazir; e) Blnalshibn Ramzi Mohammed Abdullah; f) Ramzi Binalshib; g) Ramzi Mohamed Abdellah Omar Hassan Alassiri; h) Binalshibh Ramsi Mohamed Abdullah; i) Abu Ubaydah; j) Umar Muhammad Abdallah Ba Amar', '04', 'Bin Al Shibh', 'BIN AL SHIBH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('973', '20170807', '����췢[2017]106��', '1: REDENDO 2: CAIN 3: DELLOSA 4: na', 'a) Abu Ilonggo; b) Brandon Berusa; c) Abu Muadz; d) Arnulfo Alvarado; e) Habil Ahmad Dellosa', '02', 'REDENDO CAIN', 'REDENDO CAIN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('974', '20170807', '����췢[2017]106��', '1: REDENDO 2: CAIN 3: DELLOSA 4: na', 'a) Abu Ilonggo; b) Brandon Berusa; c) Abu Muadz; d) Arnulfo Alvarado; e) Habil Ahmad Dellosa', '04', 'Abu Muadz', 'ABU MUADZ', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('975', '20170807', '����췢[2017]106��', '1: REDENDO 2: CAIN 3: DELLOSA 4: na', 'a) Abu Ilonggo; b) Brandon Berusa; c) Abu Muadz; d) Arnulfo Alvarado; e) Habil Ahmad Dellosa', '04', 'Arnulfo Alvarado', 'ARNULFO ALVARADO', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('976', '20170807', '����췢[2017]106��', '1: REDENDO 2: CAIN 3: DELLOSA 4: na', 'a) Abu Ilonggo; b) Brandon Berusa; c) Abu Muadz; d) Arnulfo Alvarado; e) Habil Ahmad Dellosa', '04', 'Brandon Berusa', 'BRANDON BERUSA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('977', '20170807', '����췢[2017]106��', '1: REDENDO 2: CAIN 3: DELLOSA 4: na', 'a) Abu Ilonggo; b) Brandon Berusa; c) Abu Muadz; d) Arnulfo Alvarado; e) Habil Ahmad Dellosa', '04', 'Abu Ilonggo', 'ABU ILONGGO', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('978', '20170807', '����췢[2017]106��', '1: REDENDO 2: CAIN 3: DELLOSA 4: na', 'a) Abu Ilonggo; b) Brandon Berusa; c) Abu Muadz; d) Arnulfo Alvarado; e) Habil Ahmad Dellosa', '04', 'Habil Ahmad Dellosa', 'HABIL AHMAD DELLOSA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('979', '20170807', '����췢[2017]106��', '1: REDOUANE 2: EL HABHAB 3: na 4: na', 'a) Abdelrahman', '02', 'REDOUANE EL HABHAB', 'REDOUANE EL HABHAB', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('980', '20170807', '����췢[2017]106��', '1: REDOUANE 2: EL HABHAB 3: na 4: na', 'a) Abdelrahman', '03', 'Abdelrahman', 'ABDELRAHMAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('981', '20170807', '����췢[2017]106��', '1: RICARDO 2: PEREZ 3: AYERAS 4: na', 'a) Abdul Kareem Ayeras; b) Abdul Karim Ayeras', '02', 'RICARDO PEREZ', 'RICARDO PEREZ', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('982', '20170807', '����췢[2017]106��', '1: RICARDO 2: PEREZ 3: AYERAS 4: na', 'a) Abdul Kareem Ayeras; b) Abdul Karim Ayeras', '04', 'Abdul Kareem Ayeras', 'ABDUL KAREEM AYERAS', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('983', '20170807', '����췢[2017]106��', '1: RICARDO 2: PEREZ 3: AYERAS 4: na', 'a) Abdul Kareem Ayeras; b) Abdul Karim Ayeras', '04', 'Abdul Karim Ayeras', 'ABDUL KARIM AYERAS', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('984', '20170807', '����췢[2017]106��', '1: RUBEN 2: PESTANO 3: LAVILLA, JR 4: na', 'a) Reuben Lavilla; b) Sheik Omar c) Mile D Lavilla; d) Reymund Lavilla; e) Ramo Lavilla; f) Mike de Lavilla; g) Abdullah Muddaris; h) Ali Omar; i) Omar Lavilla; j) Omar Labella', '02', 'RUBEN PESTANO', 'RUBEN PESTANO', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('985', '20170807', '����췢[2017]106��', '1: RUBEN 2: PESTANO 3: LAVILLA, JR 4: na', 'a) Reuben Lavilla; b) Sheik Omar c) Mile D Lavilla; d) Reymund Lavilla; e) Ramo Lavilla; f) Mike de Lavilla; g) Abdullah Muddaris; h) Ali Omar; i) Omar Lavilla; j) Omar Labella', '04', 'Ali Omar', 'ALI OMAR', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('986', '20170807', '����췢[2017]106��', '1: RUBEN 2: PESTANO 3: LAVILLA, JR 4: na', 'a) Reuben Lavilla; b) Sheik Omar c) Mile D Lavilla; d) Reymund Lavilla; e) Ramo Lavilla; f) Mike de Lavilla; g) Abdullah Muddaris; h) Ali Omar; i) Omar Lavilla; j) Omar Labella', '04', 'Omar Labella', 'OMAR LABELLA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('987', '20170807', '����췢[2017]106��', '1: RUBEN 2: PESTANO 3: LAVILLA, JR 4: na', 'a) Reuben Lavilla; b) Sheik Omar c) Mile D Lavilla; d) Reymund Lavilla; e) Ramo Lavilla; f) Mike de Lavilla; g) Abdullah Muddaris; h) Ali Omar; i) Omar Lavilla; j) Omar Labella', '04', 'Omar Lavilla', 'OMAR LAVILLA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('988', '20170807', '����췢[2017]106��', '1: RUBEN 2: PESTANO 3: LAVILLA, JR 4: na', 'a) Reuben Lavilla; b) Sheik Omar c) Mile D Lavilla; d) Reymund Lavilla; e) Ramo Lavilla; f) Mike de Lavilla; g) Abdullah Muddaris; h) Ali Omar; i) Omar Lavilla; j) Omar Labella', '04', 'Abdullah Muddaris', 'ABDULLAH MUDDARIS', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('989', '20170807', '����췢[2017]106��', '1: RUBEN 2: PESTANO 3: LAVILLA, JR 4: na', 'a) Reuben Lavilla; b) Sheik Omar c) Mile D Lavilla; d) Reymund Lavilla; e) Ramo Lavilla; f) Mike de Lavilla; g) Abdullah Muddaris; h) Ali Omar; i) Omar Lavilla; j) Omar Labella', '04', 'Mike de Lavilla', 'MIKE DE LAVILLA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('990', '20170807', '����췢[2017]106��', '1: RUBEN 2: PESTANO 3: LAVILLA, JR 4: na', 'a) Reuben Lavilla; b) Sheik Omar c) Mile D Lavilla; d) Reymund Lavilla; e) Ramo Lavilla; f) Mike de Lavilla; g) Abdullah Muddaris; h) Ali Omar; i) Omar Lavilla; j) Omar Labella', '04', 'Reymund Lavilla', 'REYMUND LAVILLA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('991', '20170807', '����췢[2017]106��', '1: RUBEN 2: PESTANO 3: LAVILLA, JR 4: na', 'a) Reuben Lavilla; b) Sheik Omar c) Mile D Lavilla; d) Reymund Lavilla; e) Ramo Lavilla; f) Mike de Lavilla; g) Abdullah Muddaris; h) Ali Omar; i) Omar Lavilla; j) Omar Labella', '04', 'Reymund Lavilla', 'REYMUND LAVILLA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('992', '20170807', '����췢[2017]106��', '1: RUBEN 2: PESTANO 3: LAVILLA, JR 4: na', 'a) Reuben Lavilla; b) Sheik Omar c) Mile D Lavilla; d) Reymund Lavilla; e) Ramo Lavilla; f) Mike de Lavilla; g) Abdullah Muddaris; h) Ali Omar; i) Omar Lavilla; j) Omar Labella', '04', 'Mile D Lavilla', 'MILE D LAVILLA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('993', '20170807', '����췢[2017]106��', '1: RUBEN 2: PESTANO 3: LAVILLA, JR 4: na', 'a) Reuben Lavilla; b) Sheik Omar c) Mile D Lavilla; d) Reymund Lavilla; e) Ramo Lavilla; f) Mike de Lavilla; g) Abdullah Muddaris; h) Ali Omar; i) Omar Lavilla; j) Omar Labella', '04', 'Reuben Lavilla', 'REUBEN LAVILLA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('994', '20170807', '����췢[2017]106��', '1: RUBEN 2: PESTANO 3: LAVILLA, JR 4: na', 'a) Reuben Lavilla; b) Sheik Omar c) Mile D Lavilla; d) Reymund Lavilla; e) Ramo Lavilla; f) Mike de Lavilla; g) Abdullah Muddaris; h) Ali Omar; i) Omar Lavilla; j) Omar Labella', '04', 'Sheik Omar', 'SHEIK OMAR', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('995', '20170807', '����췢[2017]106��', '1: RUSTAM 2: MAGOMEDOVICH 3: ASELDEROV 4: na', null, '02', 'RUSTAM MAGOMEDOVICH', 'RUSTAM MAGOMEDOVICH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('996', '20170807', '����췢[2017]106��', '1: SAD 2: BIN SAD 3: MUHAMMAD SHARIYAN 4: AL-KABI', 'a) Sad bin Sad Muhammad Shiryan al-Kabi; b) Sad Sad Muhammad Shiryan al-Kabi; c) Sad al-Sharyan al-Kabi', '02', 'SAD BIN SAD', 'SAD BIN SAD', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('997', '20170807', '����췢[2017]106��', '1: SAD 2: BIN SAD 3: MUHAMMAD SHARIYAN 4: AL-KABI', 'a) Sad bin Sad Muhammad Shiryan al-Kabi; b) Sad Sad Muhammad Shiryan al-Kabi; c) Sad al-Sharyan al-Kabi', '04', 'Sad al-Sharyan al-Kabi', 'SAD AL-SHARYAN AL-KABI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('998', '20170807', '����췢[2017]106��', '1: SAD 2: BIN SAD 3: MUHAMMAD SHARIYAN 4: AL-KABI', 'a) Sad bin Sad Muhammad Shiryan al-Kabi; b) Sad Sad Muhammad Shiryan al-Kabi; c) Sad al-Sharyan al-Kabi', '04', 'Sad Sad Muhammad Shiryan al-Kabi', 'SAD SAD MUHAMMAD SHIRYAN AL-KABI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('999', '20170807', '����췢[2017]106��', '1: SAD 2: BIN SAD 3: MUHAMMAD SHARIYAN 4: AL-KABI', 'a) Sad bin Sad Muhammad Shiryan al-Kabi; b) Sad Sad Muhammad Shiryan al-Kabi; c) Sad al-Sharyan al-Kabi', '04', 'Sad bin Sad Muhammad Shiryan al-Kabi', 'SAD BIN SAD MUHAMMAD SHIRYAN AL-KABI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1000', '20170807', '����췢[2017]106��', '1: SAID 2: ARIF 3: na 4: na', 'a) Said Mohamed Arif; b) Omar Gharib; c) Abderahmane; d) Abdallah al-Jazairi; e) Slimane Chabani; f) Souleiman', '02', 'SAID ARIF', 'SAID ARIF', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1001', '20170807', '����췢[2017]106��', '1: SAID 2: ARIF 3: na 4: na', 'a) Said Mohamed Arif; b) Omar Gharib; c) Abderahmane; d) Abdallah al-Jazairi; e) Slimane Chabani; f) Souleiman', '04', 'Abderahmane', 'ABDERAHMANE', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1002', '20170807', '����췢[2017]106��', '1: SAID 2: ARIF 3: na 4: na', 'a) Said Mohamed Arif; b) Omar Gharib; c) Abderahmane; d) Abdallah al-Jazairi; e) Slimane Chabani; f) Souleiman', '04', 'Omar Gharib', 'OMAR GHARIB', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1003', '20170807', '����췢[2017]106��', '1: SAID 2: ARIF 3: na 4: na', 'a) Said Mohamed Arif; b) Omar Gharib; c) Abderahmane; d) Abdallah al-Jazairi; e) Slimane Chabani; f) Souleiman', '04', 'Souleiman', 'SOULEIMAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1004', '20170807', '����췢[2017]106��', '1: SAID 2: ARIF 3: na 4: na', 'a) Said Mohamed Arif; b) Omar Gharib; c) Abderahmane; d) Abdallah al-Jazairi; e) Slimane Chabani; f) Souleiman', '04', 'Slimane Chabani', 'SLIMANE CHABANI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1005', '20170807', '����췢[2017]106��', '1: SAID 2: ARIF 3: na 4: na', 'a) Said Mohamed Arif; b) Omar Gharib; c) Abderahmane; d) Abdallah al-Jazairi; e) Slimane Chabani; f) Souleiman', '04', 'Abdallah al-Jazairi', 'ABDALLAH AL-JAZAIRI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1006', '20170807', '����췢[2017]106��', '1: SAID 2: ARIF 3: na 4: na', 'a) Said Mohamed Arif; b) Omar Gharib; c) Abderahmane; d) Abdallah al-Jazairi; e) Slimane Chabani; f) Souleiman', '04', 'Said Mohamed Arif', 'SAID MOHAMED ARIF', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1007', '20170807', '����췢[2017]106��', '1: SAID 2: BAHAJI 3: na 4: na', 'a) Zouheir Al Maghribi', '02', 'SAID BAHAJI', 'SAID BAHAJI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1008', '20170807', '����췢[2017]106��', '1: SAID 2: BAHAJI 3: na 4: na', 'a) Zouheir Al Maghribi', '03', 'Zouheir Al Maghribi', 'ZOUHEIR AL MAGHRIBI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1009', '20170807', '����췢[2017]106��', '1: SAID 2:BEN ABDELHAKIM 3: BEN OMAR 4: AL-CHERIF', 'a) Cherif Said born 25 Jan. 1970 in Tunisia; b) Binhamoda Hokri born 25 Jan. 1970 in Sosa, Tunisia; c) Hcrif Ataf born 15 Jan. 1971 in Solosse, Tunisia; d) Bin Homoda Chokri born 25 Jan. 1970 in Tunis, Tunisia; e) Atef  Cherif born 12 Dec. 1973 in Algeria; f) Sherif Ataf born 12 Dec. 1973 in Aras, Algeria; g) Ataf Cherif Said born 12 Dec. 1973 in Tunis, Tunisia; h) Cherif Said born 25 Jan. 1970 in Tunis, Tunisia; i) Cherif Said born 12 Dec. 1973 in Algeria ', '02', 'SAID 2:BEN ABDELHAKIM', 'SAID 2:BEN ABDELHAKIM', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1010', '20170807', '����췢[2017]106��', '1: SAID 2:BEN ABDELHAKIM 3: BEN OMAR 4: AL-CHERIF', 'a) Cherif Said born 25 Jan. 1970 in Tunisia; b) Binhamoda Hokri born 25 Jan. 1970 in Sosa, Tunisia; c) Hcrif Ataf born 15 Jan. 1971 in Solosse, Tunisia; d) Bin Homoda Chokri born 25 Jan. 1970 in Tunis, Tunisia; e) Atef  Cherif born 12 Dec. 1973 in Algeria; f) Sherif Ataf born 12 Dec. 1973 in Aras, Algeria; g) Ataf Cherif Said born 12 Dec. 1973 in Tunis, Tunisia; h) Cherif Said born 25 Jan. 1970 in Tunis, Tunisia; i) Cherif Said born 12 Dec. 1973 in Algeria ', '04', 'Ataf Cherif Said', 'ATAF CHERIF SAID', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1011', '20170807', '����췢[2017]106��', '1: SAID 2:BEN ABDELHAKIM 3: BEN OMAR 4: AL-CHERIF', 'a) Cherif Said born 25 Jan. 1970 in Tunisia; b) Binhamoda Hokri born 25 Jan. 1970 in Sosa, Tunisia; c) Hcrif Ataf born 15 Jan. 1971 in Solosse, Tunisia; d) Bin Homoda Chokri born 25 Jan. 1970 in Tunis, Tunisia; e) Atef  Cherif born 12 Dec. 1973 in Algeria; f) Sherif Ataf born 12 Dec. 1973 in Aras, Algeria; g) Ataf Cherif Said born 12 Dec. 1973 in Tunis, Tunisia; h) Cherif Said born 25 Jan. 1970 in Tunis, Tunisia; i) Cherif Said born 12 Dec. 1973 in Algeria ', '04', 'Cherif Said', 'CHERIF SAID', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1012', '20170807', '����췢[2017]106��', '1: SAID 2:BEN ABDELHAKIM 3: BEN OMAR 4: AL-CHERIF', 'a) Cherif Said born 25 Jan. 1970 in Tunisia; b) Binhamoda Hokri born 25 Jan. 1970 in Sosa, Tunisia; c) Hcrif Ataf born 15 Jan. 1971 in Solosse, Tunisia; d) Bin Homoda Chokri born 25 Jan. 1970 in Tunis, Tunisia; e) Atef  Cherif born 12 Dec. 1973 in Algeria; f) Sherif Ataf born 12 Dec. 1973 in Aras, Algeria; g) Ataf Cherif Said born 12 Dec. 1973 in Tunis, Tunisia; h) Cherif Said born 25 Jan. 1970 in Tunis, Tunisia; i) Cherif Said born 12 Dec. 1973 in Algeria ', '04', 'Cherif Said', 'CHERIF SAID', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1013', '20170807', '����췢[2017]106��', '1: SAID 2:BEN ABDELHAKIM 3: BEN OMAR 4: AL-CHERIF', 'a) Cherif Said born 25 Jan. 1970 in Tunisia; b) Binhamoda Hokri born 25 Jan. 1970 in Sosa, Tunisia; c) Hcrif Ataf born 15 Jan. 1971 in Solosse, Tunisia; d) Bin Homoda Chokri born 25 Jan. 1970 in Tunis, Tunisia; e) Atef  Cherif born 12 Dec. 1973 in Algeria; f) Sherif Ataf born 12 Dec. 1973 in Aras, Algeria; g) Ataf Cherif Said born 12 Dec. 1973 in Tunis, Tunisia; h) Cherif Said born 25 Jan. 1970 in Tunis, Tunisia; i) Cherif Said born 12 Dec. 1973 in Algeria ', '04', 'Sherif Ataf', 'SHERIF ATAF', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1014', '20170807', '����췢[2017]106��', '1: SAID 2:BEN ABDELHAKIM 3: BEN OMAR 4: AL-CHERIF', 'a) Cherif Said born 25 Jan. 1970 in Tunisia; b) Binhamoda Hokri born 25 Jan. 1970 in Sosa, Tunisia; c) Hcrif Ataf born 15 Jan. 1971 in Solosse, Tunisia; d) Bin Homoda Chokri born 25 Jan. 1970 in Tunis, Tunisia; e) Atef  Cherif born 12 Dec. 1973 in Algeria; f) Sherif Ataf born 12 Dec. 1973 in Aras, Algeria; g) Ataf Cherif Said born 12 Dec. 1973 in Tunis, Tunisia; h) Cherif Said born 25 Jan. 1970 in Tunis, Tunisia; i) Cherif Said born 12 Dec. 1973 in Algeria ', '04', 'Atef  Cherif', 'ATEF  CHERIF', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1015', '20170807', '����췢[2017]106��', '1: SAID 2:BEN ABDELHAKIM 3: BEN OMAR 4: AL-CHERIF', 'a) Cherif Said born 25 Jan. 1970 in Tunisia; b) Binhamoda Hokri born 25 Jan. 1970 in Sosa, Tunisia; c) Hcrif Ataf born 15 Jan. 1971 in Solosse, Tunisia; d) Bin Homoda Chokri born 25 Jan. 1970 in Tunis, Tunisia; e) Atef  Cherif born 12 Dec. 1973 in Algeria; f) Sherif Ataf born 12 Dec. 1973 in Aras, Algeria; g) Ataf Cherif Said born 12 Dec. 1973 in Tunis, Tunisia; h) Cherif Said born 25 Jan. 1970 in Tunis, Tunisia; i) Cherif Said born 12 Dec. 1973 in Algeria ', '04', 'Hcrif Ataf', 'HCRIF ATAF', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1016', '20170807', '����췢[2017]106��', '1: SAID 2:BEN ABDELHAKIM 3: BEN OMAR 4: AL-CHERIF', 'a) Cherif Said born 25 Jan. 1970 in Tunisia; b) Binhamoda Hokri born 25 Jan. 1970 in Sosa, Tunisia; c) Hcrif Ataf born 15 Jan. 1971 in Solosse, Tunisia; d) Bin Homoda Chokri born 25 Jan. 1970 in Tunis, Tunisia; e) Atef  Cherif born 12 Dec. 1973 in Algeria; f) Sherif Ataf born 12 Dec. 1973 in Aras, Algeria; g) Ataf Cherif Said born 12 Dec. 1973 in Tunis, Tunisia; h) Cherif Said born 25 Jan. 1970 in Tunis, Tunisia; i) Cherif Said born 12 Dec. 1973 in Algeria ', '04', 'Bin Homoda Chokri', 'BIN HOMODA CHOKRI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1017', '20170807', '����췢[2017]106��', '1: SAID 2:BEN ABDELHAKIM 3: BEN OMAR 4: AL-CHERIF', 'a) Cherif Said born 25 Jan. 1970 in Tunisia; b) Binhamoda Hokri born 25 Jan. 1970 in Sosa, Tunisia; c) Hcrif Ataf born 15 Jan. 1971 in Solosse, Tunisia; d) Bin Homoda Chokri born 25 Jan. 1970 in Tunis, Tunisia; e) Atef  Cherif born 12 Dec. 1973 in Algeria; f) Sherif Ataf born 12 Dec. 1973 in Aras, Algeria; g) Ataf Cherif Said born 12 Dec. 1973 in Tunis, Tunisia; h) Cherif Said born 25 Jan. 1970 in Tunis, Tunisia; i) Cherif Said born 12 Dec. 1973 in Algeria ', '04', 'Cherif Said', 'CHERIF SAID', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1018', '20170807', '����췢[2017]106��', '1: SAID 2:BEN ABDELHAKIM 3: BEN OMAR 4: AL-CHERIF', 'a) Cherif Said born 25 Jan. 1970 in Tunisia; b) Binhamoda Hokri born 25 Jan. 1970 in Sosa, Tunisia; c) Hcrif Ataf born 15 Jan. 1971 in Solosse, Tunisia; d) Bin Homoda Chokri born 25 Jan. 1970 in Tunis, Tunisia; e) Atef  Cherif born 12 Dec. 1973 in Algeria; f) Sherif Ataf born 12 Dec. 1973 in Aras, Algeria; g) Ataf Cherif Said born 12 Dec. 1973 in Tunis, Tunisia; h) Cherif Said born 25 Jan. 1970 in Tunis, Tunisia; i) Cherif Said born 12 Dec. 1973 in Algeria ', '04', 'Binhamoda Hokri', 'BINHAMODA HOKRI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1019', '20170807', '����췢[2017]106��', '1: SAID JAN 2: ABD AL-SALAM 3: na 4: na', 'a) Said Jan Abd-al-Salam; b) Dilawar Khan Zain Khan born 1 Jan. 1972', '02', 'SAID JAN ABD AL-SALAM', 'SAID JAN ABD AL-SALAM', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1020', '20170807', '����췢[2017]106��', '1: SAID JAN 2: ABD AL-SALAM 3: na 4: na', 'a) Said Jan Abd-al-Salam; b) Dilawar Khan Zain Khan born 1 Jan. 1972', '04', 'Dilawar Khan Zain Khan', 'DILAWAR KHAN ZAIN KHAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1021', '20170807', '����췢[2017]106��', '1: SAID JAN 2: ABD AL-SALAM 3: na 4: na', 'a) Said Jan Abd-al-Salam; b) Dilawar Khan Zain Khan born 1 Jan. 1972', '04', 'Said Jan Abd-al-Salam', 'SAID JAN ABD-AL-SALAM', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1022', '20170807', '����췢[2017]106��', '1: SAIFI 2: AMMARI 3: na 4: na', 'a) El Para (combat name); b) Abderrezak Le Para (combat name); c) Abou Haidara; d) El Ourassi; e) Abderrezak Zaimeche; f) Abdul Rasak ammane Abu Haidra; g) Abdalarak', '02', 'SAIFI AMMARI', 'SAIFI AMMARI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1023', '20170807', '����췢[2017]106��', '1: SAIFI 2: AMMARI 3: na 4: na', 'a) El Para (combat name); b) Abderrezak Le Para (combat name); c) Abou Haidara; d) El Ourassi; e) Abderrezak Zaimeche; f) Abdul Rasak ammane Abu Haidra; g) Abdalarak', '04', 'Abdul Rasak ammane Abu Haidra', 'ABDUL RASAK AMMANE ABU HAIDRA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1024', '20170807', '����췢[2017]106��', '1: SAIFI 2: AMMARI 3: na 4: na', 'a) El Para (combat name); b) Abderrezak Le Para (combat name); c) Abou Haidara; d) El Ourassi; e) Abderrezak Zaimeche; f) Abdul Rasak ammane Abu Haidra; g) Abdalarak', '04', 'Abdalarak', 'ABDALARAK', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1025', '20170807', '����췢[2017]106��', '1: SAIFI 2: AMMARI 3: na 4: na', 'a) El Para (combat name); b) Abderrezak Le Para (combat name); c) Abou Haidara; d) El Ourassi; e) Abderrezak Zaimeche; f) Abdul Rasak ammane Abu Haidra; g) Abdalarak', '04', 'Abderrezak Zaimeche', 'ABDERREZAK ZAIMECHE', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1026', '20170807', '����췢[2017]106��', '1: SAIFI 2: AMMARI 3: na 4: na', 'a) El Para (combat name); b) Abderrezak Le Para (combat name); c) Abou Haidara; d) El Ourassi; e) Abderrezak Zaimeche; f) Abdul Rasak ammane Abu Haidra; g) Abdalarak', '04', 'El Para', 'EL PARA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1027', '20170807', '����췢[2017]106��', '1: SAIFI 2: AMMARI 3: na 4: na', 'a) El Para (combat name); b) Abderrezak Le Para (combat name); c) Abou Haidara; d) El Ourassi; e) Abderrezak Zaimeche; f) Abdul Rasak ammane Abu Haidra; g) Abdalarak', '04', 'Abderrezak Le Para', 'ABDERREZAK LE PARA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1028', '20170807', '����췢[2017]106��', '1: SAIFI 2: AMMARI 3: na 4: na', 'a) El Para (combat name); b) Abderrezak Le Para (combat name); c) Abou Haidara; d) El Ourassi; e) Abderrezak Zaimeche; f) Abdul Rasak ammane Abu Haidra; g) Abdalarak', '04', 'Abou Haidara', 'ABOU HAIDARA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1029', '20170807', '����췢[2017]106��', '1: SAIFI 2: AMMARI 3: na 4: na', 'a) El Para (combat name); b) Abderrezak Le Para (combat name); c) Abou Haidara; d) El Ourassi; e) Abderrezak Zaimeche; f) Abdul Rasak ammane Abu Haidra; g) Abdalarak', '04', 'El Ourassi', 'EL OURASSI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1030', '20170807', '����췢[2017]106��', '1: SALAH EDDINE 2: GASMI 3: na 4: na', 'a) Abou Mohamed Salah', '02', 'SALAH EDDINE GASMI', 'SALAH EDDINE GASMI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1031', '20170807', '����췢[2017]106��', '1: SALAH EDDINE 2: GASMI 3: na 4: na', 'a) Abou Mohamed Salah', '03', 'Abou Mohamed Salah', 'ABOU MOHAMED SALAH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1032', '20170807', '����췢[2017]106��', '1: SALEM 2: NOR ELDIN 3: AMOHAMED 4: AL-DABSKI', 'a) Abu Al-Ward; b) Abdullah Ragab', '02', 'SALEM NOR ELDIN', 'SALEM NOR ELDIN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1033', '20170807', '����췢[2017]106��', '1: SALEM 2: NOR ELDIN 3: AMOHAMED 4: AL-DABSKI', 'a) Abu Al-Ward; b) Abdullah Ragab', '04', 'Abu Al-Ward', 'ABU AL-WARD', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1034', '20170807', '����췢[2017]106��', '1: SALEM 2: NOR ELDIN 3: AMOHAMED 4: AL-DABSKI', 'a) Abu Al-Ward; b) Abdullah Ragab', '04', 'Abdullah Ragab', 'ABDULLAH RAGAB', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1035', '20170807', '����췢[2017]106��', '1: SALIM 2: AHMAD 3: SALIM 4: HAMDAN', 'a) Saqr Al-Jaddawi; b) Saqar Al Jadawi; c) Saqar Aljawadi; d) Salem Ahmed Salem Hamdan', '02', 'SALIM AHMAD', 'SALIM AHMAD', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1036', '20170807', '����췢[2017]106��', '1: SALIM 2: AHMAD 3: SALIM 4: HAMDAN', 'a) Saqr Al-Jaddawi; b) Saqar Al Jadawi; c) Saqar Aljawadi; d) Salem Ahmed Salem Hamdan', '04', 'Salem Ahmed Salem Hamdan', 'SALEM AHMED SALEM HAMDAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1037', '20170807', '����췢[2017]106��', '1: SALIM 2: AHMAD 3: SALIM 4: HAMDAN', 'a) Saqr Al-Jaddawi; b) Saqar Al Jadawi; c) Saqar Aljawadi; d) Salem Ahmed Salem Hamdan', '04', 'Saqar Aljawadi', 'SAQAR ALJAWADI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1038', '20170807', '����췢[2017]106��', '1: SALIM 2: AHMAD 3: SALIM 4: HAMDAN', 'a) Saqr Al-Jaddawi; b) Saqar Al Jadawi; c) Saqar Aljawadi; d) Salem Ahmed Salem Hamdan', '04', 'Saqar Al Jadawi', 'SAQAR AL JADAWI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1039', '20170807', '����췢[2017]106��', '1: SALIM 2: AHMAD 3: SALIM 4: HAMDAN', 'a) Saqr Al-Jaddawi; b) Saqar Al Jadawi; c) Saqar Aljawadi; d) Salem Ahmed Salem Hamdan', '04', 'Saqr Al-Jaddawi', 'SAQR AL-JADDAWI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1040', '20170807', '����췢[2017]106��', '1: SALIM 2: BENGHALEM 3: na 4: na', null, '02', 'SALIM BENGHALEM', 'SALIM BENGHALEM', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1041', '20170807', '����췢[2017]106��', '1: SALIM Y SALAMUDDIN 2: JULKIPLI 3: na 4: na', 'a) Kipli Sali; b) Julkipli Salim', '02', 'SALIM Y SALAMUDDIN JULKIPLI', 'SALIM Y SALAMUDDIN JULKIPLI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1042', '20170807', '����췢[2017]106��', '1: SALIM Y SALAMUDDIN 2: JULKIPLI 3: na 4: na', 'a) Kipli Sali; b) Julkipli Salim', '04', 'Julkipli Salim', 'JULKIPLI SALIM', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1043', '20170807', '����췢[2017]106��', '1: SALIM Y SALAMUDDIN 2: JULKIPLI 3: na 4: na', 'a) Kipli Sali; b) Julkipli Salim', '04', 'Kipli Sali', 'KIPLI SALI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1044', '20170807', '����췢[2017]106��', '1: SALLY-ANNE 2: FRANCES 3: JONES 4: na', null, '02', 'SALLY-ANNE FRANCES', 'SALLY-ANNE FRANCES', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1045', '20170807', '����췢[2017]106��', '1: SAMI 2: BEN KHAMIS 3: BEN SALEH 4: ELSSEID', 'a) Omar El Mouhajer', '02', 'SAMI BEN KHAMIS', 'SAMI BEN KHAMIS', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1046', '20170807', '����췢[2017]106��', '1: SAMI 2: BEN KHAMIS 3: BEN SALEH 4: ELSSEID', 'a) Omar El Mouhajer', '03', 'Omar El Mouhajer', 'OMAR EL MOUHAJER', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1047', '20170807', '����췢[2017]106��', '1: SAYF-AL ADL 2: na 3: na 4: na', 'a) Mohammed Salahaldin Abd El Halim Zidan (DOB: 11 Apr. 1963. POB: Monufia Governorate, Egypt. Nationality: Eygpt.); b) Muhamad Ibrahim Makkawi (DOB: a) 11 Apr. 1960; b) 11 Apr. 1963. POB: Egypt. Nationality: Egypt)', '02', 'SAYF-AL ADL', 'SAYF-AL ADL', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1048', '20170807', '����췢[2017]106��', '1: SAYF-AL ADL 2: na 3: na 4: na', 'a) Mohammed Salahaldin Abd El Halim Zidan (DOB: 11 Apr. 1963. POB: Monufia Governorate, Egypt. Nationality: Eygpt.); b) Muhamad Ibrahim Makkawi (DOB: a) 11 Apr. 1960; b) 11 Apr. 1963. POB: Egypt. Nationality: Egypt)', '04', 'Muhamad Ibrahim Makkawi', 'MUHAMAD IBRAHIM MAKKAWI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1049', '20170807', '����췢[2017]106��', '1: SAYF-AL ADL 2: na 3: na 4: na', 'a) Mohammed Salahaldin Abd El Halim Zidan (DOB: 11 Apr. 1963. POB: Monufia Governorate, Egypt. Nationality: Eygpt.); b) Muhamad Ibrahim Makkawi (DOB: a) 11 Apr. 1960; b) 11 Apr. 1963. POB: Egypt. Nationality: Egypt)', '04', 'Mohammed Salahaldin Abd El Halim Zidan', 'MOHAMMED SALAHALDIN ABD EL HALIM ZIDAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1050', '20170807', '����췢[2017]106��', '1: SEIFALLAH 2: BEN HASSINE 3: na 4: na', 'a) Seif Allah ben Hocine; b) Saifallah ben Hassine; c) Sayf Allah Umar bin Hassayn; d) Sayf Allah bin Hussayn', '02', 'SEIFALLAH BEN HASSINE', 'SEIFALLAH BEN HASSINE', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1051', '20170807', '����췢[2017]106��', '1: SEIFALLAH 2: BEN HASSINE 3: na 4: na', 'a) Seif Allah ben Hocine; b) Saifallah ben Hassine; c) Sayf Allah Umar bin Hassayn; d) Sayf Allah bin Hussayn', '04', 'Saifallah ben Hassine', 'SAIFALLAH BEN HASSINE', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1052', '20170807', '����췢[2017]106��', '1: SEIFALLAH 2: BEN HASSINE 3: na 4: na', 'a) Seif Allah ben Hocine; b) Saifallah ben Hassine; c) Sayf Allah Umar bin Hassayn; d) Sayf Allah bin Hussayn', '04', 'Sayf Allah bin Hussayn', 'SAYF ALLAH BIN HUSSAYN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1053', '20170807', '����췢[2017]106��', '1: SEIFALLAH 2: BEN HASSINE 3: na 4: na', 'a) Seif Allah ben Hocine; b) Saifallah ben Hassine; c) Sayf Allah Umar bin Hassayn; d) Sayf Allah bin Hussayn', '04', 'Sayf Allah Umar bin Hassayn', 'SAYF ALLAH UMAR BIN HASSAYN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1054', '20170807', '����췢[2017]106��', '1: SEIFALLAH 2: BEN HASSINE 3: na 4: na', 'a) Seif Allah ben Hocine; b) Saifallah ben Hassine; c) Sayf Allah Umar bin Hassayn; d) Sayf Allah bin Hussayn', '04', 'Seif Allah ben Hocine', 'SEIF ALLAH BEN HOCINE', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1055', '20170807', '����췢[2017]106��', '1: SHAFI 2: SULTAN 3: MOHAMMED 4: AL-AJMI', 'a) Shafi al-Aimi; b) Sheikh Shafi al-Ajmi', '02', 'SHAFI SULTAN', 'SHAFI SULTAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1056', '20170807', '����췢[2017]106��', '1: SHAFI 2: SULTAN 3: MOHAMMED 4: AL-AJMI', 'a) Shafi al-Aimi; b) Sheikh Shafi al-Ajmi', '04', 'Sheikh Shafi al-Ajmi', 'SHEIKH SHAFI AL-AJMI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1057', '20170807', '����췢[2017]106��', '1: SHAFI 2: SULTAN 3: MOHAMMED 4: AL-AJMI', 'a) Shafi al-Aimi; b) Sheikh Shafi al-Ajmi', '04', 'Shafi al-Aimi', 'SHAFI AL-AIMI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1058', '20170807', '����췢[2017]106��', '1: SHAMIL 2: MAGOMEDOVICH 3: ISMAILOV 4: na', 'a) Shamil Magomedovich Aliev', '02', 'SHAMIL MAGOMEDOVICH', 'SHAMIL MAGOMEDOVICH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1059', '20170807', '����췢[2017]106��', '1: SHAMIL 2: MAGOMEDOVICH 3: ISMAILOV 4: na', 'a) Shamil Magomedovich Aliev', '03', 'Shamil Magomedovich Aliev', 'SHAMIL MAGOMEDOVICH ALIEV', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1060', '20170807', '����췢[2017]106��', '1: SOFIANE 2: BEN GOUMO 3: na 4: na', 'a) Sufyan bin Qumu', '02', 'SOFIANE BEN GOUMO', 'SOFIANE BEN GOUMO', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1061', '20170807', '����췢[2017]106��', '1: SOFIANE 2: BEN GOUMO 3: na 4: na', 'a) Sufyan bin Qumu', '03', 'Sufyan bin Qumu', 'SUFYAN BIN QUMU', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1062', '20170807', '����췢[2017]106��', '1: SULAIMAN 2: JASSEM 3: SULAIMAN 4: ALI ABO GHAITH', null, '02', 'SULAIMAN JASSEM', 'SULAIMAN JASSEM', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1063', '20170807', '����췢[2017]106��', '1: TARAD 2: MOHAMMAD 3: ALJARBA 4: na', 'a) Tarad Aljarba', '02', 'TARAD MOHAMMAD', 'TARAD MOHAMMAD', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1064', '20170807', '����췢[2017]106��', '1: TARAD 2: MOHAMMAD 3: ALJARBA 4: na', 'a) Tarad Aljarba', '03', 'Tarad Aljarba', 'TARAD ALJARBA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1065', '20170807', '����췢[2017]106��', '1: TARAK 2: BEN TAHER 3: BEN FALEH 4: OUNI HARZI', null, '02', 'TARAK BEN TAHER', 'TARAK BEN TAHER', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1066', '20170807', '����췢[2017]106��', '1: TAREK 2: BEN HABIB 3: BEN AL-TOUMI 4: AL-MAAROUFI', 'a) Abu Ismail; b) Abou Ismail el Jendoubi; c) Abou Ismail Al Djoundoubi', '02', 'TAREK BEN HABIB', 'TAREK BEN HABIB', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1067', '20170807', '����췢[2017]106��', '1: TAREK 2: BEN HABIB 3: BEN AL-TOUMI 4: AL-MAAROUFI', 'a) Abu Ismail; b) Abou Ismail el Jendoubi; c) Abou Ismail Al Djoundoubi', '04', 'Abou Ismail el Jendoubi', 'ABOU ISMAIL EL JENDOUBI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1068', '20170807', '����췢[2017]106��', '1: TAREK 2: BEN HABIB 3: BEN AL-TOUMI 4: AL-MAAROUFI', 'a) Abu Ismail; b) Abou Ismail el Jendoubi; c) Abou Ismail Al Djoundoubi', '04', 'Abou Ismail Al Djoundoubi', 'ABOU ISMAIL AL DJOUNDOUBI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1069', '20170807', '����췢[2017]106��', '1: TAREK 2: BEN HABIB 3: BEN AL-TOUMI 4: AL-MAAROUFI', 'a) Abu Ismail; b) Abou Ismail el Jendoubi; c) Abou Ismail Al Djoundoubi', '04', 'Abu Ismail', 'ABU ISMAIL', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1070', '20170807', '����췢[2017]106��', '1: TARIQ 2: ANWAR 3: EL SAYED 4: AHMED', 'a) Hamdi Ahmad Farag; b) Amr Al-Fatih Fathi; c) Tarek Anwar El Sayed Ahmad', '02', 'TARIQ ANWAR', 'TARIQ ANWAR', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1071', '20170807', '����췢[2017]106��', '1: TARIQ 2: ANWAR 3: EL SAYED 4: AHMED', 'a) Hamdi Ahmad Farag; b) Amr Al-Fatih Fathi; c) Tarek Anwar El Sayed Ahmad', '04', 'Amr Al-Fatih Fathi', 'AMR AL-FATIH FATHI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1072', '20170807', '����췢[2017]106��', '1: TARIQ 2: ANWAR 3: EL SAYED 4: AHMED', 'a) Hamdi Ahmad Farag; b) Amr Al-Fatih Fathi; c) Tarek Anwar El Sayed Ahmad', '04', 'Hamdi Ahmad Farag', 'HAMDI AHMAD FARAG', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1073', '20170807', '����췢[2017]106��', '1: TARIQ 2: ANWAR 3: EL SAYED 4: AHMED', 'a) Hamdi Ahmad Farag; b) Amr Al-Fatih Fathi; c) Tarek Anwar El Sayed Ahmad', '04', 'Tarek Anwar El Sayed Ahmad', 'TAREK ANWAR EL SAYED AHMAD', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1074', '20170807', '����췢[2017]106��', '1: TARKHAN 2: ISMAILOVICH 3: GAZIEV 4: na', 'a) Ramzan Oduev; b) Tarkhan Isaevich Gaziev; c) Husan Isaevich Gaziev; d) Umar Sulimov', '02', 'TARKHAN ISMAILOVICH', 'TARKHAN ISMAILOVICH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1075', '20170807', '����췢[2017]106��', '1: TARKHAN 2: ISMAILOVICH 3: GAZIEV 4: na', 'a) Ramzan Oduev; b) Tarkhan Isaevich Gaziev; c) Husan Isaevich Gaziev; d) Umar Sulimov', '04', 'Husan Isaevich Gaziev', 'HUSAN ISAEVICH GAZIEV', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1076', '20170807', '����췢[2017]106��', '1: TARKHAN 2: ISMAILOVICH 3: GAZIEV 4: na', 'a) Ramzan Oduev; b) Tarkhan Isaevich Gaziev; c) Husan Isaevich Gaziev; d) Umar Sulimov', '04', 'Umar Sulimov', 'UMAR SULIMOV', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1077', '20170807', '����췢[2017]106��', '1: TARKHAN 2: ISMAILOVICH 3: GAZIEV 4: na', 'a) Ramzan Oduev; b) Tarkhan Isaevich Gaziev; c) Husan Isaevich Gaziev; d) Umar Sulimov', '04', 'Tarkhan Isaevich Gaziev', 'TARKHAN ISAEVICH GAZIEV', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1078', '20170807', '����췢[2017]106��', '1: TARKHAN 2: ISMAILOVICH 3: GAZIEV 4: na', 'a) Ramzan Oduev; b) Tarkhan Isaevich Gaziev; c) Husan Isaevich Gaziev; d) Umar Sulimov', '04', 'Ramzan Oduev', 'RAMZAN ODUEV', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1079', '20170807', '����췢[2017]106��', '1: TARKHAN 2: ISMAILOVICH 3: GAZIEV 4: na', 'a) Ramzan Oduev; b) Tarkhan Isaevich Gaziev; c) Husan Isaevich Gaziev; d) Umar Sulimov', '04', 'Ahmad, Abu Bakr', 'AHMAD, ABU BAKR', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1080', '20170807', '����췢[2017]106��', '1: TARKHAN 2: TAYUMURAZOVICH 3: BATIRASHVILI 4: na', 'a) Tarkhan Tayumurazovich Batyrashvili; b)Tarkhan Batirashvili', '02', 'TARKHAN TAYUMURAZOVICH', 'TARKHAN TAYUMURAZOVICH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1081', '20170807', '����췢[2017]106��', '1: TARKHAN 2: TAYUMURAZOVICH 3: BATIRASHVILI 4: na', 'a) Tarkhan Tayumurazovich Batyrashvili; b)Tarkhan Batirashvili', '04', 'Tarkhan Batirashvili', 'TARKHAN BATIRASHVILI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1082', '20170807', '����췢[2017]106��', '1: TARKHAN 2: TAYUMURAZOVICH 3: BATIRASHVILI 4: na', 'a) Tarkhan Tayumurazovich Batyrashvili; b)Tarkhan Batirashvili', '04', 'Tarkhan Tayumurazovich Batyrashvili', 'TARKHAN TAYUMURAZOVICH BATYRASHVILI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1083', '20170807', '����췢[2017]106��', '1: TAUFIK 2: RIFKI 3: na 4: na', 'a) Refke, Taufek; b) Rifqi, Taufik; c) Rifqi, Tawfiq; d) Ami Iraq; e) Ami Irza; f) Amy Erja; g) Ammy Erza; h) Ammy lzza; i) Ami Kusoman; j) Abu Obaida; k) Abu Obaidah; l) Abu Obeida; m) Abu Ubaidah; n) Obaidah; o) Abu Obayda; p) Izza Kusoman; q) Yacub, Eric', '02', 'TAUFIK RIFKI', 'TAUFIK RIFKI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1084', '20170807', '����췢[2017]106��', '1: TAUFIK 2: RIFKI 3: na 4: na', 'a) Refke, Taufek; b) Rifqi, Taufik; c) Rifqi, Tawfiq; d) Ami Iraq; e) Ami Irza; f) Amy Erja; g) Ammy Erza; h) Ammy lzza; i) Ami Kusoman; j) Abu Obaida; k) Abu Obaidah; l) Abu Obeida; m) Abu Ubaidah; n) Obaidah; o) Abu Obayda; p) Izza Kusoman; q) Yacub, Eric', '04', 'Refke, Taufek', 'REFKE, TAUFEK', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1085', '20170807', '����췢[2017]106��', '1: TAUFIK 2: RIFKI 3: na 4: na', 'a) Refke, Taufek; b) Rifqi, Taufik; c) Rifqi, Tawfiq; d) Ami Iraq; e) Ami Irza; f) Amy Erja; g) Ammy Erza; h) Ammy lzza; i) Ami Kusoman; j) Abu Obaida; k) Abu Obaidah; l) Abu Obeida; m) Abu Ubaidah; n) Obaidah; o) Abu Obayda; p) Izza Kusoman; q) Yacub, Eric', '04', 'Yacub, Eric', 'YACUB, ERIC', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1086', '20170807', '����췢[2017]106��', '1: TAUFIK 2: RIFKI 3: na 4: na', 'a) Refke, Taufek; b) Rifqi, Taufik; c) Rifqi, Tawfiq; d) Ami Iraq; e) Ami Irza; f) Amy Erja; g) Ammy Erza; h) Ammy lzza; i) Ami Kusoman; j) Abu Obaida; k) Abu Obaidah; l) Abu Obeida; m) Abu Ubaidah; n) Obaidah; o) Abu Obayda; p) Izza Kusoman; q) Yacub, Eric', '04', 'Obaidah', 'OBAIDAH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1087', '20170807', '����췢[2017]106��', '1: TAUFIK 2: RIFKI 3: na 4: na', 'a) Refke, Taufek; b) Rifqi, Taufik; c) Rifqi, Tawfiq; d) Ami Iraq; e) Ami Irza; f) Amy Erja; g) Ammy Erza; h) Ammy lzza; i) Ami Kusoman; j) Abu Obaida; k) Abu Obaidah; l) Abu Obeida; m) Abu Ubaidah; n) Obaidah; o) Abu Obayda; p) Izza Kusoman; q) Yacub, Eric', '04', 'Abu Obeida', 'ABU OBEIDA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1088', '20170807', '����췢[2017]106��', '1: TAUFIK 2: RIFKI 3: na 4: na', 'a) Refke, Taufek; b) Rifqi, Taufik; c) Rifqi, Tawfiq; d) Ami Iraq; e) Ami Irza; f) Amy Erja; g) Ammy Erza; h) Ammy lzza; i) Ami Kusoman; j) Abu Obaida; k) Abu Obaidah; l) Abu Obeida; m) Abu Ubaidah; n) Obaidah; o) Abu Obayda; p) Izza Kusoman; q) Yacub, Eric', '04', 'Abu Obaidah', 'ABU OBAIDAH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1089', '20170807', '����췢[2017]106��', '1: TAUFIK 2: RIFKI 3: na 4: na', 'a) Refke, Taufek; b) Rifqi, Taufik; c) Rifqi, Tawfiq; d) Ami Iraq; e) Ami Irza; f) Amy Erja; g) Ammy Erza; h) Ammy lzza; i) Ami Kusoman; j) Abu Obaida; k) Abu Obaidah; l) Abu Obeida; m) Abu Ubaidah; n) Obaidah; o) Abu Obayda; p) Izza Kusoman; q) Yacub, Eric', '04', 'Abu Obaida', 'ABU OBAIDA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1090', '20170807', '����췢[2017]106��', '1: TAUFIK 2: RIFKI 3: na 4: na', 'a) Refke, Taufek; b) Rifqi, Taufik; c) Rifqi, Tawfiq; d) Ami Iraq; e) Ami Irza; f) Amy Erja; g) Ammy Erza; h) Ammy lzza; i) Ami Kusoman; j) Abu Obaida; k) Abu Obaidah; l) Abu Obeida; m) Abu Ubaidah; n) Obaidah; o) Abu Obayda; p) Izza Kusoman; q) Yacub, Eric', '04', 'Ami Kusoman', 'AMI KUSOMAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1091', '20170807', '����췢[2017]106��', '1: TAUFIK 2: RIFKI 3: na 4: na', 'a) Refke, Taufek; b) Rifqi, Taufik; c) Rifqi, Tawfiq; d) Ami Iraq; e) Ami Irza; f) Amy Erja; g) Ammy Erza; h) Ammy lzza; i) Ami Kusoman; j) Abu Obaida; k) Abu Obaidah; l) Abu Obeida; m) Abu Ubaidah; n) Obaidah; o) Abu Obayda; p) Izza Kusoman; q) Yacub, Eric', '04', 'Ammy lzza', 'AMMY LZZA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1092', '20170807', '����췢[2017]106��', '1: TAUFIK 2: RIFKI 3: na 4: na', 'a) Refke, Taufek; b) Rifqi, Taufik; c) Rifqi, Tawfiq; d) Ami Iraq; e) Ami Irza; f) Amy Erja; g) Ammy Erza; h) Ammy lzza; i) Ami Kusoman; j) Abu Obaida; k) Abu Obaidah; l) Abu Obeida; m) Abu Ubaidah; n) Obaidah; o) Abu Obayda; p) Izza Kusoman; q) Yacub, Eric', '04', 'Ammy Erza', 'AMMY ERZA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1093', '20170807', '����췢[2017]106��', '1: TAUFIK 2: RIFKI 3: na 4: na', 'a) Refke, Taufek; b) Rifqi, Taufik; c) Rifqi, Tawfiq; d) Ami Iraq; e) Ami Irza; f) Amy Erja; g) Ammy Erza; h) Ammy lzza; i) Ami Kusoman; j) Abu Obaida; k) Abu Obaidah; l) Abu Obeida; m) Abu Ubaidah; n) Obaidah; o) Abu Obayda; p) Izza Kusoman; q) Yacub, Eric', '04', 'Amy Erja', 'AMY ERJA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1094', '20170807', '����췢[2017]106��', '1: TAUFIK 2: RIFKI 3: na 4: na', 'a) Refke, Taufek; b) Rifqi, Taufik; c) Rifqi, Tawfiq; d) Ami Iraq; e) Ami Irza; f) Amy Erja; g) Ammy Erza; h) Ammy lzza; i) Ami Kusoman; j) Abu Obaida; k) Abu Obaidah; l) Abu Obeida; m) Abu Ubaidah; n) Obaidah; o) Abu Obayda; p) Izza Kusoman; q) Yacub, Eric', '04', 'Ami Irza', 'AMI IRZA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1095', '20170807', '����췢[2017]106��', '1: TAUFIK 2: RIFKI 3: na 4: na', 'a) Refke, Taufek; b) Rifqi, Taufik; c) Rifqi, Tawfiq; d) Ami Iraq; e) Ami Irza; f) Amy Erja; g) Ammy Erza; h) Ammy lzza; i) Ami Kusoman; j) Abu Obaida; k) Abu Obaidah; l) Abu Obeida; m) Abu Ubaidah; n) Obaidah; o) Abu Obayda; p) Izza Kusoman; q) Yacub, Eric', '04', 'Ami Iraq', 'AMI IRAQ', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1096', '20170807', '����췢[2017]106��', '1: TAUFIK 2: RIFKI 3: na 4: na', 'a) Refke, Taufek; b) Rifqi, Taufik; c) Rifqi, Tawfiq; d) Ami Iraq; e) Ami Irza; f) Amy Erja; g) Ammy Erza; h) Ammy lzza; i) Ami Kusoman; j) Abu Obaida; k) Abu Obaidah; l) Abu Obeida; m) Abu Ubaidah; n) Obaidah; o) Abu Obayda; p) Izza Kusoman; q) Yacub, Eric', '04', 'Rifqi, Tawfiq', 'RIFQI, TAWFIQ', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1097', '20170807', '����췢[2017]106��', '1: TAUFIK 2: RIFKI 3: na 4: na', 'a) Refke, Taufek; b) Rifqi, Taufik; c) Rifqi, Tawfiq; d) Ami Iraq; e) Ami Irza; f) Amy Erja; g) Ammy Erza; h) Ammy lzza; i) Ami Kusoman; j) Abu Obaida; k) Abu Obaidah; l) Abu Obeida; m) Abu Ubaidah; n) Obaidah; o) Abu Obayda; p) Izza Kusoman; q) Yacub, Eric', '04', 'Izza Kusoman', 'IZZA KUSOMAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1098', '20170807', '����췢[2017]106��', '1: TAUFIK 2: RIFKI 3: na 4: na', 'a) Refke, Taufek; b) Rifqi, Taufik; c) Rifqi, Tawfiq; d) Ami Iraq; e) Ami Irza; f) Amy Erja; g) Ammy Erza; h) Ammy lzza; i) Ami Kusoman; j) Abu Obaida; k) Abu Obaidah; l) Abu Obeida; m) Abu Ubaidah; n) Obaidah; o) Abu Obayda; p) Izza Kusoman; q) Yacub, Eric', '04', 'Abu Ubaidah', 'ABU UBAIDAH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1099', '20170807', '����췢[2017]106��', '1: TAUFIK 2: RIFKI 3: na 4: na', 'a) Refke, Taufek; b) Rifqi, Taufik; c) Rifqi, Tawfiq; d) Ami Iraq; e) Ami Irza; f) Amy Erja; g) Ammy Erza; h) Ammy lzza; i) Ami Kusoman; j) Abu Obaida; k) Abu Obaidah; l) Abu Obeida; m) Abu Ubaidah; n) Obaidah; o) Abu Obayda; p) Izza Kusoman; q) Yacub, Eric', '04', 'Rifqi, Taufik', 'RIFQI, TAUFIK', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1100', '20170807', '����췢[2017]106��', '1: TAYEB 2: NAIL 3: na 4: na', 'a) Djaafar Abou Mohamed; b) Abou Mouhadjir; c) Mohamed Ould Ahmed Ould Ali (born in 1976)', '02', 'TAYEB NAIL', 'TAYEB NAIL', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1101', '20170807', '����췢[2017]106��', '1: TAYEB 2: NAIL 3: na 4: na', 'a) Djaafar Abou Mohamed; b) Abou Mouhadjir; c) Mohamed Ould Ahmed Ould Ali (born in 1976)', '04', 'Abou Mouhadjir', 'ABOU MOUHADJIR', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1102', '20170807', '����췢[2017]106��', '1: TAYEB 2: NAIL 3: na 4: na', 'a) Djaafar Abou Mohamed; b) Abou Mouhadjir; c) Mohamed Ould Ahmed Ould Ali (born in 1976)', '04', 'Mohamed Ould Ahmed Ould Ali', 'MOHAMED OULD AHMED OULD ALI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1103', '20170807', '����췢[2017]106��', '1: TAYEB 2: NAIL 3: na 4: na', 'a) Djaafar Abou Mohamed; b) Abou Mouhadjir; c) Mohamed Ould Ahmed Ould Ali (born in 1976)', '04', 'Djaafar Abou Mohamed', 'DJAAFAR ABOU MOHAMED', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1104', '20170807', '����췢[2017]106��', '1: THARWAT 2: SALAH 3: SHIHATA 4: na', 'a) Tarwat Salah Abdallah; b) Salah Shihata Thirwat; c) Shahata Thirwat; d) Tharwat Salah Shihata Ali', '02', 'THARWAT SALAH', 'THARWAT SALAH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1105', '20170807', '����췢[2017]106��', '1: THARWAT 2: SALAH 3: SHIHATA 4: na', 'a) Tarwat Salah Abdallah; b) Salah Shihata Thirwat; c) Shahata Thirwat; d) Tharwat Salah Shihata Ali', '04', 'Salah Shihata Thirwat', 'SALAH SHIHATA THIRWAT', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1106', '20170807', '����췢[2017]106��', '1: THARWAT 2: SALAH 3: SHIHATA 4: na', 'a) Tarwat Salah Abdallah; b) Salah Shihata Thirwat; c) Shahata Thirwat; d) Tharwat Salah Shihata Ali', '04', 'Shahata Thirwat', 'SHAHATA THIRWAT', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1107', '20170807', '����췢[2017]106��', '1: THARWAT 2: SALAH 3: SHIHATA 4: na', 'a) Tarwat Salah Abdallah; b) Salah Shihata Thirwat; c) Shahata Thirwat; d) Tharwat Salah Shihata Ali', '04', 'Tharwat Salah Shihata Ali', 'THARWAT SALAH SHIHATA ALI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1108', '20170807', '����췢[2017]106��', '1: THARWAT 2: SALAH 3: SHIHATA 4: na', 'a) Tarwat Salah Abdallah; b) Salah Shihata Thirwat; c) Shahata Thirwat; d) Tharwat Salah Shihata Ali', '04', 'Tarwat Salah Abdallah', 'TARWAT SALAH ABDALLAH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1109', '20170807', '����췢[2017]106��', '1: TUAH 2: FEBRIWANSYAH 3: na 4: na', 'a) Tuah Febriwansyah bin Arif Hasrudin; b) Tuwah Febriwansah; c) Muhammad Fachri; d) Muhamad Fachria; e) Muhammad Fachry', '02', 'TUAH FEBRIWANSYAH', 'TUAH FEBRIWANSYAH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1110', '20170807', '����췢[2017]106��', '1: TUAH 2: FEBRIWANSYAH 3: na 4: na', 'a) Tuah Febriwansyah bin Arif Hasrudin; b) Tuwah Febriwansah; c) Muhammad Fachri; d) Muhamad Fachria; e) Muhammad Fachry', '04', 'Muhamad Fachria', 'MUHAMAD FACHRIA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1111', '20170807', '����췢[2017]106��', '1: TUAH 2: FEBRIWANSYAH 3: na 4: na', 'a) Tuah Febriwansyah bin Arif Hasrudin; b) Tuwah Febriwansah; c) Muhammad Fachri; d) Muhamad Fachria; e) Muhammad Fachry', '04', 'Muhammad Fachry', 'MUHAMMAD FACHRY', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1112', '20170807', '����췢[2017]106��', '1: TUAH 2: FEBRIWANSYAH 3: na 4: na', 'a) Tuah Febriwansyah bin Arif Hasrudin; b) Tuwah Febriwansah; c) Muhammad Fachri; d) Muhamad Fachria; e) Muhammad Fachry', '04', 'Muhammad Fachri', 'MUHAMMAD FACHRI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1113', '20170807', '����췢[2017]106��', '1: TUAH 2: FEBRIWANSYAH 3: na 4: na', 'a) Tuah Febriwansyah bin Arif Hasrudin; b) Tuwah Febriwansah; c) Muhammad Fachri; d) Muhamad Fachria; e) Muhammad Fachry', '04', 'Tuah Febriwansyah bin Arif Hasrudin', 'TUAH FEBRIWANSYAH BIN ARIF HASRUDIN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1114', '20170807', '����췢[2017]106��', '1: TUAH 2: FEBRIWANSYAH 3: na 4: na', 'a) Tuah Febriwansyah bin Arif Hasrudin; b) Tuwah Febriwansah; c) Muhammad Fachri; d) Muhamad Fachria; e) Muhammad Fachry', '04', 'Tuwah Febriwansah', 'TUWAH FEBRIWANSAH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1115', '20170807', '����췢[2017]106��', '1: TURKI 2: MUBARAK 3: ABDULLAH 4: AHMAD AL-BINALI', 'a) Turki Mubarak Abdullah Al Binali; b) Turki Mubarak al-Binali; c) Turki al-Benali; d) Turki al-Binali', '02', 'TURKI MUBARAK', 'TURKI MUBARAK', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1116', '20170807', '����췢[2017]106��', '1: TURKI 2: MUBARAK 3: ABDULLAH 4: AHMAD AL-BINALI', 'a) Turki Mubarak Abdullah Al Binali; b) Turki Mubarak al-Binali; c) Turki al-Benali; d) Turki al-Binali', '04', 'Turki Mubarak al-Binali', 'TURKI MUBARAK AL-BINALI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1117', '20170807', '����췢[2017]106��', '1: TURKI 2: MUBARAK 3: ABDULLAH 4: AHMAD AL-BINALI', 'a) Turki Mubarak Abdullah Al Binali; b) Turki Mubarak al-Binali; c) Turki al-Benali; d) Turki al-Binali', '04', 'Turki al-Binali', 'TURKI AL-BINALI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1118', '20170807', '����췢[2017]106��', '1: TURKI 2: MUBARAK 3: ABDULLAH 4: AHMAD AL-BINALI', 'a) Turki Mubarak Abdullah Al Binali; b) Turki Mubarak al-Binali; c) Turki al-Benali; d) Turki al-Binali', '04', 'Turki Mubarak Abdullah Al Binali', 'TURKI MUBARAK ABDULLAH AL BINALI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1119', '20170807', '����췢[2017]106��', '1: TURKI 2: MUBARAK 3: ABDULLAH 4: AHMAD AL-BINALI', 'a) Turki Mubarak Abdullah Al Binali; b) Turki Mubarak al-Binali; c) Turki al-Benali; d) Turki al-Binali', '04', 'Turki al-Benali', 'TURKI AL-BENALI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1120', '20170807', '����췢[2017]106��', '1: UMAR 2: PATEK 3: na 4: na', 'a) Omar Patek; b) Mike Arsalan; c) Hisyam Bin Zein; d) Anis Alawi Jafar', '02', 'UMAR PATEK', 'UMAR PATEK', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1121', '20170807', '����췢[2017]106��', '1: UMAR 2: PATEK 3: na 4: na', 'a) Omar Patek; b) Mike Arsalan; c) Hisyam Bin Zein; d) Anis Alawi Jafar', '04', 'Anis Alawi Jafar', 'ANIS ALAWI JAFAR', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1122', '20170807', '����췢[2017]106��', '1: UMAR 2: PATEK 3: na 4: na', 'a) Omar Patek; b) Mike Arsalan; c) Hisyam Bin Zein; d) Anis Alawi Jafar', '04', 'Hisyam Bin Zein', 'HISYAM BIN ZEIN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1123', '20170807', '����췢[2017]106��', '1: UMAR 2: PATEK 3: na 4: na', 'a) Omar Patek; b) Mike Arsalan; c) Hisyam Bin Zein; d) Anis Alawi Jafar', '04', 'Omar Patek', 'OMAR PATEK', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1124', '20170807', '����췢[2017]106��', '1: UMAR 2: PATEK 3: na 4: na', 'a) Omar Patek; b) Mike Arsalan; c) Hisyam Bin Zein; d) Anis Alawi Jafar', '04', 'Mike Arsalan', 'MIKE ARSALAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1125', '20170807', '����췢[2017]106��', '1: WIJI 2: JOKO 3: SANTOSO 4: na', 'a) Wijijoko Santoso born 14 Jul. 1975 in Rembang, Jawa Tengah, Indonesia', '02', 'WIJI JOKO', 'WIJI JOKO', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1126', '20170807', '����췢[2017]106��', '1: WIJI 2: JOKO 3: SANTOSO 4: na', 'a) Wijijoko Santoso born 14 Jul. 1975 in Rembang, Jawa Tengah, Indonesia', '03', 'Wijijoko Santoso born 14 Jul. 1975 in Rembang, Jawa Tengah, Indonesia', 'WIJIJOKO SANTOSO BORN 14 JUL. 1975 IN REMBANG, JAWA TENGAH, INDONESIA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1127', '20170807', '����췢[2017]106��', '1: YAHIA 2: DJOUADI 3: na 4: na', 'a) Yahia Abou Amrnar; b) Abou Ala', '02', 'YAHIA DJOUADI', 'YAHIA DJOUADI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1128', '20170807', '����췢[2017]106��', '1: YAHIA 2: DJOUADI 3: na 4: na', 'a) Yahia Abou Amrnar; b) Abou Ala', '04', 'Abou Ala', 'ABOU ALA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1129', '20170807', '����췢[2017]106��', '1: YAHIA 2: DJOUADI 3: na 4: na', 'a) Yahia Abou Amrnar; b) Abou Ala', '04', 'Yahia Abou Amrnar', 'YAHIA ABOU AMRNAR', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1130', '20170807', '����췢[2017]106��', '1: YASSIN 2: CHOUKA 3: na 4: na', null, '02', 'YASSIN CHOUKA', 'YASSIN CHOUKA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1131', '20170807', '����췢[2017]106��', '1: YASSIN 2: SYAWAL 3: na 4: na', 'a) Salim Yasin; b) Yasin Mahmud Mochtar; c) Abdul Hadi Yasin; d) Muhamad Mubarok; e) Muhammad Syawal; f) Yassin Sywal ', '02', 'YASSIN SYAWAL', 'YASSIN SYAWAL', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1132', '20170807', '����췢[2017]106��', '1: YASSIN 2: SYAWAL 3: na 4: na', 'a) Salim Yasin; b) Yasin Mahmud Mochtar; c) Abdul Hadi Yasin; d) Muhamad Mubarok; e) Muhammad Syawal; f) Yassin Sywal ', '04', 'Yasin Mahmud Mochtar', 'YASIN MAHMUD MOCHTAR', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1133', '20170807', '����췢[2017]106��', '1: YASSIN 2: SYAWAL 3: na 4: na', 'a) Salim Yasin; b) Yasin Mahmud Mochtar; c) Abdul Hadi Yasin; d) Muhamad Mubarok; e) Muhammad Syawal; f) Yassin Sywal ', '04', 'Yassin Sywal', 'YASSIN SYWAL', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1134', '20170807', '����췢[2017]106��', '1: YASSIN 2: SYAWAL 3: na 4: na', 'a) Salim Yasin; b) Yasin Mahmud Mochtar; c) Abdul Hadi Yasin; d) Muhamad Mubarok; e) Muhammad Syawal; f) Yassin Sywal ', '04', 'Salim Yasin', 'SALIM YASIN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1135', '20170807', '����췢[2017]106��', '1: YASSIN 2: SYAWAL 3: na 4: na', 'a) Salim Yasin; b) Yasin Mahmud Mochtar; c) Abdul Hadi Yasin; d) Muhamad Mubarok; e) Muhammad Syawal; f) Yassin Sywal ', '04', 'Abdul Hadi Yasin', 'ABDUL HADI YASIN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1136', '20170807', '����췢[2017]106��', '1: YASSIN 2: SYAWAL 3: na 4: na', 'a) Salim Yasin; b) Yasin Mahmud Mochtar; c) Abdul Hadi Yasin; d) Muhamad Mubarok; e) Muhammad Syawal; f) Yassin Sywal ', '04', 'Muhammad Syawal', 'MUHAMMAD SYAWAL', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1137', '20170807', '����췢[2017]106��', '1: YASSIN 2: SYAWAL 3: na 4: na', 'a) Salim Yasin; b) Yasin Mahmud Mochtar; c) Abdul Hadi Yasin; d) Muhamad Mubarok; e) Muhammad Syawal; f) Yassin Sywal ', '04', 'Muhamad Mubarok', 'MUHAMAD MUBAROK', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1138', '20170807', '����췢[2017]106��', '1: YASSINE 2: CHEKKOURI 3: na 4: na', null, '02', 'YASSINE CHEKKOURI', 'YASSINE CHEKKOURI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1139', '20170807', '����췢[2017]106��', '1: YAZID 2: SUFAAT 3: na 4: na', null, '02', 'YAZID SUFAAT', 'YAZID SUFAAT', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1140', '20170807', '����췢[2017]106��', '1: YUNOS 2: UMPARA 3: MOKLIS 4: na', 'a) Muklis Yunos; b) Mukhlis Yunos; c) Saifullah Mukhlis Yunos; d) Saifulla Moklis Yunos', '02', 'YUNOS UMPARA', 'YUNOS UMPARA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1141', '20170807', '����췢[2017]106��', '1: YUNOS 2: UMPARA 3: MOKLIS 4: na', 'a) Muklis Yunos; b) Mukhlis Yunos; c) Saifullah Mukhlis Yunos; d) Saifulla Moklis Yunos', '04', 'Saifullah Mukhlis Yunos', 'SAIFULLAH MUKHLIS YUNOS', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1142', '20170807', '����췢[2017]106��', '1: YUNOS 2: UMPARA 3: MOKLIS 4: na', 'a) Muklis Yunos; b) Mukhlis Yunos; c) Saifullah Mukhlis Yunos; d) Saifulla Moklis Yunos', '04', 'Mukhlis Yunos', 'MUKHLIS YUNOS', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1143', '20170807', '����췢[2017]106��', '1: YUNOS 2: UMPARA 3: MOKLIS 4: na', 'a) Muklis Yunos; b) Mukhlis Yunos; c) Saifullah Mukhlis Yunos; d) Saifulla Moklis Yunos', '04', 'Muklis Yunos', 'MUKLIS YUNOS', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1144', '20170807', '����췢[2017]106��', '1: YUNOS 2: UMPARA 3: MOKLIS 4: na', 'a) Muklis Yunos; b) Mukhlis Yunos; c) Saifullah Mukhlis Yunos; d) Saifulla Moklis Yunos', '04', 'Saifulla Moklis Yunos', 'SAIFULLA MOKLIS YUNOS', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1145', '20170807', '����췢[2017]106��', '1: ZAFAR 2: IQBAL 3: na 4: na', 'a) Zaffer Iqbal; b) Malik Zafar Iqbal Shehbaz; c) Malik Zafar Iqbal Shahbaz; d) Malik Zafar Iqbal ', '02', 'ZAFAR IQBAL', 'ZAFAR IQBAL', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1146', '20170807', '����췢[2017]106��', '1: ZAFAR 2: IQBAL 3: na 4: na', 'a) Zaffer Iqbal; b) Malik Zafar Iqbal Shehbaz; c) Malik Zafar Iqbal Shahbaz; d) Malik Zafar Iqbal ', '04', 'Malik Zafar Iqbal Shahbaz', 'MALIK ZAFAR IQBAL SHAHBAZ', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1147', '20170807', '����췢[2017]106��', '1: ZAFAR 2: IQBAL 3: na 4: na', 'a) Zaffer Iqbal; b) Malik Zafar Iqbal Shehbaz; c) Malik Zafar Iqbal Shahbaz; d) Malik Zafar Iqbal ', '04', 'Malik Zafar Iqbal Shehbaz', 'MALIK ZAFAR IQBAL SHEHBAZ', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1148', '20170807', '����췢[2017]106��', '1: ZAFAR 2: IQBAL 3: na 4: na', 'a) Zaffer Iqbal; b) Malik Zafar Iqbal Shehbaz; c) Malik Zafar Iqbal Shahbaz; d) Malik Zafar Iqbal ', '04', 'Malik Zafar Iqbal', 'MALIK ZAFAR IQBAL', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1149', '20170807', '����췢[2017]106��', '1: ZAFAR 2: IQBAL 3: na 4: na', 'a) Zaffer Iqbal; b) Malik Zafar Iqbal Shehbaz; c) Malik Zafar Iqbal Shahbaz; d) Malik Zafar Iqbal ', '04', 'Zaffer Iqbal', 'ZAFFER IQBAL', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1150', '20170807', '����췢[2017]106��', '1: ZAKARYA 2: ESSABAR 3: na 4: na', 'a) Zakariya Essabar', '02', 'ZAKARYA ESSABAR', 'ZAKARYA ESSABAR', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1151', '20170807', '����췢[2017]106��', '1: ZAKARYA 2: ESSABAR 3: na 4: na', 'a) Zakariya Essabar', '03', 'Zakariya Essabar', 'ZAKARIYA ESSABAR', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1152', '20170807', '����췢[2017]106��', '1: ZAKI 2: EZAT 3: ZAKI 4: AHMED', 'a) Rifat Salim; b) Abu Usama', '02', 'ZAKI EZAT', 'ZAKI EZAT', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1153', '20170807', '����췢[2017]106��', '1: ZAKI 2: EZAT 3: ZAKI 4: AHMED', 'a) Rifat Salim; b) Abu Usama', '04', 'Abu Usama', 'ABU USAMA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1154', '20170807', '����췢[2017]106��', '1: ZAKI 2: EZAT 3: ZAKI 4: AHMED', 'a) Rifat Salim; b) Abu Usama', '04', 'Rifat Salim', 'RIFAT SALIM', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1155', '20170807', '����췢[2017]106��', '1: ZAKI-UR-REHMAN 2: LAKHVI 3: na 4: na', 'a) Zakir Rehman Lakvi; b) Zaki Ur-Rehman Lakvi; c) Kaki Ur-Rehman; d) Zakir Rehman; e) Abu Waheed Irshad Ahmad Arshad', '02', 'ZAKI-UR-REHMAN LAKHVI', 'ZAKI-UR-REHMAN LAKHVI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1156', '20170807', '����췢[2017]106��', '1: ZAKI-UR-REHMAN 2: LAKHVI 3: na 4: na', 'a) Zakir Rehman Lakvi; b) Zaki Ur-Rehman Lakvi; c) Kaki Ur-Rehman; d) Zakir Rehman; e) Abu Waheed Irshad Ahmad Arshad', '04', 'Zakir Rehman Lakvi', 'ZAKIR REHMAN LAKVI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1157', '20170807', '����췢[2017]106��', '1: ZAKI-UR-REHMAN 2: LAKHVI 3: na 4: na', 'a) Zakir Rehman Lakvi; b) Zaki Ur-Rehman Lakvi; c) Kaki Ur-Rehman; d) Zakir Rehman; e) Abu Waheed Irshad Ahmad Arshad', '04', 'Zaki Ur-Rehman Lakvi', 'ZAKI UR-REHMAN LAKVI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1158', '20170807', '����췢[2017]106��', '1: ZAKI-UR-REHMAN 2: LAKHVI 3: na 4: na', 'a) Zakir Rehman Lakvi; b) Zaki Ur-Rehman Lakvi; c) Kaki Ur-Rehman; d) Zakir Rehman; e) Abu Waheed Irshad Ahmad Arshad', '04', 'Zakir Rehman', 'ZAKIR REHMAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1159', '20170807', '����췢[2017]106��', '1: ZAKI-UR-REHMAN 2: LAKHVI 3: na 4: na', 'a) Zakir Rehman Lakvi; b) Zaki Ur-Rehman Lakvi; c) Kaki Ur-Rehman; d) Zakir Rehman; e) Abu Waheed Irshad Ahmad Arshad', '04', 'Abu Waheed Irshad Ahmad Arshad', 'ABU WAHEED IRSHAD AHMAD ARSHAD', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1160', '20170807', '����췢[2017]106��', '1: ZAKI-UR-REHMAN 2: LAKHVI 3: na 4: na', 'a) Zakir Rehman Lakvi; b) Zaki Ur-Rehman Lakvi; c) Kaki Ur-Rehman; d) Zakir Rehman; e) Abu Waheed Irshad Ahmad Arshad', '04', 'Kaki Ur-Rehman', 'KAKI UR-REHMAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1161', '20170807', '����췢[2017]106��', '1: ZAURBEK 2: SALIMOVICH 3: GUCHAEV 4: na', null, '02', 'ZAURBEK SALIMOVICH', 'ZAURBEK SALIMOVICH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1162', '20170807', '����췢[2017]106��', '1: ZAYN 2: AL-ABIDIN 3: MUHAMMAD 4: HUSSEIN', 'a) Abd Al-Hadi Al-Wahab; b) Zain Al-Abidin Muhammad Husain; c) Zayn Al-Abidin Muhammad Husayn; d) Zeinulabideen Muhammed Husein Abu Zubeidah', '02', 'ZAYN AL-ABIDIN', 'ZAYN AL-ABIDIN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1163', '20170807', '����췢[2017]106��', '1: ZAYN 2: AL-ABIDIN 3: MUHAMMAD 4: HUSSEIN', 'a) Abd Al-Hadi Al-Wahab; b) Zain Al-Abidin Muhammad Husain; c) Zayn Al-Abidin Muhammad Husayn; d) Zeinulabideen Muhammed Husein Abu Zubeidah', '04', 'Abd Al-Hadi Al-Wahab', 'ABD AL-HADI AL-WAHAB', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1164', '20170807', '����췢[2017]106��', '1: ZAYN 2: AL-ABIDIN 3: MUHAMMAD 4: HUSSEIN', 'a) Abd Al-Hadi Al-Wahab; b) Zain Al-Abidin Muhammad Husain; c) Zayn Al-Abidin Muhammad Husayn; d) Zeinulabideen Muhammed Husein Abu Zubeidah', '04', 'Zain Al-Abidin Muhammad Husain', 'ZAIN AL-ABIDIN MUHAMMAD HUSAIN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1165', '20170807', '����췢[2017]106��', '1: ZAYN 2: AL-ABIDIN 3: MUHAMMAD 4: HUSSEIN', 'a) Abd Al-Hadi Al-Wahab; b) Zain Al-Abidin Muhammad Husain; c) Zayn Al-Abidin Muhammad Husayn; d) Zeinulabideen Muhammed Husein Abu Zubeidah', '04', 'Zayn Al-Abidin Muhammad Husayn', 'ZAYN AL-ABIDIN MUHAMMAD HUSAYN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1166', '20170807', '����췢[2017]106��', '1: ZAYN 2: AL-ABIDIN 3: MUHAMMAD 4: HUSSEIN', 'a) Abd Al-Hadi Al-Wahab; b) Zain Al-Abidin Muhammad Husain; c) Zayn Al-Abidin Muhammad Husayn; d) Zeinulabideen Muhammed Husein Abu Zubeidah', '04', 'Zeinulabideen Muhammed Husein Abu Zubeidah', 'ZEINULABIDEEN MUHAMMED HUSEIN ABU ZUBEIDAH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1167', '20170807', '����췢[2017]106��', '1: ZULKARNAEN 2: na 3: na 4: na', 'a) Zulkarnan; b) Zulkarnain; c) Zulkamin; d) Arif Sunarso; e) Aris Sumarsono; f) Aris Sunarso; g) Ustad Daud Zulkarnaen; h) Murshid', '02', 'ZULKARNAEN', 'ZULKARNAEN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1168', '20170807', '����췢[2017]106��', '1: ZULKARNAEN 2: na 3: na 4: na', 'a) Zulkarnan; b) Zulkarnain; c) Zulkamin; d) Arif Sunarso; e) Aris Sumarsono; f) Aris Sunarso; g) Ustad Daud Zulkarnaen; h) Murshid', '04', 'Zulkarnan', 'ZULKARNAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1169', '20170807', '����췢[2017]106��', '1: ZULKARNAEN 2: na 3: na 4: na', 'a) Zulkarnan; b) Zulkarnain; c) Zulkamin; d) Arif Sunarso; e) Aris Sumarsono; f) Aris Sunarso; g) Ustad Daud Zulkarnaen; h) Murshid', '04', 'Zulkarnain', 'ZULKARNAIN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1170', '20170807', '����췢[2017]106��', '1: ZULKARNAEN 2: na 3: na 4: na', 'a) Zulkarnan; b) Zulkarnain; c) Zulkamin; d) Arif Sunarso; e) Aris Sumarsono; f) Aris Sunarso; g) Ustad Daud Zulkarnaen; h) Murshid', '04', 'Zulkamin', 'ZULKAMIN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1171', '20170807', '����췢[2017]106��', '1: ZULKARNAEN 2: na 3: na 4: na', 'a) Zulkarnan; b) Zulkarnain; c) Zulkamin; d) Arif Sunarso; e) Aris Sumarsono; f) Aris Sunarso; g) Ustad Daud Zulkarnaen; h) Murshid', '04', 'Murshid', 'MURSHID', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1172', '20170807', '����췢[2017]106��', '1: ZULKARNAEN 2: na 3: na 4: na', 'a) Zulkarnan; b) Zulkarnain; c) Zulkamin; d) Arif Sunarso; e) Aris Sumarsono; f) Aris Sunarso; g) Ustad Daud Zulkarnaen; h) Murshid', '04', 'Aris Sumarsono', 'ARIS SUMARSONO', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1173', '20170807', '����췢[2017]106��', '1: ZULKARNAEN 2: na 3: na 4: na', 'a) Zulkarnan; b) Zulkarnain; c) Zulkamin; d) Arif Sunarso; e) Aris Sumarsono; f) Aris Sunarso; g) Ustad Daud Zulkarnaen; h) Murshid', '04', 'Aris Sunarso', 'ARIS SUNARSO', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1174', '20170807', '����췢[2017]106��', '1: ZULKARNAEN 2: na 3: na 4: na', 'a) Zulkarnan; b) Zulkarnain; c) Zulkamin; d) Arif Sunarso; e) Aris Sumarsono; f) Aris Sunarso; g) Ustad Daud Zulkarnaen; h) Murshid', '04', 'Ustad Daud Zulkarnaen', 'USTAD DAUD ZULKARNAEN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1175', '20170807', '����췢[2017]106��', '1: ZULKARNAEN 2: na 3: na 4: na', 'a) Zulkarnan; b) Zulkarnain; c) Zulkamin; d) Arif Sunarso; e) Aris Sumarsono; f) Aris Sunarso; g) Ustad Daud Zulkarnaen; h) Murshid', '04', 'Arif Sunarso', 'ARIF SUNARSO', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1176', '20170807', '����췢[2017]106��', '1: ZULKIFLI 2: ABDUL HIR 3: na 4: na', 'a) Musa Abdul Hir; b) Muslimin Abdulmotalib; c) Salim Alombra; d) Armand Escalante; e) Normina Hashim; f) Henri Lawi; g) Hendri Lawi; h) Norhana Mohamad; i) Omar Salem; j) Ahmad Shobirin; k) Bin Abdul Hir Zulkifli', '02', 'ZULKIFLI ABDUL HIR', 'ZULKIFLI ABDUL HIR', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1177', '20170807', '����췢[2017]106��', '1: ZULKIFLI 2: ABDUL HIR 3: na 4: na', 'a) Musa Abdul Hir; b) Muslimin Abdulmotalib; c) Salim Alombra; d) Armand Escalante; e) Normina Hashim; f) Henri Lawi; g) Hendri Lawi; h) Norhana Mohamad; i) Omar Salem; j) Ahmad Shobirin; k) Bin Abdul Hir Zulkifli', '04', 'Muslimin Abdulmotalib', 'MUSLIMIN ABDULMOTALIB', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1178', '20170807', '����췢[2017]106��', '1: ZULKIFLI 2: ABDUL HIR 3: na 4: na', 'a) Musa Abdul Hir; b) Muslimin Abdulmotalib; c) Salim Alombra; d) Armand Escalante; e) Normina Hashim; f) Henri Lawi; g) Hendri Lawi; h) Norhana Mohamad; i) Omar Salem; j) Ahmad Shobirin; k) Bin Abdul Hir Zulkifli', '04', 'Omar Salem', 'OMAR SALEM', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1179', '20170807', '����췢[2017]106��', '1: ZULKIFLI 2: ABDUL HIR 3: na 4: na', 'a) Musa Abdul Hir; b) Muslimin Abdulmotalib; c) Salim Alombra; d) Armand Escalante; e) Normina Hashim; f) Henri Lawi; g) Hendri Lawi; h) Norhana Mohamad; i) Omar Salem; j) Ahmad Shobirin; k) Bin Abdul Hir Zulkifli', '04', 'Musa Abdul Hir', 'MUSA ABDUL HIR', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1180', '20170807', '����췢[2017]106��', '1: ZULKIFLI 2: ABDUL HIR 3: na 4: na', 'a) Musa Abdul Hir; b) Muslimin Abdulmotalib; c) Salim Alombra; d) Armand Escalante; e) Normina Hashim; f) Henri Lawi; g) Hendri Lawi; h) Norhana Mohamad; i) Omar Salem; j) Ahmad Shobirin; k) Bin Abdul Hir Zulkifli', '04', 'Norhana Mohamad', 'NORHANA MOHAMAD', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1181', '20170807', '����췢[2017]106��', '1: ZULKIFLI 2: ABDUL HIR 3: na 4: na', 'a) Musa Abdul Hir; b) Muslimin Abdulmotalib; c) Salim Alombra; d) Armand Escalante; e) Normina Hashim; f) Henri Lawi; g) Hendri Lawi; h) Norhana Mohamad; i) Omar Salem; j) Ahmad Shobirin; k) Bin Abdul Hir Zulkifli', '04', 'Ahmad Shobirin', 'AHMAD SHOBIRIN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1182', '20170807', '����췢[2017]106��', '1: ZULKIFLI 2: ABDUL HIR 3: na 4: na', 'a) Musa Abdul Hir; b) Muslimin Abdulmotalib; c) Salim Alombra; d) Armand Escalante; e) Normina Hashim; f) Henri Lawi; g) Hendri Lawi; h) Norhana Mohamad; i) Omar Salem; j) Ahmad Shobirin; k) Bin Abdul Hir Zulkifli', '04', 'Henri Lawi', 'HENRI LAWI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1183', '20170807', '����췢[2017]106��', '1: ZULKIFLI 2: ABDUL HIR 3: na 4: na', 'a) Musa Abdul Hir; b) Muslimin Abdulmotalib; c) Salim Alombra; d) Armand Escalante; e) Normina Hashim; f) Henri Lawi; g) Hendri Lawi; h) Norhana Mohamad; i) Omar Salem; j) Ahmad Shobirin; k) Bin Abdul Hir Zulkifli', '04', 'Normina Hashim', 'NORMINA HASHIM', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1184', '20170807', '����췢[2017]106��', '1: ZULKIFLI 2: ABDUL HIR 3: na 4: na', 'a) Musa Abdul Hir; b) Muslimin Abdulmotalib; c) Salim Alombra; d) Armand Escalante; e) Normina Hashim; f) Henri Lawi; g) Hendri Lawi; h) Norhana Mohamad; i) Omar Salem; j) Ahmad Shobirin; k) Bin Abdul Hir Zulkifli', '04', 'Armand Escalante', 'ARMAND ESCALANTE', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1185', '20170807', '����췢[2017]106��', '1: ZULKIFLI 2: ABDUL HIR 3: na 4: na', 'a) Musa Abdul Hir; b) Muslimin Abdulmotalib; c) Salim Alombra; d) Armand Escalante; e) Normina Hashim; f) Henri Lawi; g) Hendri Lawi; h) Norhana Mohamad; i) Omar Salem; j) Ahmad Shobirin; k) Bin Abdul Hir Zulkifli', '04', 'Salim Alombra', 'SALIM ALOMBRA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1186', '20170807', '����췢[2017]106��', '1: ZULKIFLI 2: ABDUL HIR 3: na 4: na', 'a) Musa Abdul Hir; b) Muslimin Abdulmotalib; c) Salim Alombra; d) Armand Escalante; e) Normina Hashim; f) Henri Lawi; g) Hendri Lawi; h) Norhana Mohamad; i) Omar Salem; j) Ahmad Shobirin; k) Bin Abdul Hir Zulkifli', '04', 'Bin Abdul Hir Zulkifli', 'BIN ABDUL HIR ZULKIFLI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1187', '20170807', '����췢[2017]106��', '1: ZULKIFLI 2: ABDUL HIR 3: na 4: na', 'a) Musa Abdul Hir; b) Muslimin Abdulmotalib; c) Salim Alombra; d) Armand Escalante; e) Normina Hashim; f) Henri Lawi; g) Hendri Lawi; h) Norhana Mohamad; i) Omar Salem; j) Ahmad Shobirin; k) Bin Abdul Hir Zulkifli', '04', 'Hendri Lawi', 'HENDRI LAWI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1188', '20170807', '����췢[2017]106��', 'ABDALLAH AZZAM BRIGADES (ABB)', 'a) Abdullah Azzam Brigades; b) Ziyad al-Jarrah Battalions of the Abdallah Azzam Brigades; c) Yusuf al-Uyayri Battalions of the Abdallah Azzam Brigades', '01', 'ABDALLAH AZZAM BRIGADES (ABB)', 'ABDALLAH AZZAM BRIGADES (ABB)', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1189', '20170807', '����췢[2017]106��', 'ABDALLAH AZZAM BRIGADES (ABB)', 'a) Abdullah Azzam Brigades; b) Ziyad al-Jarrah Battalions of the Abdallah Azzam Brigades; c) Yusuf al-Uyayri Battalions of the Abdallah Azzam Brigades', '04', 'Abdullah Azzam Brigades', 'ABDULLAH AZZAM BRIGADES', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1190', '20170807', '����췢[2017]106��', 'ABDALLAH AZZAM BRIGADES (ABB)', 'a) Abdullah Azzam Brigades; b) Ziyad al-Jarrah Battalions of the Abdallah Azzam Brigades; c) Yusuf al-Uyayri Battalions of the Abdallah Azzam Brigades', '04', 'Ziyad al-Jarrah Battalions of the Abdallah Azzam Brigades', 'ZIYAD AL-JARRAH BATTALIONS OF THE ABDALLAH AZZAM BRIGADES', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1191', '20170807', '����췢[2017]106��', 'ABDALLAH AZZAM BRIGADES (ABB)', 'a) Abdullah Azzam Brigades; b) Ziyad al-Jarrah Battalions of the Abdallah Azzam Brigades; c) Yusuf al-Uyayri Battalions of the Abdallah Azzam Brigades', '04', 'Yusuf al-Uyayri Battalions of the Abdallah Azzam Brigades', 'YUSUF AL-UYAYRI BATTALIONS OF THE ABDALLAH AZZAM BRIGADES', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1192', '20170807', '����췢[2017]106��', 'ABU SAYYAF GROUP', 'a) Al Harakat Al Islamiyya', '01', 'ABU SAYYAF GROUP', 'ABU SAYYAF GROUP', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1193', '20170807', '����췢[2017]106��', 'ABU SAYYAF GROUP', 'a) Al Harakat Al Islamiyya', '03', 'Al Harakat Al Islamiyya', 'AL HARAKAT AL ISLAMIYYA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1194', '20170807', '����췢[2017]106��', 'AFGHAN SUPPORT COMMITTEE (ASC)', 'a) Lajnat ul Masa Eidatul Afghania; b) Jamiat Ayat-ur-Rhas al Islamiac; c) Jamiat Ihya ul Turath al Islamia; d) Ahya ul Turas', '01', 'AFGHAN SUPPORT COMMITTEE (ASC)', 'AFGHAN SUPPORT COMMITTEE (ASC)', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1195', '20170807', '����췢[2017]106��', 'AFGHAN SUPPORT COMMITTEE (ASC)', 'a) Lajnat ul Masa Eidatul Afghania; b) Jamiat Ayat-ur-Rhas al Islamiac; c) Jamiat Ihya ul Turath al Islamia; d) Ahya ul Turas', '04', 'Lajnat ul Masa Eidatul Afghania', 'LAJNAT UL MASA EIDATUL AFGHANIA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1196', '20170807', '����췢[2017]106��', 'AFGHAN SUPPORT COMMITTEE (ASC)', 'a) Lajnat ul Masa Eidatul Afghania; b) Jamiat Ayat-ur-Rhas al Islamiac; c) Jamiat Ihya ul Turath al Islamia; d) Ahya ul Turas', '04', 'Jamiat Ayat-ur-Rhas al Islamiac', 'JAMIAT AYAT-UR-RHAS AL ISLAMIAC', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1197', '20170807', '����췢[2017]106��', 'AFGHAN SUPPORT COMMITTEE (ASC)', 'a) Lajnat ul Masa Eidatul Afghania; b) Jamiat Ayat-ur-Rhas al Islamiac; c) Jamiat Ihya ul Turath al Islamia; d) Ahya ul Turas', '04', 'Ahya ul Turas', 'AHYA UL TURAS', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1198', '20170807', '����췢[2017]106��', 'AFGHAN SUPPORT COMMITTEE (ASC)', 'a) Lajnat ul Masa Eidatul Afghania; b) Jamiat Ayat-ur-Rhas al Islamiac; c) Jamiat Ihya ul Turath al Islamia; d) Ahya ul Turas', '04', 'Jamiat Ihya ul Turath al Islamia', 'JAMIAT IHYA UL TURATH AL ISLAMIA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1199', '20170807', '����췢[2017]106��', 'AL FURQAN', 'a) Dzemilijati Furkan; b) Dzem ijjetul Furqan; c) Association for Citizens Rights and Resistance to Lies; d) Dzemijetul Furkan; e) Association of Citizens for the Support of Truth and Supression of Lies; f) Sirat; g) Association for Education, Culture and Building Society-Sirat; h) Association for Education, Culture, and to Create Society-Sirat; i) Istikamet; j) In Siratel; k) Citizens'' Association for Support and Prevention of lies-Furqan', '01', 'AL FURQAN', 'AL FURQAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1200', '20170807', '����췢[2017]106��', 'AL FURQAN', 'a) Dzemilijati Furkan; b) Dzem ijjetul Furqan; c) Association for Citizens Rights and Resistance to Lies; d) Dzemijetul Furkan; e) Association of Citizens for the Support of Truth and Supression of Lies; f) Sirat; g) Association for Education, Culture and Building Society-Sirat; h) Association for Education, Culture, and to Create Society-Sirat; i) Istikamet; j) In Siratel; k) Citizens'' Association for Support and Prevention of lies-Furqan', '04', 'Citizens'' Association for Support and Prevention of lies-Furqan', 'CITIZENS'' ASSOCIATION FOR SUPPORT AND PREVENTION OF LIES-FURQAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1201', '20170807', '����췢[2017]106��', 'AL FURQAN', 'a) Dzemilijati Furkan; b) Dzem ijjetul Furqan; c) Association for Citizens Rights and Resistance to Lies; d) Dzemijetul Furkan; e) Association of Citizens for the Support of Truth and Supression of Lies; f) Sirat; g) Association for Education, Culture and Building Society-Sirat; h) Association for Education, Culture, and to Create Society-Sirat; i) Istikamet; j) In Siratel; k) Citizens'' Association for Support and Prevention of lies-Furqan', '04', 'In Siratel', 'IN SIRATEL', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1202', '20170807', '����췢[2017]106��', 'AL FURQAN', 'a) Dzemilijati Furkan; b) Dzem ijjetul Furqan; c) Association for Citizens Rights and Resistance to Lies; d) Dzemijetul Furkan; e) Association of Citizens for the Support of Truth and Supression of Lies; f) Sirat; g) Association for Education, Culture and Building Society-Sirat; h) Association for Education, Culture, and to Create Society-Sirat; i) Istikamet; j) In Siratel; k) Citizens'' Association for Support and Prevention of lies-Furqan', '04', 'Association for Education, Culture, and to Create Society-Sirat', 'ASSOCIATION FOR EDUCATION, CULTURE, AND TO CREATE SOCIETY-SIRAT', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1203', '20170807', '����췢[2017]106��', 'AL FURQAN', 'a) Dzemilijati Furkan; b) Dzem ijjetul Furqan; c) Association for Citizens Rights and Resistance to Lies; d) Dzemijetul Furkan; e) Association of Citizens for the Support of Truth and Supression of Lies; f) Sirat; g) Association for Education, Culture and Building Society-Sirat; h) Association for Education, Culture, and to Create Society-Sirat; i) Istikamet; j) In Siratel; k) Citizens'' Association for Support and Prevention of lies-Furqan', '04', 'Association for Education, Culture and Building Society-Sirat', 'ASSOCIATION FOR EDUCATION, CULTURE AND BUILDING SOCIETY-SIRAT', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1204', '20170807', '����췢[2017]106��', 'AL FURQAN', 'a) Dzemilijati Furkan; b) Dzem ijjetul Furqan; c) Association for Citizens Rights and Resistance to Lies; d) Dzemijetul Furkan; e) Association of Citizens for the Support of Truth and Supression of Lies; f) Sirat; g) Association for Education, Culture and Building Society-Sirat; h) Association for Education, Culture, and to Create Society-Sirat; i) Istikamet; j) In Siratel; k) Citizens'' Association for Support and Prevention of lies-Furqan', '04', 'Sirat', 'SIRAT', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1205', '20170807', '����췢[2017]106��', 'AL FURQAN', 'a) Dzemilijati Furkan; b) Dzem ijjetul Furqan; c) Association for Citizens Rights and Resistance to Lies; d) Dzemijetul Furkan; e) Association of Citizens for the Support of Truth and Supression of Lies; f) Sirat; g) Association for Education, Culture and Building Society-Sirat; h) Association for Education, Culture, and to Create Society-Sirat; i) Istikamet; j) In Siratel; k) Citizens'' Association for Support and Prevention of lies-Furqan', '04', 'Association of Citizens for the Support of Truth and Supression of Lies', 'ASSOCIATION OF CITIZENS FOR THE SUPPORT OF TRUTH AND SUPRESSION OF LIES', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1206', '20170807', '����췢[2017]106��', 'AL FURQAN', 'a) Dzemilijati Furkan; b) Dzem ijjetul Furqan; c) Association for Citizens Rights and Resistance to Lies; d) Dzemijetul Furkan; e) Association of Citizens for the Support of Truth and Supression of Lies; f) Sirat; g) Association for Education, Culture and Building Society-Sirat; h) Association for Education, Culture, and to Create Society-Sirat; i) Istikamet; j) In Siratel; k) Citizens'' Association for Support and Prevention of lies-Furqan', '04', 'Dzemijetul Furkan', 'DZEMIJETUL FURKAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1207', '20170807', '����췢[2017]106��', 'AL FURQAN', 'a) Dzemilijati Furkan; b) Dzem ijjetul Furqan; c) Association for Citizens Rights and Resistance to Lies; d) Dzemijetul Furkan; e) Association of Citizens for the Support of Truth and Supression of Lies; f) Sirat; g) Association for Education, Culture and Building Society-Sirat; h) Association for Education, Culture, and to Create Society-Sirat; i) Istikamet; j) In Siratel; k) Citizens'' Association for Support and Prevention of lies-Furqan', '04', 'Association for Citizens Rights and Resistance to Lies', 'ASSOCIATION FOR CITIZENS RIGHTS AND RESISTANCE TO LIES', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1208', '20170807', '����췢[2017]106��', 'AL FURQAN', 'a) Dzemilijati Furkan; b) Dzem ijjetul Furqan; c) Association for Citizens Rights and Resistance to Lies; d) Dzemijetul Furkan; e) Association of Citizens for the Support of Truth and Supression of Lies; f) Sirat; g) Association for Education, Culture and Building Society-Sirat; h) Association for Education, Culture, and to Create Society-Sirat; i) Istikamet; j) In Siratel; k) Citizens'' Association for Support and Prevention of lies-Furqan', '04', 'Dzem ijjetul Furqan', 'DZEM IJJETUL FURQAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1209', '20170807', '����췢[2017]106��', 'AL FURQAN', 'a) Dzemilijati Furkan; b) Dzem ijjetul Furqan; c) Association for Citizens Rights and Resistance to Lies; d) Dzemijetul Furkan; e) Association of Citizens for the Support of Truth and Supression of Lies; f) Sirat; g) Association for Education, Culture and Building Society-Sirat; h) Association for Education, Culture, and to Create Society-Sirat; i) Istikamet; j) In Siratel; k) Citizens'' Association for Support and Prevention of lies-Furqan', '04', 'Dzemilijati Furkan', 'DZEMILIJATI FURKAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1210', '20170807', '����췢[2017]106��', 'AL FURQAN', 'a) Dzemilijati Furkan; b) Dzem ijjetul Furqan; c) Association for Citizens Rights and Resistance to Lies; d) Dzemijetul Furkan; e) Association of Citizens for the Support of Truth and Supression of Lies; f) Sirat; g) Association for Education, Culture and Building Society-Sirat; h) Association for Education, Culture, and to Create Society-Sirat; i) Istikamet; j) In Siratel; k) Citizens'' Association for Support and Prevention of lies-Furqan', '04', 'Istikamet', 'ISTIKAMET', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1211', '20170807', '����췢[2017]106��', 'AL MOUAKAOUNE BIDDAM', 'a) Les Signataires par le Sang; b) Ceux Qui Signent avec le Sang; c) Those who Sign in Blood', '01', 'AL MOUAKAOUNE BIDDAM', 'AL MOUAKAOUNE BIDDAM', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1212', '20170807', '����췢[2017]106��', 'AL MOUAKAOUNE BIDDAM', 'a) Les Signataires par le Sang; b) Ceux Qui Signent avec le Sang; c) Those who Sign in Blood', '04', 'Those who Sign in Blood', 'THOSE WHO SIGN IN BLOOD', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1213', '20170807', '����췢[2017]106��', 'AL MOUAKAOUNE BIDDAM', 'a) Les Signataires par le Sang; b) Ceux Qui Signent avec le Sang; c) Those who Sign in Blood', '04', 'Ceux Qui Signent avec le Sang', 'CEUX QUI SIGNENT AVEC LE SANG', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1214', '20170807', '����췢[2017]106��', 'AL MOUAKAOUNE BIDDAM', 'a) Les Signataires par le Sang; b) Ceux Qui Signent avec le Sang; c) Those who Sign in Blood', '04', 'Les Signataires par le Sang', 'LES SIGNATAIRES PAR LE SANG', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1215', '20170807', '����췢[2017]106��', 'AL MOULATHAMOUN', 'a) Les Enturbannes; b) The Veiled', '01', 'AL MOULATHAMOUN', 'AL MOULATHAMOUN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1216', '20170807', '����췢[2017]106��', 'AL MOULATHAMOUN', 'a) Les Enturbannes; b) The Veiled', '04', 'The Veiled', 'THE VEILED', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1217', '20170807', '����췢[2017]106��', 'AL MOULATHAMOUN', 'a) Les Enturbannes; b) The Veiled', '04', 'Les Enturbannes', 'LES ENTURBANNES', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1218', '20170807', '����췢[2017]106��', 'AL MOURABITOUN', 'a) Les Sentinelles; b) The Sentinels', '01', 'AL MOURABITOUN', 'AL MOURABITOUN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1219', '20170807', '����췢[2017]106��', 'AL MOURABITOUN', 'a) Les Sentinelles; b) The Sentinels', '04', 'The Sentinels', 'THE SENTINELS', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1220', '20170807', '����췢[2017]106��', 'AL MOURABITOUN', 'a) Les Sentinelles; b) The Sentinels', '04', 'Les Sentinelles', 'LES SENTINELLES', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1221', '20170807', '����췢[2017]106��', 'AL RASHID TRUST', 'a) Al-Rasheed Trust; b) Al Rasheed Trust; c) Al-Rashid Trust; d) Aid Organization of the Ulema, Pakistan; e) Al Amin Welfare Trust; f) Al Amin Trust; g) Al Ameen Trust; h) Al-Ameen Trust; i) Al Madina Trust; j) Al-Madina Trust', '01', 'AL RASHID TRUST', 'AL RASHID TRUST', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1222', '20170807', '����췢[2017]106��', 'AL RASHID TRUST', 'a) Al-Rasheed Trust; b) Al Rasheed Trust; c) Al-Rashid Trust; d) Aid Organization of the Ulema, Pakistan; e) Al Amin Welfare Trust; f) Al Amin Trust; g) Al Ameen Trust; h) Al-Ameen Trust; i) Al Madina Trust; j) Al-Madina Trust', '04', 'Al Amin Welfare Trust', 'AL AMIN WELFARE TRUST', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1223', '20170807', '����췢[2017]106��', 'AL RASHID TRUST', 'a) Al-Rasheed Trust; b) Al Rasheed Trust; c) Al-Rashid Trust; d) Aid Organization of the Ulema, Pakistan; e) Al Amin Welfare Trust; f) Al Amin Trust; g) Al Ameen Trust; h) Al-Ameen Trust; i) Al Madina Trust; j) Al-Madina Trust', '04', 'Aid Organization of the Ulema, Pakistan', 'AID ORGANIZATION OF THE ULEMA, PAKISTAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1224', '20170807', '����췢[2017]106��', 'AL RASHID TRUST', 'a) Al-Rasheed Trust; b) Al Rasheed Trust; c) Al-Rashid Trust; d) Aid Organization of the Ulema, Pakistan; e) Al Amin Welfare Trust; f) Al Amin Trust; g) Al Ameen Trust; h) Al-Ameen Trust; i) Al Madina Trust; j) Al-Madina Trust', '04', 'Al Rasheed Trust', 'AL RASHEED TRUST', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1225', '20170807', '����췢[2017]106��', 'AL RASHID TRUST', 'a) Al-Rasheed Trust; b) Al Rasheed Trust; c) Al-Rashid Trust; d) Aid Organization of the Ulema, Pakistan; e) Al Amin Welfare Trust; f) Al Amin Trust; g) Al Ameen Trust; h) Al-Ameen Trust; i) Al Madina Trust; j) Al-Madina Trust', '04', 'Al Amin Trust', 'AL AMIN TRUST', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1226', '20170807', '����췢[2017]106��', 'AL RASHID TRUST', 'a) Al-Rasheed Trust; b) Al Rasheed Trust; c) Al-Rashid Trust; d) Aid Organization of the Ulema, Pakistan; e) Al Amin Welfare Trust; f) Al Amin Trust; g) Al Ameen Trust; h) Al-Ameen Trust; i) Al Madina Trust; j) Al-Madina Trust', '04', 'Al-Rasheed Trust', 'AL-RASHEED TRUST', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1227', '20170807', '����췢[2017]106��', 'AL RASHID TRUST', 'a) Al-Rasheed Trust; b) Al Rasheed Trust; c) Al-Rashid Trust; d) Aid Organization of the Ulema, Pakistan; e) Al Amin Welfare Trust; f) Al Amin Trust; g) Al Ameen Trust; h) Al-Ameen Trust; i) Al Madina Trust; j) Al-Madina Trust', '04', 'Al-Madina Trust', 'AL-MADINA TRUST', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1228', '20170807', '����췢[2017]106��', 'AL RASHID TRUST', 'a) Al-Rasheed Trust; b) Al Rasheed Trust; c) Al-Rashid Trust; d) Aid Organization of the Ulema, Pakistan; e) Al Amin Welfare Trust; f) Al Amin Trust; g) Al Ameen Trust; h) Al-Ameen Trust; i) Al Madina Trust; j) Al-Madina Trust', '04', 'Al-Rashid Trust', 'AL-RASHID TRUST', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1229', '20170807', '����췢[2017]106��', 'AL RASHID TRUST', 'a) Al-Rasheed Trust; b) Al Rasheed Trust; c) Al-Rashid Trust; d) Aid Organization of the Ulema, Pakistan; e) Al Amin Welfare Trust; f) Al Amin Trust; g) Al Ameen Trust; h) Al-Ameen Trust; i) Al Madina Trust; j) Al-Madina Trust', '04', 'Al Ameen Trust', 'AL AMEEN TRUST', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1230', '20170807', '����췢[2017]106��', 'AL RASHID TRUST', 'a) Al-Rasheed Trust; b) Al Rasheed Trust; c) Al-Rashid Trust; d) Aid Organization of the Ulema, Pakistan; e) Al Amin Welfare Trust; f) Al Amin Trust; g) Al Ameen Trust; h) Al-Ameen Trust; i) Al Madina Trust; j) Al-Madina Trust', '04', 'Al-Ameen Trust', 'AL-AMEEN TRUST', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1231', '20170807', '����췢[2017]106��', 'AL RASHID TRUST', 'a) Al-Rasheed Trust; b) Al Rasheed Trust; c) Al-Rashid Trust; d) Aid Organization of the Ulema, Pakistan; e) Al Amin Welfare Trust; f) Al Amin Trust; g) Al Ameen Trust; h) Al-Ameen Trust; i) Al Madina Trust; j) Al-Madina Trust', '04', 'Al Madina Trust', 'AL MADINA TRUST', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1232', '20170807', '����췢[2017]106��', 'AL-AKHTAR TRUST INTERNATIONAL', 'a) Al Akhtar Trust; b) Al-Akhtar Medical Centre; c) Akhtarabad Medical Camp; d) Pakistan Relief Foundation; e) Pakistani Relief Foundation; f) Azmat-e-Pakistan Trust; g) Azmat Pakistan', '01', 'AL-AKHTAR TRUST INTERNATIONAL', 'AL-AKHTAR TRUST INTERNATIONAL', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1233', '20170807', '����췢[2017]106��', 'AL-AKHTAR TRUST INTERNATIONAL', 'a) Al Akhtar Trust; b) Al-Akhtar Medical Centre; c) Akhtarabad Medical Camp; d) Pakistan Relief Foundation; e) Pakistani Relief Foundation; f) Azmat-e-Pakistan Trust; g) Azmat Pakistan', '04', 'Pakistan Relief Foundation', 'PAKISTAN RELIEF FOUNDATION', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1234', '20170807', '����췢[2017]106��', 'AL-AKHTAR TRUST INTERNATIONAL', 'a) Al Akhtar Trust; b) Al-Akhtar Medical Centre; c) Akhtarabad Medical Camp; d) Pakistan Relief Foundation; e) Pakistani Relief Foundation; f) Azmat-e-Pakistan Trust; g) Azmat Pakistan', '04', 'Pakistani Relief Foundation', 'PAKISTANI RELIEF FOUNDATION', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1235', '20170807', '����췢[2017]106��', 'AL-AKHTAR TRUST INTERNATIONAL', 'a) Al Akhtar Trust; b) Al-Akhtar Medical Centre; c) Akhtarabad Medical Camp; d) Pakistan Relief Foundation; e) Pakistani Relief Foundation; f) Azmat-e-Pakistan Trust; g) Azmat Pakistan', '04', 'Azmat-e-Pakistan Trust', 'AZMAT-E-PAKISTAN TRUST', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1236', '20170807', '����췢[2017]106��', 'AL-AKHTAR TRUST INTERNATIONAL', 'a) Al Akhtar Trust; b) Al-Akhtar Medical Centre; c) Akhtarabad Medical Camp; d) Pakistan Relief Foundation; e) Pakistani Relief Foundation; f) Azmat-e-Pakistan Trust; g) Azmat Pakistan', '04', 'Azmat Pakistan', 'AZMAT PAKISTAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1237', '20170807', '����췢[2017]106��', 'AL-AKHTAR TRUST INTERNATIONAL', 'a) Al Akhtar Trust; b) Al-Akhtar Medical Centre; c) Akhtarabad Medical Camp; d) Pakistan Relief Foundation; e) Pakistani Relief Foundation; f) Azmat-e-Pakistan Trust; g) Azmat Pakistan', '04', 'Al Akhtar Trust', 'AL AKHTAR TRUST', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1238', '20170807', '����췢[2017]106��', 'AL-AKHTAR TRUST INTERNATIONAL', 'a) Al Akhtar Trust; b) Al-Akhtar Medical Centre; c) Akhtarabad Medical Camp; d) Pakistan Relief Foundation; e) Pakistani Relief Foundation; f) Azmat-e-Pakistan Trust; g) Azmat Pakistan', '04', 'Al-Akhtar Medical Centre', 'AL-AKHTAR MEDICAL CENTRE', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1239', '20170807', '����췢[2017]106��', 'AL-AKHTAR TRUST INTERNATIONAL', 'a) Al Akhtar Trust; b) Al-Akhtar Medical Centre; c) Akhtarabad Medical Camp; d) Pakistan Relief Foundation; e) Pakistani Relief Foundation; f) Azmat-e-Pakistan Trust; g) Azmat Pakistan', '04', 'Akhtarabad Medical Camp', 'AKHTARABAD MEDICAL CAMP', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1240', '20170807', '����췢[2017]106��', 'AL-HARAMAIN & AL MASJED AL-AQSA CHARITY FOUNDATION', 'a) Al Haramain Al Masjed Al Aqsa; b) Al Haramayn Al Masjid Al Aqsa; c) Al-Haramayn and Al Masjid Al Aqsa Charitable Foundation; d) Al Harammein Al Masjed Al-Aqsa Charity Foundation', '01', 'AL-HARAMAIN & AL MASJED AL-AQSA CHARITY FOUNDATION', 'AL-HARAMAIN & AL MASJED AL-AQSA CHARITY FOUNDATION', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1241', '20170807', '����췢[2017]106��', 'AL-HARAMAIN & AL MASJED AL-AQSA CHARITY FOUNDATION', 'a) Al Haramain Al Masjed Al Aqsa; b) Al Haramayn Al Masjid Al Aqsa; c) Al-Haramayn and Al Masjid Al Aqsa Charitable Foundation; d) Al Harammein Al Masjed Al-Aqsa Charity Foundation', '04', 'Al Haramain Al Masjed Al Aqsa', 'AL HARAMAIN AL MASJED AL AQSA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1242', '20170807', '����췢[2017]106��', 'AL-HARAMAIN & AL MASJED AL-AQSA CHARITY FOUNDATION', 'a) Al Haramain Al Masjed Al Aqsa; b) Al Haramayn Al Masjid Al Aqsa; c) Al-Haramayn and Al Masjid Al Aqsa Charitable Foundation; d) Al Harammein Al Masjed Al-Aqsa Charity Foundation', '04', 'Al Haramayn Al Masjid Al Aqsa', 'AL HARAMAYN AL MASJID AL AQSA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1243', '20170807', '����췢[2017]106��', 'AL-HARAMAIN & AL MASJED AL-AQSA CHARITY FOUNDATION', 'a) Al Haramain Al Masjed Al Aqsa; b) Al Haramayn Al Masjid Al Aqsa; c) Al-Haramayn and Al Masjid Al Aqsa Charitable Foundation; d) Al Harammein Al Masjed Al-Aqsa Charity Foundation', '04', 'Al-Haramayn and Al Masjid Al Aqsa Charitable Foundation', 'AL-HARAMAYN AND AL MASJID AL AQSA CHARITABLE FOUNDATION', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1244', '20170807', '����췢[2017]106��', 'AL-HARAMAIN & AL MASJED AL-AQSA CHARITY FOUNDATION', 'a) Al Haramain Al Masjed Al Aqsa; b) Al Haramayn Al Masjid Al Aqsa; c) Al-Haramayn and Al Masjid Al Aqsa Charitable Foundation; d) Al Harammein Al Masjed Al-Aqsa Charity Foundation', '04', 'Al Harammein Al Masjed Al-Aqsa Charity Foundation', 'AL HARAMMEIN AL MASJED AL-AQSA CHARITY FOUNDATION', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1245', '20170807', '����췢[2017]106��', 'AL-HARAMAIN FOUNDATION (INDONESIA)', 'a) Yayaaan Al-Manahil-Indonesia', '01', 'AL-HARAMAIN FOUNDATION (INDONESIA)', 'AL-HARAMAIN FOUNDATION (INDONESIA)', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1246', '20170807', '����췢[2017]106��', 'AL-HARAMAIN FOUNDATION (INDONESIA)', 'a) Yayaaan Al-Manahil-Indonesia', '04', 'Yayaaan Al-Manahil-Indonesia', 'YAYAAAN AL-MANAHIL-INDONESIA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1247', '20170807', '����췢[2017]106��', 'AL-HARAMAIN FOUNDATION (PAKISTAN)', null, '01', 'AL-HARAMAIN FOUNDATION (PAKISTAN)', 'AL-HARAMAIN FOUNDATION (PAKISTAN)', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1248', '20170807', '����췢[2017]106��', 'AL-HARAMAIN FOUNDATION (UNION OF THE COMOROS)', null, '01', 'AL-HARAMAIN FOUNDATION (UNION OF THE COMOROS)', 'AL-HARAMAIN FOUNDATION (UNION OF THE COMOROS)', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1249', '20170807', '����췢[2017]106��', 'AL-HARAMAIN ISLAMIC FOUNDATION', 'a) Vazir; b) Vezir', '01', 'AL-HARAMAIN ISLAMIC FOUNDATION', 'AL-HARAMAIN ISLAMIC FOUNDATION', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1250', '20170807', '����췢[2017]106��', 'AL-HARAMAIN ISLAMIC FOUNDATION', 'a) Vazir; b) Vezir', '04', 'Vazir', 'VAZIR', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1251', '20170807', '����췢[2017]106��', 'AL-HARAMAIN ISLAMIC FOUNDATION', 'a) Vazir; b) Vezir', '04', 'Vezir', 'VEZIR', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1252', '20170807', '����췢[2017]106��', 'AL-HARAMAIN ISLAMIC FOUNDATION (SOMALIA)', null, '01', 'AL-HARAMAIN ISLAMIC FOUNDATION (SOMALIA)', 'AL-HARAMAIN ISLAMIC FOUNDATION (SOMALIA)', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1253', '20170807', '����췢[2017]106��', 'AL-HARAMAIN: AFGHANISTAN BRANCH', null, '01', 'AL-HARAMAIN: AFGHANISTAN BRANCH', 'AL-HARAMAIN: AFGHANISTAN BRANCH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1254', '20170807', '����췢[2017]106��', 'AL-HARAMAIN: ALBANIA BRANCH', null, '01', 'AL-HARAMAIN: ALBANIA BRANCH', 'AL-HARAMAIN: ALBANIA BRANCH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1255', '20170807', '����췢[2017]106��', 'AL-HARAMAIN: BANGLADESH BRANCH', null, '01', 'AL-HARAMAIN: BANGLADESH BRANCH', 'AL-HARAMAIN: BANGLADESH BRANCH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1256', '20170807', '����췢[2017]106��', 'AL-HARAMAIN: ETHIOPIA BRANCH', null, '01', 'AL-HARAMAIN: ETHIOPIA BRANCH', 'AL-HARAMAIN: ETHIOPIA BRANCH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1257', '20170807', '����췢[2017]106��', 'AL-HARAMAIN: THE NETHERLANDS BRANCH', 'a) Stichting Al Haramain Humanitarian', '01', 'AL-HARAMAIN: THE NETHERLANDS BRANCH', 'AL-HARAMAIN: THE NETHERLANDS BRANCH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1258', '20170807', '����췢[2017]106��', 'AL-HARAMAIN: THE NETHERLANDS BRANCH', 'a) Stichting Al Haramain Humanitarian', '03', 'Stichting Al Haramain Humanitarian', 'STICHTING AL HARAMAIN HUMANITARIAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1259', '20170807', '����췢[2017]106��', 'AL-HARAMAYN FOUNDATION (KENYA)', null, '01', 'AL-HARAMAYN FOUNDATION (KENYA)', 'AL-HARAMAYN FOUNDATION (KENYA)', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1260', '20170807', '����췢[2017]106��', 'AL-HARAMAYN FOUNDATION (TANZANIA)', null, '01', 'AL-HARAMAYN FOUNDATION (TANZANIA)', 'AL-HARAMAYN FOUNDATION (TANZANIA)', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1261', '20170807', '����췢[2017]106��', 'AL-ITIHAAD AL-ISLAMIYA / AIAI', null, '01', 'AL-ITIHAAD AL-ISLAMIYA / AIAI', 'AL-ITIHAAD AL-ISLAMIYA / AIAI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1262', '20170807', '����췢[2017]106��', 'AL-NUSRAH FRONT FOR THE PEOPLE OF THE LEVANT', 'a) the Victory Front; Jabhat al-Nusrah; Jabhet al-Nusra; Al-Nusrah Front; Al-Nusra Front; b) sub-unit name: Ansar al-Mujahideen Network; c) sub-unit name: Lovantine Mujahideen on the Battlefields of Jihad', '01', 'AL-NUSRAH FRONT FOR THE PEOPLE OF THE LEVANT', 'AL-NUSRAH FRONT FOR THE PEOPLE OF THE LEVANT', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1263', '20170807', '����췢[2017]106��', 'AL-NUSRAH FRONT FOR THE PEOPLE OF THE LEVANT', 'a) the Victory Front; Jabhat al-Nusrah; Jabhet al-Nusra; Al-Nusrah Front; Al-Nusra Front; b) sub-unit name: Ansar al-Mujahideen Network; c) sub-unit name: Lovantine Mujahideen on the Battlefields of Jihad', '04', 'sub-unit name: Lovantine Mujahideen on the Battlefields of Jihad', 'SUB-UNIT NAME: LOVANTINE MUJAHIDEEN ON THE BATTLEFIELDS OF JIHAD', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1264', '20170807', '����췢[2017]106��', 'AL-NUSRAH FRONT FOR THE PEOPLE OF THE LEVANT', 'a) the Victory Front; Jabhat al-Nusrah; Jabhet al-Nusra; Al-Nusrah Front; Al-Nusra Front; b) sub-unit name: Ansar al-Mujahideen Network; c) sub-unit name: Lovantine Mujahideen on the Battlefields of Jihad', '04', 'the Victory Front; Jabhat al-Nusrah; Jabhet al-Nusra; Al-Nusrah Front; Al-Nusra Front', 'THE VICTORY FRONT; JABHAT AL-NUSRAH; JABHET AL-NUSRA; AL-NUSRAH FRONT; AL-NUSRA FRONT', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1265', '20170807', '����췢[2017]106��', 'AL-NUSRAH FRONT FOR THE PEOPLE OF THE LEVANT', 'a) the Victory Front; Jabhat al-Nusrah; Jabhet al-Nusra; Al-Nusrah Front; Al-Nusra Front; b) sub-unit name: Ansar al-Mujahideen Network; c) sub-unit name: Lovantine Mujahideen on the Battlefields of Jihad', '04', 'the Victory Front', 'THE VICTORY FRONT', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1266', '20170807', '����췢[2017]106��', 'AL-NUSRAH FRONT FOR THE PEOPLE OF THE LEVANT', 'a) the Victory Front; Jabhat al-Nusrah; Jabhet al-Nusra; Al-Nusrah Front; Al-Nusra Front; b) sub-unit name: Ansar al-Mujahideen Network; c) sub-unit name: Lovantine Mujahideen on the Battlefields of Jihad', '04', 'Jabhat al-Nusrah', 'JABHAT AL-NUSRAH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1267', '20170807', '����췢[2017]106��', 'AL-NUSRAH FRONT FOR THE PEOPLE OF THE LEVANT', 'a) the Victory Front; Jabhat al-Nusrah; Jabhet al-Nusra; Al-Nusrah Front; Al-Nusra Front; b) sub-unit name: Ansar al-Mujahideen Network; c) sub-unit name: Lovantine Mujahideen on the Battlefields of Jihad', '04', 'Jabhet al-Nusra', 'JABHET AL-NUSRA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1268', '20170807', '����췢[2017]106��', 'AL-NUSRAH FRONT FOR THE PEOPLE OF THE LEVANT', 'a) the Victory Front; Jabhat al-Nusrah; Jabhet al-Nusra; Al-Nusrah Front; Al-Nusra Front; b) sub-unit name: Ansar al-Mujahideen Network; c) sub-unit name: Lovantine Mujahideen on the Battlefields of Jihad', '04', 'Al-Nusrah Front', 'AL-NUSRAH FRONT', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1269', '20170807', '����췢[2017]106��', 'AL-NUSRAH FRONT FOR THE PEOPLE OF THE LEVANT', 'a) the Victory Front; Jabhat al-Nusrah; Jabhet al-Nusra; Al-Nusrah Front; Al-Nusra Front; b) sub-unit name: Ansar al-Mujahideen Network; c) sub-unit name: Lovantine Mujahideen on the Battlefields of Jihad', '04', 'Al-Nusra Front', 'AL-NUSRA FRONT', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1270', '20170807', '����췢[2017]106��', 'AL-NUSRAH FRONT FOR THE PEOPLE OF THE LEVANT', 'a) the Victory Front; Jabhat al-Nusrah; Jabhet al-Nusra; Al-Nusrah Front; Al-Nusra Front; b) sub-unit name: Ansar al-Mujahideen Network; c) sub-unit name: Lovantine Mujahideen on the Battlefields of Jihad', '04', 'sub-unit name: Ansar al-Mujahideen Network', 'SUB-UNIT NAME: ANSAR AL-MUJAHIDEEN NETWORK', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1271', '20170807', '����췢[2017]106��', 'AL-QAIDA', 'a) The Base; b) Al Qaeda; c) Islamic Salvation Foundation; d) The Group for the Preservation of the Holy Sites; e) The Islamic Army for the Liberation of Holy Places; f) The World Islamic Front for Jihad Against Jews and Crusaders; g) Usama Bin Laden Network; h) Usama Bin Laden Organization; i) Al Qaida; j) Al Qaida/Islamic Army', '01', 'AL-QAIDA', 'AL-QAIDA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1272', '20170807', '����췢[2017]106��', 'AL-QAIDA', 'a) The Base; b) Al Qaeda; c) Islamic Salvation Foundation; d) The Group for the Preservation of the Holy Sites; e) The Islamic Army for the Liberation of Holy Places; f) The World Islamic Front for Jihad Against Jews and Crusaders; g) Usama Bin Laden Network; h) Usama Bin Laden Organization; i) Al Qaida; j) Al Qaida/Islamic Army', '04', 'Usama Bin Laden Network', 'USAMA BIN LADEN NETWORK', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1273', '20170807', '����췢[2017]106��', 'AL-QAIDA', 'a) The Base; b) Al Qaeda; c) Islamic Salvation Foundation; d) The Group for the Preservation of the Holy Sites; e) The Islamic Army for the Liberation of Holy Places; f) The World Islamic Front for Jihad Against Jews and Crusaders; g) Usama Bin Laden Network; h) Usama Bin Laden Organization; i) Al Qaida; j) Al Qaida/Islamic Army', '04', 'The World Islamic Front for Jihad Against Jews and Crusaders', 'THE WORLD ISLAMIC FRONT FOR JIHAD AGAINST JEWS AND CRUSADERS', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1274', '20170807', '����췢[2017]106��', 'AL-QAIDA', 'a) The Base; b) Al Qaeda; c) Islamic Salvation Foundation; d) The Group for the Preservation of the Holy Sites; e) The Islamic Army for the Liberation of Holy Places; f) The World Islamic Front for Jihad Against Jews and Crusaders; g) Usama Bin Laden Network; h) Usama Bin Laden Organization; i) Al Qaida; j) Al Qaida/Islamic Army', '04', 'Al Qaeda', 'AL QAEDA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1275', '20170807', '����췢[2017]106��', 'AL-QAIDA', 'a) The Base; b) Al Qaeda; c) Islamic Salvation Foundation; d) The Group for the Preservation of the Holy Sites; e) The Islamic Army for the Liberation of Holy Places; f) The World Islamic Front for Jihad Against Jews and Crusaders; g) Usama Bin Laden Network; h) Usama Bin Laden Organization; i) Al Qaida; j) Al Qaida/Islamic Army', '04', 'The Base', 'THE BASE', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1276', '20170807', '����췢[2017]106��', 'AL-QAIDA', 'a) The Base; b) Al Qaeda; c) Islamic Salvation Foundation; d) The Group for the Preservation of the Holy Sites; e) The Islamic Army for the Liberation of Holy Places; f) The World Islamic Front for Jihad Against Jews and Crusaders; g) Usama Bin Laden Network; h) Usama Bin Laden Organization; i) Al Qaida; j) Al Qaida/Islamic Army', '04', 'Al Qaida', 'AL QAIDA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1277', '20170807', '����췢[2017]106��', 'AL-QAIDA', 'a) The Base; b) Al Qaeda; c) Islamic Salvation Foundation; d) The Group for the Preservation of the Holy Sites; e) The Islamic Army for the Liberation of Holy Places; f) The World Islamic Front for Jihad Against Jews and Crusaders; g) Usama Bin Laden Network; h) Usama Bin Laden Organization; i) Al Qaida; j) Al Qaida/Islamic Army', '04', 'Islamic Salvation Foundation', 'ISLAMIC SALVATION FOUNDATION', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1278', '20170807', '����췢[2017]106��', 'AL-QAIDA', 'a) The Base; b) Al Qaeda; c) Islamic Salvation Foundation; d) The Group for the Preservation of the Holy Sites; e) The Islamic Army for the Liberation of Holy Places; f) The World Islamic Front for Jihad Against Jews and Crusaders; g) Usama Bin Laden Network; h) Usama Bin Laden Organization; i) Al Qaida; j) Al Qaida/Islamic Army', '04', 'The Islamic Army for the Liberation of Holy Places', 'THE ISLAMIC ARMY FOR THE LIBERATION OF HOLY PLACES', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1279', '20170807', '����췢[2017]106��', 'AL-QAIDA', 'a) The Base; b) Al Qaeda; c) Islamic Salvation Foundation; d) The Group for the Preservation of the Holy Sites; e) The Islamic Army for the Liberation of Holy Places; f) The World Islamic Front for Jihad Against Jews and Crusaders; g) Usama Bin Laden Network; h) Usama Bin Laden Organization; i) Al Qaida; j) Al Qaida/Islamic Army', '04', 'The Group for the Preservation of the Holy Sites', 'THE GROUP FOR THE PRESERVATION OF THE HOLY SITES', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1280', '20170807', '����췢[2017]106��', 'AL-QAIDA', 'a) The Base; b) Al Qaeda; c) Islamic Salvation Foundation; d) The Group for the Preservation of the Holy Sites; e) The Islamic Army for the Liberation of Holy Places; f) The World Islamic Front for Jihad Against Jews and Crusaders; g) Usama Bin Laden Network; h) Usama Bin Laden Organization; i) Al Qaida; j) Al Qaida/Islamic Army', '04', 'Al Qaida/Islamic Army', 'AL QAIDA/ISLAMIC ARMY', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1281', '20170807', '����췢[2017]106��', 'AL-QAIDA', 'a) The Base; b) Al Qaeda; c) Islamic Salvation Foundation; d) The Group for the Preservation of the Holy Sites; e) The Islamic Army for the Liberation of Holy Places; f) The World Islamic Front for Jihad Against Jews and Crusaders; g) Usama Bin Laden Network; h) Usama Bin Laden Organization; i) Al Qaida; j) Al Qaida/Islamic Army', '04', 'Usama Bin Laden Organization', 'USAMA BIN LADEN ORGANIZATION', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1282', '20170807', '����췢[2017]106��', 'AL-QAIDA IN IRAQ', 'a) AQI; b) al-Tawhid; c) the Monotheism and Jihad Group; d) Qaida of the Jihad in the Land of the Two Rivers; e) Al-Qaida of Jihad in the Land of the Two Rivers; h) The Organization Base of Jihad/Mesopotamia; i) Tanzim Qaidat Al Jihad fi Bilad al-Rafidayn; j) Tanzeem Qaidat al Jihad/Bilad al Raafidaini; k) Jama at Al-Tawhid Wa''al-Jihad; l) JTJ; m) Islamic State of Iraq; n) ISI; o) al-Zarqawi network; p) Islamic State in Iraq and the Levant', '01', 'AL-QAIDA IN IRAQ', 'AL-QAIDA IN IRAQ', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1283', '20170807', '����췢[2017]106��', 'AL-QAIDA IN IRAQ', 'a) AQI; b) al-Tawhid; c) the Monotheism and Jihad Group; d) Qaida of the Jihad in the Land of the Two Rivers; e) Al-Qaida of Jihad in the Land of the Two Rivers; h) The Organization Base of Jihad/Mesopotamia; i) Tanzim Qaidat Al Jihad fi Bilad al-Rafidayn; j) Tanzeem Qaidat al Jihad/Bilad al Raafidaini; k) Jama at Al-Tawhid Wa''al-Jihad; l) JTJ; m) Islamic State of Iraq; n) ISI; o) al-Zarqawi network; p) Islamic State in Iraq and the Levant', '04', 'Islamic State in Iraq and the Levant', 'ISLAMIC STATE IN IRAQ AND THE LEVANT', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1284', '20170807', '����췢[2017]106��', 'AL-QAIDA IN IRAQ', 'a) AQI; b) al-Tawhid; c) the Monotheism and Jihad Group; d) Qaida of the Jihad in the Land of the Two Rivers; e) Al-Qaida of Jihad in the Land of the Two Rivers; h) The Organization Base of Jihad/Mesopotamia; i) Tanzim Qaidat Al Jihad fi Bilad al-Rafidayn; j) Tanzeem Qaidat al Jihad/Bilad al Raafidaini; k) Jama at Al-Tawhid Wa''al-Jihad; l) JTJ; m) Islamic State of Iraq; n) ISI; o) al-Zarqawi network; p) Islamic State in Iraq and the Levant', '04', 'al-Zarqawi network', 'AL-ZARQAWI NETWORK', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1285', '20170807', '����췢[2017]106��', 'AL-QAIDA IN IRAQ', 'a) AQI; b) al-Tawhid; c) the Monotheism and Jihad Group; d) Qaida of the Jihad in the Land of the Two Rivers; e) Al-Qaida of Jihad in the Land of the Two Rivers; h) The Organization Base of Jihad/Mesopotamia; i) Tanzim Qaidat Al Jihad fi Bilad al-Rafidayn; j) Tanzeem Qaidat al Jihad/Bilad al Raafidaini; k) Jama at Al-Tawhid Wa''al-Jihad; l) JTJ; m) Islamic State of Iraq; n) ISI; o) al-Zarqawi network; p) Islamic State in Iraq and the Levant', '04', 'ISI', 'ISI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1286', '20170807', '����췢[2017]106��', 'AL-QAIDA IN IRAQ', 'a) AQI; b) al-Tawhid; c) the Monotheism and Jihad Group; d) Qaida of the Jihad in the Land of the Two Rivers; e) Al-Qaida of Jihad in the Land of the Two Rivers; h) The Organization Base of Jihad/Mesopotamia; i) Tanzim Qaidat Al Jihad fi Bilad al-Rafidayn; j) Tanzeem Qaidat al Jihad/Bilad al Raafidaini; k) Jama at Al-Tawhid Wa''al-Jihad; l) JTJ; m) Islamic State of Iraq; n) ISI; o) al-Zarqawi network; p) Islamic State in Iraq and the Levant', '04', 'Islamic State of Iraq', 'ISLAMIC STATE OF IRAQ', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1287', '20170807', '����췢[2017]106��', 'AL-QAIDA IN IRAQ', 'a) AQI; b) al-Tawhid; c) the Monotheism and Jihad Group; d) Qaida of the Jihad in the Land of the Two Rivers; e) Al-Qaida of Jihad in the Land of the Two Rivers; h) The Organization Base of Jihad/Mesopotamia; i) Tanzim Qaidat Al Jihad fi Bilad al-Rafidayn; j) Tanzeem Qaidat al Jihad/Bilad al Raafidaini; k) Jama at Al-Tawhid Wa''al-Jihad; l) JTJ; m) Islamic State of Iraq; n) ISI; o) al-Zarqawi network; p) Islamic State in Iraq and the Levant', '04', 'JTJ', 'JTJ', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1288', '20170807', '����췢[2017]106��', 'AL-QAIDA IN IRAQ', 'a) AQI; b) al-Tawhid; c) the Monotheism and Jihad Group; d) Qaida of the Jihad in the Land of the Two Rivers; e) Al-Qaida of Jihad in the Land of the Two Rivers; h) The Organization Base of Jihad/Mesopotamia; i) Tanzim Qaidat Al Jihad fi Bilad al-Rafidayn; j) Tanzeem Qaidat al Jihad/Bilad al Raafidaini; k) Jama at Al-Tawhid Wa''al-Jihad; l) JTJ; m) Islamic State of Iraq; n) ISI; o) al-Zarqawi network; p) Islamic State in Iraq and the Levant', '04', 'Jama at Al-Tawhid Wa''al-Jihad', 'JAMA AT AL-TAWHID WA''AL-JIHAD', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1289', '20170807', '����췢[2017]106��', 'AL-QAIDA IN IRAQ', 'a) AQI; b) al-Tawhid; c) the Monotheism and Jihad Group; d) Qaida of the Jihad in the Land of the Two Rivers; e) Al-Qaida of Jihad in the Land of the Two Rivers; h) The Organization Base of Jihad/Mesopotamia; i) Tanzim Qaidat Al Jihad fi Bilad al-Rafidayn; j) Tanzeem Qaidat al Jihad/Bilad al Raafidaini; k) Jama at Al-Tawhid Wa''al-Jihad; l) JTJ; m) Islamic State of Iraq; n) ISI; o) al-Zarqawi network; p) Islamic State in Iraq and the Levant', '04', 'Tanzeem Qaidat al Jihad/Bilad al Raafidaini', 'TANZEEM QAIDAT AL JIHAD/BILAD AL RAAFIDAINI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1290', '20170807', '����췢[2017]106��', 'AL-QAIDA IN IRAQ', 'a) AQI; b) al-Tawhid; c) the Monotheism and Jihad Group; d) Qaida of the Jihad in the Land of the Two Rivers; e) Al-Qaida of Jihad in the Land of the Two Rivers; h) The Organization Base of Jihad/Mesopotamia; i) Tanzim Qaidat Al Jihad fi Bilad al-Rafidayn; j) Tanzeem Qaidat al Jihad/Bilad al Raafidaini; k) Jama at Al-Tawhid Wa''al-Jihad; l) JTJ; m) Islamic State of Iraq; n) ISI; o) al-Zarqawi network; p) Islamic State in Iraq and the Levant', '04', 'Tanzim Qaidat Al Jihad fi Bilad al-Rafidayn', 'TANZIM QAIDAT AL JIHAD FI BILAD AL-RAFIDAYN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1291', '20170807', '����췢[2017]106��', 'AL-QAIDA IN IRAQ', 'a) AQI; b) al-Tawhid; c) the Monotheism and Jihad Group; d) Qaida of the Jihad in the Land of the Two Rivers; e) Al-Qaida of Jihad in the Land of the Two Rivers; h) The Organization Base of Jihad/Mesopotamia; i) Tanzim Qaidat Al Jihad fi Bilad al-Rafidayn; j) Tanzeem Qaidat al Jihad/Bilad al Raafidaini; k) Jama at Al-Tawhid Wa''al-Jihad; l) JTJ; m) Islamic State of Iraq; n) ISI; o) al-Zarqawi network; p) Islamic State in Iraq and the Levant', '04', 'The Organization Base of Jihad/Mesopotamia', 'THE ORGANIZATION BASE OF JIHAD/MESOPOTAMIA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1292', '20170807', '����췢[2017]106��', 'AL-QAIDA IN IRAQ', 'a) AQI; b) al-Tawhid; c) the Monotheism and Jihad Group; d) Qaida of the Jihad in the Land of the Two Rivers; e) Al-Qaida of Jihad in the Land of the Two Rivers; h) The Organization Base of Jihad/Mesopotamia; i) Tanzim Qaidat Al Jihad fi Bilad al-Rafidayn; j) Tanzeem Qaidat al Jihad/Bilad al Raafidaini; k) Jama at Al-Tawhid Wa''al-Jihad; l) JTJ; m) Islamic State of Iraq; n) ISI; o) al-Zarqawi network; p) Islamic State in Iraq and the Levant', '04', 'Al-Qaida of Jihad in the Land of the Two Rivers', 'AL-QAIDA OF JIHAD IN THE LAND OF THE TWO RIVERS', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1293', '20170807', '����췢[2017]106��', 'AL-QAIDA IN IRAQ', 'a) AQI; b) al-Tawhid; c) the Monotheism and Jihad Group; d) Qaida of the Jihad in the Land of the Two Rivers; e) Al-Qaida of Jihad in the Land of the Two Rivers; h) The Organization Base of Jihad/Mesopotamia; i) Tanzim Qaidat Al Jihad fi Bilad al-Rafidayn; j) Tanzeem Qaidat al Jihad/Bilad al Raafidaini; k) Jama at Al-Tawhid Wa''al-Jihad; l) JTJ; m) Islamic State of Iraq; n) ISI; o) al-Zarqawi network; p) Islamic State in Iraq and the Levant', '04', 'al-Tawhid', 'AL-TAWHID', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1294', '20170807', '����췢[2017]106��', 'AL-QAIDA IN IRAQ', 'a) AQI; b) al-Tawhid; c) the Monotheism and Jihad Group; d) Qaida of the Jihad in the Land of the Two Rivers; e) Al-Qaida of Jihad in the Land of the Two Rivers; h) The Organization Base of Jihad/Mesopotamia; i) Tanzim Qaidat Al Jihad fi Bilad al-Rafidayn; j) Tanzeem Qaidat al Jihad/Bilad al Raafidaini; k) Jama at Al-Tawhid Wa''al-Jihad; l) JTJ; m) Islamic State of Iraq; n) ISI; o) al-Zarqawi network; p) Islamic State in Iraq and the Levant', '04', 'the Monotheism and Jihad Group', 'THE MONOTHEISM AND JIHAD GROUP', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1295', '20170807', '����췢[2017]106��', 'AL-QAIDA IN IRAQ', 'a) AQI; b) al-Tawhid; c) the Monotheism and Jihad Group; d) Qaida of the Jihad in the Land of the Two Rivers; e) Al-Qaida of Jihad in the Land of the Two Rivers; h) The Organization Base of Jihad/Mesopotamia; i) Tanzim Qaidat Al Jihad fi Bilad al-Rafidayn; j) Tanzeem Qaidat al Jihad/Bilad al Raafidaini; k) Jama at Al-Tawhid Wa''al-Jihad; l) JTJ; m) Islamic State of Iraq; n) ISI; o) al-Zarqawi network; p) Islamic State in Iraq and the Levant', '04', 'Qaida of the Jihad in the Land of the Two Rivers', 'QAIDA OF THE JIHAD IN THE LAND OF THE TWO RIVERS', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1296', '20170807', '����췢[2017]106��', 'AL-QAIDA IN IRAQ', 'a) AQI; b) al-Tawhid; c) the Monotheism and Jihad Group; d) Qaida of the Jihad in the Land of the Two Rivers; e) Al-Qaida of Jihad in the Land of the Two Rivers; h) The Organization Base of Jihad/Mesopotamia; i) Tanzim Qaidat Al Jihad fi Bilad al-Rafidayn; j) Tanzeem Qaidat al Jihad/Bilad al Raafidaini; k) Jama at Al-Tawhid Wa''al-Jihad; l) JTJ; m) Islamic State of Iraq; n) ISI; o) al-Zarqawi network; p) Islamic State in Iraq and the Levant', '04', 'AQI', 'AQI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1297', '20170807', '����췢[2017]106��', 'AL-QAIDA IN THE ARABIAN PENINSULA (AQAP)', 'a) Al-Qaida of Jihad Organization in the Arabian Peninsula; b) Tanzim Qaidat al-Jihad Ii Jazirat al-Arab; c) Al-Qaida Organization in the Arabian Peninsula (AQAP); d) Al-Qaida in the South Arabian Peninsula; e) Ansar al-Sharia (AAS)', '01', 'AL-QAIDA IN THE ARABIAN PENINSULA (AQAP)', 'AL-QAIDA IN THE ARABIAN PENINSULA (AQAP)', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1298', '20170807', '����췢[2017]106��', 'AL-QAIDA IN THE ARABIAN PENINSULA (AQAP)', 'a) Al-Qaida of Jihad Organization in the Arabian Peninsula; b) Tanzim Qaidat al-Jihad Ii Jazirat al-Arab; c) Al-Qaida Organization in the Arabian Peninsula (AQAP); d) Al-Qaida in the South Arabian Peninsula; e) Ansar al-Sharia (AAS)', '04', 'Ansar al-Sharia (AAS)', 'ANSAR AL-SHARIA (AAS)', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1299', '20170807', '����췢[2017]106��', 'AL-QAIDA IN THE ARABIAN PENINSULA (AQAP)', 'a) Al-Qaida of Jihad Organization in the Arabian Peninsula; b) Tanzim Qaidat al-Jihad Ii Jazirat al-Arab; c) Al-Qaida Organization in the Arabian Peninsula (AQAP); d) Al-Qaida in the South Arabian Peninsula; e) Ansar al-Sharia (AAS)', '04', 'Ansar al-Sharia', 'ANSAR AL-SHARIA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1300', '20170807', '����췢[2017]106��', 'AL-QAIDA IN THE ARABIAN PENINSULA (AQAP)', 'a) Al-Qaida of Jihad Organization in the Arabian Peninsula; b) Tanzim Qaidat al-Jihad Ii Jazirat al-Arab; c) Al-Qaida Organization in the Arabian Peninsula (AQAP); d) Al-Qaida in the South Arabian Peninsula; e) Ansar al-Sharia (AAS)', '04', 'AAS', 'AAS', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1301', '20170807', '����췢[2017]106��', 'AL-QAIDA IN THE ARABIAN PENINSULA (AQAP)', 'a) Al-Qaida of Jihad Organization in the Arabian Peninsula; b) Tanzim Qaidat al-Jihad Ii Jazirat al-Arab; c) Al-Qaida Organization in the Arabian Peninsula (AQAP); d) Al-Qaida in the South Arabian Peninsula; e) Ansar al-Sharia (AAS)', '04', 'Ansar al-Sharia', 'ANSAR AL-SHARIA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1302', '20170807', '����췢[2017]106��', 'AL-QAIDA IN THE ARABIAN PENINSULA (AQAP)', 'a) Al-Qaida of Jihad Organization in the Arabian Peninsula; b) Tanzim Qaidat al-Jihad Ii Jazirat al-Arab; c) Al-Qaida Organization in the Arabian Peninsula (AQAP); d) Al-Qaida in the South Arabian Peninsula; e) Ansar al-Sharia (AAS)', '04', 'AAS', 'AAS', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1303', '20170807', '����췢[2017]106��', 'AL-QAIDA IN THE ARABIAN PENINSULA (AQAP)', 'a) Al-Qaida of Jihad Organization in the Arabian Peninsula; b) Tanzim Qaidat al-Jihad Ii Jazirat al-Arab; c) Al-Qaida Organization in the Arabian Peninsula (AQAP); d) Al-Qaida in the South Arabian Peninsula; e) Ansar al-Sharia (AAS)', '04', 'Al-Qaida Organization in the Arabian Peninsula (AQAP)', 'AL-QAIDA ORGANIZATION IN THE ARABIAN PENINSULA (AQAP)', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1304', '20170807', '����췢[2017]106��', 'AL-QAIDA IN THE ARABIAN PENINSULA (AQAP)', 'a) Al-Qaida of Jihad Organization in the Arabian Peninsula; b) Tanzim Qaidat al-Jihad Ii Jazirat al-Arab; c) Al-Qaida Organization in the Arabian Peninsula (AQAP); d) Al-Qaida in the South Arabian Peninsula; e) Ansar al-Sharia (AAS)', '04', 'Al-Qaida Organization in the Arabian Peninsula', 'AL-QAIDA ORGANIZATION IN THE ARABIAN PENINSULA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1305', '20170807', '����췢[2017]106��', 'AL-QAIDA IN THE ARABIAN PENINSULA (AQAP)', 'a) Al-Qaida of Jihad Organization in the Arabian Peninsula; b) Tanzim Qaidat al-Jihad Ii Jazirat al-Arab; c) Al-Qaida Organization in the Arabian Peninsula (AQAP); d) Al-Qaida in the South Arabian Peninsula; e) Ansar al-Sharia (AAS)', '04', 'AQAP', 'AQAP', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1306', '20170807', '����췢[2017]106��', 'AL-QAIDA IN THE ARABIAN PENINSULA (AQAP)', 'a) Al-Qaida of Jihad Organization in the Arabian Peninsula; b) Tanzim Qaidat al-Jihad Ii Jazirat al-Arab; c) Al-Qaida Organization in the Arabian Peninsula (AQAP); d) Al-Qaida in the South Arabian Peninsula; e) Ansar al-Sharia (AAS)', '04', 'Tanzim Qaidat al-Jihad Ii Jazirat al-Arab', 'TANZIM QAIDAT AL-JIHAD II JAZIRAT AL-ARAB', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1307', '20170807', '����췢[2017]106��', 'AL-QAIDA IN THE ARABIAN PENINSULA (AQAP)', 'a) Al-Qaida of Jihad Organization in the Arabian Peninsula; b) Tanzim Qaidat al-Jihad Ii Jazirat al-Arab; c) Al-Qaida Organization in the Arabian Peninsula (AQAP); d) Al-Qaida in the South Arabian Peninsula; e) Ansar al-Sharia (AAS)', '04', 'Al-Qaida of Jihad Organization in the Arabian Peninsula', 'AL-QAIDA OF JIHAD ORGANIZATION IN THE ARABIAN PENINSULA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1308', '20170807', '����췢[2017]106��', 'AL-QAIDA IN THE ARABIAN PENINSULA (AQAP)', 'a) Al-Qaida of Jihad Organization in the Arabian Peninsula; b) Tanzim Qaidat al-Jihad Ii Jazirat al-Arab; c) Al-Qaida Organization in the Arabian Peninsula (AQAP); d) Al-Qaida in the South Arabian Peninsula; e) Ansar al-Sharia (AAS)', '04', 'Al-Qaida in the South Arabian Peninsula', 'AL-QAIDA IN THE SOUTH ARABIAN PENINSULA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1309', '20170807', '����췢[2017]106��', 'ANSAR AL CHARIA BENGHAZI', 'a) Ansar al Charia; b) Ansar al-Charia; c) Ansar al-Sharia; d) Ansar al-Charia Benghazi; e) Ansar al-Sharia Benghazo; f) Ansar al Charia in Libya(ASL); g) Katibat Ansar al Charia; h) Ansar al Sharia', '01', 'ANSAR AL CHARIA BENGHAZI', 'ANSAR AL CHARIA BENGHAZI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1310', '20170807', '����췢[2017]106��', 'ANSAR AL CHARIA BENGHAZI', 'a) Ansar al Charia; b) Ansar al-Charia; c) Ansar al-Sharia; d) Ansar al-Charia Benghazi; e) Ansar al-Sharia Benghazo; f) Ansar al Charia in Libya(ASL); g) Katibat Ansar al Charia; h) Ansar al Sharia', '04', 'Ansar al-Charia', 'ANSAR AL-CHARIA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1311', '20170807', '����췢[2017]106��', 'ANSAR AL CHARIA BENGHAZI', 'a) Ansar al Charia; b) Ansar al-Charia; c) Ansar al-Sharia; d) Ansar al-Charia Benghazi; e) Ansar al-Sharia Benghazo; f) Ansar al Charia in Libya(ASL); g) Katibat Ansar al Charia; h) Ansar al Sharia', '04', 'Ansar al-Sharia', 'ANSAR AL-SHARIA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1312', '20170807', '����췢[2017]106��', 'ANSAR AL CHARIA BENGHAZI', 'a) Ansar al Charia; b) Ansar al-Charia; c) Ansar al-Sharia; d) Ansar al-Charia Benghazi; e) Ansar al-Sharia Benghazo; f) Ansar al Charia in Libya(ASL); g) Katibat Ansar al Charia; h) Ansar al Sharia', '04', 'Ansar al-Charia Benghazi', 'ANSAR AL-CHARIA BENGHAZI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1313', '20170807', '����췢[2017]106��', 'ANSAR AL CHARIA BENGHAZI', 'a) Ansar al Charia; b) Ansar al-Charia; c) Ansar al-Sharia; d) Ansar al-Charia Benghazi; e) Ansar al-Sharia Benghazo; f) Ansar al Charia in Libya(ASL); g) Katibat Ansar al Charia; h) Ansar al Sharia', '04', 'Ansar al Charia in Libya(ASL)', 'ANSAR AL CHARIA IN LIBYA(ASL)', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1314', '20170807', '����췢[2017]106��', 'ANSAR AL CHARIA BENGHAZI', 'a) Ansar al Charia; b) Ansar al-Charia; c) Ansar al-Sharia; d) Ansar al-Charia Benghazi; e) Ansar al-Sharia Benghazo; f) Ansar al Charia in Libya(ASL); g) Katibat Ansar al Charia; h) Ansar al Sharia', '04', 'Ansar al Charia in Libya', 'ANSAR AL CHARIA IN LIBYA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1315', '20170807', '����췢[2017]106��', 'ANSAR AL CHARIA BENGHAZI', 'a) Ansar al Charia; b) Ansar al-Charia; c) Ansar al-Sharia; d) Ansar al-Charia Benghazi; e) Ansar al-Sharia Benghazo; f) Ansar al Charia in Libya(ASL); g) Katibat Ansar al Charia; h) Ansar al Sharia', '04', 'ASL', 'ASL', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1316', '20170807', '����췢[2017]106��', 'ANSAR AL CHARIA BENGHAZI', 'a) Ansar al Charia; b) Ansar al-Charia; c) Ansar al-Sharia; d) Ansar al-Charia Benghazi; e) Ansar al-Sharia Benghazo; f) Ansar al Charia in Libya(ASL); g) Katibat Ansar al Charia; h) Ansar al Sharia', '04', 'Katibat Ansar al Charia', 'KATIBAT ANSAR AL CHARIA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1317', '20170807', '����췢[2017]106��', 'ANSAR AL CHARIA BENGHAZI', 'a) Ansar al Charia; b) Ansar al-Charia; c) Ansar al-Sharia; d) Ansar al-Charia Benghazi; e) Ansar al-Sharia Benghazo; f) Ansar al Charia in Libya(ASL); g) Katibat Ansar al Charia; h) Ansar al Sharia', '04', 'Ansar al Sharia', 'ANSAR AL SHARIA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1318', '20170807', '����췢[2017]106��', 'ANSAR AL CHARIA BENGHAZI', 'a) Ansar al Charia; b) Ansar al-Charia; c) Ansar al-Sharia; d) Ansar al-Charia Benghazi; e) Ansar al-Sharia Benghazo; f) Ansar al Charia in Libya(ASL); g) Katibat Ansar al Charia; h) Ansar al Sharia', '04', 'Ansar al Charia', 'ANSAR AL CHARIA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1319', '20170807', '����췢[2017]106��', 'ANSAR AL CHARIA BENGHAZI', 'a) Ansar al Charia; b) Ansar al-Charia; c) Ansar al-Sharia; d) Ansar al-Charia Benghazi; e) Ansar al-Sharia Benghazo; f) Ansar al Charia in Libya(ASL); g) Katibat Ansar al Charia; h) Ansar al Sharia', '04', 'Ansar al-Sharia Benghazo', 'ANSAR AL-SHARIA BENGHAZO', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1320', '20170807', '����췢[2017]106��', 'ANSAR AL CHARIA DERNA', 'a) Ansar al-Charia Derna; b) Ansar al-Sharia Dema; c) Ansar al Charia; c) Ansar al-Sharia; e) Ansar al Sharia', '01', 'ANSAR AL CHARIA DERNA', 'ANSAR AL CHARIA DERNA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1321', '20170807', '����췢[2017]106��', 'ANSAR AL CHARIA DERNA', 'a) Ansar al-Charia Derna; b) Ansar al-Sharia Dema; c) Ansar al Charia; c) Ansar al-Sharia; e) Ansar al Sharia', '04', 'Ansar al-Charia Derna', 'ANSAR AL-CHARIA DERNA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1322', '20170807', '����췢[2017]106��', 'ANSAR AL CHARIA DERNA', 'a) Ansar al-Charia Derna; b) Ansar al-Sharia Dema; c) Ansar al Charia; c) Ansar al-Sharia; e) Ansar al Sharia', '04', 'Ansar al-Sharia Dema', 'ANSAR AL-SHARIA DEMA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1323', '20170807', '����췢[2017]106��', 'ANSAR AL CHARIA DERNA', 'a) Ansar al-Charia Derna; b) Ansar al-Sharia Dema; c) Ansar al Charia; c) Ansar al-Sharia; e) Ansar al Sharia', '04', 'Ansar al Charia', 'ANSAR AL CHARIA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1324', '20170807', '����췢[2017]106��', 'ANSAR AL CHARIA DERNA', 'a) Ansar al-Charia Derna; b) Ansar al-Sharia Dema; c) Ansar al Charia; c) Ansar al-Sharia; e) Ansar al Sharia', '04', 'Ansar al-Sharia', 'ANSAR AL-SHARIA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1325', '20170807', '����췢[2017]106��', 'ANSAR AL CHARIA DERNA', 'a) Ansar al-Charia Derna; b) Ansar al-Sharia Dema; c) Ansar al Charia; c) Ansar al-Sharia; e) Ansar al Sharia', '04', 'Ansar al Sharia', 'ANSAR AL SHARIA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1326', '20170807', '����췢[2017]106��', 'ANSAR AL-ISLAM', 'a) Devotees of Islam; b) Jund al-Islam; c) Soldiers of Islam; d) Kurdistan Supporters of Islam; e) Supporters of Islam in Kurdistan; f) Followers of Islam in Kurdistan; g) Kurdish Taliban; h) Soldiers of God; i) Ansar al-Sunna Army; j) Jaish Ansar al-Sunna; k) Ansar al-Sunna', '01', 'ANSAR AL-ISLAM', 'ANSAR AL-ISLAM', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1327', '20170807', '����췢[2017]106��', 'ANSAR AL-ISLAM', 'a) Devotees of Islam; b) Jund al-Islam; c) Soldiers of Islam; d) Kurdistan Supporters of Islam; e) Supporters of Islam in Kurdistan; f) Followers of Islam in Kurdistan; g) Kurdish Taliban; h) Soldiers of God; i) Ansar al-Sunna Army; j) Jaish Ansar al-Sunna; k) Ansar al-Sunna', '04', 'Jund al-Islam', 'JUND AL-ISLAM', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1328', '20170807', '����췢[2017]106��', 'ANSAR AL-ISLAM', 'a) Devotees of Islam; b) Jund al-Islam; c) Soldiers of Islam; d) Kurdistan Supporters of Islam; e) Supporters of Islam in Kurdistan; f) Followers of Islam in Kurdistan; g) Kurdish Taliban; h) Soldiers of God; i) Ansar al-Sunna Army; j) Jaish Ansar al-Sunna; k) Ansar al-Sunna', '04', 'Soldiers of Islam', 'SOLDIERS OF ISLAM', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1329', '20170807', '����췢[2017]106��', 'ANSAR AL-ISLAM', 'a) Devotees of Islam; b) Jund al-Islam; c) Soldiers of Islam; d) Kurdistan Supporters of Islam; e) Supporters of Islam in Kurdistan; f) Followers of Islam in Kurdistan; g) Kurdish Taliban; h) Soldiers of God; i) Ansar al-Sunna Army; j) Jaish Ansar al-Sunna; k) Ansar al-Sunna', '04', 'Kurdistan Supporters of Islam', 'KURDISTAN SUPPORTERS OF ISLAM', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1330', '20170807', '����췢[2017]106��', 'ANSAR AL-ISLAM', 'a) Devotees of Islam; b) Jund al-Islam; c) Soldiers of Islam; d) Kurdistan Supporters of Islam; e) Supporters of Islam in Kurdistan; f) Followers of Islam in Kurdistan; g) Kurdish Taliban; h) Soldiers of God; i) Ansar al-Sunna Army; j) Jaish Ansar al-Sunna; k) Ansar al-Sunna', '04', 'Followers of Islam in Kurdistan', 'FOLLOWERS OF ISLAM IN KURDISTAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1331', '20170807', '����췢[2017]106��', 'ANSAR AL-ISLAM', 'a) Devotees of Islam; b) Jund al-Islam; c) Soldiers of Islam; d) Kurdistan Supporters of Islam; e) Supporters of Islam in Kurdistan; f) Followers of Islam in Kurdistan; g) Kurdish Taliban; h) Soldiers of God; i) Ansar al-Sunna Army; j) Jaish Ansar al-Sunna; k) Ansar al-Sunna', '04', 'Supporters of Islam in Kurdistan', 'SUPPORTERS OF ISLAM IN KURDISTAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1332', '20170807', '����췢[2017]106��', 'ANSAR AL-ISLAM', 'a) Devotees of Islam; b) Jund al-Islam; c) Soldiers of Islam; d) Kurdistan Supporters of Islam; e) Supporters of Islam in Kurdistan; f) Followers of Islam in Kurdistan; g) Kurdish Taliban; h) Soldiers of God; i) Ansar al-Sunna Army; j) Jaish Ansar al-Sunna; k) Ansar al-Sunna', '04', 'Soldiers of God', 'SOLDIERS OF GOD', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1333', '20170807', '����췢[2017]106��', 'ANSAR AL-ISLAM', 'a) Devotees of Islam; b) Jund al-Islam; c) Soldiers of Islam; d) Kurdistan Supporters of Islam; e) Supporters of Islam in Kurdistan; f) Followers of Islam in Kurdistan; g) Kurdish Taliban; h) Soldiers of God; i) Ansar al-Sunna Army; j) Jaish Ansar al-Sunna; k) Ansar al-Sunna', '04', 'Ansar al-Sunna Army', 'ANSAR AL-SUNNA ARMY', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1334', '20170807', '����췢[2017]106��', 'ANSAR AL-ISLAM', 'a) Devotees of Islam; b) Jund al-Islam; c) Soldiers of Islam; d) Kurdistan Supporters of Islam; e) Supporters of Islam in Kurdistan; f) Followers of Islam in Kurdistan; g) Kurdish Taliban; h) Soldiers of God; i) Ansar al-Sunna Army; j) Jaish Ansar al-Sunna; k) Ansar al-Sunna', '04', 'Jaish Ansar al-Sunna', 'JAISH ANSAR AL-SUNNA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1335', '20170807', '����췢[2017]106��', 'ANSAR AL-ISLAM', 'a) Devotees of Islam; b) Jund al-Islam; c) Soldiers of Islam; d) Kurdistan Supporters of Islam; e) Supporters of Islam in Kurdistan; f) Followers of Islam in Kurdistan; g) Kurdish Taliban; h) Soldiers of God; i) Ansar al-Sunna Army; j) Jaish Ansar al-Sunna; k) Ansar al-Sunna', '04', 'Ansar al-Sunna', 'ANSAR AL-SUNNA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1336', '20170807', '����췢[2017]106��', 'ANSAR AL-ISLAM', 'a) Devotees of Islam; b) Jund al-Islam; c) Soldiers of Islam; d) Kurdistan Supporters of Islam; e) Supporters of Islam in Kurdistan; f) Followers of Islam in Kurdistan; g) Kurdish Taliban; h) Soldiers of God; i) Ansar al-Sunna Army; j) Jaish Ansar al-Sunna; k) Ansar al-Sunna', '04', 'Devotees of Islam', 'DEVOTEES OF ISLAM', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1337', '20170807', '����췢[2017]106��', 'ANSAR AL-ISLAM', 'a) Devotees of Islam; b) Jund al-Islam; c) Soldiers of Islam; d) Kurdistan Supporters of Islam; e) Supporters of Islam in Kurdistan; f) Followers of Islam in Kurdistan; g) Kurdish Taliban; h) Soldiers of God; i) Ansar al-Sunna Army; j) Jaish Ansar al-Sunna; k) Ansar al-Sunna', '04', 'Kurdish Taliban', 'KURDISH TALIBAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1338', '20170807', '����췢[2017]106��', 'ANSAR AL-SHARI''A IN TUNISIA (AAS-T)', 'a) Ansar al-Sharia in Tunisia; b) Ansar al-Shari''ah in Tunisia; c) Ansar al-Shari''ah; d) Ansar al-Sharia; e) Supporters of Islamic Law; f) Al-Qayrawan Media Foundation', '01', 'ANSAR AL-SHARI''A IN TUNISIA (AAS-T)', 'ANSAR AL-SHARI''A IN TUNISIA (AAS-T)', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1339', '20170807', '����췢[2017]106��', 'ANSAR AL-SHARI''A IN TUNISIA (AAS-T)', 'a) Ansar al-Sharia in Tunisia; b) Ansar al-Shari''ah in Tunisia; c) Ansar al-Shari''ah; d) Ansar al-Sharia; e) Supporters of Islamic Law; f) Al-Qayrawan Media Foundation', '04', 'Supporters of Islamic Law', 'SUPPORTERS OF ISLAMIC LAW', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1340', '20170807', '����췢[2017]106��', 'ANSAR AL-SHARI''A IN TUNISIA (AAS-T)', 'a) Ansar al-Sharia in Tunisia; b) Ansar al-Shari''ah in Tunisia; c) Ansar al-Shari''ah; d) Ansar al-Sharia; e) Supporters of Islamic Law; f) Al-Qayrawan Media Foundation', '04', 'Al-Qayrawan Media Foundation', 'AL-QAYRAWAN MEDIA FOUNDATION', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1341', '20170807', '����췢[2017]106��', 'ANSAR AL-SHARI''A IN TUNISIA (AAS-T)', 'a) Ansar al-Sharia in Tunisia; b) Ansar al-Shari''ah in Tunisia; c) Ansar al-Shari''ah; d) Ansar al-Sharia; e) Supporters of Islamic Law; f) Al-Qayrawan Media Foundation', '04', 'Ansar al-Sharia', 'ANSAR AL-SHARIA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1342', '20170807', '����췢[2017]106��', 'ANSAR AL-SHARI''A IN TUNISIA (AAS-T)', 'a) Ansar al-Sharia in Tunisia; b) Ansar al-Shari''ah in Tunisia; c) Ansar al-Shari''ah; d) Ansar al-Sharia; e) Supporters of Islamic Law; f) Al-Qayrawan Media Foundation', '04', 'Ansar al-Shari''ah in Tunisia', 'ANSAR AL-SHARI''AH IN TUNISIA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1343', '20170807', '����췢[2017]106��', 'ANSAR AL-SHARI''A IN TUNISIA (AAS-T)', 'a) Ansar al-Sharia in Tunisia; b) Ansar al-Shari''ah in Tunisia; c) Ansar al-Shari''ah; d) Ansar al-Sharia; e) Supporters of Islamic Law; f) Al-Qayrawan Media Foundation', '04', 'Ansar al-Sharia in Tunisia', 'ANSAR AL-SHARIA IN TUNISIA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1344', '20170807', '����췢[2017]106��', 'ANSAR AL-SHARI''A IN TUNISIA (AAS-T)', 'a) Ansar al-Sharia in Tunisia; b) Ansar al-Shari''ah in Tunisia; c) Ansar al-Shari''ah; d) Ansar al-Sharia; e) Supporters of Islamic Law; f) Al-Qayrawan Media Foundation', '04', 'Ansar al-Shari''ah', 'ANSAR AL-SHARI''AH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1345', '20170807', '����췢[2017]106��', 'ANSAR EDDINE', 'a) Ansar', '01', 'ANSAR EDDINE', 'ANSAR EDDINE', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1346', '20170807', '����췢[2017]106��', 'ANSAR EDDINE', 'a) Ansar', '03', 'Ansar', 'ANSAR', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1347', '20170807', '����췢[2017]106��', 'ANSARUL MUSLIMINA FI BILADIS SUDAN', 'a) Ansaru; b) Ansarul Muslimina fi Biladis Sudan; c) Jama''atu Ansaril Muslimina fi Biladis-Sudan (JAMBS); f) Vanguards for the Protection of Muslims in Black Africa; g) Vanguard for the Protection of Muslims in Black Africa', '01', 'ANSARUL MUSLIMINA FI BILADIS SUDAN', 'ANSARUL MUSLIMINA FI BILADIS SUDAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1348', '20170807', '����췢[2017]106��', 'ANSARUL MUSLIMINA FI BILADIS SUDAN', 'a) Ansaru; b) Ansarul Muslimina fi Biladis Sudan; c) Jama''atu Ansaril Muslimina fi Biladis-Sudan (JAMBS); f) Vanguards for the Protection of Muslims in Black Africa; g) Vanguard for the Protection of Muslims in Black Africa', '04', 'Jama''atu Ansaril Muslimina fi Biladis-Sudan (JAMBS)', 'JAMA''ATU ANSARIL MUSLIMINA FI BILADIS-SUDAN (JAMBS)', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1349', '20170807', '����췢[2017]106��', 'ANSARUL MUSLIMINA FI BILADIS SUDAN', 'a) Ansaru; b) Ansarul Muslimina fi Biladis Sudan; c) Jama''atu Ansaril Muslimina fi Biladis-Sudan (JAMBS); f) Vanguards for the Protection of Muslims in Black Africa; g) Vanguard for the Protection of Muslims in Black Africa', '04', 'Jama''atu Ansaril Muslimina fi Biladis-Sudan', 'JAMA''ATU ANSARIL MUSLIMINA FI BILADIS-SUDAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1350', '20170807', '����췢[2017]106��', 'ANSARUL MUSLIMINA FI BILADIS SUDAN', 'a) Ansaru; b) Ansarul Muslimina fi Biladis Sudan; c) Jama''atu Ansaril Muslimina fi Biladis-Sudan (JAMBS); f) Vanguards for the Protection of Muslims in Black Africa; g) Vanguard for the Protection of Muslims in Black Africa', '04', 'JAMBS', 'JAMBS', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1351', '20170807', '����췢[2017]106��', 'ANSARUL MUSLIMINA FI BILADIS SUDAN', 'a) Ansaru; b) Ansarul Muslimina fi Biladis Sudan; c) Jama''atu Ansaril Muslimina fi Biladis-Sudan (JAMBS); f) Vanguards for the Protection of Muslims in Black Africa; g) Vanguard for the Protection of Muslims in Black Africa', '04', 'Vanguard for the Protection of Muslims in Black Africa', 'VANGUARD FOR THE PROTECTION OF MUSLIMS IN BLACK AFRICA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1352', '20170807', '����췢[2017]106��', 'ANSARUL MUSLIMINA FI BILADIS SUDAN', 'a) Ansaru; b) Ansarul Muslimina fi Biladis Sudan; c) Jama''atu Ansaril Muslimina fi Biladis-Sudan (JAMBS); f) Vanguards for the Protection of Muslims in Black Africa; g) Vanguard for the Protection of Muslims in Black Africa', '04', 'Ansarul Muslimina fi Biladis Sudan', 'ANSARUL MUSLIMINA FI BILADIS SUDAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1353', '20170807', '����췢[2017]106��', 'ANSARUL MUSLIMINA FI BILADIS SUDAN', 'a) Ansaru; b) Ansarul Muslimina fi Biladis Sudan; c) Jama''atu Ansaril Muslimina fi Biladis-Sudan (JAMBS); f) Vanguards for the Protection of Muslims in Black Africa; g) Vanguard for the Protection of Muslims in Black Africa', '04', 'Ansaru', 'ANSARU', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1354', '20170807', '����췢[2017]106��', 'ANSARUL MUSLIMINA FI BILADIS SUDAN', 'a) Ansaru; b) Ansarul Muslimina fi Biladis Sudan; c) Jama''atu Ansaril Muslimina fi Biladis-Sudan (JAMBS); f) Vanguards for the Protection of Muslims in Black Africa; g) Vanguard for the Protection of Muslims in Black Africa', '04', 'Vanguards for the Protection of Muslims in Black Africa', 'VANGUARDS FOR THE PROTECTION OF MUSLIMS IN BLACK AFRICA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1355', '20170807', '����췢[2017]106��', 'ARMED ISLAMIC GROUP', 'a) Al Jamm''ah Al-Islamiah Al-Musallah; b) GIA; c) Groupe Islamique Arme', '01', 'ARMED ISLAMIC GROUP', 'ARMED ISLAMIC GROUP', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1356', '20170807', '����췢[2017]106��', 'ARMED ISLAMIC GROUP', 'a) Al Jamm''ah Al-Islamiah Al-Musallah; b) GIA; c) Groupe Islamique Arme', '04', 'Groupe Islamique Arme', 'GROUPE ISLAMIQUE ARME', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1357', '20170807', '����췢[2017]106��', 'ARMED ISLAMIC GROUP', 'a) Al Jamm''ah Al-Islamiah Al-Musallah; b) GIA; c) Groupe Islamique Arme', '04', 'GIA', 'GIA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1358', '20170807', '����췢[2017]106��', 'ARMED ISLAMIC GROUP', 'a) Al Jamm''ah Al-Islamiah Al-Musallah; b) GIA; c) Groupe Islamique Arme', '04', 'Al Jamm''ah Al-Islamiah Al-Musallah', 'AL JAMM''AH AL-ISLAMIAH AL-MUSALLAH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1359', '20170807', '����췢[2017]106��', 'ASBAT AL-ANSAR', null, '01', 'ASBAT AL-ANSAR', 'ASBAT AL-ANSAR', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1360', '20170807', '����췢[2017]106��', 'BENEVOLENCE INTERNATIONAL FOUNDATION', 'a) Al Bir Dawalia; b) BIF; c) BIF-USA; d) Mezhdunarodnyj Blagotvoritel''nyl Fond', '01', 'BENEVOLENCE INTERNATIONAL FOUNDATION', 'BENEVOLENCE INTERNATIONAL FOUNDATION', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1361', '20170807', '����췢[2017]106��', 'BENEVOLENCE INTERNATIONAL FOUNDATION', 'a) Al Bir Dawalia; b) BIF; c) BIF-USA; d) Mezhdunarodnyj Blagotvoritel''nyl Fond', '04', 'Al Bir Dawalia', 'AL BIR DAWALIA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1362', '20170807', '����췢[2017]106��', 'BENEVOLENCE INTERNATIONAL FOUNDATION', 'a) Al Bir Dawalia; b) BIF; c) BIF-USA; d) Mezhdunarodnyj Blagotvoritel''nyl Fond', '04', 'BIF-USA', 'BIF-USA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1363', '20170807', '����췢[2017]106��', 'BENEVOLENCE INTERNATIONAL FOUNDATION', 'a) Al Bir Dawalia; b) BIF; c) BIF-USA; d) Mezhdunarodnyj Blagotvoritel''nyl Fond', '04', 'Mezhdunarodnyj Blagotvoritel''nyl Fond', 'MEZHDUNARODNYJ BLAGOTVORITEL''NYL FOND', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1364', '20170807', '����췢[2017]106��', 'BENEVOLENCE INTERNATIONAL FOUNDATION', 'a) Al Bir Dawalia; b) BIF; c) BIF-USA; d) Mezhdunarodnyj Blagotvoritel''nyl Fond', '04', 'BIF', 'BIF', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1365', '20170807', '����췢[2017]106��', 'DJAMAT HOUMAT DAAWA SALAFIA (DHDS)', 'a) Djamaat Houmah Al-Dawah Al-Salafiat', '01', 'DJAMAT HOUMAT DAAWA SALAFIA (DHDS)', 'DJAMAT HOUMAT DAAWA SALAFIA (DHDS)', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1366', '20170807', '����췢[2017]106��', 'DJAMAT HOUMAT DAAWA SALAFIA (DHDS)', 'a) Djamaat Houmah Al-Dawah Al-Salafiat', '03', 'Djamaat Houmah Al-Dawah Al-Salafiat', 'DJAMAAT HOUMAH AL-DAWAH AL-SALAFIAT', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1367', '20170807', '����췢[2017]106��', 'EASTERN TURKISTAN ISLAMIC MOVEMENT (ETIM)', 'a) The Eastern Turkistan Islamic Party; b) The Eastern Turkistan Islamic Party of Allah; c) Islamic Party of Turkesta; d) Djamaat Turkistan', '01', 'EASTERN TURKISTAN ISLAMIC MOVEMENT (ETIM)', 'EASTERN TURKISTAN ISLAMIC MOVEMENT (ETIM)', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1368', '20170807', '����췢[2017]106��', 'EASTERN TURKISTAN ISLAMIC MOVEMENT (ETIM)', 'a) The Eastern Turkistan Islamic Party; b) The Eastern Turkistan Islamic Party of Allah; c) Islamic Party of Turkesta; d) Djamaat Turkistan', '04', 'Djamaat Turkistan', 'DJAMAAT TURKISTAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1369', '20170807', '����췢[2017]106��', 'EASTERN TURKISTAN ISLAMIC MOVEMENT (ETIM)', 'a) The Eastern Turkistan Islamic Party; b) The Eastern Turkistan Islamic Party of Allah; c) Islamic Party of Turkesta; d) Djamaat Turkistan', '04', 'Islamic Party of Turkesta', 'ISLAMIC PARTY OF TURKESTA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1370', '20170807', '����췢[2017]106��', 'EASTERN TURKISTAN ISLAMIC MOVEMENT (ETIM)', 'a) The Eastern Turkistan Islamic Party; b) The Eastern Turkistan Islamic Party of Allah; c) Islamic Party of Turkesta; d) Djamaat Turkistan', '04', 'The Eastern Turkistan Islamic Party of Allah', 'THE EASTERN TURKISTAN ISLAMIC PARTY OF ALLAH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1371', '20170807', '����췢[2017]106��', 'EASTERN TURKISTAN ISLAMIC MOVEMENT (ETIM)', 'a) The Eastern Turkistan Islamic Party; b) The Eastern Turkistan Islamic Party of Allah; c) Islamic Party of Turkesta; d) Djamaat Turkistan', '04', 'The Eastern Turkistan Islamic Party', 'THE EASTERN TURKISTAN ISLAMIC PARTY', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1372', '20170807', '����췢[2017]106��', 'EGYPTIAN ISLAMIC JIHAD', 'a) Egyptian Al-Jihad; b) Jihad Group; c) New Jihad; d) Al-Jihad; e) Egyptian Islamic Movement', '01', 'EGYPTIAN ISLAMIC JIHAD', 'EGYPTIAN ISLAMIC JIHAD', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1373', '20170807', '����췢[2017]106��', 'EGYPTIAN ISLAMIC JIHAD', 'a) Egyptian Al-Jihad; b) Jihad Group; c) New Jihad; d) Al-Jihad; e) Egyptian Islamic Movement', '04', 'Jihad Group', 'JIHAD GROUP', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1374', '20170807', '����췢[2017]106��', 'EGYPTIAN ISLAMIC JIHAD', 'a) Egyptian Al-Jihad; b) Jihad Group; c) New Jihad; d) Al-Jihad; e) Egyptian Islamic Movement', '04', 'Al-Jihad', 'AL-JIHAD', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1375', '20170807', '����췢[2017]106��', 'EGYPTIAN ISLAMIC JIHAD', 'a) Egyptian Al-Jihad; b) Jihad Group; c) New Jihad; d) Al-Jihad; e) Egyptian Islamic Movement', '04', 'Egyptian Islamic Movement', 'EGYPTIAN ISLAMIC MOVEMENT', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1376', '20170807', '����췢[2017]106��', 'EGYPTIAN ISLAMIC JIHAD', 'a) Egyptian Al-Jihad; b) Jihad Group; c) New Jihad; d) Al-Jihad; e) Egyptian Islamic Movement', '04', 'Egyptian Al-Jihad', 'EGYPTIAN AL-JIHAD', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1377', '20170807', '����췢[2017]106��', 'EGYPTIAN ISLAMIC JIHAD', 'a) Egyptian Al-Jihad; b) Jihad Group; c) New Jihad; d) Al-Jihad; e) Egyptian Islamic Movement', '04', 'New Jihad', 'NEW JIHAD', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1378', '20170807', '����췢[2017]106��', 'EMARAT KAVKAZ', null, '01', 'EMARAT KAVKAZ', 'EMARAT KAVKAZ', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1379', '20170807', '����췢[2017]106��', 'GLOBAL RELIEF FOUNDATION (GRF)', null, '01', 'GLOBAL RELIEF FOUNDATION (GRF)', 'GLOBAL RELIEF FOUNDATION (GRF)', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1380', '20170807', '����췢[2017]106��', 'HARAKAT SHAM AL-ISLAM', 'a) Haraket Sham al-Islam; b) Sham al-Islam; c) Sham al-Islam Movement', '01', 'HARAKAT SHAM AL-ISLAM', 'HARAKAT SHAM AL-ISLAM', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1381', '20170807', '����췢[2017]106��', 'HARAKAT SHAM AL-ISLAM', 'a) Haraket Sham al-Islam; b) Sham al-Islam; c) Sham al-Islam Movement', '04', 'Sham al-Islam', 'SHAM AL-ISLAM', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1382', '20170807', '����췢[2017]106��', 'HARAKAT SHAM AL-ISLAM', 'a) Haraket Sham al-Islam; b) Sham al-Islam; c) Sham al-Islam Movement', '04', 'Haraket Sham al-Islam', 'HARAKET SHAM AL-ISLAM', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1383', '20170807', '����췢[2017]106��', 'HARAKAT SHAM AL-ISLAM', 'a) Haraket Sham al-Islam; b) Sham al-Islam; c) Sham al-Islam Movement', '04', 'Sham al-Islam Movement', 'SHAM AL-ISLAM MOVEMENT', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1384', '20170807', '����췢[2017]106��', 'HARAKAT UL-MUJAHIDIN / HUM', 'a) Al-Faran; b) Al-Hadid; c) Al-Hadith; d) Harakat Ul-Ansar; e) HUA; f) Harakat Ul-Mujahideen', '01', 'HARAKAT UL-MUJAHIDIN / HUM', 'HARAKAT UL-MUJAHIDIN / HUM', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1385', '20170807', '����췢[2017]106��', 'HARAKAT UL-MUJAHIDIN / HUM', 'a) Al-Faran; b) Al-Hadid; c) Al-Hadith; d) Harakat Ul-Ansar; e) HUA; f) Harakat Ul-Mujahideen', '04', 'Harakat Ul-Mujahideen', 'HARAKAT UL-MUJAHIDEEN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1386', '20170807', '����췢[2017]106��', 'HARAKAT UL-MUJAHIDIN / HUM', 'a) Al-Faran; b) Al-Hadid; c) Al-Hadith; d) Harakat Ul-Ansar; e) HUA; f) Harakat Ul-Mujahideen', '04', 'HUA', 'HUA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1387', '20170807', '����췢[2017]106��', 'HARAKAT UL-MUJAHIDIN / HUM', 'a) Al-Faran; b) Al-Hadid; c) Al-Hadith; d) Harakat Ul-Ansar; e) HUA; f) Harakat Ul-Mujahideen', '04', 'Harakat Ul-Ansar', 'HARAKAT UL-ANSAR', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1388', '20170807', '����췢[2017]106��', 'HARAKAT UL-MUJAHIDIN / HUM', 'a) Al-Faran; b) Al-Hadid; c) Al-Hadith; d) Harakat Ul-Ansar; e) HUA; f) Harakat Ul-Mujahideen', '04', 'Al-Hadid', 'AL-HADID', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1389', '20170807', '����췢[2017]106��', 'HARAKAT UL-MUJAHIDIN / HUM', 'a) Al-Faran; b) Al-Hadid; c) Al-Hadith; d) Harakat Ul-Ansar; e) HUA; f) Harakat Ul-Mujahideen', '04', 'Al-Faran', 'AL-FARAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1390', '20170807', '����췢[2017]106��', 'HARAKAT UL-MUJAHIDIN / HUM', 'a) Al-Faran; b) Al-Hadid; c) Al-Hadith; d) Harakat Ul-Ansar; e) HUA; f) Harakat Ul-Mujahideen', '04', 'Al-Hadith', 'AL-HADITH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1391', '20170807', '����췢[2017]106��', 'HARAKAT-UL JIHAD ISLAMI', 'a) HUJI; b) Movement of Islamic Holy War; c) Harkat-ul-Jihad-al Islami; d) Harkat-al-Jihad-ul Islami; e) Harkat-ul-Jehad-al-Islami; f) Harakat ul Jihad-e-Islami', '01', 'HARAKAT-UL JIHAD ISLAMI', 'HARAKAT-UL JIHAD ISLAMI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1392', '20170807', '����췢[2017]106��', 'HARAKAT-UL JIHAD ISLAMI', 'a) HUJI; b) Movement of Islamic Holy War; c) Harkat-ul-Jihad-al Islami; d) Harkat-al-Jihad-ul Islami; e) Harkat-ul-Jehad-al-Islami; f) Harakat ul Jihad-e-Islami', '04', 'Harkat-al-Jihad-ul Islami', 'HARKAT-AL-JIHAD-UL ISLAMI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1393', '20170807', '����췢[2017]106��', 'HARAKAT-UL JIHAD ISLAMI', 'a) HUJI; b) Movement of Islamic Holy War; c) Harkat-ul-Jihad-al Islami; d) Harkat-al-Jihad-ul Islami; e) Harkat-ul-Jehad-al-Islami; f) Harakat ul Jihad-e-Islami', '04', 'HUJI', 'HUJI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1394', '20170807', '����췢[2017]106��', 'HARAKAT-UL JIHAD ISLAMI', 'a) HUJI; b) Movement of Islamic Holy War; c) Harkat-ul-Jihad-al Islami; d) Harkat-al-Jihad-ul Islami; e) Harkat-ul-Jehad-al-Islami; f) Harakat ul Jihad-e-Islami', '04', 'Movement of Islamic Holy War', 'MOVEMENT OF ISLAMIC HOLY WAR', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1395', '20170807', '����췢[2017]106��', 'HARAKAT-UL JIHAD ISLAMI', 'a) HUJI; b) Movement of Islamic Holy War; c) Harkat-ul-Jihad-al Islami; d) Harkat-al-Jihad-ul Islami; e) Harkat-ul-Jehad-al-Islami; f) Harakat ul Jihad-e-Islami', '04', 'Harkat-ul-Jehad-al-Islami', 'HARKAT-UL-JEHAD-AL-ISLAMI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1396', '20170807', '����췢[2017]106��', 'HARAKAT-UL JIHAD ISLAMI', 'a) HUJI; b) Movement of Islamic Holy War; c) Harkat-ul-Jihad-al Islami; d) Harkat-al-Jihad-ul Islami; e) Harkat-ul-Jehad-al-Islami; f) Harakat ul Jihad-e-Islami', '04', 'Harkat-ul-Jihad-al Islami', 'HARKAT-UL-JIHAD-AL ISLAMI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1397', '20170807', '����췢[2017]106��', 'HARAKAT-UL JIHAD ISLAMI', 'a) HUJI; b) Movement of Islamic Holy War; c) Harkat-ul-Jihad-al Islami; d) Harkat-al-Jihad-ul Islami; e) Harkat-ul-Jehad-al-Islami; f) Harakat ul Jihad-e-Islami', '04', 'Harakat ul Jihad-e-Islami', 'HARAKAT UL JIHAD-E-ISLAMI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1398', '20170807', '����췢[2017]106��', 'HILAL ANMAR SOCIETY INDONESIA (HASI)', 'a) Yayasan Hilal Ahmar; b) Indonesia Hilal Ahmar Society for Syria', '01', 'HILAL ANMAR SOCIETY INDONESIA (HASI)', 'HILAL ANMAR SOCIETY INDONESIA (HASI)', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1399', '20170807', '����췢[2017]106��', 'HILAL ANMAR SOCIETY INDONESIA (HASI)', 'a) Yayasan Hilal Ahmar; b) Indonesia Hilal Ahmar Society for Syria', '04', 'Indonesia Hilal Ahmar Society for Syria', 'INDONESIA HILAL AHMAR SOCIETY FOR SYRIA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1400', '20170807', '����췢[2017]106��', 'HILAL ANMAR SOCIETY INDONESIA (HASI)', 'a) Yayasan Hilal Ahmar; b) Indonesia Hilal Ahmar Society for Syria', '04', 'Yayasan Hilal Ahmar', 'YAYASAN HILAL AHMAR', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1401', '20170807', '����췢[2017]106��', 'ISLAMIC ARMY OF ADEN', null, '01', 'ISLAMIC ARMY OF ADEN', 'ISLAMIC ARMY OF ADEN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1402', '20170807', '����췢[2017]106��', 'ISLAMIC INTERNATIONAL BRIGADE(IIB)', 'a) The Islamic Peacekeeping Brigade; b) The Islamic Peacekeeping Army; c) The International Brigade'' d) Islamic Peacekeeping Baltalion; e) International Battallon; f) Islamic Peacekeeping International Brigade', '01', 'ISLAMIC INTERNATIONAL BRIGADE(IIB)', 'ISLAMIC INTERNATIONAL BRIGADE(IIB)', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1403', '20170807', '����췢[2017]106��', 'ISLAMIC INTERNATIONAL BRIGADE(IIB)', 'a) The Islamic Peacekeeping Brigade; b) The Islamic Peacekeeping Army; c) The International Brigade'' d) Islamic Peacekeeping Baltalion; e) International Battallon; f) Islamic Peacekeeping International Brigade', '04', 'Islamic Peacekeeping International Brigade', 'ISLAMIC PEACEKEEPING INTERNATIONAL BRIGADE', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1404', '20170807', '����췢[2017]106��', 'ISLAMIC INTERNATIONAL BRIGADE(IIB)', 'a) The Islamic Peacekeeping Brigade; b) The Islamic Peacekeeping Army; c) The International Brigade'' d) Islamic Peacekeeping Baltalion; e) International Battallon; f) Islamic Peacekeeping International Brigade', '04', 'The Islamic Peacekeeping Army', 'THE ISLAMIC PEACEKEEPING ARMY', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1405', '20170807', '����췢[2017]106��', 'ISLAMIC INTERNATIONAL BRIGADE(IIB)', 'a) The Islamic Peacekeeping Brigade; b) The Islamic Peacekeeping Army; c) The International Brigade'' d) Islamic Peacekeeping Baltalion; e) International Battallon; f) Islamic Peacekeeping International Brigade', '04', 'International Battallon', 'INTERNATIONAL BATTALLON', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1406', '20170807', '����췢[2017]106��', 'ISLAMIC INTERNATIONAL BRIGADE(IIB)', 'a) The Islamic Peacekeeping Brigade; b) The Islamic Peacekeeping Army; c) The International Brigade'' d) Islamic Peacekeeping Baltalion; e) International Battallon; f) Islamic Peacekeeping International Brigade', '04', 'Islamic Peacekeeping Baltalion', 'ISLAMIC PEACEKEEPING BALTALION', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1407', '20170807', '����췢[2017]106��', 'ISLAMIC INTERNATIONAL BRIGADE(IIB)', 'a) The Islamic Peacekeeping Brigade; b) The Islamic Peacekeeping Army; c) The International Brigade'' d) Islamic Peacekeeping Baltalion; e) International Battallon; f) Islamic Peacekeeping International Brigade', '04', 'The International Brigade''', 'THE INTERNATIONAL BRIGADE''', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1408', '20170807', '����췢[2017]106��', 'ISLAMIC INTERNATIONAL BRIGADE(IIB)', 'a) The Islamic Peacekeeping Brigade; b) The Islamic Peacekeeping Army; c) The International Brigade'' d) Islamic Peacekeeping Baltalion; e) International Battallon; f) Islamic Peacekeeping International Brigade', '04', 'The Islamic Peacekeeping Brigade', 'THE ISLAMIC PEACEKEEPING BRIGADE', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1409', '20170807', '����췢[2017]106��', 'ISLAMIC JIHAD GROUP', 'a) Jama''at al-Jihad; b) Libyan Society; c) Kazakh Jama''at; d) Jamaat Mojahedin; e) Jamiyat; f) Jamiat al-Jihad al-Islami; g) Dzhamaat Modzhakhedov; h) Islamic Jihad Group of Uzbekistan; i) al-Djihad al-Islami; j) Zamaat Modzhakhedov Tsentralnoy Asii; k) Islamic Jihad Union', '01', 'ISLAMIC JIHAD GROUP', 'ISLAMIC JIHAD GROUP', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1410', '20170807', '����췢[2017]106��', 'ISLAMIC JIHAD GROUP', 'a) Jama''at al-Jihad; b) Libyan Society; c) Kazakh Jama''at; d) Jamaat Mojahedin; e) Jamiyat; f) Jamiat al-Jihad al-Islami; g) Dzhamaat Modzhakhedov; h) Islamic Jihad Group of Uzbekistan; i) al-Djihad al-Islami; j) Zamaat Modzhakhedov Tsentralnoy Asii; k) Islamic Jihad Union', '04', 'Dzhamaat Modzhakhedov', 'DZHAMAAT MODZHAKHEDOV', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1411', '20170807', '����췢[2017]106��', 'ISLAMIC JIHAD GROUP', 'a) Jama''at al-Jihad; b) Libyan Society; c) Kazakh Jama''at; d) Jamaat Mojahedin; e) Jamiyat; f) Jamiat al-Jihad al-Islami; g) Dzhamaat Modzhakhedov; h) Islamic Jihad Group of Uzbekistan; i) al-Djihad al-Islami; j) Zamaat Modzhakhedov Tsentralnoy Asii; k) Islamic Jihad Union', '04', 'Zamaat Modzhakhedov Tsentralnoy Asii', 'ZAMAAT MODZHAKHEDOV TSENTRALNOY ASII', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1412', '20170807', '����췢[2017]106��', 'ISLAMIC JIHAD GROUP', 'a) Jama''at al-Jihad; b) Libyan Society; c) Kazakh Jama''at; d) Jamaat Mojahedin; e) Jamiyat; f) Jamiat al-Jihad al-Islami; g) Dzhamaat Modzhakhedov; h) Islamic Jihad Group of Uzbekistan; i) al-Djihad al-Islami; j) Zamaat Modzhakhedov Tsentralnoy Asii; k) Islamic Jihad Union', '04', 'Zamaat Modzhakhedov Tsentralnoy Asii', 'ZAMAAT MODZHAKHEDOV TSENTRALNOY ASII', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1413', '20170807', '����췢[2017]106��', 'ISLAMIC JIHAD GROUP', 'a) Jama''at al-Jihad; b) Libyan Society; c) Kazakh Jama''at; d) Jamaat Mojahedin; e) Jamiyat; f) Jamiat al-Jihad al-Islami; g) Dzhamaat Modzhakhedov; h) Islamic Jihad Group of Uzbekistan; i) al-Djihad al-Islami; j) Zamaat Modzhakhedov Tsentralnoy Asii; k) Islamic Jihad Union', '04', 'al-Djihad al-Islami', 'AL-DJIHAD AL-ISLAMI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1414', '20170807', '����췢[2017]106��', 'ISLAMIC JIHAD GROUP', 'a) Jama''at al-Jihad; b) Libyan Society; c) Kazakh Jama''at; d) Jamaat Mojahedin; e) Jamiyat; f) Jamiat al-Jihad al-Islami; g) Dzhamaat Modzhakhedov; h) Islamic Jihad Group of Uzbekistan; i) al-Djihad al-Islami; j) Zamaat Modzhakhedov Tsentralnoy Asii; k) Islamic Jihad Union', '04', 'Islamic Jihad Group of Uzbekistan', 'ISLAMIC JIHAD GROUP OF UZBEKISTAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1415', '20170807', '����췢[2017]106��', 'ISLAMIC JIHAD GROUP', 'a) Jama''at al-Jihad; b) Libyan Society; c) Kazakh Jama''at; d) Jamaat Mojahedin; e) Jamiyat; f) Jamiat al-Jihad al-Islami; g) Dzhamaat Modzhakhedov; h) Islamic Jihad Group of Uzbekistan; i) al-Djihad al-Islami; j) Zamaat Modzhakhedov Tsentralnoy Asii; k) Islamic Jihad Union', '04', 'Jamiyat', 'JAMIYAT', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1416', '20170807', '����췢[2017]106��', 'ISLAMIC JIHAD GROUP', 'a) Jama''at al-Jihad; b) Libyan Society; c) Kazakh Jama''at; d) Jamaat Mojahedin; e) Jamiyat; f) Jamiat al-Jihad al-Islami; g) Dzhamaat Modzhakhedov; h) Islamic Jihad Group of Uzbekistan; i) al-Djihad al-Islami; j) Zamaat Modzhakhedov Tsentralnoy Asii; k) Islamic Jihad Union', '04', 'Jamaat Mojahedin', 'JAMAAT MOJAHEDIN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1417', '20170807', '����췢[2017]106��', 'ISLAMIC JIHAD GROUP', 'a) Jama''at al-Jihad; b) Libyan Society; c) Kazakh Jama''at; d) Jamaat Mojahedin; e) Jamiyat; f) Jamiat al-Jihad al-Islami; g) Dzhamaat Modzhakhedov; h) Islamic Jihad Group of Uzbekistan; i) al-Djihad al-Islami; j) Zamaat Modzhakhedov Tsentralnoy Asii; k) Islamic Jihad Union', '04', 'Kazakh Jama''at', 'KAZAKH JAMA''AT', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1418', '20170807', '����췢[2017]106��', 'ISLAMIC JIHAD GROUP', 'a) Jama''at al-Jihad; b) Libyan Society; c) Kazakh Jama''at; d) Jamaat Mojahedin; e) Jamiyat; f) Jamiat al-Jihad al-Islami; g) Dzhamaat Modzhakhedov; h) Islamic Jihad Group of Uzbekistan; i) al-Djihad al-Islami; j) Zamaat Modzhakhedov Tsentralnoy Asii; k) Islamic Jihad Union', '04', 'Libyan Society', 'LIBYAN SOCIETY', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1419', '20170807', '����췢[2017]106��', 'ISLAMIC JIHAD GROUP', 'a) Jama''at al-Jihad; b) Libyan Society; c) Kazakh Jama''at; d) Jamaat Mojahedin; e) Jamiyat; f) Jamiat al-Jihad al-Islami; g) Dzhamaat Modzhakhedov; h) Islamic Jihad Group of Uzbekistan; i) al-Djihad al-Islami; j) Zamaat Modzhakhedov Tsentralnoy Asii; k) Islamic Jihad Union', '04', 'Jama''at al-Jihad', 'JAMA''AT AL-JIHAD', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1420', '20170807', '����췢[2017]106��', 'ISLAMIC JIHAD GROUP', 'a) Jama''at al-Jihad; b) Libyan Society; c) Kazakh Jama''at; d) Jamaat Mojahedin; e) Jamiyat; f) Jamiat al-Jihad al-Islami; g) Dzhamaat Modzhakhedov; h) Islamic Jihad Group of Uzbekistan; i) al-Djihad al-Islami; j) Zamaat Modzhakhedov Tsentralnoy Asii; k) Islamic Jihad Union', '04', 'Jamiat al-Jihad al-Islami', 'JAMIAT AL-JIHAD AL-ISLAMI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1421', '20170807', '����췢[2017]106��', 'ISLAMIC MOVEMENT OF UZBEKISTAN', 'a) IMU', '01', 'ISLAMIC MOVEMENT OF UZBEKISTAN', 'ISLAMIC MOVEMENT OF UZBEKISTAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1422', '20170807', '����췢[2017]106��', 'ISLAMIC MOVEMENT OF UZBEKISTAN', 'a) IMU', '03', 'IMU', 'IMU', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1423', '20170807', '����췢[2017]106��', 'JAISH-MOHAMMED', 'a) Army of Mohammed', '01', 'JAISH-MOHAMMED', 'JAISH-MOHAMMED', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1424', '20170807', '����췢[2017]106��', 'JAISH-MOHAMMED', 'a) Army of Mohammed', '03', 'Army of Mohammed', 'ARMY OF MOHAMMED', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1425', '20170807', '����췢[2017]106��', 'JAM''YAH TA''AWUN AL-ISLAMIA', 'a) Society of Islamic Cooperation; b) Jam''iyat Al Ta''awun Al Islamiyya; c) Jit ', '01', 'JAM''YAH TA''AWUN AL-ISLAMIA', 'JAM''YAH TA''AWUN AL-ISLAMIA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1426', '20170807', '����췢[2017]106��', 'JAM''YAH TA''AWUN AL-ISLAMIA', 'a) Society of Islamic Cooperation; b) Jam''iyat Al Ta''awun Al Islamiyya; c) Jit ', '04', 'Jit', 'JIT', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1427', '20170807', '����췢[2017]106��', 'JAM''YAH TA''AWUN AL-ISLAMIA', 'a) Society of Islamic Cooperation; b) Jam''iyat Al Ta''awun Al Islamiyya; c) Jit ', '04', 'Jam''iyat Al Ta''awun Al Islamiyya', 'JAM''IYAT AL TA''AWUN AL ISLAMIYYA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1428', '20170807', '����췢[2017]106��', 'JAM''YAH TA''AWUN AL-ISLAMIA', 'a) Society of Islamic Cooperation; b) Jam''iyat Al Ta''awun Al Islamiyya; c) Jit ', '04', 'Society of Islamic Cooperation', 'SOCIETY OF ISLAMIC COOPERATION', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1429', '20170807', '����췢[2017]106��', 'JAMA''ATU AHLIS SUNNA LIDDA''AWATI WAL-JIHAD', 'a) Jama''atu Ahlus-Sunnah Lidda''Awati Wal Jihad; b) Jama''atu Ahlus-Sunna Lidda''Awati Wal Jihad; c) n/a; d) Boko Haram; e) Western Education is a Sin', '01', 'JAMA''ATU AHLIS SUNNA LIDDA''AWATI WAL-JIHAD', 'JAMA''ATU AHLIS SUNNA LIDDA''AWATI WAL-JIHAD', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1430', '20170807', '����췢[2017]106��', 'JAMA''ATU AHLIS SUNNA LIDDA''AWATI WAL-JIHAD', 'a) Jama''atu Ahlus-Sunnah Lidda''Awati Wal Jihad; b) Jama''atu Ahlus-Sunna Lidda''Awati Wal Jihad; c) n/a; d) Boko Haram; e) Western Education is a Sin', '04', 'n/a', 'N/A', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1431', '20170807', '����췢[2017]106��', 'JAMA''ATU AHLIS SUNNA LIDDA''AWATI WAL-JIHAD', 'a) Jama''atu Ahlus-Sunnah Lidda''Awati Wal Jihad; b) Jama''atu Ahlus-Sunna Lidda''Awati Wal Jihad; c) n/a; d) Boko Haram; e) Western Education is a Sin', '04', 'Jama''atu Ahlus-Sunnah Lidda''Awati Wal Jihad', 'JAMA''ATU AHLUS-SUNNAH LIDDA''AWATI WAL JIHAD', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1432', '20170807', '����췢[2017]106��', 'JAMA''ATU AHLIS SUNNA LIDDA''AWATI WAL-JIHAD', 'a) Jama''atu Ahlus-Sunnah Lidda''Awati Wal Jihad; b) Jama''atu Ahlus-Sunna Lidda''Awati Wal Jihad; c) n/a; d) Boko Haram; e) Western Education is a Sin', '04', 'Boko Haram', 'BOKO HARAM', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1433', '20170807', '����췢[2017]106��', 'JAMA''ATU AHLIS SUNNA LIDDA''AWATI WAL-JIHAD', 'a) Jama''atu Ahlus-Sunnah Lidda''Awati Wal Jihad; b) Jama''atu Ahlus-Sunna Lidda''Awati Wal Jihad; c) n/a; d) Boko Haram; e) Western Education is a Sin', '04', 'Jama''atu Ahlus-Sunna Lidda''Awati Wal Jihad', 'JAMA''ATU AHLUS-SUNNA LIDDA''AWATI WAL JIHAD', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1434', '20170807', '����췢[2017]106��', 'JAMA''ATU AHLIS SUNNA LIDDA''AWATI WAL-JIHAD', 'a) Jama''atu Ahlus-Sunnah Lidda''Awati Wal Jihad; b) Jama''atu Ahlus-Sunna Lidda''Awati Wal Jihad; c) n/a; d) Boko Haram; e) Western Education is a Sin', '04', 'Western Education is a Sin', 'WESTERN EDUCATION IS A SIN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1435', '20170807', '����췢[2017]106��', 'JEMAAH ISLAMIYAH', 'a) Jema''ah Islamiyah; b) Jemaah Islamiya; c) Jemaah Islamiah; d) Jamaah Islamiyah; e) Jama''ah Islamiyah', '01', 'JEMAAH ISLAMIYAH', 'JEMAAH ISLAMIYAH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1436', '20170807', '����췢[2017]106��', 'JEMAAH ISLAMIYAH', 'a) Jema''ah Islamiyah; b) Jemaah Islamiya; c) Jemaah Islamiah; d) Jamaah Islamiyah; e) Jama''ah Islamiyah', '04', 'Jemaah Islamiah', 'JEMAAH ISLAMIAH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1437', '20170807', '����췢[2017]106��', 'JEMAAH ISLAMIYAH', 'a) Jema''ah Islamiyah; b) Jemaah Islamiya; c) Jemaah Islamiah; d) Jamaah Islamiyah; e) Jama''ah Islamiyah', '04', 'Jama''ah Islamiyah', 'JAMA''AH ISLAMIYAH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1438', '20170807', '����췢[2017]106��', 'JEMAAH ISLAMIYAH', 'a) Jema''ah Islamiyah; b) Jemaah Islamiya; c) Jemaah Islamiah; d) Jamaah Islamiyah; e) Jama''ah Islamiyah', '04', 'Jemaah Islamiya', 'JEMAAH ISLAMIYA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1439', '20170807', '����췢[2017]106��', 'JEMAAH ISLAMIYAH', 'a) Jema''ah Islamiyah; b) Jemaah Islamiya; c) Jemaah Islamiah; d) Jamaah Islamiyah; e) Jama''ah Islamiyah', '04', 'Jema''ah Islamiyah', 'JEMA''AH ISLAMIYAH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1440', '20170807', '����췢[2017]106��', 'JEMAAH ISLAMIYAH', 'a) Jema''ah Islamiyah; b) Jemaah Islamiya; c) Jemaah Islamiah; d) Jamaah Islamiyah; e) Jama''ah Islamiyah', '04', 'Jamaah Islamiyah', 'JAMAAH ISLAMIYAH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1441', '20170807', '����췢[2017]106��', 'JEMMAH ANSHORUT TAUHID (JAT)', 'a) Jemaah Anshorut Tauhid; b) Jemmah Ansharut Tauhid; c) Jem''mah Ansharut Tauhid; d) Jamaah Ansharut Tauhid; e) Jamaah Ansharut Tauhid; f) Laskar 99', '01', 'JEMMAH ANSHORUT TAUHID (JAT)', 'JEMMAH ANSHORUT TAUHID (JAT)', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1442', '20170807', '����췢[2017]106��', 'JEMMAH ANSHORUT TAUHID (JAT)', 'a) Jemaah Anshorut Tauhid; b) Jemmah Ansharut Tauhid; c) Jem''mah Ansharut Tauhid; d) Jamaah Ansharut Tauhid; e) Jamaah Ansharut Tauhid; f) Laskar 99', '04', 'Laskar 99', 'LASKAR 99', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1443', '20170807', '����췢[2017]106��', 'JEMMAH ANSHORUT TAUHID (JAT)', 'a) Jemaah Anshorut Tauhid; b) Jemmah Ansharut Tauhid; c) Jem''mah Ansharut Tauhid; d) Jamaah Ansharut Tauhid; e) Jamaah Ansharut Tauhid; f) Laskar 99', '04', 'Jemmah Ansharut Tauhid', 'JEMMAH ANSHARUT TAUHID', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1444', '20170807', '����췢[2017]106��', 'JEMMAH ANSHORUT TAUHID (JAT)', 'a) Jemaah Anshorut Tauhid; b) Jemmah Ansharut Tauhid; c) Jem''mah Ansharut Tauhid; d) Jamaah Ansharut Tauhid; e) Jamaah Ansharut Tauhid; f) Laskar 99', '04', 'Jemaah Anshorut Tauhid', 'JEMAAH ANSHORUT TAUHID', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1445', '20170807', '����췢[2017]106��', 'JEMMAH ANSHORUT TAUHID (JAT)', 'a) Jemaah Anshorut Tauhid; b) Jemmah Ansharut Tauhid; c) Jem''mah Ansharut Tauhid; d) Jamaah Ansharut Tauhid; e) Jamaah Ansharut Tauhid; f) Laskar 99', '04', 'Jem''mah Ansharut Tauhid', 'JEM''MAH ANSHARUT TAUHID', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1446', '20170807', '����췢[2017]106��', 'JEMMAH ANSHORUT TAUHID (JAT)', 'a) Jemaah Anshorut Tauhid; b) Jemmah Ansharut Tauhid; c) Jem''mah Ansharut Tauhid; d) Jamaah Ansharut Tauhid; e) Jamaah Ansharut Tauhid; f) Laskar 99', '04', 'Jamaah Ansharut Tauhid', 'JAMAAH ANSHARUT TAUHID', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1447', '20170807', '����췢[2017]106��', 'JEMMAH ANSHORUT TAUHID (JAT)', 'a) Jemaah Anshorut Tauhid; b) Jemmah Ansharut Tauhid; c) Jem''mah Ansharut Tauhid; d) Jamaah Ansharut Tauhid; e) Jamaah Ansharut Tauhid; f) Laskar 99', '04', 'Jamaah Ansharut Tauhid', 'JAMAAH ANSHARUT TAUHID', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1448', '20170807', '����췢[2017]106��', 'JUND AL-KHILAFAH ALGERIA (JAK-A)', 'a) Jund al Khalifa; b) Jund al-Khilafah fi Ard al-Jaza''ir; c) Jund al-Khalifa fi Ard al-Jazayer; d) Soldiers of the Caliphate in Algeria; e) Soldiers of the Caliphate of Algeria; f) Soldiers of the Caliphate in the Land of Algeria', '01', 'JUND AL-KHILAFAH ALGERIA (JAK-A)', 'JUND AL-KHILAFAH ALGERIA (JAK-A)', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1449', '20170807', '����췢[2017]106��', 'JUND AL-KHILAFAH ALGERIA (JAK-A)', 'a) Jund al Khalifa; b) Jund al-Khilafah fi Ard al-Jaza''ir; c) Jund al-Khalifa fi Ard al-Jazayer; d) Soldiers of the Caliphate in Algeria; e) Soldiers of the Caliphate of Algeria; f) Soldiers of the Caliphate in the Land of Algeria', '04', 'Jund al-Khilafah fi Ard al-Jaza''ir', 'JUND AL-KHILAFAH FI ARD AL-JAZA''IR', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1450', '20170807', '����췢[2017]106��', 'JUND AL-KHILAFAH ALGERIA (JAK-A)', 'a) Jund al Khalifa; b) Jund al-Khilafah fi Ard al-Jaza''ir; c) Jund al-Khalifa fi Ard al-Jazayer; d) Soldiers of the Caliphate in Algeria; e) Soldiers of the Caliphate of Algeria; f) Soldiers of the Caliphate in the Land of Algeria', '04', 'Jund al Khalifa', 'JUND AL KHALIFA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1451', '20170807', '����췢[2017]106��', 'JUND AL-KHILAFAH ALGERIA (JAK-A)', 'a) Jund al Khalifa; b) Jund al-Khilafah fi Ard al-Jaza''ir; c) Jund al-Khalifa fi Ard al-Jazayer; d) Soldiers of the Caliphate in Algeria; e) Soldiers of the Caliphate of Algeria; f) Soldiers of the Caliphate in the Land of Algeria', '04', 'Soldiers of the Caliphate in the Land of Algeria', 'SOLDIERS OF THE CALIPHATE IN THE LAND OF ALGERIA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1452', '20170807', '����췢[2017]106��', 'JUND AL-KHILAFAH ALGERIA (JAK-A)', 'a) Jund al Khalifa; b) Jund al-Khilafah fi Ard al-Jaza''ir; c) Jund al-Khalifa fi Ard al-Jazayer; d) Soldiers of the Caliphate in Algeria; e) Soldiers of the Caliphate of Algeria; f) Soldiers of the Caliphate in the Land of Algeria', '04', 'Soldiers of the Caliphate of Algeria', 'SOLDIERS OF THE CALIPHATE OF ALGERIA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1453', '20170807', '����췢[2017]106��', 'JUND AL-KHILAFAH ALGERIA (JAK-A)', 'a) Jund al Khalifa; b) Jund al-Khilafah fi Ard al-Jaza''ir; c) Jund al-Khalifa fi Ard al-Jazayer; d) Soldiers of the Caliphate in Algeria; e) Soldiers of the Caliphate of Algeria; f) Soldiers of the Caliphate in the Land of Algeria', '04', 'Soldiers of the Caliphate in Algeria', 'SOLDIERS OF THE CALIPHATE IN ALGERIA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1454', '20170807', '����췢[2017]106��', 'JUND AL-KHILAFAH ALGERIA (JAK-A)', 'a) Jund al Khalifa; b) Jund al-Khilafah fi Ard al-Jaza''ir; c) Jund al-Khalifa fi Ard al-Jazayer; d) Soldiers of the Caliphate in Algeria; e) Soldiers of the Caliphate of Algeria; f) Soldiers of the Caliphate in the Land of Algeria', '04', 'Jund al-Khalifa fi Ard al-Jazayer', 'JUND AL-KHALIFA FI ARD AL-JAZAYER', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1455', '20170807', '����췢[2017]106��', 'LASHKAR I JHANGVI (LJ)', null, '01', 'LASHKAR I JHANGVI (LJ)', 'LASHKAR I JHANGVI (LJ)', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1456', '20170807', '����췢[2017]106��', 'LASHKAR-E-TAYYIBA', 'a) Lashkar-e-Toiba; b) Lashkar-i-Taiba; c) al Mansoorian; d) al Mansooreen; e) Army of the Pure; f) Army of the Righteous; g) Army of the Pure and Righteous; h) Paasban-e-Kashmir; i) Paasban-i-Ahle-Hadith; j) Pasban-e-Kashmir; k) Pasban-e-Ahle-Hadith; l) Paasban-e-Ahle-Hadis; m) Pashan-e-ahle Hadis; n) Lashkar e Tayyaba; o) LET; p) Jamaat-ud-Dawa; q) JUD; r) Jama''at al-Dawa; s) Jamaat ud-Daawa; t) Jamaat ul-Dawah; u) Jamaat-ul-Dawa; v) Jama''at-i-Dawat; w) Jamaiat-ud-Dawa; x) Jama''at-ud-Da''awah; y) Jama''at-ud-Da''awa; z) Jamaati-ud-Dawa; aa) Falah-i-Insaniat Foundation (FIF)', '01', 'LASHKAR-E-TAYYIBA', 'LASHKAR-E-TAYYIBA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1457', '20170807', '����췢[2017]106��', 'LASHKAR-E-TAYYIBA', 'a) Lashkar-e-Toiba; b) Lashkar-i-Taiba; c) al Mansoorian; d) al Mansooreen; e) Army of the Pure; f) Army of the Righteous; g) Army of the Pure and Righteous; h) Paasban-e-Kashmir; i) Paasban-i-Ahle-Hadith; j) Pasban-e-Kashmir; k) Pasban-e-Ahle-Hadith; l) Paasban-e-Ahle-Hadis; m) Pashan-e-ahle Hadis; n) Lashkar e Tayyaba; o) LET; p) Jamaat-ud-Dawa; q) JUD; r) Jama''at al-Dawa; s) Jamaat ud-Daawa; t) Jamaat ul-Dawah; u) Jamaat-ul-Dawa; v) Jama''at-i-Dawat; w) Jamaiat-ud-Dawa; x) Jama''at-ud-Da''awah; y) Jama''at-ud-Da''awa; z) Jamaati-ud-Dawa; aa) Falah-i-Insaniat Foundation (FIF)', '04', 'Lashkar e Tayyaba', 'LASHKAR E TAYYABA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1458', '20170807', '����췢[2017]106��', 'LASHKAR-E-TAYYIBA', 'a) Lashkar-e-Toiba; b) Lashkar-i-Taiba; c) al Mansoorian; d) al Mansooreen; e) Army of the Pure; f) Army of the Righteous; g) Army of the Pure and Righteous; h) Paasban-e-Kashmir; i) Paasban-i-Ahle-Hadith; j) Pasban-e-Kashmir; k) Pasban-e-Ahle-Hadith; l) Paasban-e-Ahle-Hadis; m) Pashan-e-ahle Hadis; n) Lashkar e Tayyaba; o) LET; p) Jamaat-ud-Dawa; q) JUD; r) Jama''at al-Dawa; s) Jamaat ud-Daawa; t) Jamaat ul-Dawah; u) Jamaat-ul-Dawa; v) Jama''at-i-Dawat; w) Jamaiat-ud-Dawa; x) Jama''at-ud-Da''awah; y) Jama''at-ud-Da''awa; z) Jamaati-ud-Dawa; aa) Falah-i-Insaniat Foundation (FIF)', '04', 'LET', 'LET', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1459', '20170807', '����췢[2017]106��', 'LASHKAR-E-TAYYIBA', 'a) Lashkar-e-Toiba; b) Lashkar-i-Taiba; c) al Mansoorian; d) al Mansooreen; e) Army of the Pure; f) Army of the Righteous; g) Army of the Pure and Righteous; h) Paasban-e-Kashmir; i) Paasban-i-Ahle-Hadith; j) Pasban-e-Kashmir; k) Pasban-e-Ahle-Hadith; l) Paasban-e-Ahle-Hadis; m) Pashan-e-ahle Hadis; n) Lashkar e Tayyaba; o) LET; p) Jamaat-ud-Dawa; q) JUD; r) Jama''at al-Dawa; s) Jamaat ud-Daawa; t) Jamaat ul-Dawah; u) Jamaat-ul-Dawa; v) Jama''at-i-Dawat; w) Jamaiat-ud-Dawa; x) Jama''at-ud-Da''awah; y) Jama''at-ud-Da''awa; z) Jamaati-ud-Dawa; aa) Falah-i-Insaniat Foundation (FIF)', '04', 'Jamaat-ud-Dawa', 'JAMAAT-UD-DAWA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1460', '20170807', '����췢[2017]106��', 'LASHKAR-E-TAYYIBA', 'a) Lashkar-e-Toiba; b) Lashkar-i-Taiba; c) al Mansoorian; d) al Mansooreen; e) Army of the Pure; f) Army of the Righteous; g) Army of the Pure and Righteous; h) Paasban-e-Kashmir; i) Paasban-i-Ahle-Hadith; j) Pasban-e-Kashmir; k) Pasban-e-Ahle-Hadith; l) Paasban-e-Ahle-Hadis; m) Pashan-e-ahle Hadis; n) Lashkar e Tayyaba; o) LET; p) Jamaat-ud-Dawa; q) JUD; r) Jama''at al-Dawa; s) Jamaat ud-Daawa; t) Jamaat ul-Dawah; u) Jamaat-ul-Dawa; v) Jama''at-i-Dawat; w) Jamaiat-ud-Dawa; x) Jama''at-ud-Da''awah; y) Jama''at-ud-Da''awa; z) Jamaati-ud-Dawa; aa) Falah-i-Insaniat Foundation (FIF)', '04', 'JUD', 'JUD', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1461', '20170807', '����췢[2017]106��', 'LASHKAR-E-TAYYIBA', 'a) Lashkar-e-Toiba; b) Lashkar-i-Taiba; c) al Mansoorian; d) al Mansooreen; e) Army of the Pure; f) Army of the Righteous; g) Army of the Pure and Righteous; h) Paasban-e-Kashmir; i) Paasban-i-Ahle-Hadith; j) Pasban-e-Kashmir; k) Pasban-e-Ahle-Hadith; l) Paasban-e-Ahle-Hadis; m) Pashan-e-ahle Hadis; n) Lashkar e Tayyaba; o) LET; p) Jamaat-ud-Dawa; q) JUD; r) Jama''at al-Dawa; s) Jamaat ud-Daawa; t) Jamaat ul-Dawah; u) Jamaat-ul-Dawa; v) Jama''at-i-Dawat; w) Jamaiat-ud-Dawa; x) Jama''at-ud-Da''awah; y) Jama''at-ud-Da''awa; z) Jamaati-ud-Dawa; aa) Falah-i-Insaniat Foundation (FIF)', '04', 'Jama''at al-Dawa', 'JAMA''AT AL-DAWA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1462', '20170807', '����췢[2017]106��', 'LASHKAR-E-TAYYIBA', 'a) Lashkar-e-Toiba; b) Lashkar-i-Taiba; c) al Mansoorian; d) al Mansooreen; e) Army of the Pure; f) Army of the Righteous; g) Army of the Pure and Righteous; h) Paasban-e-Kashmir; i) Paasban-i-Ahle-Hadith; j) Pasban-e-Kashmir; k) Pasban-e-Ahle-Hadith; l) Paasban-e-Ahle-Hadis; m) Pashan-e-ahle Hadis; n) Lashkar e Tayyaba; o) LET; p) Jamaat-ud-Dawa; q) JUD; r) Jama''at al-Dawa; s) Jamaat ud-Daawa; t) Jamaat ul-Dawah; u) Jamaat-ul-Dawa; v) Jama''at-i-Dawat; w) Jamaiat-ud-Dawa; x) Jama''at-ud-Da''awah; y) Jama''at-ud-Da''awa; z) Jamaati-ud-Dawa; aa) Falah-i-Insaniat Foundation (FIF)', '04', 'Jamaat ud-Daawa', 'JAMAAT UD-DAAWA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1463', '20170807', '����췢[2017]106��', 'LASHKAR-E-TAYYIBA', 'a) Lashkar-e-Toiba; b) Lashkar-i-Taiba; c) al Mansoorian; d) al Mansooreen; e) Army of the Pure; f) Army of the Righteous; g) Army of the Pure and Righteous; h) Paasban-e-Kashmir; i) Paasban-i-Ahle-Hadith; j) Pasban-e-Kashmir; k) Pasban-e-Ahle-Hadith; l) Paasban-e-Ahle-Hadis; m) Pashan-e-ahle Hadis; n) Lashkar e Tayyaba; o) LET; p) Jamaat-ud-Dawa; q) JUD; r) Jama''at al-Dawa; s) Jamaat ud-Daawa; t) Jamaat ul-Dawah; u) Jamaat-ul-Dawa; v) Jama''at-i-Dawat; w) Jamaiat-ud-Dawa; x) Jama''at-ud-Da''awah; y) Jama''at-ud-Da''awa; z) Jamaati-ud-Dawa; aa) Falah-i-Insaniat Foundation (FIF)', '04', 'Jamaat ul-Dawah', 'JAMAAT UL-DAWAH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1464', '20170807', '����췢[2017]106��', 'LASHKAR-E-TAYYIBA', 'a) Lashkar-e-Toiba; b) Lashkar-i-Taiba; c) al Mansoorian; d) al Mansooreen; e) Army of the Pure; f) Army of the Righteous; g) Army of the Pure and Righteous; h) Paasban-e-Kashmir; i) Paasban-i-Ahle-Hadith; j) Pasban-e-Kashmir; k) Pasban-e-Ahle-Hadith; l) Paasban-e-Ahle-Hadis; m) Pashan-e-ahle Hadis; n) Lashkar e Tayyaba; o) LET; p) Jamaat-ud-Dawa; q) JUD; r) Jama''at al-Dawa; s) Jamaat ud-Daawa; t) Jamaat ul-Dawah; u) Jamaat-ul-Dawa; v) Jama''at-i-Dawat; w) Jamaiat-ud-Dawa; x) Jama''at-ud-Da''awah; y) Jama''at-ud-Da''awa; z) Jamaati-ud-Dawa; aa) Falah-i-Insaniat Foundation (FIF)', '04', 'Jamaat-ul-Dawa', 'JAMAAT-UL-DAWA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1465', '20170807', '����췢[2017]106��', 'LASHKAR-E-TAYYIBA', 'a) Lashkar-e-Toiba; b) Lashkar-i-Taiba; c) al Mansoorian; d) al Mansooreen; e) Army of the Pure; f) Army of the Righteous; g) Army of the Pure and Righteous; h) Paasban-e-Kashmir; i) Paasban-i-Ahle-Hadith; j) Pasban-e-Kashmir; k) Pasban-e-Ahle-Hadith; l) Paasban-e-Ahle-Hadis; m) Pashan-e-ahle Hadis; n) Lashkar e Tayyaba; o) LET; p) Jamaat-ud-Dawa; q) JUD; r) Jama''at al-Dawa; s) Jamaat ud-Daawa; t) Jamaat ul-Dawah; u) Jamaat-ul-Dawa; v) Jama''at-i-Dawat; w) Jamaiat-ud-Dawa; x) Jama''at-ud-Da''awah; y) Jama''at-ud-Da''awa; z) Jamaati-ud-Dawa; aa) Falah-i-Insaniat Foundation (FIF)', '04', 'Jama''at-i-Dawat', 'JAMA''AT-I-DAWAT', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1466', '20170807', '����췢[2017]106��', 'LASHKAR-E-TAYYIBA', 'a) Lashkar-e-Toiba; b) Lashkar-i-Taiba; c) al Mansoorian; d) al Mansooreen; e) Army of the Pure; f) Army of the Righteous; g) Army of the Pure and Righteous; h) Paasban-e-Kashmir; i) Paasban-i-Ahle-Hadith; j) Pasban-e-Kashmir; k) Pasban-e-Ahle-Hadith; l) Paasban-e-Ahle-Hadis; m) Pashan-e-ahle Hadis; n) Lashkar e Tayyaba; o) LET; p) Jamaat-ud-Dawa; q) JUD; r) Jama''at al-Dawa; s) Jamaat ud-Daawa; t) Jamaat ul-Dawah; u) Jamaat-ul-Dawa; v) Jama''at-i-Dawat; w) Jamaiat-ud-Dawa; x) Jama''at-ud-Da''awah; y) Jama''at-ud-Da''awa; z) Jamaati-ud-Dawa; aa) Falah-i-Insaniat Foundation (FIF)', '04', 'Jamaiat-ud-Dawa', 'JAMAIAT-UD-DAWA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1467', '20170807', '����췢[2017]106��', 'LASHKAR-E-TAYYIBA', 'a) Lashkar-e-Toiba; b) Lashkar-i-Taiba; c) al Mansoorian; d) al Mansooreen; e) Army of the Pure; f) Army of the Righteous; g) Army of the Pure and Righteous; h) Paasban-e-Kashmir; i) Paasban-i-Ahle-Hadith; j) Pasban-e-Kashmir; k) Pasban-e-Ahle-Hadith; l) Paasban-e-Ahle-Hadis; m) Pashan-e-ahle Hadis; n) Lashkar e Tayyaba; o) LET; p) Jamaat-ud-Dawa; q) JUD; r) Jama''at al-Dawa; s) Jamaat ud-Daawa; t) Jamaat ul-Dawah; u) Jamaat-ul-Dawa; v) Jama''at-i-Dawat; w) Jamaiat-ud-Dawa; x) Jama''at-ud-Da''awah; y) Jama''at-ud-Da''awa; z) Jamaati-ud-Dawa; aa) Falah-i-Insaniat Foundation (FIF)', '04', 'Jama''at-ud-Da''awah', 'JAMA''AT-UD-DA''AWAH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1468', '20170807', '����췢[2017]106��', 'LASHKAR-E-TAYYIBA', 'a) Lashkar-e-Toiba; b) Lashkar-i-Taiba; c) al Mansoorian; d) al Mansooreen; e) Army of the Pure; f) Army of the Righteous; g) Army of the Pure and Righteous; h) Paasban-e-Kashmir; i) Paasban-i-Ahle-Hadith; j) Pasban-e-Kashmir; k) Pasban-e-Ahle-Hadith; l) Paasban-e-Ahle-Hadis; m) Pashan-e-ahle Hadis; n) Lashkar e Tayyaba; o) LET; p) Jamaat-ud-Dawa; q) JUD; r) Jama''at al-Dawa; s) Jamaat ud-Daawa; t) Jamaat ul-Dawah; u) Jamaat-ul-Dawa; v) Jama''at-i-Dawat; w) Jamaiat-ud-Dawa; x) Jama''at-ud-Da''awah; y) Jama''at-ud-Da''awa; z) Jamaati-ud-Dawa; aa) Falah-i-Insaniat Foundation (FIF)', '04', 'Jama''at-ud-Da''awa', 'JAMA''AT-UD-DA''AWA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1469', '20170807', '����췢[2017]106��', 'LASHKAR-E-TAYYIBA', 'a) Lashkar-e-Toiba; b) Lashkar-i-Taiba; c) al Mansoorian; d) al Mansooreen; e) Army of the Pure; f) Army of the Righteous; g) Army of the Pure and Righteous; h) Paasban-e-Kashmir; i) Paasban-i-Ahle-Hadith; j) Pasban-e-Kashmir; k) Pasban-e-Ahle-Hadith; l) Paasban-e-Ahle-Hadis; m) Pashan-e-ahle Hadis; n) Lashkar e Tayyaba; o) LET; p) Jamaat-ud-Dawa; q) JUD; r) Jama''at al-Dawa; s) Jamaat ud-Daawa; t) Jamaat ul-Dawah; u) Jamaat-ul-Dawa; v) Jama''at-i-Dawat; w) Jamaiat-ud-Dawa; x) Jama''at-ud-Da''awah; y) Jama''at-ud-Da''awa; z) Jamaati-ud-Dawa; aa) Falah-i-Insaniat Foundation (FIF)', '04', 'Jamaati-ud-Dawa', 'JAMAATI-UD-DAWA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1470', '20170807', '����췢[2017]106��', 'LASHKAR-E-TAYYIBA', 'a) Lashkar-e-Toiba; b) Lashkar-i-Taiba; c) al Mansoorian; d) al Mansooreen; e) Army of the Pure; f) Army of the Righteous; g) Army of the Pure and Righteous; h) Paasban-e-Kashmir; i) Paasban-i-Ahle-Hadith; j) Pasban-e-Kashmir; k) Pasban-e-Ahle-Hadith; l) Paasban-e-Ahle-Hadis; m) Pashan-e-ahle Hadis; n) Lashkar e Tayyaba; o) LET; p) Jamaat-ud-Dawa; q) JUD; r) Jama''at al-Dawa; s) Jamaat ud-Daawa; t) Jamaat ul-Dawah; u) Jamaat-ul-Dawa; v) Jama''at-i-Dawat; w) Jamaiat-ud-Dawa; x) Jama''at-ud-Da''awah; y) Jama''at-ud-Da''awa; z) Jamaati-ud-Dawa; aa) Falah-i-Insaniat Foundation (FIF)', '04', 'Falah-i-Insaniat Foundation (FIF)', 'FALAH-I-INSANIAT FOUNDATION (FIF)', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1471', '20170807', '����췢[2017]106��', 'LASHKAR-E-TAYYIBA', 'a) Lashkar-e-Toiba; b) Lashkar-i-Taiba; c) al Mansoorian; d) al Mansooreen; e) Army of the Pure; f) Army of the Righteous; g) Army of the Pure and Righteous; h) Paasban-e-Kashmir; i) Paasban-i-Ahle-Hadith; j) Pasban-e-Kashmir; k) Pasban-e-Ahle-Hadith; l) Paasban-e-Ahle-Hadis; m) Pashan-e-ahle Hadis; n) Lashkar e Tayyaba; o) LET; p) Jamaat-ud-Dawa; q) JUD; r) Jama''at al-Dawa; s) Jamaat ud-Daawa; t) Jamaat ul-Dawah; u) Jamaat-ul-Dawa; v) Jama''at-i-Dawat; w) Jamaiat-ud-Dawa; x) Jama''at-ud-Da''awah; y) Jama''at-ud-Da''awa; z) Jamaati-ud-Dawa; aa) Falah-i-Insaniat Foundation (FIF)', '04', 'Falah-i-Insaniat Foundation', 'FALAH-I-INSANIAT FOUNDATION', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1472', '20170807', '����췢[2017]106��', 'LASHKAR-E-TAYYIBA', 'a) Lashkar-e-Toiba; b) Lashkar-i-Taiba; c) al Mansoorian; d) al Mansooreen; e) Army of the Pure; f) Army of the Righteous; g) Army of the Pure and Righteous; h) Paasban-e-Kashmir; i) Paasban-i-Ahle-Hadith; j) Pasban-e-Kashmir; k) Pasban-e-Ahle-Hadith; l) Paasban-e-Ahle-Hadis; m) Pashan-e-ahle Hadis; n) Lashkar e Tayyaba; o) LET; p) Jamaat-ud-Dawa; q) JUD; r) Jama''at al-Dawa; s) Jamaat ud-Daawa; t) Jamaat ul-Dawah; u) Jamaat-ul-Dawa; v) Jama''at-i-Dawat; w) Jamaiat-ud-Dawa; x) Jama''at-ud-Da''awah; y) Jama''at-ud-Da''awa; z) Jamaati-ud-Dawa; aa) Falah-i-Insaniat Foundation (FIF)', '04', 'FIF', 'FIF', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1473', '20170807', '����췢[2017]106��', 'LASHKAR-E-TAYYIBA', 'a) Lashkar-e-Toiba; b) Lashkar-i-Taiba; c) al Mansoorian; d) al Mansooreen; e) Army of the Pure; f) Army of the Righteous; g) Army of the Pure and Righteous; h) Paasban-e-Kashmir; i) Paasban-i-Ahle-Hadith; j) Pasban-e-Kashmir; k) Pasban-e-Ahle-Hadith; l) Paasban-e-Ahle-Hadis; m) Pashan-e-ahle Hadis; n) Lashkar e Tayyaba; o) LET; p) Jamaat-ud-Dawa; q) JUD; r) Jama''at al-Dawa; s) Jamaat ud-Daawa; t) Jamaat ul-Dawah; u) Jamaat-ul-Dawa; v) Jama''at-i-Dawat; w) Jamaiat-ud-Dawa; x) Jama''at-ud-Da''awah; y) Jama''at-ud-Da''awa; z) Jamaati-ud-Dawa; aa) Falah-i-Insaniat Foundation (FIF)', '04', 'Lashkar-e-Toiba', 'LASHKAR-E-TOIBA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1474', '20170807', '����췢[2017]106��', 'LASHKAR-E-TAYYIBA', 'a) Lashkar-e-Toiba; b) Lashkar-i-Taiba; c) al Mansoorian; d) al Mansooreen; e) Army of the Pure; f) Army of the Righteous; g) Army of the Pure and Righteous; h) Paasban-e-Kashmir; i) Paasban-i-Ahle-Hadith; j) Pasban-e-Kashmir; k) Pasban-e-Ahle-Hadith; l) Paasban-e-Ahle-Hadis; m) Pashan-e-ahle Hadis; n) Lashkar e Tayyaba; o) LET; p) Jamaat-ud-Dawa; q) JUD; r) Jama''at al-Dawa; s) Jamaat ud-Daawa; t) Jamaat ul-Dawah; u) Jamaat-ul-Dawa; v) Jama''at-i-Dawat; w) Jamaiat-ud-Dawa; x) Jama''at-ud-Da''awah; y) Jama''at-ud-Da''awa; z) Jamaati-ud-Dawa; aa) Falah-i-Insaniat Foundation (FIF)', '04', 'Lashkar-i-Taiba', 'LASHKAR-I-TAIBA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1475', '20170807', '����췢[2017]106��', 'LASHKAR-E-TAYYIBA', 'a) Lashkar-e-Toiba; b) Lashkar-i-Taiba; c) al Mansoorian; d) al Mansooreen; e) Army of the Pure; f) Army of the Righteous; g) Army of the Pure and Righteous; h) Paasban-e-Kashmir; i) Paasban-i-Ahle-Hadith; j) Pasban-e-Kashmir; k) Pasban-e-Ahle-Hadith; l) Paasban-e-Ahle-Hadis; m) Pashan-e-ahle Hadis; n) Lashkar e Tayyaba; o) LET; p) Jamaat-ud-Dawa; q) JUD; r) Jama''at al-Dawa; s) Jamaat ud-Daawa; t) Jamaat ul-Dawah; u) Jamaat-ul-Dawa; v) Jama''at-i-Dawat; w) Jamaiat-ud-Dawa; x) Jama''at-ud-Da''awah; y) Jama''at-ud-Da''awa; z) Jamaati-ud-Dawa; aa) Falah-i-Insaniat Foundation (FIF)', '04', 'al Mansoorian', 'AL MANSOORIAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1476', '20170807', '����췢[2017]106��', 'LASHKAR-E-TAYYIBA', 'a) Lashkar-e-Toiba; b) Lashkar-i-Taiba; c) al Mansoorian; d) al Mansooreen; e) Army of the Pure; f) Army of the Righteous; g) Army of the Pure and Righteous; h) Paasban-e-Kashmir; i) Paasban-i-Ahle-Hadith; j) Pasban-e-Kashmir; k) Pasban-e-Ahle-Hadith; l) Paasban-e-Ahle-Hadis; m) Pashan-e-ahle Hadis; n) Lashkar e Tayyaba; o) LET; p) Jamaat-ud-Dawa; q) JUD; r) Jama''at al-Dawa; s) Jamaat ud-Daawa; t) Jamaat ul-Dawah; u) Jamaat-ul-Dawa; v) Jama''at-i-Dawat; w) Jamaiat-ud-Dawa; x) Jama''at-ud-Da''awah; y) Jama''at-ud-Da''awa; z) Jamaati-ud-Dawa; aa) Falah-i-Insaniat Foundation (FIF)', '04', 'al Mansooreen', 'AL MANSOOREEN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1477', '20170807', '����췢[2017]106��', 'LASHKAR-E-TAYYIBA', 'a) Lashkar-e-Toiba; b) Lashkar-i-Taiba; c) al Mansoorian; d) al Mansooreen; e) Army of the Pure; f) Army of the Righteous; g) Army of the Pure and Righteous; h) Paasban-e-Kashmir; i) Paasban-i-Ahle-Hadith; j) Pasban-e-Kashmir; k) Pasban-e-Ahle-Hadith; l) Paasban-e-Ahle-Hadis; m) Pashan-e-ahle Hadis; n) Lashkar e Tayyaba; o) LET; p) Jamaat-ud-Dawa; q) JUD; r) Jama''at al-Dawa; s) Jamaat ud-Daawa; t) Jamaat ul-Dawah; u) Jamaat-ul-Dawa; v) Jama''at-i-Dawat; w) Jamaiat-ud-Dawa; x) Jama''at-ud-Da''awah; y) Jama''at-ud-Da''awa; z) Jamaati-ud-Dawa; aa) Falah-i-Insaniat Foundation (FIF)', '04', 'Army of the Pure', 'ARMY OF THE PURE', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1478', '20170807', '����췢[2017]106��', 'LASHKAR-E-TAYYIBA', 'a) Lashkar-e-Toiba; b) Lashkar-i-Taiba; c) al Mansoorian; d) al Mansooreen; e) Army of the Pure; f) Army of the Righteous; g) Army of the Pure and Righteous; h) Paasban-e-Kashmir; i) Paasban-i-Ahle-Hadith; j) Pasban-e-Kashmir; k) Pasban-e-Ahle-Hadith; l) Paasban-e-Ahle-Hadis; m) Pashan-e-ahle Hadis; n) Lashkar e Tayyaba; o) LET; p) Jamaat-ud-Dawa; q) JUD; r) Jama''at al-Dawa; s) Jamaat ud-Daawa; t) Jamaat ul-Dawah; u) Jamaat-ul-Dawa; v) Jama''at-i-Dawat; w) Jamaiat-ud-Dawa; x) Jama''at-ud-Da''awah; y) Jama''at-ud-Da''awa; z) Jamaati-ud-Dawa; aa) Falah-i-Insaniat Foundation (FIF)', '04', 'Army of the Righteous', 'ARMY OF THE RIGHTEOUS', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1479', '20170807', '����췢[2017]106��', 'LASHKAR-E-TAYYIBA', 'a) Lashkar-e-Toiba; b) Lashkar-i-Taiba; c) al Mansoorian; d) al Mansooreen; e) Army of the Pure; f) Army of the Righteous; g) Army of the Pure and Righteous; h) Paasban-e-Kashmir; i) Paasban-i-Ahle-Hadith; j) Pasban-e-Kashmir; k) Pasban-e-Ahle-Hadith; l) Paasban-e-Ahle-Hadis; m) Pashan-e-ahle Hadis; n) Lashkar e Tayyaba; o) LET; p) Jamaat-ud-Dawa; q) JUD; r) Jama''at al-Dawa; s) Jamaat ud-Daawa; t) Jamaat ul-Dawah; u) Jamaat-ul-Dawa; v) Jama''at-i-Dawat; w) Jamaiat-ud-Dawa; x) Jama''at-ud-Da''awah; y) Jama''at-ud-Da''awa; z) Jamaati-ud-Dawa; aa) Falah-i-Insaniat Foundation (FIF)', '04', 'Army of the Pure and Righteous', 'ARMY OF THE PURE AND RIGHTEOUS', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1480', '20170807', '����췢[2017]106��', 'LASHKAR-E-TAYYIBA', 'a) Lashkar-e-Toiba; b) Lashkar-i-Taiba; c) al Mansoorian; d) al Mansooreen; e) Army of the Pure; f) Army of the Righteous; g) Army of the Pure and Righteous; h) Paasban-e-Kashmir; i) Paasban-i-Ahle-Hadith; j) Pasban-e-Kashmir; k) Pasban-e-Ahle-Hadith; l) Paasban-e-Ahle-Hadis; m) Pashan-e-ahle Hadis; n) Lashkar e Tayyaba; o) LET; p) Jamaat-ud-Dawa; q) JUD; r) Jama''at al-Dawa; s) Jamaat ud-Daawa; t) Jamaat ul-Dawah; u) Jamaat-ul-Dawa; v) Jama''at-i-Dawat; w) Jamaiat-ud-Dawa; x) Jama''at-ud-Da''awah; y) Jama''at-ud-Da''awa; z) Jamaati-ud-Dawa; aa) Falah-i-Insaniat Foundation (FIF)', '04', 'Paasban-e-Kashmir', 'PAASBAN-E-KASHMIR', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1481', '20170807', '����췢[2017]106��', 'LASHKAR-E-TAYYIBA', 'a) Lashkar-e-Toiba; b) Lashkar-i-Taiba; c) al Mansoorian; d) al Mansooreen; e) Army of the Pure; f) Army of the Righteous; g) Army of the Pure and Righteous; h) Paasban-e-Kashmir; i) Paasban-i-Ahle-Hadith; j) Pasban-e-Kashmir; k) Pasban-e-Ahle-Hadith; l) Paasban-e-Ahle-Hadis; m) Pashan-e-ahle Hadis; n) Lashkar e Tayyaba; o) LET; p) Jamaat-ud-Dawa; q) JUD; r) Jama''at al-Dawa; s) Jamaat ud-Daawa; t) Jamaat ul-Dawah; u) Jamaat-ul-Dawa; v) Jama''at-i-Dawat; w) Jamaiat-ud-Dawa; x) Jama''at-ud-Da''awah; y) Jama''at-ud-Da''awa; z) Jamaati-ud-Dawa; aa) Falah-i-Insaniat Foundation (FIF)', '04', 'Paasban-i-Ahle-Hadith', 'PAASBAN-I-AHLE-HADITH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1482', '20170807', '����췢[2017]106��', 'LASHKAR-E-TAYYIBA', 'a) Lashkar-e-Toiba; b) Lashkar-i-Taiba; c) al Mansoorian; d) al Mansooreen; e) Army of the Pure; f) Army of the Righteous; g) Army of the Pure and Righteous; h) Paasban-e-Kashmir; i) Paasban-i-Ahle-Hadith; j) Pasban-e-Kashmir; k) Pasban-e-Ahle-Hadith; l) Paasban-e-Ahle-Hadis; m) Pashan-e-ahle Hadis; n) Lashkar e Tayyaba; o) LET; p) Jamaat-ud-Dawa; q) JUD; r) Jama''at al-Dawa; s) Jamaat ud-Daawa; t) Jamaat ul-Dawah; u) Jamaat-ul-Dawa; v) Jama''at-i-Dawat; w) Jamaiat-ud-Dawa; x) Jama''at-ud-Da''awah; y) Jama''at-ud-Da''awa; z) Jamaati-ud-Dawa; aa) Falah-i-Insaniat Foundation (FIF)', '04', 'Pasban-e-Kashmir', 'PASBAN-E-KASHMIR', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1483', '20170807', '����췢[2017]106��', 'LASHKAR-E-TAYYIBA', 'a) Lashkar-e-Toiba; b) Lashkar-i-Taiba; c) al Mansoorian; d) al Mansooreen; e) Army of the Pure; f) Army of the Righteous; g) Army of the Pure and Righteous; h) Paasban-e-Kashmir; i) Paasban-i-Ahle-Hadith; j) Pasban-e-Kashmir; k) Pasban-e-Ahle-Hadith; l) Paasban-e-Ahle-Hadis; m) Pashan-e-ahle Hadis; n) Lashkar e Tayyaba; o) LET; p) Jamaat-ud-Dawa; q) JUD; r) Jama''at al-Dawa; s) Jamaat ud-Daawa; t) Jamaat ul-Dawah; u) Jamaat-ul-Dawa; v) Jama''at-i-Dawat; w) Jamaiat-ud-Dawa; x) Jama''at-ud-Da''awah; y) Jama''at-ud-Da''awa; z) Jamaati-ud-Dawa; aa) Falah-i-Insaniat Foundation (FIF)', '04', 'Pashan-e-ahle Hadis', 'PASHAN-E-AHLE HADIS', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1484', '20170807', '����췢[2017]106��', 'LASHKAR-E-TAYYIBA', 'a) Lashkar-e-Toiba; b) Lashkar-i-Taiba; c) al Mansoorian; d) al Mansooreen; e) Army of the Pure; f) Army of the Righteous; g) Army of the Pure and Righteous; h) Paasban-e-Kashmir; i) Paasban-i-Ahle-Hadith; j) Pasban-e-Kashmir; k) Pasban-e-Ahle-Hadith; l) Paasban-e-Ahle-Hadis; m) Pashan-e-ahle Hadis; n) Lashkar e Tayyaba; o) LET; p) Jamaat-ud-Dawa; q) JUD; r) Jama''at al-Dawa; s) Jamaat ud-Daawa; t) Jamaat ul-Dawah; u) Jamaat-ul-Dawa; v) Jama''at-i-Dawat; w) Jamaiat-ud-Dawa; x) Jama''at-ud-Da''awah; y) Jama''at-ud-Da''awa; z) Jamaati-ud-Dawa; aa) Falah-i-Insaniat Foundation (FIF)', '04', 'Pasban-e-Ahle-Hadith', 'PASBAN-E-AHLE-HADITH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1485', '20170807', '����췢[2017]106��', 'LASHKAR-E-TAYYIBA', 'a) Lashkar-e-Toiba; b) Lashkar-i-Taiba; c) al Mansoorian; d) al Mansooreen; e) Army of the Pure; f) Army of the Righteous; g) Army of the Pure and Righteous; h) Paasban-e-Kashmir; i) Paasban-i-Ahle-Hadith; j) Pasban-e-Kashmir; k) Pasban-e-Ahle-Hadith; l) Paasban-e-Ahle-Hadis; m) Pashan-e-ahle Hadis; n) Lashkar e Tayyaba; o) LET; p) Jamaat-ud-Dawa; q) JUD; r) Jama''at al-Dawa; s) Jamaat ud-Daawa; t) Jamaat ul-Dawah; u) Jamaat-ul-Dawa; v) Jama''at-i-Dawat; w) Jamaiat-ud-Dawa; x) Jama''at-ud-Da''awah; y) Jama''at-ud-Da''awa; z) Jamaati-ud-Dawa; aa) Falah-i-Insaniat Foundation (FIF)', '04', 'Paasban-e-Ahle-Hadis', 'PAASBAN-E-AHLE-HADIS', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1486', '20170807', '����췢[2017]106��', 'LIBYAN ISLAMIC FIGHTING GROUP', 'a) LIFG', '01', 'LIBYAN ISLAMIC FIGHTING GROUP', 'LIBYAN ISLAMIC FIGHTING GROUP', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1487', '20170807', '����췢[2017]106��', 'LIBYAN ISLAMIC FIGHTING GROUP', 'a) LIFG', '03', 'LIFG', 'LIFG', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1488', '20170807', '����췢[2017]106��', 'MAKHTAB AL-KHIDAMAT', 'a) MAK; b) Al Kifah', '01', 'MAKHTAB AL-KHIDAMAT', 'MAKHTAB AL-KHIDAMAT', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1489', '20170807', '����췢[2017]106��', 'MAKHTAB AL-KHIDAMAT', 'a) MAK; b) Al Kifah', '04', 'Al Kifah', 'AL KIFAH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1490', '20170807', '����췢[2017]106��', 'MAKHTAB AL-KHIDAMAT', 'a) MAK; b) Al Kifah', '04', 'MAK', 'MAK', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1491', '20170807', '����췢[2017]106��', 'MOROCCAN ISLAMIC COMBATANT GROUP', 'a) Groupe Islamique Combattant Marocain; b) GICM', '01', 'MOROCCAN ISLAMIC COMBATANT GROUP', 'MOROCCAN ISLAMIC COMBATANT GROUP', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1492', '20170807', '����췢[2017]106��', 'MOROCCAN ISLAMIC COMBATANT GROUP', 'a) Groupe Islamique Combattant Marocain; b) GICM', '04', 'Groupe Islamique Combattant Marocain', 'GROUPE ISLAMIQUE COMBATTANT MAROCAIN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1493', '20170807', '����췢[2017]106��', 'MOROCCAN ISLAMIC COMBATANT GROUP', 'a) Groupe Islamique Combattant Marocain; b) GICM', '04', 'GICM', 'GICM', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1494', '20170807', '����췢[2017]106��', 'MUHAMMAD JAMAL NETWORK (MJN)', 'a) Muhammad Jamal Group; b) Jamal Network; c) Abu Ahmed Group; d) Al-Qaida in Egypt (AQE)', '01', 'MUHAMMAD JAMAL NETWORK (MJN)', 'MUHAMMAD JAMAL NETWORK (MJN)', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1495', '20170807', '����췢[2017]106��', 'MUHAMMAD JAMAL NETWORK (MJN)', 'a) Muhammad Jamal Group; b) Jamal Network; c) Abu Ahmed Group; d) Al-Qaida in Egypt (AQE)', '04', 'Jamal Network', 'JAMAL NETWORK', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1496', '20170807', '����췢[2017]106��', 'MUHAMMAD JAMAL NETWORK (MJN)', 'a) Muhammad Jamal Group; b) Jamal Network; c) Abu Ahmed Group; d) Al-Qaida in Egypt (AQE)', '04', 'Al-Qaida in Egypt (AQE)', 'AL-QAIDA IN EGYPT (AQE)', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1497', '20170807', '����췢[2017]106��', 'MUHAMMAD JAMAL NETWORK (MJN)', 'a) Muhammad Jamal Group; b) Jamal Network; c) Abu Ahmed Group; d) Al-Qaida in Egypt (AQE)', '04', 'Al-Qaida in Egypt', 'AL-QAIDA IN EGYPT', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1498', '20170807', '����췢[2017]106��', 'MUHAMMAD JAMAL NETWORK (MJN)', 'a) Muhammad Jamal Group; b) Jamal Network; c) Abu Ahmed Group; d) Al-Qaida in Egypt (AQE)', '04', 'AQE', 'AQE', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1499', '20170807', '����췢[2017]106��', 'MUHAMMAD JAMAL NETWORK (MJN)', 'a) Muhammad Jamal Group; b) Jamal Network; c) Abu Ahmed Group; d) Al-Qaida in Egypt (AQE)', '04', 'Abu Ahmed Group', 'ABU AHMED GROUP', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1500', '20170807', '����췢[2017]106��', 'MUHAMMAD JAMAL NETWORK (MJN)', 'a) Muhammad Jamal Group; b) Jamal Network; c) Abu Ahmed Group; d) Al-Qaida in Egypt (AQE)', '04', 'Muhammad Jamal Group', 'MUHAMMAD JAMAL GROUP', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1501', '20170807', '����췢[2017]106��', 'MUJAHIDIN INDONESIAN TIMUR (MIT)', 'a) Mujahidin of Eastern Indonesia; b) East Indonesia Mujahideen; c) Mujahidin Indonesia Timor; d) Mujahidin Indonesia Barat (MIB); e) Mujshidin of Western Indonesia', '01', 'MUJAHIDIN INDONESIAN TIMUR (MIT)', 'MUJAHIDIN INDONESIAN TIMUR (MIT)', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1502', '20170807', '����췢[2017]106��', 'MUJAHIDIN INDONESIAN TIMUR (MIT)', 'a) Mujahidin of Eastern Indonesia; b) East Indonesia Mujahideen; c) Mujahidin Indonesia Timor; d) Mujahidin Indonesia Barat (MIB); e) Mujshidin of Western Indonesia', '04', 'Mujahidin Indonesia Barat (MIB)', 'MUJAHIDIN INDONESIA BARAT (MIB)', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1503', '20170807', '����췢[2017]106��', 'MUJAHIDIN INDONESIAN TIMUR (MIT)', 'a) Mujahidin of Eastern Indonesia; b) East Indonesia Mujahideen; c) Mujahidin Indonesia Timor; d) Mujahidin Indonesia Barat (MIB); e) Mujshidin of Western Indonesia', '04', 'Mujahidin Indonesia Barat', 'MUJAHIDIN INDONESIA BARAT', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1504', '20170807', '����췢[2017]106��', 'MUJAHIDIN INDONESIAN TIMUR (MIT)', 'a) Mujahidin of Eastern Indonesia; b) East Indonesia Mujahideen; c) Mujahidin Indonesia Timor; d) Mujahidin Indonesia Barat (MIB); e) Mujshidin of Western Indonesia', '04', 'MIB', 'MIB', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1505', '20170807', '����췢[2017]106��', 'MUJAHIDIN INDONESIAN TIMUR (MIT)', 'a) Mujahidin of Eastern Indonesia; b) East Indonesia Mujahideen; c) Mujahidin Indonesia Timor; d) Mujahidin Indonesia Barat (MIB); e) Mujshidin of Western Indonesia', '04', 'Mujahidin Indonesia Timor', 'MUJAHIDIN INDONESIA TIMOR', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1506', '20170807', '����췢[2017]106��', 'MUJAHIDIN INDONESIAN TIMUR (MIT)', 'a) Mujahidin of Eastern Indonesia; b) East Indonesia Mujahideen; c) Mujahidin Indonesia Timor; d) Mujahidin Indonesia Barat (MIB); e) Mujshidin of Western Indonesia', '04', 'Mujshidin of Western Indonesia', 'MUJSHIDIN OF WESTERN INDONESIA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1507', '20170807', '����췢[2017]106��', 'MUJAHIDIN INDONESIAN TIMUR (MIT)', 'a) Mujahidin of Eastern Indonesia; b) East Indonesia Mujahideen; c) Mujahidin Indonesia Timor; d) Mujahidin Indonesia Barat (MIB); e) Mujshidin of Western Indonesia', '04', 'East Indonesia Mujahideen', 'EAST INDONESIA MUJAHIDEEN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1508', '20170807', '����췢[2017]106��', 'MUJAHIDIN INDONESIAN TIMUR (MIT)', 'a) Mujahidin of Eastern Indonesia; b) East Indonesia Mujahideen; c) Mujahidin Indonesia Timor; d) Mujahidin Indonesia Barat (MIB); e) Mujshidin of Western Indonesia', '04', 'Mujahidin of Eastern Indonesia', 'MUJAHIDIN OF EASTERN INDONESIA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1509', '20170807', '����췢[2017]106��', 'Mouvement pour I''Unification et le Jihad en Afrique de I''Ouest (MUJAO)', null, '01', 'Mouvement pour I''Unification et le Jihad en Afrique de I''Ouest (MUJAO)', 'MOUVEMENT POUR I''UNIFICATION ET LE JIHAD EN AFRIQUE DE I''OUEST (MUJAO)', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1510', '20170807', '����췢[2017]106��', 'RABITA TRUST', null, '01', 'RABITA TRUST', 'RABITA TRUST', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1511', '20170807', '����췢[2017]106��', 'RAJAH SOLAIMAN MOVEMENT', 'a) Rajah Solaiman Islamic Movement; b) Rajah Solaiman Revolutionary Movement', '01', 'RAJAH SOLAIMAN MOVEMENT', 'RAJAH SOLAIMAN MOVEMENT', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1512', '20170807', '����췢[2017]106��', 'RAJAH SOLAIMAN MOVEMENT', 'a) Rajah Solaiman Islamic Movement; b) Rajah Solaiman Revolutionary Movement', '04', 'Rajah Solaiman Islamic Movement', 'RAJAH SOLAIMAN ISLAMIC MOVEMENT', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1513', '20170807', '����췢[2017]106��', 'RAJAH SOLAIMAN MOVEMENT', 'a) Rajah Solaiman Islamic Movement; b) Rajah Solaiman Revolutionary Movement', '04', 'Rajah Solaiman Revolutionary Movement', 'RAJAH SOLAIMAN REVOLUTIONARY MOVEMENT', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1514', '20170807', '����췢[2017]106��', 'REVIVAL OF ISLAMIC HERITAGE SOCIETY', 'a) Revival of Islamic Society Heritage on the African Continent; b) Jamia Ihya ul Turath; c) RIHS; d) Jamiat Ihia Al-Turath Al-Islamiya; e) Al-Furqan Foundation Welfare Trust; f) Al-Furqan Welfare Foundation', '01', 'REVIVAL OF ISLAMIC HERITAGE SOCIETY', 'REVIVAL OF ISLAMIC HERITAGE SOCIETY', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1515', '20170807', '����췢[2017]106��', 'REVIVAL OF ISLAMIC HERITAGE SOCIETY', 'a) Revival of Islamic Society Heritage on the African Continent; b) Jamia Ihya ul Turath; c) RIHS; d) Jamiat Ihia Al-Turath Al-Islamiya; e) Al-Furqan Foundation Welfare Trust; f) Al-Furqan Welfare Foundation', '04', 'Jamiat Ihia Al-Turath Al-Islamiya', 'JAMIAT IHIA AL-TURATH AL-ISLAMIYA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1516', '20170807', '����췢[2017]106��', 'REVIVAL OF ISLAMIC HERITAGE SOCIETY', 'a) Revival of Islamic Society Heritage on the African Continent; b) Jamia Ihya ul Turath; c) RIHS; d) Jamiat Ihia Al-Turath Al-Islamiya; e) Al-Furqan Foundation Welfare Trust; f) Al-Furqan Welfare Foundation', '04', 'Al-Furqan Welfare Foundation', 'AL-FURQAN WELFARE FOUNDATION', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1517', '20170807', '����췢[2017]106��', 'REVIVAL OF ISLAMIC HERITAGE SOCIETY', 'a) Revival of Islamic Society Heritage on the African Continent; b) Jamia Ihya ul Turath; c) RIHS; d) Jamiat Ihia Al-Turath Al-Islamiya; e) Al-Furqan Foundation Welfare Trust; f) Al-Furqan Welfare Foundation', '04', 'Al-Furqan Foundation Welfare Trust', 'AL-FURQAN FOUNDATION WELFARE TRUST', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1518', '20170807', '����췢[2017]106��', 'REVIVAL OF ISLAMIC HERITAGE SOCIETY', 'a) Revival of Islamic Society Heritage on the African Continent; b) Jamia Ihya ul Turath; c) RIHS; d) Jamiat Ihia Al-Turath Al-Islamiya; e) Al-Furqan Foundation Welfare Trust; f) Al-Furqan Welfare Foundation', '04', 'RIHS', 'RIHS', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1519', '20170807', '����췢[2017]106��', 'REVIVAL OF ISLAMIC HERITAGE SOCIETY', 'a) Revival of Islamic Society Heritage on the African Continent; b) Jamia Ihya ul Turath; c) RIHS; d) Jamiat Ihia Al-Turath Al-Islamiya; e) Al-Furqan Foundation Welfare Trust; f) Al-Furqan Welfare Foundation', '04', 'Jamia Ihya ul Turath', 'JAMIA IHYA UL TURATH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1520', '20170807', '����췢[2017]106��', 'REVIVAL OF ISLAMIC HERITAGE SOCIETY', 'a) Revival of Islamic Society Heritage on the African Continent; b) Jamia Ihya ul Turath; c) RIHS; d) Jamiat Ihia Al-Turath Al-Islamiya; e) Al-Furqan Foundation Welfare Trust; f) Al-Furqan Welfare Foundation', '04', 'Revival of Islamic Society Heritage on the African Continent', 'REVIVAL OF ISLAMIC SOCIETY HERITAGE ON THE AFRICAN CONTINENT', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1521', '20170807', '����췢[2017]106��', 'RIYADUS-SALIKHIN RECONNAISSANCE AND SABOTAGE BATTALION OF CHECHEN MARTYRS (RSRSBCM)', 'a) Riyadus-Salikhin Reconnaissance and Sabotage Battallon; b) Riyadh-as-Saliheen; c) The Sabotage and Military Surveillance Group of the Riyadh al-Sallhin Martyrs; d) Firqat al-Takhrib wa al-Istitla al-Askariyah li Shuhada Riyadh al-Salihin; e) Riyadus-Salikhin Reconnaissance and Sabotage battalion of Shahids (martyra)', '01', 'RIYADUS-SALIKHIN RECONNAISSANCE AND SABOTAGE BATTALION OF CHECHEN MARTYRS (RSRSBCM)', 'RIYADUS-SALIKHIN RECONNAISSANCE AND SABOTAGE BATTALION OF CHECHEN MARTYRS (RSRSBCM)', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1522', '20170807', '����췢[2017]106��', 'RIYADUS-SALIKHIN RECONNAISSANCE AND SABOTAGE BATTALION OF CHECHEN MARTYRS (RSRSBCM)', 'a) Riyadus-Salikhin Reconnaissance and Sabotage Battallon; b) Riyadh-as-Saliheen; c) The Sabotage and Military Surveillance Group of the Riyadh al-Sallhin Martyrs; d) Firqat al-Takhrib wa al-Istitla al-Askariyah li Shuhada Riyadh al-Salihin; e) Riyadus-Salikhin Reconnaissance and Sabotage battalion of Shahids (martyra)', '04', 'Riyadus-Salikhin Reconnaissance and Sabotage Battallon', 'RIYADUS-SALIKHIN RECONNAISSANCE AND SABOTAGE BATTALLON', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1523', '20170807', '����췢[2017]106��', 'RIYADUS-SALIKHIN RECONNAISSANCE AND SABOTAGE BATTALION OF CHECHEN MARTYRS (RSRSBCM)', 'a) Riyadus-Salikhin Reconnaissance and Sabotage Battallon; b) Riyadh-as-Saliheen; c) The Sabotage and Military Surveillance Group of the Riyadh al-Sallhin Martyrs; d) Firqat al-Takhrib wa al-Istitla al-Askariyah li Shuhada Riyadh al-Salihin; e) Riyadus-Salikhin Reconnaissance and Sabotage battalion of Shahids (martyra)', '04', 'Riyadus-Salikhin Reconnaissance and Sabotage battalion of Shahids (martyra)', 'RIYADUS-SALIKHIN RECONNAISSANCE AND SABOTAGE BATTALION OF SHAHIDS (MARTYRA)', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1524', '20170807', '����췢[2017]106��', 'RIYADUS-SALIKHIN RECONNAISSANCE AND SABOTAGE BATTALION OF CHECHEN MARTYRS (RSRSBCM)', 'a) Riyadus-Salikhin Reconnaissance and Sabotage Battallon; b) Riyadh-as-Saliheen; c) The Sabotage and Military Surveillance Group of the Riyadh al-Sallhin Martyrs; d) Firqat al-Takhrib wa al-Istitla al-Askariyah li Shuhada Riyadh al-Salihin; e) Riyadus-Salikhin Reconnaissance and Sabotage battalion of Shahids (martyra)', '04', 'Riyadus-Salikhin Reconnaissance and Sabotage battalion of Shahids', 'RIYADUS-SALIKHIN RECONNAISSANCE AND SABOTAGE BATTALION OF SHAHIDS', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1525', '20170807', '����췢[2017]106��', 'RIYADUS-SALIKHIN RECONNAISSANCE AND SABOTAGE BATTALION OF CHECHEN MARTYRS (RSRSBCM)', 'a) Riyadus-Salikhin Reconnaissance and Sabotage Battallon; b) Riyadh-as-Saliheen; c) The Sabotage and Military Surveillance Group of the Riyadh al-Sallhin Martyrs; d) Firqat al-Takhrib wa al-Istitla al-Askariyah li Shuhada Riyadh al-Salihin; e) Riyadus-Salikhin Reconnaissance and Sabotage battalion of Shahids (martyra)', '04', 'martyra', 'MARTYRA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1526', '20170807', '����췢[2017]106��', 'RIYADUS-SALIKHIN RECONNAISSANCE AND SABOTAGE BATTALION OF CHECHEN MARTYRS (RSRSBCM)', 'a) Riyadus-Salikhin Reconnaissance and Sabotage Battallon; b) Riyadh-as-Saliheen; c) The Sabotage and Military Surveillance Group of the Riyadh al-Sallhin Martyrs; d) Firqat al-Takhrib wa al-Istitla al-Askariyah li Shuhada Riyadh al-Salihin; e) Riyadus-Salikhin Reconnaissance and Sabotage battalion of Shahids (martyra)', '04', 'Firqat al-Takhrib wa al-Istitla al-Askariyah li Shuhada Riyadh al-Salihin', 'FIRQAT AL-TAKHRIB WA AL-ISTITLA AL-ASKARIYAH LI SHUHADA RIYADH AL-SALIHIN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1527', '20170807', '����췢[2017]106��', 'RIYADUS-SALIKHIN RECONNAISSANCE AND SABOTAGE BATTALION OF CHECHEN MARTYRS (RSRSBCM)', 'a) Riyadus-Salikhin Reconnaissance and Sabotage Battallon; b) Riyadh-as-Saliheen; c) The Sabotage and Military Surveillance Group of the Riyadh al-Sallhin Martyrs; d) Firqat al-Takhrib wa al-Istitla al-Askariyah li Shuhada Riyadh al-Salihin; e) Riyadus-Salikhin Reconnaissance and Sabotage battalion of Shahids (martyra)', '04', 'The Sabotage and Military Surveillance Group of the Riyadh al-Sallhin Martyrs', 'THE SABOTAGE AND MILITARY SURVEILLANCE GROUP OF THE RIYADH AL-SALLHIN MARTYRS', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1528', '20170807', '����췢[2017]106��', 'RIYADUS-SALIKHIN RECONNAISSANCE AND SABOTAGE BATTALION OF CHECHEN MARTYRS (RSRSBCM)', 'a) Riyadus-Salikhin Reconnaissance and Sabotage Battallon; b) Riyadh-as-Saliheen; c) The Sabotage and Military Surveillance Group of the Riyadh al-Sallhin Martyrs; d) Firqat al-Takhrib wa al-Istitla al-Askariyah li Shuhada Riyadh al-Salihin; e) Riyadus-Salikhin Reconnaissance and Sabotage battalion of Shahids (martyra)', '04', 'Riyadh-as-Saliheen', 'RIYADH-AS-SALIHEEN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1529', '20170807', '����췢[2017]106��', 'SPECIAL PURPOSE ISLAMIC REGIMENT (SPIR)', 'a) The Islamic Special Purpose Regiment; b) The al-Jihad-Fisi-Sabililah Special Islamic Regiment; c) Islamic Regiment of Special Meaning', '01', 'SPECIAL PURPOSE ISLAMIC REGIMENT (SPIR)', 'SPECIAL PURPOSE ISLAMIC REGIMENT (SPIR)', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1530', '20170807', '����췢[2017]106��', 'SPECIAL PURPOSE ISLAMIC REGIMENT (SPIR)', 'a) The Islamic Special Purpose Regiment; b) The al-Jihad-Fisi-Sabililah Special Islamic Regiment; c) Islamic Regiment of Special Meaning', '04', 'The al-Jihad-Fisi-Sabililah Special Islamic Regiment', 'THE AL-JIHAD-FISI-SABILILAH SPECIAL ISLAMIC REGIMENT', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1531', '20170807', '����췢[2017]106��', 'SPECIAL PURPOSE ISLAMIC REGIMENT (SPIR)', 'a) The Islamic Special Purpose Regiment; b) The al-Jihad-Fisi-Sabililah Special Islamic Regiment; c) Islamic Regiment of Special Meaning', '04', 'The Islamic Special Purpose Regiment', 'THE ISLAMIC SPECIAL PURPOSE REGIMENT', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1532', '20170807', '����췢[2017]106��', 'SPECIAL PURPOSE ISLAMIC REGIMENT (SPIR)', 'a) The Islamic Special Purpose Regiment; b) The al-Jihad-Fisi-Sabililah Special Islamic Regiment; c) Islamic Regiment of Special Meaning', '04', 'Islamic Regiment of Special Meaning', 'ISLAMIC REGIMENT OF SPECIAL MEANING', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1533', '20170807', '����췢[2017]106��', 'TAIBAH INTERNATIONAL-BOSNIA OFFICES', 'a) Taibah International Aid Agency; b) Taibah International Aid Association; c) Al Taibah; d) Taibah International Aide Association', '01', 'TAIBAH INTERNATIONAL-BOSNIA OFFICES', 'TAIBAH INTERNATIONAL-BOSNIA OFFICES', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1534', '20170807', '����췢[2017]106��', 'TAIBAH INTERNATIONAL-BOSNIA OFFICES', 'a) Taibah International Aid Agency; b) Taibah International Aid Association; c) Al Taibah; d) Taibah International Aide Association', '04', 'Taibah International Aid Association', 'TAIBAH INTERNATIONAL AID ASSOCIATION', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1535', '20170807', '����췢[2017]106��', 'TAIBAH INTERNATIONAL-BOSNIA OFFICES', 'a) Taibah International Aid Agency; b) Taibah International Aid Association; c) Al Taibah; d) Taibah International Aide Association', '04', 'Al Taibah', 'AL TAIBAH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1536', '20170807', '����췢[2017]106��', 'TAIBAH INTERNATIONAL-BOSNIA OFFICES', 'a) Taibah International Aid Agency; b) Taibah International Aid Association; c) Al Taibah; d) Taibah International Aide Association', '04', 'Taibah International Aid Agency', 'TAIBAH INTERNATIONAL AID AGENCY', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1537', '20170807', '����췢[2017]106��', 'TAIBAH INTERNATIONAL-BOSNIA OFFICES', 'a) Taibah International Aid Agency; b) Taibah International Aid Association; c) Al Taibah; d) Taibah International Aide Association', '04', 'Taibah International Aide Association', 'TAIBAH INTERNATIONAL AIDE ASSOCIATION', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1538', '20170807', '����췢[2017]106��', 'TEHRIK-E TALIBAN PAKISTAN (TTP)', 'a) Tehrik-l-Taliban Pakistan; b) Tehrik-e-Taliban; c) Pakistani Taliban; d) Tehreek-e-Taliban', '01', 'TEHRIK-E TALIBAN PAKISTAN (TTP)', 'TEHRIK-E TALIBAN PAKISTAN (TTP)', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1539', '20170807', '����췢[2017]106��', 'TEHRIK-E TALIBAN PAKISTAN (TTP)', 'a) Tehrik-l-Taliban Pakistan; b) Tehrik-e-Taliban; c) Pakistani Taliban; d) Tehreek-e-Taliban', '04', 'Tehrik-l-Taliban Pakistan', 'TEHRIK-L-TALIBAN PAKISTAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1540', '20170807', '����췢[2017]106��', 'TEHRIK-E TALIBAN PAKISTAN (TTP)', 'a) Tehrik-l-Taliban Pakistan; b) Tehrik-e-Taliban; c) Pakistani Taliban; d) Tehreek-e-Taliban', '04', 'Tehreek-e-Taliban', 'TEHREEK-E-TALIBAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1541', '20170807', '����췢[2017]106��', 'TEHRIK-E TALIBAN PAKISTAN (TTP)', 'a) Tehrik-l-Taliban Pakistan; b) Tehrik-e-Taliban; c) Pakistani Taliban; d) Tehreek-e-Taliban', '04', 'Pakistani Taliban', 'PAKISTANI TALIBAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1542', '20170807', '����췢[2017]106��', 'TEHRIK-E TALIBAN PAKISTAN (TTP)', 'a) Tehrik-l-Taliban Pakistan; b) Tehrik-e-Taliban; c) Pakistani Taliban; d) Tehreek-e-Taliban', '04', 'Tehrik-e-Taliban', 'TEHRIK-E-TALIBAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1543', '20170807', '����췢[2017]106��', 'THE ARMY OF EMIGRANTS AND SUPPORTERS', 'a) Battalion of Emigrants and Sopporters; b) Army of Emigrants and Supporters organization; c) Battalion of Emigrants and Ansar; d) Jaysh al-Muhajirin wal-Ansar (JAMWA)', '01', 'THE ARMY OF EMIGRANTS AND SUPPORTERS', 'THE ARMY OF EMIGRANTS AND SUPPORTERS', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1544', '20170807', '����췢[2017]106��', 'THE ARMY OF EMIGRANTS AND SUPPORTERS', 'a) Battalion of Emigrants and Sopporters; b) Army of Emigrants and Supporters organization; c) Battalion of Emigrants and Ansar; d) Jaysh al-Muhajirin wal-Ansar (JAMWA)', '04', 'Jaysh al-Muhajirin wal-Ansar (JAMWA)', 'JAYSH AL-MUHAJIRIN WAL-ANSAR (JAMWA)', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1545', '20170807', '����췢[2017]106��', 'THE ARMY OF EMIGRANTS AND SUPPORTERS', 'a) Battalion of Emigrants and Sopporters; b) Army of Emigrants and Supporters organization; c) Battalion of Emigrants and Ansar; d) Jaysh al-Muhajirin wal-Ansar (JAMWA)', '04', 'Jaysh al-Muhajirin wal-Ansar', 'JAYSH AL-MUHAJIRIN WAL-ANSAR', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1546', '20170807', '����췢[2017]106��', 'THE ARMY OF EMIGRANTS AND SUPPORTERS', 'a) Battalion of Emigrants and Sopporters; b) Army of Emigrants and Supporters organization; c) Battalion of Emigrants and Ansar; d) Jaysh al-Muhajirin wal-Ansar (JAMWA)', '04', 'JAMWA', 'JAMWA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1547', '20170807', '����췢[2017]106��', 'THE ARMY OF EMIGRANTS AND SUPPORTERS', 'a) Battalion of Emigrants and Sopporters; b) Army of Emigrants and Supporters organization; c) Battalion of Emigrants and Ansar; d) Jaysh al-Muhajirin wal-Ansar (JAMWA)', '04', 'Battalion of Emigrants and Ansar', 'BATTALION OF EMIGRANTS AND ANSAR', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1548', '20170807', '����췢[2017]106��', 'THE ARMY OF EMIGRANTS AND SUPPORTERS', 'a) Battalion of Emigrants and Sopporters; b) Army of Emigrants and Supporters organization; c) Battalion of Emigrants and Ansar; d) Jaysh al-Muhajirin wal-Ansar (JAMWA)', '04', 'Army of Emigrants and Supporters organization', 'ARMY OF EMIGRANTS AND SUPPORTERS ORGANIZATION', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1549', '20170807', '����췢[2017]106��', 'THE ARMY OF EMIGRANTS AND SUPPORTERS', 'a) Battalion of Emigrants and Sopporters; b) Army of Emigrants and Supporters organization; c) Battalion of Emigrants and Ansar; d) Jaysh al-Muhajirin wal-Ansar (JAMWA)', '04', 'Battalion of Emigrants and Sopporters', 'BATTALION OF EMIGRANTS AND SOPPORTERS', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1550', '20170807', '����췢[2017]106��', 'THE ORGANIZATION OF AL-QAIDA IN THE ISLAMIC MAGHREB', 'a) AQIM; b) Al Qaida au Maghreb islamique (AQMI)', '01', 'THE ORGANIZATION OF AL-QAIDA IN THE ISLAMIC MAGHREB', 'THE ORGANIZATION OF AL-QAIDA IN THE ISLAMIC MAGHREB', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1551', '20170807', '����췢[2017]106��', 'THE ORGANIZATION OF AL-QAIDA IN THE ISLAMIC MAGHREB', 'a) AQIM; b) Al Qaida au Maghreb islamique (AQMI)', '04', 'Al Qaida au Maghreb islamique (AQMI)', 'AL QAIDA AU MAGHREB ISLAMIQUE (AQMI)', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1552', '20170807', '����췢[2017]106��', 'THE ORGANIZATION OF AL-QAIDA IN THE ISLAMIC MAGHREB', 'a) AQIM; b) Al Qaida au Maghreb islamique (AQMI)', '04', 'AQIM', 'AQIM', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1553', '20170807', '����췢[2017]106��', 'TUNISIAN COMBATANT GROUP', 'a) Groupe Combattant Tunisien; b) Groupe Islamiste Combattant Tunisien; c) GICT', '01', 'TUNISIAN COMBATANT GROUP', 'TUNISIAN COMBATANT GROUP', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1554', '20170807', '����췢[2017]106��', 'TUNISIAN COMBATANT GROUP', 'a) Groupe Combattant Tunisien; b) Groupe Islamiste Combattant Tunisien; c) GICT', '04', 'Groupe Islamiste Combattant Tunisien', 'GROUPE ISLAMISTE COMBATTANT TUNISIEN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1555', '20170807', '����췢[2017]106��', 'TUNISIAN COMBATANT GROUP', 'a) Groupe Combattant Tunisien; b) Groupe Islamiste Combattant Tunisien; c) GICT', '04', 'GICT', 'GICT', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1556', '20170807', '����췢[2017]106��', 'TUNISIAN COMBATANT GROUP', 'a) Groupe Combattant Tunisien; b) Groupe Islamiste Combattant Tunisien; c) GICT', '04', 'Groupe Combattant Tunisien', 'GROUPE COMBATTANT TUNISIEN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1557', '20170807', '����췢[2017]106��', 'UMMAH TAMEER E-NAU (UTN)', null, '01', 'UMMAH TAMEER E-NAU (UTN)', 'UMMAH TAMEER E-NAU (UTN)', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1558', '20170807', '����췢[2017]106��', 'WAFA HUMANITARIAN ORGANIZATION', 'a) Al Wafa; b) Al Wafa Organization; c) Wafa Al-Igatha Al-Islamia', '01', 'WAFA HUMANITARIAN ORGANIZATION', 'WAFA HUMANITARIAN ORGANIZATION', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1559', '20170807', '����췢[2017]106��', 'WAFA HUMANITARIAN ORGANIZATION', 'a) Al Wafa; b) Al Wafa Organization; c) Wafa Al-Igatha Al-Islamia', '04', 'Al Wafa', 'AL WAFA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1560', '20170807', '����췢[2017]106��', 'WAFA HUMANITARIAN ORGANIZATION', 'a) Al Wafa; b) Al Wafa Organization; c) Wafa Al-Igatha Al-Islamia', '04', 'Wafa Al-Igatha Al-Islamia', 'WAFA AL-IGATHA AL-ISLAMIA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1561', '20170807', '����췢[2017]106��', 'WAFA HUMANITARIAN ORGANIZATION', 'a) Al Wafa; b) Al Wafa Organization; c) Wafa Al-Igatha Al-Islamia', '04', 'Al Wafa Organization', 'AL WAFA ORGANIZATION', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1562', '20170830', '����췢[2017]115��', '1: Malik 2: Ruslanovich 3: Barkhanoev 4: na', null, '02', 'Malik Ruslanovich', 'MALIK RUSLANOVICH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1563', '20170830', '����췢[2017]115��', '1: Muhammad 2: Bahrum 3: Naim 4: Anggih Tamtomo', 'a) Bahrun Naim; b) Anggih Tamtomo', '02', 'Muhammad Bahrum', 'MUHAMMAD BAHRUM', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1564', '20170830', '����췢[2017]115��', '1: Muhammad 2: Bahrum 3: Naim 4: Anggih Tamtomo', 'a) Bahrun Naim; b) Anggih Tamtomo', '04', 'Anggih Tamtomo', 'ANGGIH TAMTOMO', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1565', '20170830', '����췢[2017]115��', '1: Muhammad 2: Bahrum 3: Naim 4: Anggih Tamtomo', 'a) Bahrun Naim; b) Anggih Tamtomo', '04', 'Bahrun Naim', 'BAHRUN NAIM', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1566', '20170830', '����췢[2017]115��', '1: Murad 2: Iraklievich 3: Margoshvili 4: na', 'a) Zurab iraklievich Margoshvili; b) Murad Akhmedovich Madayev; c) Lova Madayev; d) Abu-Muslim Al-Shishani', '02', 'Murad Iraklievich', 'MURAD IRAKLIEVICH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1567', '20170830', '����췢[2017]115��', '1: Murad 2: Iraklievich 3: Margoshvili 4: na', 'a) Zurab iraklievich Margoshvili; b) Murad Akhmedovich Madayev; c) Lova Madayev; d) Abu-Muslim Al-Shishani', '04', 'Lova Madayev', 'LOVA MADAYEV', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1568', '20170830', '����췢[2017]115��', '1: Murad 2: Iraklievich 3: Margoshvili 4: na', 'a) Zurab iraklievich Margoshvili; b) Murad Akhmedovich Madayev; c) Lova Madayev; d) Abu-Muslim Al-Shishani', '04', 'Murad Akhmedovich Madayev', 'MURAD AKHMEDOVICH MADAYEV', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1569', '20170830', '����췢[2017]115��', '1: Murad 2: Iraklievich 3: Margoshvili 4: na', 'a) Zurab iraklievich Margoshvili; b) Murad Akhmedovich Madayev; c) Lova Madayev; d) Abu-Muslim Al-Shishani', '04', 'Abu-Muslim Al-Shishani', 'ABU-MUSLIM AL-SHISHANI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1570', '20170830', '����췢[2017]115��', '1: Murad 2: Iraklievich 3: Margoshvili 4: na', 'a) Zurab iraklievich Margoshvili; b) Murad Akhmedovich Madayev; c) Lova Madayev; d) Abu-Muslim Al-Shishani', '04', 'Zurab iraklievich Margoshvili', 'ZURAB IRAKLIEVICH MARGOSHVILI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1571', '20170830', '����췢[2017]115��', '1: Oman 2: Rochman 3: na 4: na', 'a) Oman Rahman; b) Abu Sulaiman Aman Abdurrahman Al-Arkhabilly; c) Aman Abdul Rahman; d) Aman Abdurahman; e) Aman Abdurrachman; f) Oman Abdulrohman; g) Oman Abdurrahman; h) Aman Abdurrahman', '02', 'Oman Rochman', 'OMAN ROCHMAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1572', '20170830', '����췢[2017]115��', '1: Oman 2: Rochman 3: na 4: na', 'a) Oman Rahman; b) Abu Sulaiman Aman Abdurrahman Al-Arkhabilly; c) Aman Abdul Rahman; d) Aman Abdurahman; e) Aman Abdurrachman; f) Oman Abdulrohman; g) Oman Abdurrahman; h) Aman Abdurrahman', '04', 'Oman Abdulrohman', 'OMAN ABDULROHMAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1573', '20170830', '����췢[2017]115��', '1: Oman 2: Rochman 3: na 4: na', 'a) Oman Rahman; b) Abu Sulaiman Aman Abdurrahman Al-Arkhabilly; c) Aman Abdul Rahman; d) Aman Abdurahman; e) Aman Abdurrachman; f) Oman Abdulrohman; g) Oman Abdurrahman; h) Aman Abdurrahman', '04', 'Aman Abdurrachman', 'AMAN ABDURRACHMAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1574', '20170830', '����췢[2017]115��', '1: Oman 2: Rochman 3: na 4: na', 'a) Oman Rahman; b) Abu Sulaiman Aman Abdurrahman Al-Arkhabilly; c) Aman Abdul Rahman; d) Aman Abdurahman; e) Aman Abdurrachman; f) Oman Abdulrohman; g) Oman Abdurrahman; h) Aman Abdurrahman', '04', 'Aman Abdul Rahman', 'AMAN ABDUL RAHMAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1575', '20170830', '����췢[2017]115��', '1: Oman 2: Rochman 3: na 4: na', 'a) Oman Rahman; b) Abu Sulaiman Aman Abdurrahman Al-Arkhabilly; c) Aman Abdul Rahman; d) Aman Abdurahman; e) Aman Abdurrachman; f) Oman Abdulrohman; g) Oman Abdurrahman; h) Aman Abdurrahman', '04', 'Abu Sulaiman Aman Abdurrahman Al-Arkhabilly', 'ABU SULAIMAN AMAN ABDURRAHMAN AL-ARKHABILLY', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1576', '20170830', '����췢[2017]115��', '1: Oman 2: Rochman 3: na 4: na', 'a) Oman Rahman; b) Abu Sulaiman Aman Abdurrahman Al-Arkhabilly; c) Aman Abdul Rahman; d) Aman Abdurahman; e) Aman Abdurrachman; f) Oman Abdulrohman; g) Oman Abdurrahman; h) Aman Abdurrahman', '04', 'Oman Rahman', 'OMAN RAHMAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1577', '20170830', '����췢[2017]115��', '1: Oman 2: Rochman 3: na 4: na', 'a) Oman Rahman; b) Abu Sulaiman Aman Abdurrahman Al-Arkhabilly; c) Aman Abdul Rahman; d) Aman Abdurahman; e) Aman Abdurrachman; f) Oman Abdulrohman; g) Oman Abdurrahman; h) Aman Abdurrahman', '04', 'Aman Abdurrahman', 'AMAN ABDURRAHMAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1578', '20170830', '����췢[2017]115��', '1: Oman 2: Rochman 3: na 4: na', 'a) Oman Rahman; b) Abu Sulaiman Aman Abdurrahman Al-Arkhabilly; c) Aman Abdul Rahman; d) Aman Abdurahman; e) Aman Abdurrachman; f) Oman Abdulrohman; g) Oman Abdurrahman; h) Aman Abdurrahman', '04', 'Oman Abdurrahman', 'OMAN ABDURRAHMAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1579', '20170830', '����췢[2017]115��', '1: Oman 2: Rochman 3: na 4: na', 'a) Oman Rahman; b) Abu Sulaiman Aman Abdurrahman Al-Arkhabilly; c) Aman Abdul Rahman; d) Aman Abdurahman; e) Aman Abdurrachman; f) Oman Abdulrohman; g) Oman Abdurrahman; h) Aman Abdurrahman', '04', 'Aman Abdurahman', 'AMAN ABDURAHMAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1580', '20170830', '����췢[2017]115��', 'CHOE CHUN YONG', 'Ch''oe Ch''un-yo''ng', '01', 'CHOE CHUN YONG', 'CHOE CHUN YONG', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1581', '20170830', '����췢[2017]115��', 'CHOE CHUN YONG', 'Ch''oe Ch''un-yo''ng', '03', 'Ch''oe Ch''un-yo''ng', 'CH''OE CH''UN-YO''NG', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1582', '20170830', '����췢[2017]115��', 'FOREIGN TRADE BANK (FTB)', null, '01', 'FOREIGN TRADE BANK (FTB)', 'FOREIGN TRADE BANK (FTB)', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1583', '20170830', '����췢[2017]115��', 'HAN JANG SU', 'Chang-Su Han', '01', 'HAN JANG SU', 'HAN JANG SU', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1584', '20170830', '����췢[2017]115��', 'HAN JANG SU', 'Chang-Su Han', '03', 'Chang-Su Han', 'CHANG-SU HAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1585', '20170830', '����췢[2017]115��', 'Hanifa Money Exchange Office (branch located in Albu Kamal, Syrian Arab Republic)', 'a) Hanifah Currency Exchange; b) Hanifeh Exchange; c) Hanifa Exchange; d) Hunaifa Office; e) Hanifah Exchange Company; f) Hanifa Money Exchange Office', '01', 'Hanifa Money Exchange Office (branch located in Albu Kamal, Syrian Arab Republic)', 'HANIFA MONEY EXCHANGE OFFICE (BRANCH LOCATED IN ALBU KAMAL, SYRIAN ARAB REPUBLIC)', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1586', '20170830', '����췢[2017]115��', 'Hanifa Money Exchange Office (branch located in Albu Kamal, Syrian Arab Republic)', 'a) Hanifah Currency Exchange; b) Hanifeh Exchange; c) Hanifa Exchange; d) Hunaifa Office; e) Hanifah Exchange Company; f) Hanifa Money Exchange Office', '04', 'Hanifa Money', 'HANIFA MONEY', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1587', '20170830', '����췢[2017]115��', 'Hanifa Money Exchange Office (branch located in Albu Kamal, Syrian Arab Republic)', 'a) Hanifah Currency Exchange; b) Hanifeh Exchange; c) Hanifa Exchange; d) Hunaifa Office; e) Hanifah Exchange Company; f) Hanifa Money Exchange Office', '04', 'Hunaifa Office', 'HUNAIFA OFFICE', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1588', '20170830', '����췢[2017]115��', 'Hanifa Money Exchange Office (branch located in Albu Kamal, Syrian Arab Republic)', 'a) Hanifah Currency Exchange; b) Hanifeh Exchange; c) Hanifa Exchange; d) Hunaifa Office; e) Hanifah Exchange Company; f) Hanifa Money Exchange Office', '04', 'Hanifa Exchange', 'HANIFA EXCHANGE', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1589', '20170830', '����췢[2017]115��', 'Hanifa Money Exchange Office (branch located in Albu Kamal, Syrian Arab Republic)', 'a) Hanifah Currency Exchange; b) Hanifeh Exchange; c) Hanifa Exchange; d) Hunaifa Office; e) Hanifah Exchange Company; f) Hanifa Money Exchange Office', '04', 'Hanifah Currency Exchange', 'HANIFAH CURRENCY EXCHANGE', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1590', '20170830', '����췢[2017]115��', 'Hanifa Money Exchange Office (branch located in Albu Kamal, Syrian Arab Republic)', 'a) Hanifah Currency Exchange; b) Hanifeh Exchange; c) Hanifa Exchange; d) Hunaifa Office; e) Hanifah Exchange Company; f) Hanifa Money Exchange Office', '04', 'Hanifah Exchange Company', 'HANIFAH EXCHANGE COMPANY', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1591', '20170830', '����췢[2017]115��', 'Hanifa Money Exchange Office (branch located in Albu Kamal, Syrian Arab Republic)', 'a) Hanifah Currency Exchange; b) Hanifeh Exchange; c) Hanifa Exchange; d) Hunaifa Office; e) Hanifah Exchange Company; f) Hanifa Money Exchange Office', '04', 'Hanifeh Exchange', 'HANIFEH EXCHANGE', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1592', '20170830', '����췢[2017]115��', 'JANG SONG CHOL', null, '01', 'JANG SONG CHOL', 'JANG SONG CHOL', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1593', '20170830', '����췢[2017]115��', 'JANG SUNG NAM', null, '01', 'JANG SUNG NAM', 'JANG SUNG NAM', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1594', '20170830', '����췢[2017]115��', 'JO CHOL SONG', 'Cho Ch''o''l-so''ng', '01', 'JO CHOL SONG', 'JO CHOL SONG', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1595', '20170830', '����췢[2017]115��', 'JO CHOL SONG', 'Cho Ch''o''l-so''ng', '03', 'Cho Ch''o''l-so''ng', 'CHO CH''O''L-SO''NG', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1596', '20170830', '����췢[2017]115��', 'Jaysh Khalid Ibn al Waleed', 'a) Khalid ibn al-Walid Army; b) Liwa Shuhada al-Yarmouk; c) Harakat al-Muthanna al-Islamia', '01', 'Jaysh Khalid Ibn al Waleed', 'JAYSH KHALID IBN AL WALEED', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1597', '20170830', '����췢[2017]115��', 'Jaysh Khalid Ibn al Waleed', 'a) Khalid ibn al-Walid Army; b) Liwa Shuhada al-Yarmouk; c) Harakat al-Muthanna al-Islamia', '04', 'Liwa Shuhada al-Yarmouk', 'LIWA SHUHADA AL-YARMOUK', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1598', '20170830', '����췢[2017]115��', 'Jaysh Khalid Ibn al Waleed', 'a) Khalid ibn al-Walid Army; b) Liwa Shuhada al-Yarmouk; c) Harakat al-Muthanna al-Islamia', '04', 'Khalid ibn al-Walid Army', 'KHALID IBN AL-WALID ARMY', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1599', '20170830', '����췢[2017]115��', 'Jaysh Khalid Ibn al Waleed', 'a) Khalid ibn al-Walid Army; b) Liwa Shuhada al-Yarmouk; c) Harakat al-Muthanna al-Islamia', '04', 'Harakat al-Muthanna al-Islamia', 'HARAKAT AL-MUTHANNA AL-ISLAMIA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1600', '20170830', '����췢[2017]115��', 'Jund al Aqsa', 'a) The Soldiers of Aqsa; b) Soldiers of Aqsa; c) Sarayat Al Quds', '01', 'Jund al Aqsa', 'JUND AL AQSA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1601', '20170830', '����췢[2017]115��', 'Jund al Aqsa', 'a) The Soldiers of Aqsa; b) Soldiers of Aqsa; c) Sarayat Al Quds', '04', 'Soldiers of Aqsa', 'SOLDIERS OF AQSA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1602', '20170830', '����췢[2017]115��', 'Jund al Aqsa', 'a) The Soldiers of Aqsa; b) Soldiers of Aqsa; c) Sarayat Al Quds', '04', 'Sarayat Al Quds', 'SARAYAT AL QUDS', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1603', '20170830', '����췢[2017]115��', 'Jund al Aqsa', 'a) The Soldiers of Aqsa; b) Soldiers of Aqsa; c) Sarayat Al Quds', '04', 'The Soldiers of Aqsa', 'THE SOLDIERS OF AQSA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1604', '20170830', '����췢[2017]115��', 'KANG CHOL SU', null, '01', 'KANG CHOL SU', 'KANG CHOL SU', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1605', '20170830', '����췢[2017]115��', 'KIM MUN CHOL', 'Kim Mun-ch''o''l', '01', 'KIM MUN CHOL', 'KIM MUN CHOL', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1606', '20170830', '����췢[2017]115��', 'KIM MUN CHOL', 'Kim Mun-ch''o''l', '03', 'Kim Mun-ch''o''l', 'KIM MUN-CH''O''L', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1607', '20170830', '����췢[2017]115��', 'KIM NAM UNG', null, '01', 'KIM NAM UNG', 'KIM NAM UNG', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1608', '20170830', '����췢[2017]115��', 'KOREAN NATIONAL INSURANCE COMPANY (KNIC)', 'Korea Foreign Insurance Company', '01', 'KOREAN NATIONAL INSURANCE COMPANY (KNIC)', 'KOREAN NATIONAL INSURANCE COMPANY (KNIC)', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1609', '20170830', '����췢[2017]115��', 'KOREAN NATIONAL INSURANCE COMPANY (KNIC)', 'Korea Foreign Insurance Company', '03', 'Korea Foreign Insurance Company', 'KOREA FOREIGN INSURANCE COMPANY', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1610', '20170830', '����췢[2017]115��', 'KORYO CREDIT DEVELOPMENT BANK', 'Daesong Credit Development Bank; Koryo Global Credit Bank; Koryo Global Trust Bank', '01', 'KORYO CREDIT DEVELOPMENT BANK', 'KORYO CREDIT DEVELOPMENT BANK', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1611', '20170830', '����췢[2017]115��', 'KORYO CREDIT DEVELOPMENT BANK', 'Daesong Credit Development Bank; Koryo Global Credit Bank; Koryo Global Trust Bank', '04', 'Koryo Global Credit Bank', 'KORYO GLOBAL CREDIT BANK', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1612', '20170830', '����췢[2017]115��', 'KORYO CREDIT DEVELOPMENT BANK', 'Daesong Credit Development Bank; Koryo Global Credit Bank; Koryo Global Trust Bank', '04', 'Koryo Global Credit Bank', 'KORYO GLOBAL CREDIT BANK', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1613', '20170830', '����췢[2017]115��', 'KORYO CREDIT DEVELOPMENT BANK', 'Daesong Credit Development Bank; Koryo Global Credit Bank; Koryo Global Trust Bank', '04', 'Koryo Global Trust Bank', 'KORYO GLOBAL TRUST BANK', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1614', '20170830', '����췢[2017]115��', 'KORYO CREDIT DEVELOPMENT BANK', 'Daesong Credit Development Bank; Koryo Global Credit Bank; Koryo Global Trust Bank', '04', 'Daesong Credit Development Bank', 'DAESONG CREDIT DEVELOPMENT BANK', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1615', '20170830', '����췢[2017]115��', 'MANSUDAE OVERSEAS PROJECT GROUP OF COMPANIES', 'Mansudae Art Studio', '01', 'MANSUDAE OVERSEAS PROJECT GROUP OF COMPANIES', 'MANSUDAE OVERSEAS PROJECT GROUP OF COMPANIES', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1616', '20170830', '����췢[2017]115��', 'MANSUDAE OVERSEAS PROJECT GROUP OF COMPANIES', 'Mansudae Art Studio', '03', 'Mansudae Art Studio', 'MANSUDAE ART STUDIO', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1617', '20170830', '����췢[2017]115��', 'PAK IL KYU', 'Pak Il-Gyu', '01', 'PAK IL KYU', 'PAK IL KYU', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1618', '20170830', '����췢[2017]115��', 'PAK IL KYU', 'Pak Il-Gyu', '03', 'Pak Il-Gyu', 'PAK IL-GYU', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1619', '20170830', '����췢[2017]115��', 'Selselat al-Thabab', 'a) Silsilet al Thahab; b) Selselat al Thahab For Money Exchange; c) Silsilat Money Exchange Company; d) Silsilah Money Exchange Company; e) Al Silsilah al Dhahaba; f) Silsalat al Dhab', '01', 'Selselat al-Thabab', 'SELSELAT AL-THABAB', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1620', '20170830', '����췢[2017]115��', 'Selselat al-Thabab', 'a) Silsilet al Thahab; b) Selselat al Thahab For Money Exchange; c) Silsilat Money Exchange Company; d) Silsilah Money Exchange Company; e) Al Silsilah al Dhahaba; f) Silsalat al Dhab', '04', 'Silsilet al Thahab', 'SILSILET AL THAHAB', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1621', '20170830', '����췢[2017]115��', 'Selselat al-Thabab', 'a) Silsilet al Thahab; b) Selselat al Thahab For Money Exchange; c) Silsilat Money Exchange Company; d) Silsilah Money Exchange Company; e) Al Silsilah al Dhahaba; f) Silsalat al Dhab', '04', 'Silsilah Money Exchange', 'SILSILAH MONEY EXCHANGE', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1622', '20170830', '����췢[2017]115��', 'Selselat al-Thabab', 'a) Silsilet al Thahab; b) Selselat al Thahab For Money Exchange; c) Silsilat Money Exchange Company; d) Silsilah Money Exchange Company; e) Al Silsilah al Dhahaba; f) Silsalat al Dhab', '04', 'Selselat al Thahab For Money Exchange', 'SELSELAT AL THAHAB FOR MONEY EXCHANGE', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1623', '20170830', '����췢[2017]115��', 'Selselat al-Thabab', 'a) Silsilet al Thahab; b) Selselat al Thahab For Money Exchange; c) Silsilat Money Exchange Company; d) Silsilah Money Exchange Company; e) Al Silsilah al Dhahaba; f) Silsalat al Dhab', '04', 'Silsilat Money Exchange Company', 'SILSILAT MONEY EXCHANGE COMPANY', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1624', '20170908', '����췢[2017]122��', '1: ABDELHAFIZ 2: ZLITNI 3: na 4: na', null, '02', 'ABDELHAFIZ ZLITNI', 'ABDELHAFIZ ZLITNI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1625', '20170908', '����췢[2017]122��', '1: ABDULLAH 2:AL-SENUSSI 3: na 4: na', 'Abdoullah Ould Ahmed', '02', 'ABDULLAH 2:AL-SENUSSI', 'ABDULLAH 2:AL-SENUSSI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1626', '20170908', '����췢[2017]122��', '1: ABDULLAH 2:AL-SENUSSI 3: na 4: na', 'Abdoullah Ould Ahmed', '03', 'Abdoullah Ould Ahmed', 'ABDOULLAH OULD AHMED', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1627', '20170908', '����췢[2017]122��', '1: ABDULQADER 2: MOHAMMED 3: AL-BAGHDADI 4: na', null, '02', 'ABDULQADER MOHAMMED', 'ABDULQADER MOHAMMED', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1628', '20170908', '����췢[2017]122��', '1: ABDULQADER 2: YUSEF 3: DIBRI 4: na', null, '02', 'ABDULQADER YUSEF', 'ABDULQADER YUSEF', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1629', '20170908', '����췢[2017]122��', '1: ABU 2: BAKR 3: YUNIS 4: JABIR', null, '02', 'ABU BAKR', 'ABU BAKR', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1630', '20170908', '����췢[2017]122��', '1: ABU 2: ZAYD 3: UMAR 4: DORDA', null, '02', 'ABU ZAYD', 'ABU ZAYD', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1631', '20170908', '����췢[2017]122��', '1: AISHA 2: MUAMMAR MUHAMMED 3: ABU MINYAR 4: QADHAFI', 'Aisha Muhammed Abdui Salam', '02', 'AISHA MUAMMAR MUHAMMED', 'AISHA MUAMMAR MUHAMMED', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1632', '20170908', '����췢[2017]122��', '1: AISHA 2: MUAMMAR MUHAMMED 3: ABU MINYAR 4: QADHAFI', 'Aisha Muhammed Abdui Salam', '03', 'Aisha Muhammed Abdui Salam', 'AISHA MUHAMMED ABDUI SALAM', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1633', '20170908', '����췢[2017]122��', '1: AMID 2: HUSAIN 3: AL KUNI 4: na', null, '02', 'AMID HUSAIN', 'AMID HUSAIN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1634', '20170908', '����췢[2017]122��', '1: HANNIBAL 2: MUAMMAR 3: QADHAFI 4: na', null, '02', 'HANNIBAL MUAMMAR', 'HANNIBAL MUAMMAR', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1635', '20170908', '����췢[2017]122��', '1: KHAMIS 2: MUAMMAR 3: QADHAFI 4: na', null, '02', 'KHAMIS MUAMMAR', 'KHAMIS MUAMMAR', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1636', '20170908', '����췢[2017]122��', '1: MATUQ 2: MOHAMMED 3: MATUQ 4: na', null, '02', 'MATUQ MOHAMMED', 'MATUQ MOHAMMED', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1637', '20170908', '����췢[2017]122��', '1: MOHAMMED 2: MUAMMAR 3: QADHAFI 4: na', null, '02', 'MOHAMMED MUAMMAR', 'MOHAMMED MUAMMAR', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1638', '20170908', '����췢[2017]122��', '1: MUAMMAR 2: MOHAMMED 3: ABU MINYAR 4: QADHAFI', null, '02', 'MUAMMAR MOHAMMED', 'MUAMMAR MOHAMMED', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1639', '20170908', '����췢[2017]122��', '1: MUTASSIM 2: QADHAFI 3: na 4: na', 'a) Almuatesem Bellah Muammer Qadhafi; b) Mutassim Billah Abuminyar Qadhafi', '02', 'MUTASSIM QADHAFI', 'MUTASSIM QADHAFI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1640', '20170908', '����췢[2017]122��', '1: MUTASSIM 2: QADHAFI 3: na 4: na', 'a) Almuatesem Bellah Muammer Qadhafi; b) Mutassim Billah Abuminyar Qadhafi', '04', 'Mutassim Billah Abuminyar Qadhafi', 'MUTASSIM BILLAH ABUMINYAR QADHAFI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1641', '20170908', '����췢[2017]122��', '1: MUTASSIM 2: QADHAFI 3: na 4: na', 'a) Almuatesem Bellah Muammer Qadhafi; b) Mutassim Billah Abuminyar Qadhafi', '04', 'Almuatesem Bellah Muammer Qadhafi', 'ALMUATESEM BELLAH MUAMMER QADHAFI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1642', '20170908', '����췢[2017]122��', '1: QUREN 2: SALIH 3: QUREN 4: AL QADHAFI', 'Akrin Saleh Akrin', '02', 'QUREN SALIH', 'QUREN SALIH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1643', '20170908', '����췢[2017]122��', '1: QUREN 2: SALIH 3: QUREN 4: AL QADHAFI', 'Akrin Saleh Akrin', '03', 'Akrin Saleh Akrin', 'AKRIN SALEH AKRIN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1644', '20170908', '����췢[2017]122��', '1: SAADI 2: QADHAFI 3: na 4: na', null, '02', 'SAADI QADHAFI', 'SAADI QADHAFI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1645', '20170908', '����췢[2017]122��', '1: SAFIA 2: FARKASH 3: AL-BARASSI 4: na', 'Safia Farkash Mohammed Al-Hadad', '02', 'SAFIA FARKASH', 'SAFIA FARKASH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1646', '20170908', '����췢[2017]122��', '1: SAFIA 2: FARKASH 3: AL-BARASSI 4: na', 'Safia Farkash Mohammed Al-Hadad', '03', 'Safia Farkash Mohammed Al-Hadad', 'SAFIA FARKASH MOHAMMED AL-HADAD', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1647', '20170908', '����췢[2017]122��', '1: SAIF AL-ARAB 2: QADHAFI 3: na 4: na', null, '02', 'SAIF AL-ARAB QADHAFI', 'SAIF AL-ARAB QADHAFI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1648', '20170908', '����췢[2017]122��', '1: SAYYID 2: MOHAMMED 3: QADHAF AL-DAM 4: na', 'Sayed M. Gaddef Eddam', '02', 'SAYYID MOHAMMED', 'SAYYID MOHAMMED', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1649', '20170908', '����췢[2017]122��', '1: SAYYID 2: MOHAMMED 3: QADHAF AL-DAM 4: na', 'Sayed M. Gaddef Eddam', '03', 'Sayed M. Gaddef Eddam', 'SAYED M. GADDEF EDDAM', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1650', '20170908', '����췢[2017]122��', 'CAPRICORN', null, '01', 'CAPRICORN', 'CAPRICORN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1651', '20170908', '����췢[2017]122��', 'LIBYAN AFRICA INVESTMENT PORTFOLIO', null, '01', 'LIBYAN AFRICA INVESTMENT PORTFOLIO', 'LIBYAN AFRICA INVESTMENT PORTFOLIO', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1652', '20170908', '����췢[2017]122��', 'LIBYAN INVESTMENT AUTHORITY', 'Libyan Foreign Investment Company (LFIC)', '01', 'LIBYAN INVESTMENT AUTHORITY', 'LIBYAN INVESTMENT AUTHORITY', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1653', '20170908', '����췢[2017]122��', 'LIBYAN INVESTMENT AUTHORITY', 'Libyan Foreign Investment Company (LFIC)', '03', 'Libyan Foreign Investment Company (LFIC)', 'LIBYAN FOREIGN INVESTMENT COMPANY (LFIC)', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1654', '20170908', '����췢[2017]122��', 'Lynn S', null, '01', 'Lynn S', 'LYNN S', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1655', '20171010', '����췢[2017]133��', 'CENTRAL MILITARY COMMISSION OF THE WORKERS'' PARTY OF KOREA (CMC)', null, '01', 'CENTRAL MILITARY COMMISSION OF THE WORKERS'' PARTY OF KOREA (CMC)', 'CENTRAL MILITARY COMMISSION OF THE WORKERS'' PARTY OF KOREA (CMC)', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1656', '20171010', '����췢[2017]133��', 'ORGANIZATION AND GUIDANCE DEPARTMENT (OGD)', null, '01', 'ORGANIZATION AND GUIDANCE DEPARTMENT (OGD)', 'ORGANIZATION AND GUIDANCE DEPARTMENT (OGD)', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1657', '20171010', '����췢[2017]133��', 'PAK YONG SIK', null, '01', 'PAK YONG SIK', 'PAK YONG SIK', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1658', '20171010', '����췢[2017]133��', 'PROPAGANDA AND AGITATION DEPARTMENT (PAD)', null, '01', 'PROPAGANDA AND AGITATION DEPARTMENT (PAD)', 'PROPAGANDA AND AGITATION DEPARTMENT (PAD)', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1659', '20171206', '����췢[2017]158��', '1: ABD 2: AL-KHALIQ 3: AL-HOUTHI 4: na ', 'a) Abd-al-Khaliq al-Huthi; b) Abd-al-Khaliq Badr-al-Din al Huthi; c) ''Abd al-Khaliq Badr al-Din al-Huthi; d) Abd al-Khaliq al-Huthi', '02', 'ABD AL-KHALIQ', 'ABD AL-KHALIQ', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1660', '20171206', '����췢[2017]158��', '1: ABD 2: AL-KHALIQ 3: AL-HOUTHI 4: na ', 'a) Abd-al-Khaliq al-Huthi; b) Abd-al-Khaliq Badr-al-Din al Huthi; c) ''Abd al-Khaliq Badr al-Din al-Huthi; d) Abd al-Khaliq al-Huthi', '04', 'Abd-al-Khaliq Badr-al-Din al Huthi', 'ABD-AL-KHALIQ BADR-AL-DIN AL HUTHI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1661', '20171206', '����췢[2017]158��', '1: ABD 2: AL-KHALIQ 3: AL-HOUTHI 4: na ', 'a) Abd-al-Khaliq al-Huthi; b) Abd-al-Khaliq Badr-al-Din al Huthi; c) ''Abd al-Khaliq Badr al-Din al-Huthi; d) Abd al-Khaliq al-Huthi', '04', 'Abd al-Khaliq al-Huthi', 'ABD AL-KHALIQ AL-HUTHI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1662', '20171206', '����췢[2017]158��', '1: ABD 2: AL-KHALIQ 3: AL-HOUTHI 4: na ', 'a) Abd-al-Khaliq al-Huthi; b) Abd-al-Khaliq Badr-al-Din al Huthi; c) ''Abd al-Khaliq Badr al-Din al-Huthi; d) Abd al-Khaliq al-Huthi', '04', 'Abd al-Khaliq Badr al-Din al-Huthi', 'ABD AL-KHALIQ BADR AL-DIN AL-HUTHI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1663', '20171206', '����췢[2017]158��', '1: ABD 2: AL-KHALIQ 3: AL-HOUTHI 4: na ', 'a) Abd-al-Khaliq al-Huthi; b) Abd-al-Khaliq Badr-al-Din al Huthi; c) ''Abd al-Khaliq Badr al-Din al-Huthi; d) Abd al-Khaliq al-Huthi', '04', 'Abd-al-Khaliq al-Huthi', 'ABD-AL-KHALIQ AL-HUTHI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1664', '20171206', '����췢[2017]158��', '1: ABD-AL-BAQI 2: ABD-AL-KARIM 3: ABDALLAH 4: AL-SADUN', null, '02', 'ABD-AL-BAQI ABD-AL-KARIM', 'ABD-AL-BAQI ABD-AL-KARIM', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1665', '20171206', '����췢[2017]158��', '1: ABDUL AZIZ 2: ABBASIN 3: na 4: na', 'Abdul Aziz Mahsud', '02', 'ABDUL AZIZ ABBASIN', 'ABDUL AZIZ ABBASIN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1666', '20171206', '����췢[2017]158��', '1: ABDUL AZIZ 2: ABBASIN 3: na 4: na', 'Abdul Aziz Mahsud', '03', 'Abdul Aziz Mahsud', 'ABDUL AZIZ MAHSUD', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1667', '20171206', '����췢[2017]158��', '1: ABDUL BAQI 2: BASIR 3: AWAL SHAH 4: na', 'a) Abdul Baqi ', '02', 'ABDUL BAQI BASIR', 'ABDUL BAQI BASIR', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1668', '20171206', '����췢[2017]158��', '1: ABDUL BAQI 2: BASIR 3: AWAL SHAH 4: na', 'a) Abdul Baqi ', '04', 'Abdul Baqi', 'ABDUL BAQI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1669', '20171206', '����췢[2017]158��', '1: ABDUL BARI 2: AKHUND 3: na 4: na', 'Haji Mullah Sahib', '02', 'ABDUL BARI AKHUND', 'ABDUL BARI AKHUND', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1670', '20171206', '����췢[2017]158��', '1: ABDUL BARI 2: AKHUND 3: na 4: na', 'Haji Mullah Sahib', '03', 'Haji Mullah Sahib', 'HAJI MULLAH SAHIB', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1671', '20171206', '����췢[2017]158��', '1: ABDUL GHAFAR 2: QURISHI 3: ABDUL GHANI 4: na', 'Abdul Ghaffar Qureshi', '02', 'ABDUL GHAFAR QURISHI', 'ABDUL GHAFAR QURISHI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1672', '20171206', '����췢[2017]158��', '1: ABDUL GHAFAR 2: QURISHI 3: ABDUL GHANI 4: na', 'Abdul Ghaffar Qureshi', '03', 'Abdul Ghaffar Qureshi', 'ABDUL GHAFFAR QURESHI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1673', '20171206', '����췢[2017]158��', '1: ABDUL GHANI 2: BARADAR 3: ABDUL AHMAD TURK 4: na', 'a) Mullah Baradar Akhund; b) Abdul Ghani Baradar', '02', 'ABDUL GHANI BARADAR', 'ABDUL GHANI BARADAR', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1674', '20171206', '����췢[2017]158��', '1: ABDUL GHANI 2: BARADAR 3: ABDUL AHMAD TURK 4: na', 'a) Mullah Baradar Akhund; b) Abdul Ghani Baradar', '04', 'Abdul Ghani Baradar', 'ABDUL GHANI BARADAR', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1675', '20171206', '����췢[2017]158��', '1: ABDUL GHANI 2: BARADAR 3: ABDUL AHMAD TURK 4: na', 'a) Mullah Baradar Akhund; b) Abdul Ghani Baradar', '04', 'Mullah Baradar Akhund', 'MULLAH BARADAR AKHUND', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1676', '20171206', '����췢[2017]158��', '1: ABDUL HABIB 2: ALIZAI 3: na 4: na', 'a) Haji Agha Jan Alizai; b) Hajji Agha Jan; c) Agha Jan Alazai; d) Haji Loi Lala; e) Loi Agha; f) Abdul Habib; g) Agha Jan Alizai', '02', 'ABDUL HABIB ALIZAI', 'ABDUL HABIB ALIZAI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1677', '20171206', '����췢[2017]158��', '1: ABDUL HABIB 2: ALIZAI 3: na 4: na', 'a) Haji Agha Jan Alizai; b) Hajji Agha Jan; c) Agha Jan Alazai; d) Haji Loi Lala; e) Loi Agha; f) Abdul Habib; g) Agha Jan Alizai', '04', 'Agha Jan Alizai', 'AGHA JAN ALIZAI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1678', '20171206', '����췢[2017]158��', '1: ABDUL HABIB 2: ALIZAI 3: na 4: na', 'a) Haji Agha Jan Alizai; b) Hajji Agha Jan; c) Agha Jan Alazai; d) Haji Loi Lala; e) Loi Agha; f) Abdul Habib; g) Agha Jan Alizai', '04', 'Haji Agha Jan Alizai', 'HAJI AGHA JAN ALIZAI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1679', '20171206', '����췢[2017]158��', '1: ABDUL HABIB 2: ALIZAI 3: na 4: na', 'a) Haji Agha Jan Alizai; b) Hajji Agha Jan; c) Agha Jan Alazai; d) Haji Loi Lala; e) Loi Agha; f) Abdul Habib; g) Agha Jan Alizai', '04', 'Loi Agha', 'LOI AGHA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1680', '20171206', '����췢[2017]158��', '1: ABDUL HABIB 2: ALIZAI 3: na 4: na', 'a) Haji Agha Jan Alizai; b) Hajji Agha Jan; c) Agha Jan Alazai; d) Haji Loi Lala; e) Loi Agha; f) Abdul Habib; g) Agha Jan Alizai', '04', 'Hajji Agha Jan', 'HAJJI AGHA JAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1681', '20171206', '����췢[2017]158��', '1: ABDUL HABIB 2: ALIZAI 3: na 4: na', 'a) Haji Agha Jan Alizai; b) Hajji Agha Jan; c) Agha Jan Alazai; d) Haji Loi Lala; e) Loi Agha; f) Abdul Habib; g) Agha Jan Alizai', '04', 'Agha Jan Alazai', 'AGHA JAN ALAZAI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1682', '20171206', '����췢[2017]158��', '1: ABDUL HABIB 2: ALIZAI 3: na 4: na', 'a) Haji Agha Jan Alizai; b) Hajji Agha Jan; c) Agha Jan Alazai; d) Haji Loi Lala; e) Loi Agha; f) Abdul Habib; g) Agha Jan Alizai', '04', 'Abdul Habib', 'ABDUL HABIB', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1683', '20171206', '����췢[2017]158��', '1: ABDUL HABIB 2: ALIZAI 3: na 4: na', 'a) Haji Agha Jan Alizai; b) Hajji Agha Jan; c) Agha Jan Alazai; d) Haji Loi Lala; e) Loi Agha; f) Abdul Habib; g) Agha Jan Alizai', '04', 'Haji Loi Lala', 'HAJI LOI LALA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1684', '20171206', '����췢[2017]158��', '1: ABDUL HAI 2: HAZEM 3: ABDUL QADER 4: na', 'Abdul Hai Hazem', '02', 'ABDUL HAI HAZEM', 'ABDUL HAI HAZEM', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1685', '20171206', '����췢[2017]158��', '1: ABDUL HAI 2: HAZEM 3: ABDUL QADER 4: na', 'Abdul Hai Hazem', '03', 'Abdul Hai Hazem', 'ABDUL HAI HAZEM', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1686', '20171206', '����췢[2017]158��', '1: ABDUL QADEER 2: BASIR 3: ABDUL BASEER 4: na', 'a) Abdul Qadir; b) Ahmad Haji; c) Abdul Qadir Haqqani; d) Abdul Qadir Basir', '02', 'ABDUL QADEER BASIR', 'ABDUL QADEER BASIR', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1687', '20171206', '����췢[2017]158��', '1: ABDUL QADEER 2: BASIR 3: ABDUL BASEER 4: na', 'a) Abdul Qadir; b) Ahmad Haji; c) Abdul Qadir Haqqani; d) Abdul Qadir Basir', '04', 'Abdul Qadir Haqqani', 'ABDUL QADIR HAQQANI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1688', '20171206', '����췢[2017]158��', '1: ABDUL QADEER 2: BASIR 3: ABDUL BASEER 4: na', 'a) Abdul Qadir; b) Ahmad Haji; c) Abdul Qadir Haqqani; d) Abdul Qadir Basir', '04', 'Abdul Qadir Basir', 'ABDUL QADIR BASIR', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1689', '20171206', '����췢[2017]158��', '1: ABDUL QADEER 2: BASIR 3: ABDUL BASEER 4: na', 'a) Abdul Qadir; b) Ahmad Haji; c) Abdul Qadir Haqqani; d) Abdul Qadir Basir', '04', 'Ahmad Haji', 'AHMAD HAJI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1690', '20171206', '����췢[2017]158��', '1: ABDUL QADEER 2: BASIR 3: ABDUL BASEER 4: na', 'a) Abdul Qadir; b) Ahmad Haji; c) Abdul Qadir Haqqani; d) Abdul Qadir Basir', '04', 'Abdul Qadir', 'ABDUL QADIR', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1691', '20171206', '����췢[2017]158��', '1: ABDUL RAHMAN 2: AGHA 3: na 4: na', null, '02', 'ABDUL RAHMAN AGHA', 'ABDUL RAHMAN AGHA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1692', '20171206', '����췢[2017]158��', '1: ABDUL SAMAD 2: ACHEKZAI 3: na 4: na', 'Abdul Samad', '02', 'ABDUL SAMAD ACHEKZAI', 'ABDUL SAMAD ACHEKZAI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1693', '20171206', '����췢[2017]158��', '1: ABDUL SAMAD 2: ACHEKZAI 3: na 4: na', 'Abdul Samad', '03', 'Abdul Samad', 'ABDUL SAMAD', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1694', '20171206', '����췢[2017]158��', '1: ABDUL SATAR 2: ABDUL MANAN 3: na 4: na', 'a) Haji Abdul Sattar Barakzai; b) Haji Abdul Satar; c) Haji Satar Barakzai; d) Abdulasattar ', '02', 'ABDUL SATAR ABDUL MANAN', 'ABDUL SATAR ABDUL MANAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1695', '20171206', '����췢[2017]158��', '1: ABDUL SATAR 2: ABDUL MANAN 3: na 4: na', 'a) Haji Abdul Sattar Barakzai; b) Haji Abdul Satar; c) Haji Satar Barakzai; d) Abdulasattar ', '04', 'Abdulasattar', 'ABDULASATTAR', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1696', '20171206', '����췢[2017]158��', '1: ABDUL SATAR 2: ABDUL MANAN 3: na 4: na', 'a) Haji Abdul Sattar Barakzai; b) Haji Abdul Satar; c) Haji Satar Barakzai; d) Abdulasattar ', '04', 'Haji Abdul Satar', 'HAJI ABDUL SATAR', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1697', '20171206', '����췢[2017]158��', '1: ABDUL SATAR 2: ABDUL MANAN 3: na 4: na', 'a) Haji Abdul Sattar Barakzai; b) Haji Abdul Satar; c) Haji Satar Barakzai; d) Abdulasattar ', '04', 'Haji Abdul Sattar Barakzai', 'HAJI ABDUL SATTAR BARAKZAI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1698', '20171206', '����췢[2017]158��', '1: ABDUL SATAR 2: ABDUL MANAN 3: na 4: na', 'a) Haji Abdul Sattar Barakzai; b) Haji Abdul Satar; c) Haji Satar Barakzai; d) Abdulasattar ', '04', 'Haji Satar Barakzai', 'HAJI SATAR BARAKZAI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1699', '20171206', '����췢[2017]158��', '1: ABDULLAH 2: AL-SENUSSI 3: na 4: na', 'a) Abdoullah Ould Ahmed ( Passport number: B0515260; DOB: 1948; POB: Anefif (Kidal), Mali; Date of issue: 10 Jan 2012; Place of issue: Bamako, Mali; Date of expiration: 10 Jan 2017.); b) Abdoullah Ould Ahmed (Mali ID Number 073/SPICRE; POB: Anefif, Mali; Date of issue: 6 Dec 2011; Place of issue: Essouck, Mali)', '02', 'ABDULLAH AL-SENUSSI', 'ABDULLAH AL-SENUSSI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1700', '20171206', '����췢[2017]158��', '1: ABDULLAH 2: AL-SENUSSI 3: na 4: na', 'a) Abdoullah Ould Ahmed ( Passport number: B0515260; DOB: 1948; POB: Anefif (Kidal), Mali; Date of issue: 10 Jan 2012; Place of issue: Bamako, Mali; Date of expiration: 10 Jan 2017.); b) Abdoullah Ould Ahmed (Mali ID Number 073/SPICRE; POB: Anefif, Mali; Date of issue: 6 Dec 2011; Place of issue: Essouck, Mali)', '04', 'Abdoullah Ould Ahmed', 'ABDOULLAH OULD AHMED', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1701', '20171206', '����췢[2017]158��', '1: ABDULLAH 2: AL-SENUSSI 3: na 4: na', 'a) Abdoullah Ould Ahmed ( Passport number: B0515260; DOB: 1948; POB: Anefif (Kidal), Mali; Date of issue: 10 Jan 2012; Place of issue: Bamako, Mali; Date of expiration: 10 Jan 2017.); b) Abdoullah Ould Ahmed (Mali ID Number 073/SPICRE; POB: Anefif, Mali; Date of issue: 6 Dec 2011; Place of issue: Essouck, Mali)', '04', 'Abdoullah Ould Ahmed', 'ABDOULLAH OULD AHMED', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1702', '20171206', '����췢[2017]158��', '1: ABDULLAH 2: YAHYA 3: AL HAKIM 4: na', 'a) Abu Ali al Hakim; b) Abu-Ali al-Hakim; c) Abdallah al-Hakim; d) Abu Ali Alhakim; e) Abdallah al-Mu''ayyad', '02', 'ABDULLAH YAHYA', 'ABDULLAH YAHYA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1703', '20171206', '����췢[2017]158��', '1: ABDULLAH 2: YAHYA 3: AL HAKIM 4: na', 'a) Abu Ali al Hakim; b) Abu-Ali al-Hakim; c) Abdallah al-Hakim; d) Abu Ali Alhakim; e) Abdallah al-Mu''ayyad', '04', 'Abu Ali Alhakim', 'ABU ALI ALHAKIM', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1704', '20171206', '����췢[2017]158��', '1: ABDULLAH 2: YAHYA 3: AL HAKIM 4: na', 'a) Abu Ali al Hakim; b) Abu-Ali al-Hakim; c) Abdallah al-Hakim; d) Abu Ali Alhakim; e) Abdallah al-Mu''ayyad', '04', 'Abdallah al-Hakim', 'ABDALLAH AL-HAKIM', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1705', '20171206', '����췢[2017]158��', '1: ABDULLAH 2: YAHYA 3: AL HAKIM 4: na', 'a) Abu Ali al Hakim; b) Abu-Ali al-Hakim; c) Abdallah al-Hakim; d) Abu Ali Alhakim; e) Abdallah al-Mu''ayyad', '04', 'Abu Ali al Hakim', 'ABU ALI AL HAKIM', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1706', '20171206', '����췢[2017]158��', '1: ABDULLAH 2: YAHYA 3: AL HAKIM 4: na', 'a) Abu Ali al Hakim; b) Abu-Ali al-Hakim; c) Abdallah al-Hakim; d) Abu Ali Alhakim; e) Abdallah al-Mu''ayyad', '04', 'Abu-Ali al-Hakim', 'ABU-ALI AL-HAKIM', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1707', '20171206', '����췢[2017]158��', '1: ABDULLAH 2: YAHYA 3: AL HAKIM 4: na', 'a) Abu Ali al Hakim; b) Abu-Ali al-Hakim; c) Abdallah al-Hakim; d) Abu Ali Alhakim; e) Abdallah al-Mu''ayyad', '04', 'Abdallah al-Mu''ayyad', 'ABDALLAH AL-MU''AYYAD', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1708', '20171206', '����췢[2017]158��', '1: ABDULMALIK 2: AL-HOUTHI 3: na 4: na', 'Abdulmalik al-Huthi', '02', 'ABDULMALIK AL-HOUTHI', 'ABDULMALIK AL-HOUTHI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1709', '20171206', '����췢[2017]158��', '1: ABDULMALIK 2: AL-HOUTHI 3: na 4: na', 'Abdulmalik al-Huthi', '03', 'Abdulmalik al-Huthi', 'ABDULMALIK AL-HUTHI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1710', '20171206', '����췢[2017]158��', '1: ABID 2: HAMID 3: MAHMUD 4: AL-TIKRITI', 'a) Abid Hamid Bid Hamid Mahmud; b) Col Abdel Hamid Mahmoud; c) Abed Mahmoud Hammud', '02', 'ABID HAMID', 'ABID HAMID', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1711', '20171206', '����췢[2017]158��', '1: ABID 2: HAMID 3: MAHMUD 4: AL-TIKRITI', 'a) Abid Hamid Bid Hamid Mahmud; b) Col Abdel Hamid Mahmoud; c) Abed Mahmoud Hammud', '04', 'Col Abdel Hamid Mahmoud', 'COL ABDEL HAMID MAHMOUD', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1712', '20171206', '����췢[2017]158��', '1: ABID 2: HAMID 3: MAHMUD 4: AL-TIKRITI', 'a) Abid Hamid Bid Hamid Mahmud; b) Col Abdel Hamid Mahmoud; c) Abed Mahmoud Hammud', '04', 'Abed Mahmoud Hammud', 'ABED MAHMOUD HAMMUD', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1713', '20171206', '����췢[2017]158��', '1: ABID 2: HAMID 3: MAHMUD 4: AL-TIKRITI', 'a) Abid Hamid Bid Hamid Mahmud; b) Col Abdel Hamid Mahmoud; c) Abed Mahmoud Hammud', '04', 'Abid Hamid Bid Hamid Mahmud', 'ABID HAMID BID HAMID MAHMUD', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1714', '20171206', '����췢[2017]158��', '1: ABUBAKER 2: SHARIFF 3: AHMED 4: na', 'a) Makaburi; b) Sheikh Abubakar Ahmed; c) Abubaker Shariff Ahmed; d) Abu Makaburi Shariff; e) Abubaker Shariff; f) Abubakar Ahmed', '02', 'ABUBAKER SHARIFF', 'ABUBAKER SHARIFF', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1715', '20171206', '����췢[2017]158��', '1: ABUBAKER 2: SHARIFF 3: AHMED 4: na', 'a) Makaburi; b) Sheikh Abubakar Ahmed; c) Abubaker Shariff Ahmed; d) Abu Makaburi Shariff; e) Abubaker Shariff; f) Abubakar Ahmed', '04', 'Abubakar Ahmed', 'ABUBAKAR AHMED', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1716', '20171206', '����췢[2017]158��', '1: ABUBAKER 2: SHARIFF 3: AHMED 4: na', 'a) Makaburi; b) Sheikh Abubakar Ahmed; c) Abubaker Shariff Ahmed; d) Abu Makaburi Shariff; e) Abubaker Shariff; f) Abubakar Ahmed', '04', 'Makaburi', 'MAKABURI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1717', '20171206', '����췢[2017]158��', '1: ABUBAKER 2: SHARIFF 3: AHMED 4: na', 'a) Makaburi; b) Sheikh Abubakar Ahmed; c) Abubaker Shariff Ahmed; d) Abu Makaburi Shariff; e) Abubaker Shariff; f) Abubakar Ahmed', '04', 'Abubaker Shariff Ahmed', 'ABUBAKER SHARIFF AHMED', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1718', '20171206', '����췢[2017]158��', '1: ABUBAKER 2: SHARIFF 3: AHMED 4: na', 'a) Makaburi; b) Sheikh Abubakar Ahmed; c) Abubaker Shariff Ahmed; d) Abu Makaburi Shariff; e) Abubaker Shariff; f) Abubakar Ahmed', '04', 'Abu Makaburi Shariff', 'ABU MAKABURI SHARIFF', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1719', '20171206', '����췢[2017]158��', '1: ABUBAKER 2: SHARIFF 3: AHMED 4: na', 'a) Makaburi; b) Sheikh Abubakar Ahmed; c) Abubaker Shariff Ahmed; d) Abu Makaburi Shariff; e) Abubaker Shariff; f) Abubakar Ahmed', '04', 'Abubaker Shariff', 'ABUBAKER SHARIFF', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1720', '20171206', '����췢[2017]158��', '1: ABUBAKER 2: SHARIFF 3: AHMED 4: na', 'a) Makaburi; b) Sheikh Abubakar Ahmed; c) Abubaker Shariff Ahmed; d) Abu Makaburi Shariff; e) Abubaker Shariff; f) Abubakar Ahmed', '04', 'Sheikh Abubakar Ahmed', 'SHEIKH ABUBAKAR AHMED', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1721', '20171206', '����췢[2017]158��', '1: ADAM KHAN 2: ACHEKZAI 3: na 4: na', 'a) Maulavi Adam Khan; b) Maulavi Adam', '02', 'ADAM KHAN ACHEKZAI', 'ADAM KHAN ACHEKZAI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1722', '20171206', '����췢[2017]158��', '1: ADAM KHAN 2: ACHEKZAI 3: na 4: na', 'a) Maulavi Adam Khan; b) Maulavi Adam', '04', 'Maulavi Adam Khan', 'MAULAVI ADAM KHAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1723', '20171206', '����췢[2017]158��', '1: ADAM KHAN 2: ACHEKZAI 3: na 4: na', 'a) Maulavi Adam Khan; b) Maulavi Adam', '04', 'Maulavi Adam', 'MAULAVI ADAM', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1724', '20171206', '����췢[2017]158��', '1: ADIB 2: SHABAN 3: AL-ANI 4: na', 'a) Dr. Adib Sha''ban; b) Adib Shaban', '02', 'ADIB SHABAN', 'ADIB SHABAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1725', '20171206', '����췢[2017]158��', '1: ADIB 2: SHABAN 3: AL-ANI 4: na', 'a) Dr. Adib Sha''ban; b) Adib Shaban', '04', 'Dr. Adib Sha''ban', 'DR. ADIB SHA''BAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1726', '20171206', '����췢[2017]158��', '1: ADIB 2: SHABAN 3: AL-ANI 4: na', 'a) Dr. Adib Sha''ban; b) Adib Shaban', '04', 'Adib Shaban', 'ADIB SHABAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1727', '20171206', '����췢[2017]158��', '1: ADNAN 2: S. 3: HASAN 4: AHMED', 'a) Hasan Ahmed S. Adnan; b) Ahmed Sultan', '02', 'ADNAN S', 'ADNAN S', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1728', '20171206', '����췢[2017]158��', '1: ADNAN 2: S. 3: HASAN 4: AHMED', 'a) Hasan Ahmed S. Adnan; b) Ahmed Sultan', '04', 'Ahmed Sultan', 'AHMED SULTAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1729', '20171206', '����췢[2017]158��', '1: ADNAN 2: S. 3: HASAN 4: AHMED', 'a) Hasan Ahmed S. Adnan; b) Ahmed Sultan', '04', 'Hasan Ahmed S. Adnan', 'HASAN AHMED S. ADNAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1730', '20171206', '����췢[2017]158��', '1: AHMAD 2: ZIA 3: AGHA 4: na', 'a) Zia Agha; b) Noor Ahmad; c) Noor Ahmed', '02', 'AHMAD ZIA', 'AHMAD ZIA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1731', '20171206', '����췢[2017]158��', '1: AHMAD 2: ZIA 3: AGHA 4: na', 'a) Zia Agha; b) Noor Ahmad; c) Noor Ahmed', '04', 'Noor Ahmad', 'NOOR AHMAD', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1732', '20171206', '����췢[2017]158��', '1: AHMAD 2: ZIA 3: AGHA 4: na', 'a) Zia Agha; b) Noor Ahmad; c) Noor Ahmed', '04', 'Noor Ahmed', 'NOOR AHMED', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1733', '20171206', '����췢[2017]158��', '1: AHMAD 2: ZIA 3: AGHA 4: na', 'a) Zia Agha; b) Noor Ahmad; c) Noor Ahmed', '04', 'Zia Agha', 'ZIA AGHA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1734', '20171206', '����췢[2017]158��', '1: AHMAD JAN 2: AKHUNDZADA 3: SHUKOOR 4: AKHUNDZADA', 'a) Ahmad Jan Akhunzada; b) Ahmad Jan Akhund Zada', '02', 'AHMAD JAN AKHUNDZADA', 'AHMAD JAN AKHUNDZADA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1735', '20171206', '����췢[2017]158��', '1: AHMAD JAN 2: AKHUNDZADA 3: SHUKOOR 4: AKHUNDZADA', 'a) Ahmad Jan Akhunzada; b) Ahmad Jan Akhund Zada', '04', 'Ahmad Jan Akhunzada', 'AHMAD JAN AKHUNZADA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1736', '20171206', '����췢[2017]158��', '1: AHMAD JAN 2: AKHUNDZADA 3: SHUKOOR 4: AKHUNDZADA', 'a) Ahmad Jan Akhunzada; b) Ahmad Jan Akhund Zada', '04', 'Ahmad Jan Akhund Zada', 'AHMAD JAN AKHUND ZADA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1737', '20171206', '����췢[2017]158��', '1: AHMAD TAHA 2: KHALID 3: ABDUL QADIR 4: na', null, '02', 'AHMAD TAHA KHALID', 'AHMAD TAHA KHALID', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1738', '20171206', '����췢[2017]158��', '1: AHMAD VAHID 2: DASTJERDI 3: na 4: na', null, '02', 'AHMAD VAHID DASTJERDI', 'AHMAD VAHID DASTJERDI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1739', '20171206', '����췢[2017]158��', '1: AHMED 2: ABDI 3: AW-MOHAMED 4: na', 'a) ABU ZUBEYR, Muktar Abdirahman; b) ABUZUBAIR, Muktar Abdulrahim; c) AW MOHAMMED, Ahmed Abdi; d) AW-MOHAMUD, Ahmed Abdi; e) "GODANE"; f) "GODANI"; g) "MUKHTAR, Shaykh"; h) " ZUBEYR, Abu"', '02', 'AHMED ABDI', 'AHMED ABDI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1740', '20171206', '����췢[2017]158��', '1: AHMED 2: ABDI 3: AW-MOHAMED 4: na', 'a) ABU ZUBEYR, Muktar Abdirahman; b) ABUZUBAIR, Muktar Abdulrahim; c) AW MOHAMMED, Ahmed Abdi; d) AW-MOHAMUD, Ahmed Abdi; e) "GODANE"; f) "GODANI"; g) "MUKHTAR, Shaykh"; h) " ZUBEYR, Abu"', '04', 'MUKHTAR', 'MUKHTAR', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1741', '20171206', '����췢[2017]158��', '1: AHMED 2: ABDI 3: AW-MOHAMED 4: na', 'a) ABU ZUBEYR, Muktar Abdirahman; b) ABUZUBAIR, Muktar Abdulrahim; c) AW MOHAMMED, Ahmed Abdi; d) AW-MOHAMUD, Ahmed Abdi; e) "GODANE"; f) "GODANI"; g) "MUKHTAR, Shaykh"; h) " ZUBEYR, Abu"', '04', 'Muktar Abdirahman', 'MUKTAR ABDIRAHMAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1742', '20171206', '����췢[2017]158��', '1: AHMED 2: ABDI 3: AW-MOHAMED 4: na', 'a) ABU ZUBEYR, Muktar Abdirahman; b) ABUZUBAIR, Muktar Abdulrahim; c) AW MOHAMMED, Ahmed Abdi; d) AW-MOHAMUD, Ahmed Abdi; e) "GODANE"; f) "GODANI"; g) "MUKHTAR, Shaykh"; h) " ZUBEYR, Abu"', '04', 'Shaykh', 'SHAYKH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1743', '20171206', '����췢[2017]158��', '1: AHMED 2: ABDI 3: AW-MOHAMED 4: na', 'a) ABU ZUBEYR, Muktar Abdirahman; b) ABUZUBAIR, Muktar Abdulrahim; c) AW MOHAMMED, Ahmed Abdi; d) AW-MOHAMUD, Ahmed Abdi; e) "GODANE"; f) "GODANI"; g) "MUKHTAR, Shaykh"; h) " ZUBEYR, Abu"', '04', 'ZUBEYR', 'ZUBEYR', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1744', '20171206', '����췢[2017]158��', '1: AHMED 2: ABDI 3: AW-MOHAMED 4: na', 'a) ABU ZUBEYR, Muktar Abdirahman; b) ABUZUBAIR, Muktar Abdulrahim; c) AW MOHAMMED, Ahmed Abdi; d) AW-MOHAMUD, Ahmed Abdi; e) "GODANE"; f) "GODANI"; g) "MUKHTAR, Shaykh"; h) " ZUBEYR, Abu"', '04', 'Abu', 'ABU', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1745', '20171206', '����췢[2017]158��', '1: AHMED 2: ABDI 3: AW-MOHAMED 4: na', 'a) ABU ZUBEYR, Muktar Abdirahman; b) ABUZUBAIR, Muktar Abdulrahim; c) AW MOHAMMED, Ahmed Abdi; d) AW-MOHAMUD, Ahmed Abdi; e) "GODANE"; f) "GODANI"; g) "MUKHTAR, Shaykh"; h) " ZUBEYR, Abu"', '04', 'Ahmed Abdi', 'AHMED ABDI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1746', '20171206', '����췢[2017]158��', '1: AHMED 2: ABDI 3: AW-MOHAMED 4: na', 'a) ABU ZUBEYR, Muktar Abdirahman; b) ABUZUBAIR, Muktar Abdulrahim; c) AW MOHAMMED, Ahmed Abdi; d) AW-MOHAMUD, Ahmed Abdi; e) "GODANE"; f) "GODANI"; g) "MUKHTAR, Shaykh"; h) " ZUBEYR, Abu"', '04', 'GODANI', 'GODANI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1747', '20171206', '����췢[2017]158��', '1: AHMED 2: ABDI 3: AW-MOHAMED 4: na', 'a) ABU ZUBEYR, Muktar Abdirahman; b) ABUZUBAIR, Muktar Abdulrahim; c) AW MOHAMMED, Ahmed Abdi; d) AW-MOHAMUD, Ahmed Abdi; e) "GODANE"; f) "GODANI"; g) "MUKHTAR, Shaykh"; h) " ZUBEYR, Abu"', '04', 'GODANE', 'GODANE', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1748', '20171206', '����췢[2017]158��', '1: AHMED 2: ABDI 3: AW-MOHAMED 4: na', 'a) ABU ZUBEYR, Muktar Abdirahman; b) ABUZUBAIR, Muktar Abdulrahim; c) AW MOHAMMED, Ahmed Abdi; d) AW-MOHAMUD, Ahmed Abdi; e) "GODANE"; f) "GODANI"; g) "MUKHTAR, Shaykh"; h) " ZUBEYR, Abu"', '04', 'AW-MOHAMUD', 'AW-MOHAMUD', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1749', '20171206', '����췢[2017]158��', '1: AHMED 2: ABDI 3: AW-MOHAMED 4: na', 'a) ABU ZUBEYR, Muktar Abdirahman; b) ABUZUBAIR, Muktar Abdulrahim; c) AW MOHAMMED, Ahmed Abdi; d) AW-MOHAMUD, Ahmed Abdi; e) "GODANE"; f) "GODANI"; g) "MUKHTAR, Shaykh"; h) " ZUBEYR, Abu"', '04', 'Ahmed Abdi', 'AHMED ABDI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1750', '20171206', '����췢[2017]158��', '1: AHMED 2: ABDI 3: AW-MOHAMED 4: na', 'a) ABU ZUBEYR, Muktar Abdirahman; b) ABUZUBAIR, Muktar Abdulrahim; c) AW MOHAMMED, Ahmed Abdi; d) AW-MOHAMUD, Ahmed Abdi; e) "GODANE"; f) "GODANI"; g) "MUKHTAR, Shaykh"; h) " ZUBEYR, Abu"', '04', 'AW MOHAMMED', 'AW MOHAMMED', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1751', '20171206', '����췢[2017]158��', '1: AHMED 2: ABDI 3: AW-MOHAMED 4: na', 'a) ABU ZUBEYR, Muktar Abdirahman; b) ABUZUBAIR, Muktar Abdulrahim; c) AW MOHAMMED, Ahmed Abdi; d) AW-MOHAMUD, Ahmed Abdi; e) "GODANE"; f) "GODANI"; g) "MUKHTAR, Shaykh"; h) " ZUBEYR, Abu"', '04', 'ABU ZUBEYR', 'ABU ZUBEYR', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1752', '20171206', '����췢[2017]158��', '1: AHMED 2: ABDI 3: AW-MOHAMED 4: na', 'a) ABU ZUBEYR, Muktar Abdirahman; b) ABUZUBAIR, Muktar Abdulrahim; c) AW MOHAMMED, Ahmed Abdi; d) AW-MOHAMUD, Ahmed Abdi; e) "GODANE"; f) "GODANI"; g) "MUKHTAR, Shaykh"; h) " ZUBEYR, Abu"', '04', 'ABUZUBAIR', 'ABUZUBAIR', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1753', '20171206', '����췢[2017]158��', '1: AHMED 2: ABDI 3: AW-MOHAMED 4: na', 'a) ABU ZUBEYR, Muktar Abdirahman; b) ABUZUBAIR, Muktar Abdulrahim; c) AW MOHAMMED, Ahmed Abdi; d) AW-MOHAMUD, Ahmed Abdi; e) "GODANE"; f) "GODANI"; g) "MUKHTAR, Shaykh"; h) " ZUBEYR, Abu"', '04', 'Muktar Abdulrahim', 'MUKTAR ABDULRAHIM', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1754', '20171206', '����췢[2017]158��', '1: AHMED JAN 2: WAZIR 3: AKHTAR MOHAMMAD 4: na', 'a) Ahmed Jan Kuchi; b) Ahmed Jan Zadran', '02', 'AHMED JAN WAZIR', 'AHMED JAN WAZIR', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1755', '20171206', '����췢[2017]158��', '1: AHMED JAN 2: WAZIR 3: AKHTAR MOHAMMAD 4: na', 'a) Ahmed Jan Kuchi; b) Ahmed Jan Zadran', '04', 'Ahmed Jan Kuchi', 'AHMED JAN KUCHI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1756', '20171206', '����췢[2017]158��', '1: AHMED JAN 2: WAZIR 3: AKHTAR MOHAMMAD 4: na', 'a) Ahmed Jan Kuchi; b) Ahmed Jan Zadran', '04', 'Ahmed Jan Zadran', 'AHMED JAN ZADRAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1757', '20171206', '����췢[2017]158��', '1: ALI 2: HASSAN 3: AL-MAJID 4: AL-TIKRITI', null, '02', 'ALI HASSAN', 'ALI HASSAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1758', '20171206', '����췢[2017]158��', '1: ALI 2: SADDAM 3: HUSSEIN 4: AL-TIKRITI', null, '02', 'ALI SADDAM', 'ALI SADDAM', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1759', '20171206', '����췢[2017]158��', '1: ALI AKBAR 2: AHMADIAN 3: na 4: na', 'Ali Akbar Ahmedian', '02', 'ALI AKBAR AHMADIAN', 'ALI AKBAR AHMADIAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1760', '20171206', '����췢[2017]158��', '1: ALI AKBAR 2: AHMADIAN 3: na 4: na', 'Ali Akbar Ahmedian', '03', 'Ali Akbar Ahmedian', 'ALI AKBAR AHMEDIAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1761', '20171206', '����췢[2017]158��', '1: AMIR 2: ABDULLAH 3: na 4: na', null, '02', 'AMIR ABDULLAH', 'AMIR ABDULLAH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1762', '20171206', '����췢[2017]158��', '1: AMIR 2: HAMUDI 3: HASSAN 4: AL-SA''DI', null, '02', 'AMIR HAMUDI', 'AMIR HAMUDI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1763', '20171206', '����췢[2017]158��', '1: AMIR 2: RASHID 3: MUHAMMAD 4: AL-UBAIDI', null, '02', 'AMIR RASHID', 'AMIR RASHID', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1764', '20171206', '����췢[2017]158��', '1: ATTIQULLAH 2: AKHUND 3: na 4: na', null, '02', 'ATTIQULLAH AKHUND', 'ATTIQULLAH AKHUND', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1765', '20171206', '����췢[2017]158��', '1: AYAD 2: FUTAYYIH 3: KHALIFA 4: AL-RAWI', null, '02', 'AYAD FUTAYYIH', 'AYAD FUTAYYIH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1766', '20171206', '����췢[2017]158��', '1: AZIM 2: AGHAJANI 3: na 4: na', 'Azim Adhajani; Azim Agha-Jani', '02', 'AZIM AGHAJANI', 'AZIM AGHAJANI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1767', '20171206', '����췢[2017]158��', '1: AZIM 2: AGHAJANI 3: na 4: na', 'Azim Adhajani; Azim Agha-Jani', '03', 'Azim Agha-Jani', 'AZIM AGHA-JANI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1768', '20171206', '����췢[2017]158��', '1: AZIM 2: AGHAJANI 3: na 4: na', 'Azim Adhajani; Azim Agha-Jani', '03', 'Azim Adhajani', 'AZIM ADHAJANI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1769', '20171206', '����췢[2017]158��', '1: AZIZ 2: SALIH 3: AL-NUMAN 4: na', null, '02', 'AZIZ SALIH', 'AZIZ SALIH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1770', '20171206', '����췢[2017]158��', '1: AZIZIRAHMAN 2: ABDUL AHAD 3: na 4: na', null, '02', 'AZIZIRAHMAN ABDUL AHAD', 'AZIZIRAHMAN ABDUL AHAD', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1771', '20171206', '����췢[2017]158��', '1: BAHMANYAR MORTEZA 2: BAHMANYAR 3: na 4: na', null, '02', 'BAHMANYAR MORTEZA BAHMANYAR', 'BAHMANYAR MORTEZA BAHMANYAR', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1772', '20171206', '����췢[2017]158��', '1: BARZAN 2: ABD AL-GHAFUR 3: SULAIMAN MAJID 4: AL-TIKRITI', 'a) Barzan Razuki Abd al-Ghafur', '02', 'BARZAN ABD AL-GHAFUR', 'BARZAN ABD AL-GHAFUR', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1773', '20171206', '����췢[2017]158��', '1: BARZAN 2: ABD AL-GHAFUR 3: SULAIMAN MAJID 4: AL-TIKRITI', 'a) Barzan Razuki Abd al-Ghafur', '04', 'Barzan Razuki Abd al-Ghafur', 'BARZAN RAZUKI ABD AL-GHAFUR', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1774', '20171206', '����췢[2017]158��', '1: BARZAN 2: IBRAHIM 3: HASSAN 4: AL-TIKRITI', null, '02', 'BARZAN IBRAHIM', 'BARZAN IBRAHIM', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1775', '20171206', '����췢[2017]158��', '1: BOUBEKEUR 2: BOULGHITI 3: na 4: na', 'Boubakeur Boulghit', '02', 'BOUBEKEUR BOULGHITI', 'BOUBEKEUR BOULGHITI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1776', '20171206', '����췢[2017]158��', '1: BOUBEKEUR 2: BOULGHITI 3: na 4: na', 'Boubakeur Boulghit', '03', 'Boubakeur Boulghit', 'BOUBAKEUR BOULGHIT', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1777', '20171206', '����췢[2017]158��', '1: CHOE 2: CHUN YONG 3: na 4: na', 'a) Ch''oe Ch''un-yo''ng', '02', 'CHOE CHUN YONG', 'CHOE CHUN YONG', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1778', '20171206', '����췢[2017]158��', '1: CHOE 2: CHUN YONG 3: na 4: na', 'a) Ch''oe Ch''un-yo''ng', '04', 'Ch''oe Ch''un-yo''ng', 'CH''OE CH''UN-YO''NG', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1779', '20171206', '����췢[2017]158��', '1: CHOE 2: CHUN-SIK 3: na 4: na', 'a) Choe Chun Sik; b) Ch''oe Ch''un Sik', '02', 'CHOE CHUN-SIK', 'CHOE CHUN-SIK', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1780', '20171206', '����췢[2017]158��', '1: CHOE 2: CHUN-SIK 3: na 4: na', 'a) Choe Chun Sik; b) Ch''oe Ch''un Sik', '04', 'Choe Chun Sik', 'CHOE CHUN SIK', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1781', '20171206', '����췢[2017]158��', '1: CHOE 2: CHUN-SIK 3: na 4: na', 'a) Choe Chun Sik; b) Ch''oe Ch''un Sik', '04', 'Ch''oe Ch''un Sik', 'CH''OE CH''UN SIK', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1782', '20171206', '����췢[2017]158��', '1: CRANHA 2: DANFA 3: na 4: na', null, '02', 'CRANHA DANFA', 'CRANHA DANFA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1783', '20171206', '����췢[2017]158��', '1: EHSANULLAH 2: SARFIDA 3: HESAMUDDIN 4: AKHUNDZADA', 'a) Ehsanullah Sarfadi; b) Ehsanullah Sarfida ', '02', 'EHSANULLAH SARFIDA', 'EHSANULLAH SARFIDA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1784', '20171206', '����췢[2017]158��', '1: EHSANULLAH 2: SARFIDA 3: HESAMUDDIN 4: AKHUNDZADA', 'a) Ehsanullah Sarfadi; b) Ehsanullah Sarfida ', '04', 'Ehsanullah Sarfadi', 'EHSANULLAH SARFADI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1785', '20171206', '����췢[2017]158��', '1: EHSANULLAH 2: SARFIDA 3: HESAMUDDIN 4: AKHUNDZADA', 'a) Ehsanullah Sarfadi; b) Ehsanullah Sarfida ', '04', 'Ehsanullah Sarfida', 'EHSANULLAH SARFIDA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1786', '20171206', '����췢[2017]158��', '1: ERIC 2: BADEGE 3: na 4: na', null, '02', 'ERIC BADEGE', 'ERIC BADEGE', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1787', '20171206', '����췢[2017]158��', '1: FEREIDOUN 2: ABBASI-DAVANI 3: na 4: na', null, '02', 'FEREIDOUN ABBASI-DAVANI', 'FEREIDOUN ABBASI-DAVANI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1788', '20171206', '����췢[2017]158��', '1: FRANCOIS 2: YANGOUVONDA 3: BOZIZE 4: na', 'a) Bozize Yangouvonda', '02', 'FRANCOIS YANGOUVONDA', 'FRANCOIS YANGOUVONDA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1789', '20171206', '����췢[2017]158��', '1: FRANCOIS 2: YANGOUVONDA 3: BOZIZE 4: na', 'a) Bozize Yangouvonda', '04', 'Bozize Yangouvonda', 'BOZIZE YANGOUVONDA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1790', '20171206', '����췢[2017]158��', '1: FRANK KAKOLELE 2: BWAMBALE 3: na 4: na', 'a) FRANK KAKORERE; b) FRANK KAKORERE BWAMBALE; c) AIGLE BLANC', '02', 'FRANK KAKOLELE BWAMBALE', 'FRANK KAKOLELE BWAMBALE', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1791', '20171206', '����췢[2017]158��', '1: FRANK KAKOLELE 2: BWAMBALE 3: na 4: na', 'a) FRANK KAKORERE; b) FRANK KAKORERE BWAMBALE; c) AIGLE BLANC', '04', 'FRANK KAKORERE BWAMBALE', 'FRANK KAKORERE BWAMBALE', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1792', '20171206', '����췢[2017]158��', '1: FRANK KAKOLELE 2: BWAMBALE 3: na 4: na', 'a) FRANK KAKORERE; b) FRANK KAKORERE BWAMBALE; c) AIGLE BLANC', '04', 'FRANK KAKORERE', 'FRANK KAKORERE', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1793', '20171206', '����췢[2017]158��', '1: FRANK KAKOLELE 2: BWAMBALE 3: na 4: na', 'a) FRANK KAKORERE; b) FRANK KAKORERE BWAMBALE; c) AIGLE BLANC', '04', 'AIGLE BLANC', 'AIGLE BLANC', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1794', '20171206', '����췢[2017]158��', '1: GHAZI 2: HAMMUD 3: AL-UBAIDI 4: na', null, '02', 'GHAZI HAMMUD', 'GHAZI HAMMUD', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1795', '20171206', '����췢[2017]158��', '1: HALA 2: SADDAM 3: HUSSEIN 4: AL-TIKRITI', null, '02', 'HALA SADDAM', 'HALA SADDAM', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1796', '20171206', '����췢[2017]158��', '1: HAMDULLAH 2: ALLAH NOOR 3: na 4: na', null, '02', 'HAMDULLAH ALLAH NOOR', 'HAMDULLAH ALLAH NOOR', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1797', '20171206', '����췢[2017]158��', '1: HAMID 2: RAJA 3: SHALAH 4: AL-TIKRITI', 'a) Hassan Al-Tikriti; b) Hamid Raja-Shalah Hassum Al-Tikriti', '02', 'HAMID RAJA', 'HAMID RAJA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1798', '20171206', '����췢[2017]158��', '1: HAMID 2: RAJA 3: SHALAH 4: AL-TIKRITI', 'a) Hassan Al-Tikriti; b) Hamid Raja-Shalah Hassum Al-Tikriti', '04', 'Hamid Raja-Shalah Hassum Al-Tikriti', 'HAMID RAJA-SHALAH HASSUM AL-TIKRITI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1799', '20171206', '����췢[2017]158��', '1: HAMID 2: RAJA 3: SHALAH 4: AL-TIKRITI', 'a) Hassan Al-Tikriti; b) Hamid Raja-Shalah Hassum Al-Tikriti', '04', 'Hassan Al-Tikriti', 'HASSAN AL-TIKRITI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1800', '20171206', '����췢[2017]158��', '1: HANI 2: ABD-AL-LATIF 3: TILFAH 4: AL-TIKRITI', null, '02', 'HANI ABD-AL-LATIF', 'HANI ABD-AL-LATIF', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1801', '20171206', '����췢[2017]158��', '1: HIKMAT 2: MIZBAN 3: IBRAHIM 4: AL-AZZAWI', null, '02', 'HIKMAT MIZBAN', 'HIKMAT MIZBAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1802', '20171206', '����췢[2017]158��', '1: HUDA 2: SALIH 3: MAHDI 4: AMMASH', null, '02', 'HUDA SALIH', 'HUDA SALIH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1803', '20171206', '����췢[2017]158��', '1: HUMAM 2: ABD-AL-KHALIQ 3: ABD-AL-GHAFUR 4: na', 'a) Humam ''Abd-al-Khaliq ''Abd-al-Rahman; b) Humam ''Abd-al-Khaliq Rashid', '02', 'HUMAM ABD-AL-KHALIQ', 'HUMAM ABD-AL-KHALIQ', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1804', '20171206', '����췢[2017]158��', '1: HUMAM 2: ABD-AL-KHALIQ 3: ABD-AL-GHAFUR 4: na', 'a) Humam ''Abd-al-Khaliq ''Abd-al-Rahman; b) Humam ''Abd-al-Khaliq Rashid', '04', 'Humam ''Abd-al-Khaliq ''Abd-al-Rahman', 'HUMAM ''ABD-AL-KHALIQ ''ABD-AL-RAHMAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1805', '20171206', '����췢[2017]158��', '1: HUMAM 2: ABD-AL-KHALIQ 3: ABD-AL-GHAFUR 4: na', 'a) Humam ''Abd-al-Khaliq ''Abd-al-Rahman; b) Humam ''Abd-al-Khaliq Rashid', '04', 'Humam ''Abd-al-Khaliq Rashid', 'HUMAM ''ABD-AL-KHALIQ RASHID', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1806', '20171206', '����췢[2017]158��', '1: HUSAM 2: MUHAMMAD 3: AMIN 4: AL-YASSIN', null, '02', 'HUSAM MUHAMMAD', 'HUSAM MUHAMMAD', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1807', '20171206', '����췢[2017]158��', '1: IBRAHIM 2: AHMAD ABD AL-SATTAR 3: MUHAMMED 4: AL-TIKRITI', null, '02', 'IBRAHIM AHMAD ABD AL-SATTAR', 'IBRAHIM AHMAD ABD AL-SATTAR', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1808', '20171206', '����췢[2017]158��', '1: IBRAIMA 2: CAMARA 3: na 4: na', 'a) Papa Camara', '02', 'IBRAIMA CAMARA', 'IBRAIMA CAMARA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1809', '20171206', '����췢[2017]158��', '1: IBRAIMA 2: CAMARA 3: na 4: na', 'a) Papa Camara', '04', 'Papa Camara', 'PAPA CAMARA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1810', '20171206', '����췢[2017]158��', '1: INTISSAR 2: AL-UBAYDI 3: na 4: na', null, '02', 'INTISSAR AL-UBAYDI', 'INTISSAR AL-UBAYDI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1811', '20171206', '����췢[2017]158��', '1: IZZAT 2: IBRAHIM 3: AL-DURI 4: na', null, '02', 'IZZAT IBRAHIM', 'IZZAT IBRAHIM', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1812', '20171206', '����췢[2017]158��', '1: JAMAL 2: MUSTAFA ABDALLAH 3: SULTAN 4: AL-TIKRITI', null, '02', 'JAMAL MUSTAFA ABDALLAH', 'JAMAL MUSTAFA ABDALLAH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1813', '20171206', '����췢[2017]158��', '1: JAMES 2: KOANG 3: CHUOL 4: na', 'a) James Koang Chol Ranley; b) James Koang Chol; c) Koang Chuol Ranley; d) James Koang Chual', '02', 'JAMES KOANG', 'JAMES KOANG', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1814', '20171206', '����췢[2017]158��', '1: JAMES 2: KOANG 3: CHUOL 4: na', 'a) James Koang Chol Ranley; b) James Koang Chol; c) Koang Chuol Ranley; d) James Koang Chual', '04', 'James Koang Chol', 'JAMES KOANG CHOL', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1815', '20171206', '����췢[2017]158��', '1: JAMES 2: KOANG 3: CHUOL 4: na', 'a) James Koang Chol Ranley; b) James Koang Chol; c) Koang Chuol Ranley; d) James Koang Chual', '04', 'Koang Chuol Ranley', 'KOANG CHUOL RANLEY', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1816', '20171206', '����췢[2017]158��', '1: JAMES 2: KOANG 3: CHUOL 4: na', 'a) James Koang Chol Ranley; b) James Koang Chol; c) Koang Chuol Ranley; d) James Koang Chual', '04', 'James Koang Chual', 'JAMES KOANG CHUAL', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1817', '20171206', '����췢[2017]158��', '1: JAMES 2: KOANG 3: CHUOL 4: na', 'a) James Koang Chol Ranley; b) James Koang Chol; c) Koang Chuol Ranley; d) James Koang Chual', '04', 'James Koang Chol Ranley', 'JAMES KOANG CHOL RANLEY', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1818', '20171206', '����췢[2017]158��', '1: JANAN 2: AGHA 3: na 4: na', 'Abdullah Jan Agha', '02', 'JANAN AGHA', 'JANAN AGHA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1819', '20171206', '����췢[2017]158��', '1: JANAN 2: AGHA 3: na 4: na', 'Abdullah Jan Agha', '03', 'Abdullah Jan Agha', 'ABDULLAH JAN AGHA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1820', '20171206', '����췢[2017]158��', '1: JANG 2: BOM SU 3: na 4: na', 'a) Jang Pom Su; b) Jang Hyon U born 22 Feb. 1958', '02', 'JANG BOM SU', 'JANG BOM SU', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1821', '20171206', '����췢[2017]158��', '1: JANG 2: BOM SU 3: na 4: na', 'a) Jang Pom Su; b) Jang Hyon U born 22 Feb. 1958', '04', 'Jang Hyon U', 'JANG HYON U', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1822', '20171206', '����췢[2017]158��', '1: JANG 2: BOM SU 3: na 4: na', 'a) Jang Pom Su; b) Jang Hyon U born 22 Feb. 1958', '04', 'Jang Pom Su', 'JANG POM SU', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1823', '20171206', '����췢[2017]158��', '1: JAWHAR 2: MAJID 3: AL-DURI 4: na', null, '02', 'JAWHAR MAJID', 'JAWHAR MAJID', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1824', '20171206', '����췢[2017]158��', '1: JO 2: CHOL SONG 3: na 4: na', 'a) Cho Ch''o''l-so''ng', '02', 'JO CHOL SONG', 'JO CHOL SONG', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1825', '20171206', '����췢[2017]158��', '1: JO 2: CHOL SONG 3: na 4: na', 'a) Cho Ch''o''l-so''ng', '04', 'Cho Ch''o''l-so''ng', 'CHO CH''O''L-SO''NG', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1826', '20171206', '����췢[2017]158��', '1: KAMAL 2: MUSTAFA 3: ABDALLAH 4: na', 'Kamal Mustafa Abdallah Sultan al-Tikriti', '02', 'KAMAL MUSTAFA', 'KAMAL MUSTAFA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1827', '20171206', '����췢[2017]158��', '1: KAMAL 2: MUSTAFA 3: ABDALLAH 4: na', 'Kamal Mustafa Abdallah Sultan al-Tikriti', '03', 'Kamal Mustafa Abdallah Sultan al-Tikriti', 'KAMAL MUSTAFA ABDALLAH SULTAN AL-TIKRITI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1828', '20171206', '����췢[2017]158��', '1: KANG 2: CHOL SU 3: na 4: na', null, '02', 'KANG CHOL SU', 'KANG CHOL SU', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1829', '20171206', '����췢[2017]158��', '1: KHALAF 2: M. 3:. 4: AL-DULAYMI', 'Khalaf Al Dulaimi', '02', 'KHALAF M.', 'KHALAF M.', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1830', '20171206', '����췢[2017]158��', '1: KHALAF 2: M. 3:. 4: AL-DULAYMI', 'Khalaf Al Dulaimi', '03', 'Khalaf Al Dulaimi', 'KHALAF AL DULAIMI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1831', '20171206', '����췢[2017]158��', '1: KHAMIS 2: SIRHAN 3: AL-MUHAMMAD 4: na', 'Dr. Fnu Mnu Khamis', '02', 'KHAMIS SIRHAN', 'KHAMIS SIRHAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1832', '20171206', '����췢[2017]158��', '1: KHAMIS 2: SIRHAN 3: AL-MUHAMMAD 4: na', 'Dr. Fnu Mnu Khamis', '03', 'Dr. Fnu Mnu Khamis', 'DR. FNU MNU KHAMIS', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1833', '20171206', '����췢[2017]158��', '1: KIM 2: CHOL NAM 3: na 4: na', null, '02', 'KIM CHOL NAM', 'KIM CHOL NAM', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1834', '20171206', '����췢[2017]158��', '1: KO 2: CH''O''L-CHAE 3: na 4: na', null, '02', 'KO CH''O''L-CHAE', 'KO CH''O''L-CHAE', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1835', '20171206', '����췢[2017]158��', '1: LATIF 2: NUSAYYIF 3: JASIM 4: AL-DULAYMI', null, '02', 'LATIF NUSAYYIF', 'LATIF NUSAYYIF', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1836', '20171206', '����췢[2017]158��', '1: MAHMUD 2: DHIYAB 3: AL-AHMED 4: na', null, '02', 'MAHMUD DHIYAB', 'MAHMUD DHIYAB', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1837', '20171206', '����췢[2017]158��', '1: MIN 2: BYONG CHOL 3: na 4: na', 'a) Min Pyo''ng-ch''o''l; b) Min Byong-chol; c) Min Byong Chun', '02', 'MIN BYONG CHOL', 'MIN BYONG CHOL', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1838', '20171206', '����췢[2017]158��', '1: MIN 2: BYONG CHOL 3: na 4: na', 'a) Min Pyo''ng-ch''o''l; b) Min Byong-chol; c) Min Byong Chun', '04', 'Min Byong-chol', 'MIN BYONG-CHOL', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1839', '20171206', '����췢[2017]158��', '1: MIN 2: BYONG CHOL 3: na 4: na', 'a) Min Pyo''ng-ch''o''l; b) Min Byong-chol; c) Min Byong Chun', '04', 'Min Byong Chun', 'MIN BYONG CHUN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1840', '20171206', '����췢[2017]158��', '1: MIN 2: BYONG CHOL 3: na 4: na', 'a) Min Pyo''ng-ch''o''l; b) Min Byong-chol; c) Min Byong Chun', '04', 'Min Pyo''ng-ch''o''l', 'MIN PYO''NG-CH''O''L', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1841', '20171206', '����췢[2017]158��', '1: MOHAMMAD 2: AHMADI 3: na 4: na', null, '02', 'MOHAMMAD AHMADI', 'MOHAMMAD AHMADI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1842', '20171206', '����췢[2017]158��', '1: MOHAMMAD 2: AMAN 3: AKHUND 4: na', 'a) Mohammed Aman; b) Mullah Mohammed Oman; c) Mullah Mohammad Aman Ustad Noorzai', '02', 'MOHAMMAD AMAN', 'MOHAMMAD AMAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1843', '20171206', '����췢[2017]158��', '1: MOHAMMAD 2: AMAN 3: AKHUND 4: na', 'a) Mohammed Aman; b) Mullah Mohammed Oman; c) Mullah Mohammad Aman Ustad Noorzai', '04', 'Mullah Mohammed Oman', 'MULLAH MOHAMMED OMAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1844', '20171206', '����췢[2017]158��', '1: MOHAMMAD 2: AMAN 3: AKHUND 4: na', 'a) Mohammed Aman; b) Mullah Mohammed Oman; c) Mullah Mohammad Aman Ustad Noorzai', '04', 'Mohammed Aman', 'MOHAMMED AMAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1845', '20171206', '����췢[2017]158��', '1: MOHAMMAD 2: AMAN 3: AKHUND 4: na', 'a) Mohammed Aman; b) Mullah Mohammed Oman; c) Mullah Mohammad Aman Ustad Noorzai', '04', 'Mullah Mohammad Aman Ustad Noorzai', 'MULLAH MOHAMMAD AMAN USTAD NOORZAI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1846', '20171206', '����췢[2017]158��', '1: MOHAMMAD 2: HASSAN 3: AKHUND 4: na', null, '02', 'MOHAMMAD HASSAN', 'MOHAMMAD HASSAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1847', '20171206', '����췢[2017]158��', '1: MOHAMMAD ABBAS 2: AKHUND 3: na 4: na', null, '02', 'MOHAMMAD ABBAS AKHUND', 'MOHAMMAD ABBAS AKHUND', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1848', '20171206', '����췢[2017]158��', '1: MOHAMMAD ESHAQ 2: AKHUNZADA 3: na 4: na', 'Mohammad Ishaq Akhund born in 1963', '02', 'MOHAMMAD ESHAQ AKHUNZADA', 'MOHAMMAD ESHAQ AKHUNZADA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1849', '20171206', '����췢[2017]158��', '1: MOHAMMAD ESHAQ 2: AKHUNZADA 3: na 4: na', 'Mohammad Ishaq Akhund born in 1963', '03', 'Mohammad Ishaq Akhund born in 1963', 'MOHAMMAD ISHAQ AKHUND BORN IN 1963', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1850', '20171206', '����췢[2017]158��', '1: MOHAMMAD ESSA 2: AKHUND 3: na 4: na', null, '02', 'MOHAMMAD ESSA AKHUND', 'MOHAMMAD ESSA AKHUND', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1851', '20171206', '����췢[2017]158��', '1: MOHAMMAD RASUL 2: AYYUB 3: na 4: na', 'a) Gurg', '02', 'MOHAMMAD RASUL AYYUB', 'MOHAMMAD RASUL AYYUB', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1852', '20171206', '����췢[2017]158��', '1: MOHAMMAD RASUL 2: AYYUB 3: na 4: na', 'a) Gurg', '04', 'Gurg', 'GURG', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1853', '20171206', '����췢[2017]158��', '1: MOHAMMAD SADIQ 2: AMIR MOHAMMAD 3: na 4: na', null, '02', 'MOHAMMAD SADIQ AMIR MOHAMMAD', 'MOHAMMAD SADIQ AMIR MOHAMMAD', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1854', '20171206', '����췢[2017]158��', '1: MUHAMMAD 2: MAHDI 3: AL-SALIH 4: na', null, '02', 'MUHAMMAD MAHDI', 'MUHAMMAD MAHDI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1855', '20171206', '����췢[2017]158��', '1: MUHAMMAD 2: TAHER 3: ANWARI 4: na', 'a) Mohammad Taher Anwari; b) Muhammad Tahir Anwari; c) Mohammad Tahre Anwari', '02', 'MUHAMMAD TAHER', 'MUHAMMAD TAHER', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1856', '20171206', '����췢[2017]158��', '1: MUHAMMAD 2: TAHER 3: ANWARI 4: na', 'a) Mohammad Taher Anwari; b) Muhammad Tahir Anwari; c) Mohammad Tahre Anwari', '04', 'Mohammad Tahre Anwari', 'MOHAMMAD TAHRE ANWARI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1857', '20171206', '����췢[2017]158��', '1: MUHAMMAD 2: TAHER 3: ANWARI 4: na', 'a) Mohammad Taher Anwari; b) Muhammad Tahir Anwari; c) Mohammad Tahre Anwari', '04', 'Muhammad Tahir Anwari', 'MUHAMMAD TAHIR ANWARI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1858', '20171206', '����췢[2017]158��', '1: MUHAMMAD 2: TAHER 3: ANWARI 4: na', 'a) Mohammad Taher Anwari; b) Muhammad Tahir Anwari; c) Mohammad Tahre Anwari', '04', 'Mohammad Taher Anwari', 'MOHAMMAD TAHER ANWARI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1859', '20171206', '����췢[2017]158��', '1: MUHAMMAD 2: YUNIS 3: AHMAD 4: na', 'a) Muhammad Yunis Al-Ahmed; b) Muhammad Yunis Ahmed; c) Muhammad Yunis Ahmad Al-Badrani; d) Muhammad Yunis Ahmed Al-Moali', '02', 'MUHAMMAD YUNIS', 'MUHAMMAD YUNIS', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1860', '20171206', '����췢[2017]158��', '1: MUHAMMAD 2: YUNIS 3: AHMAD 4: na', 'a) Muhammad Yunis Al-Ahmed; b) Muhammad Yunis Ahmed; c) Muhammad Yunis Ahmad Al-Badrani; d) Muhammad Yunis Ahmed Al-Moali', '04', 'Muhammad Yunis Ahmed Al-Moali', 'MUHAMMAD YUNIS AHMED AL-MOALI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1861', '20171206', '����췢[2017]158��', '1: MUHAMMAD 2: YUNIS 3: AHMAD 4: na', 'a) Muhammad Yunis Al-Ahmed; b) Muhammad Yunis Ahmed; c) Muhammad Yunis Ahmad Al-Badrani; d) Muhammad Yunis Ahmed Al-Moali', '04', 'Muhammad Yunis Al-Ahmed', 'MUHAMMAD YUNIS AL-AHMED', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1862', '20171206', '����췢[2017]158��', '1: MUHAMMAD 2: YUNIS 3: AHMAD 4: na', 'a) Muhammad Yunis Al-Ahmed; b) Muhammad Yunis Ahmed; c) Muhammad Yunis Ahmad Al-Badrani; d) Muhammad Yunis Ahmed Al-Moali', '04', 'Muhammad Yunis Ahmad Al-Badrani', 'MUHAMMAD YUNIS AHMAD AL-BADRANI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1863', '20171206', '����췢[2017]158��', '1: MUHAMMAD 2: YUNIS 3: AHMAD 4: na', 'a) Muhammad Yunis Al-Ahmed; b) Muhammad Yunis Ahmed; c) Muhammad Yunis Ahmad Al-Badrani; d) Muhammad Yunis Ahmed Al-Moali', '04', 'Muhammad Yunis Ahmed', 'MUHAMMAD YUNIS AHMED', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1864', '20171206', '����췢[2017]158��', '1: MUHAMMAD 2: ZIMAM 3: ABD-AL-RAZZAQ 4: AL-SADUN', null, '02', 'MUHAMMAD ZIMAM', 'MUHAMMAD ZIMAM', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1865', '20171206', '����췢[2017]158��', '1: MUHSIN 2: KHADR 3: AL-KHAFAJI 4: na', null, '02', 'MUHSIN KHADR', 'MUHSIN KHADR', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1866', '20171206', '����췢[2017]158��', '1: MUN 2: CHO''NG-CH''O''L 3: na 4: na', null, '02', 'MUN CHO''NG-CH''O''L', 'MUN CHO''NG-CH''O''L', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1867', '20171206', '����췢[2017]158��', '1: MUNIR 2: AL QUBAYSI 3: na 4: na', 'a) Munir Al-Kubaysi; b) Muneer Al-Kubaisi; c) Munir Awad; d) Munir A Mamduh. Awad', '02', 'MUNIR AL QUBAYSI', 'MUNIR AL QUBAYSI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1868', '20171206', '����췢[2017]158��', '1: MUNIR 2: AL QUBAYSI 3: na 4: na', 'a) Munir Al-Kubaysi; b) Muneer Al-Kubaisi; c) Munir Awad; d) Munir A Mamduh. Awad', '04', 'Munir Awad', 'MUNIR AWAD', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1869', '20171206', '����췢[2017]158��', '1: MUNIR 2: AL QUBAYSI 3: na 4: na', 'a) Munir Al-Kubaysi; b) Muneer Al-Kubaisi; c) Munir Awad; d) Munir A Mamduh. Awad', '04', 'Muneer Al-Kubaisi', 'MUNEER AL-KUBAISI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1870', '20171206', '����췢[2017]158��', '1: MUNIR 2: AL QUBAYSI 3: na 4: na', 'a) Munir Al-Kubaysi; b) Muneer Al-Kubaisi; c) Munir Awad; d) Munir A Mamduh. Awad', '04', 'Munir Al-Kubaysi', 'MUNIR AL-KUBAYSI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1871', '20171206', '����췢[2017]158��', '1: MUNIR 2: AL QUBAYSI 3: na 4: na', 'a) Munir Al-Kubaysi; b) Muneer Al-Kubaisi; c) Munir Awad; d) Munir A Mamduh. Awad', '04', 'Munir A Mamduh. Awad', 'MUNIR A MAMDUH. AWAD', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1872', '20171206', '����췢[2017]158��', '1: MUSA 2: HILAL 3: ABDALLA 4: ALNSIEM', null, '02', 'MUSA HILAL', 'MUSA HILAL', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1873', '20171206', '����췢[2017]158��', '1: MUZAHIM 2: SAB 3: HASSAN 4: AL-TIKRITI', null, '02', 'MUZAHIM SAB', 'MUZAHIM SAB', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1874', '20171206', '����췢[2017]158��', '1: NAZIR MOHAMMAD 2: ABDUL BASIR 3: na 4: na', 'Nazar Mohammad', '02', 'NAZIR MOHAMMAD ABDUL BASIR', 'NAZIR MOHAMMAD ABDUL BASIR', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1875', '20171206', '����췢[2017]158��', '1: NAZIR MOHAMMAD 2: ABDUL BASIR 3: na 4: na', 'Nazar Mohammad', '03', 'Nazar Mohammad', 'NAZAR MOHAMMAD', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1876', '20171206', '����췢[2017]158��', '1: NIDAL 2: AL-RABI 3: na 4: na', null, '02', 'NIDAL AL-RABI', 'NIDAL AL-RABI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1877', '20171206', '����췢[2017]158��', '1: NOURREDINE 2: ADAM 3: na 4: na', 'a) Nureldine Adam; b) Nourreldine Adam; c) Nourreddine Adam; d) Mahamat Nouradine Adam', '02', 'NOURREDINE ADAM', 'NOURREDINE ADAM', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1878', '20171206', '����췢[2017]158��', '1: NOURREDINE 2: ADAM 3: na 4: na', 'a) Nureldine Adam; b) Nourreldine Adam; c) Nourreddine Adam; d) Mahamat Nouradine Adam', '04', 'Nureldine Adam', 'NURELDINE ADAM', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1879', '20171206', '����췢[2017]158��', '1: NOURREDINE 2: ADAM 3: na 4: na', 'a) Nureldine Adam; b) Nourreldine Adam; c) Nourreddine Adam; d) Mahamat Nouradine Adam', '04', 'Nourreldine Adam', 'NOURRELDINE ADAM', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1880', '20171206', '����췢[2017]158��', '1: NOURREDINE 2: ADAM 3: na 4: na', 'a) Nureldine Adam; b) Nourreldine Adam; c) Nourreddine Adam; d) Mahamat Nouradine Adam', '04', 'Nourreddine Adam', 'NOURREDDINE ADAM', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1881', '20171206', '����췢[2017]158��', '1: NOURREDINE 2: ADAM 3: na 4: na', 'a) Nureldine Adam; b) Nourreldine Adam; c) Nourreddine Adam; d) Mahamat Nouradine Adam', '04', 'Mahamat Nouradine Adam', 'MAHAMAT NOURADINE ADAM', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1882', '20171206', '����췢[2017]158��', '1: PAEK 2: CHANG-HO 3: na 4: na', 'a) Pak Chang-Ho; b) Paek Ch''ang-Ho', '02', 'PAEK CHANG-HO', 'PAEK CHANG-HO', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1883', '20171206', '����췢[2017]158��', '1: PAEK 2: CHANG-HO 3: na 4: na', 'a) Pak Chang-Ho; b) Paek Ch''ang-Ho', '04', 'Paek Ch''ang-Ho', 'PAEK CH''ANG-HO', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1884', '20171206', '����췢[2017]158��', '1: PAEK 2: CHANG-HO 3: na 4: na', 'a) Pak Chang-Ho; b) Paek Ch''ang-Ho', '04', 'Pak Chang-Ho', 'PAK CHANG-HO', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1885', '20171206', '����췢[2017]158��', '1: QAID 2: HUSSEIN 3: AL-AWADI 4: na', null, '02', 'QAID HUSSEIN', 'QAID HUSSEIN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1886', '20171206', '����췢[2017]158��', '1: QUSAY 2: SADDAM 3: HUSSEIN 4: AL-TIKRITI', null, '02', 'QUSAY SADDAM', 'QUSAY SADDAM', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1887', '20171206', '����췢[2017]158��', '1: RAFI 2: ABD-AL-LATIF 3: TILFAH 4: AL-TIKRITI', null, '02', 'RAFI ABD-AL-LATIF', 'RAFI ABD-AL-LATIF', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1888', '20171206', '����췢[2017]158��', '1: RAGHAD 2: SADDAM 3: HUSSEIN 4: AL-TIKRITI', null, '02', 'RAGHAD SADDAM', 'RAGHAD SADDAM', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1889', '20171206', '����췢[2017]158��', '1: RANA 2: SADDAM 3: HUSSEIN 4: AL-TIKRITI', null, '02', 'RANA SADDAM', 'RANA SADDAM', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1890', '20171206', '����췢[2017]158��', '1: RUKAN 2: RAZUKI 3: ABD-AL-GHAFUR SULAIMAN 4: AL-TIKRITI', 'a) Rukan Abdal-Ghaffur Sulayman al-Majid; b) Rukan Razuqi Abd al-Ghafur Al-Majid; c) Rukan Abd al-Ghaffur al-Majid Al-Tikriti Abu Walid', '02', 'RUKAN RAZUKI', 'RUKAN RAZUKI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1891', '20171206', '����췢[2017]158��', '1: RUKAN 2: RAZUKI 3: ABD-AL-GHAFUR SULAIMAN 4: AL-TIKRITI', 'a) Rukan Abdal-Ghaffur Sulayman al-Majid; b) Rukan Razuqi Abd al-Ghafur Al-Majid; c) Rukan Abd al-Ghaffur al-Majid Al-Tikriti Abu Walid', '04', 'Rukan Abdal-Ghaffur Sulayman al-Majid', 'RUKAN ABDAL-GHAFFUR SULAYMAN AL-MAJID', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1892', '20171206', '����췢[2017]158��', '1: RUKAN 2: RAZUKI 3: ABD-AL-GHAFUR SULAIMAN 4: AL-TIKRITI', 'a) Rukan Abdal-Ghaffur Sulayman al-Majid; b) Rukan Razuqi Abd al-Ghafur Al-Majid; c) Rukan Abd al-Ghaffur al-Majid Al-Tikriti Abu Walid', '04', 'Rukan Razuqi Abd al-Ghafur Al-Majid', 'RUKAN RAZUQI ABD AL-GHAFUR AL-MAJID', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1893', '20171206', '����췢[2017]158��', '1: RUKAN 2: RAZUKI 3: ABD-AL-GHAFUR SULAIMAN 4: AL-TIKRITI', 'a) Rukan Abdal-Ghaffur Sulayman al-Majid; b) Rukan Razuqi Abd al-Ghafur Al-Majid; c) Rukan Abd al-Ghaffur al-Majid Al-Tikriti Abu Walid', '04', 'Rukan Abd al-Ghaffur al-Majid Al-Tikriti Abu Walid', 'RUKAN ABD AL-GHAFFUR AL-MAJID AL-TIKRITI ABU WALID', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1894', '20171206', '����췢[2017]158��', '1: SA''D 2: ABD-AL-MAJID 3: AL-FAISAL 4: AL-TIKRITI', null, '02', 'SA''D ABD-AL-MAJID', 'SA''D ABD-AL-MAJID', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1895', '20171206', '����췢[2017]158��', '1: SABAWI 2: IBRAHIM 3: HASSAN 4: AL-TIKRITI', null, '02', 'SABAWI IBRAHIM', 'SABAWI IBRAHIM', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1896', '20171206', '����췢[2017]158��', '1: SADDAM 2: HUSSEIN 3: AL-TIKRITI 4: na', null, '02', 'SADDAM HUSSEIN', 'SADDAM HUSSEIN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1897', '20171206', '����췢[2017]158��', '1: SAHIR 2: BERHAN 3: na 4: na', 'a) Dr. Sahir Barhan; b) Saher Burhan Al-Deen; c) Sahir Burhan', '02', 'SAHIR BERHAN', 'SAHIR BERHAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1898', '20171206', '����췢[2017]158��', '1: SAHIR 2: BERHAN 3: na 4: na', 'a) Dr. Sahir Barhan; b) Saher Burhan Al-Deen; c) Sahir Burhan', '04', 'Sahir Burhan', 'SAHIR BURHAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1899', '20171206', '����췢[2017]158��', '1: SAHIR 2: BERHAN 3: na 4: na', 'a) Dr. Sahir Barhan; b) Saher Burhan Al-Deen; c) Sahir Burhan', '04', 'Saher Burhan Al-Deen', 'SAHER BURHAN AL-DEEN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1900', '20171206', '����췢[2017]158��', '1: SAHIR 2: BERHAN 3: na 4: na', 'a) Dr. Sahir Barhan; b) Saher Burhan Al-Deen; c) Sahir Burhan', '04', 'Dr. Sahir Barhan', 'DR. SAHIR BARHAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1901', '20171206', '����췢[2017]158��', '1: SAIF-AL-DIN 2: AL-MASHHADANI 3: na 4: na', null, '02', 'SAIF-AL-DIN AL-MASHHADANI', 'SAIF-AL-DIN AL-MASHHADANI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1902', '20171206', '����췢[2017]158��', '1: SAIF-AL-DIN 2: FULAYYIH 3: HASSAN TAHA 4: AL-RAWI', 'Ayad Futayyih Al-Rawi', '02', 'SAIF-AL-DIN FULAYYIH', 'SAIF-AL-DIN FULAYYIH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1903', '20171206', '����췢[2017]158��', '1: SAIF-AL-DIN 2: FULAYYIH 3: HASSAN TAHA 4: AL-RAWI', 'Ayad Futayyih Al-Rawi', '03', 'Ayad Futayyih Al-Rawi', 'AYAD FUTAYYIH AL-RAWI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1904', '20171206', '����췢[2017]158��', '1: SALEH 2: MOHAMMAD 3: KAKAR 4: AKHTAR MUHAMMAD', 'Saleh Mohammad', '02', 'SALEH MOHAMMAD', 'SALEH MOHAMMAD', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1905', '20171206', '����췢[2017]158��', '1: SALEH 2: MOHAMMAD 3: KAKAR 4: AKHTAR MUHAMMAD', 'Saleh Mohammad', '03', 'Saleh Mohammad', 'SALEH MOHAMMAD', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1906', '20171206', '����췢[2017]158��', '1: SAMIR 2: ABD AL-AZIZ 3: AL-NAJIM 4: na', null, '02', 'SAMIR ABD AL-AZIZ', 'SAMIR ABD AL-AZIZ', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1907', '20171206', '����췢[2017]158��', '1: SANHA 2: CLUSSE 3: na 4: na', null, '02', 'SANHA CLUSSE', 'SANHA CLUSSE', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1908', '20171206', '����췢[2017]158��', '1: SAYED 2: MOHAMMAD 3: AZIM 4: AGHA', 'a) Sayed Mohammad Azim Agha; b) Agha Saheb', '02', 'SAYED MOHAMMAD', 'SAYED MOHAMMAD', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1909', '20171206', '����췢[2017]158��', '1: SAYED 2: MOHAMMAD 3: AZIM 4: AGHA', 'a) Sayed Mohammad Azim Agha; b) Agha Saheb', '04', 'Agha Saheb', 'AGHA SAHEB', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1910', '20171206', '����췢[2017]158��', '1: SAYED 2: MOHAMMAD 3: AZIM 4: AGHA', 'a) Sayed Mohammad Azim Agha; b) Agha Saheb', '04', 'Sayed Mohammad Azim Agha', 'SAYED MOHAMMAD AZIM AGHA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1911', '20171206', '����췢[2017]158��', '1: SAYED ESMATULLAH 2: ASEM 3: ABDUL QUDDUS 4: na', 'a) Esmatullah Asem; b) Asmatullah Asem; c) Sayed Esmatullah Asem', '02', 'SAYED ESMATULLAH ASEM', 'SAYED ESMATULLAH ASEM', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1912', '20171206', '����췢[2017]158��', '1: SAYED ESMATULLAH 2: ASEM 3: ABDUL QUDDUS 4: na', 'a) Esmatullah Asem; b) Asmatullah Asem; c) Sayed Esmatullah Asem', '04', 'Asmatullah Asem', 'ASMATULLAH ASEM', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1913', '20171206', '����췢[2017]158��', '1: SAYED ESMATULLAH 2: ASEM 3: ABDUL QUDDUS 4: na', 'a) Esmatullah Asem; b) Asmatullah Asem; c) Sayed Esmatullah Asem', '04', 'Sayed Esmatullah Asem', 'SAYED ESMATULLAH ASEM', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1914', '20171206', '����췢[2017]158��', '1: SAYED ESMATULLAH 2: ASEM 3: ABDUL QUDDUS 4: na', 'a) Esmatullah Asem; b) Asmatullah Asem; c) Sayed Esmatullah Asem', '04', 'Esmatullah Asem', 'ESMATULLAH ASEM', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1915', '20171206', '����췢[2017]158��', '1: SHAMS 2: UR-RAHMAN 3: ABDUL ZAHIR 4: na', 'a) Shamsurrahman; b) Shams-u-Rahman; c) Shamsurrahman Abdurahman', '02', 'SHAMS UR-RAHMAN', 'SHAMS UR-RAHMAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1916', '20171206', '����췢[2017]158��', '1: SHAMS 2: UR-RAHMAN 3: ABDUL ZAHIR 4: na', 'a) Shamsurrahman; b) Shams-u-Rahman; c) Shamsurrahman Abdurahman', '04', 'Shamsurrahman', 'SHAMSURRAHMAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1917', '20171206', '����췢[2017]158��', '1: SHAMS 2: UR-RAHMAN 3: ABDUL ZAHIR 4: na', 'a) Shamsurrahman; b) Shams-u-Rahman; c) Shamsurrahman Abdurahman', '04', 'Shams-u-Rahman', 'SHAMS-U-RAHMAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1918', '20171206', '����췢[2017]158��', '1: SHAMS 2: UR-RAHMAN 3: ABDUL ZAHIR 4: na', 'a) Shamsurrahman; b) Shams-u-Rahman; c) Shamsurrahman Abdurahman', '04', 'Shamsurrahman Abdurahman', 'SHAMSURRAHMAN ABDURAHMAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1919', '20171206', '����췢[2017]158��', '1: SHANE 2: DOMINIC 3: CRAWFORD 4: na', null, '02', 'SHANE DOMINIC', 'SHANE DOMINIC', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1920', '20171206', '����췢[2017]158��', '1: SULTAN 2: HASHIM 3: AHMAD 4: AL-TAI', null, '02', 'SULTAN HASHIM', 'SULTAN HASHIM', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1921', '20171206', '����췢[2017]158��', '1: Sundus 2: Abd Al-Ghafur 3: na 4: na', null, '02', 'Sundus Abd', 'SUNDUS ABD', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1922', '20171206', '����췢[2017]158��', '1: TAHA 2: YASSIN 3: RAMADAN 4: AL-JIZRAWI', null, '02', 'TAHA YASSIN', 'TAHA YASSIN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1923', '20171206', '����췢[2017]158��', '1: TAHIR 2: JALIL 3: HABBUSH 4: AL-TIKRITI', null, '02', 'TAHIR JALIL', 'TAHIR JALIL', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1924', '20171206', '����췢[2017]158��', '1: TARIQ 2: AZIZ 3: na 4: na', 'a) Tariq Mikhail Aziz in Baghdad, Iraq', '02', 'TARIQ AZIZ', 'TARIQ AZIZ', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1925', '20171206', '����췢[2017]158��', '1: TARIQ 2: AZIZ 3: na 4: na', 'a) Tariq Mikhail Aziz in Baghdad, Iraq', '04', 'Tariq Mikhail Aziz in Baghdad', 'TARIQ MIKHAIL AZIZ IN BAGHDAD', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1926', '20171206', '����췢[2017]158��', '1: TARIQ 2: AZIZ 3: na 4: na', 'a) Tariq Mikhail Aziz in Baghdad, Iraq', '04', 'Iraq', 'IRAQ', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1927', '20171206', '����췢[2017]158��', '1: TOREK 2: AGHA 3: na 4: na', 'Sayed Mohammed Hashan', '02', 'TOREK AGHA', 'TOREK AGHA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1928', '20171206', '����췢[2017]158��', '1: TOREK 2: AGHA 3: na 4: na', 'Sayed Mohammed Hashan', '03', 'Sayed Mohammed Hashan', 'SAYED MOHAMMED HASHAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1929', '20171206', '����췢[2017]158��', '1: UDAY 2: SADDAM 3: HUSSEIN 4: AL-TIKRITI', null, '02', 'UDAY SADDAM', 'UDAY SADDAM', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1930', '20171206', '����췢[2017]158��', '1: UGLA 2: ABID 3: SAKR 4: AL-ZUBAISI', 'a) Saqr al-Kabisi Abd Aqala', '02', 'UGLA ABID', 'UGLA ABID', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1931', '20171206', '����췢[2017]158��', '1: UGLA 2: ABID 3: SAKR 4: AL-ZUBAISI', 'a) Saqr al-Kabisi Abd Aqala', '04', 'Saqr al-Kabisi Abd Aqala', 'SAQR AL-KABISI ABD AQALA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1932', '20171206', '����췢[2017]158��', '1: WALID 2: HAMID 3: TAWFIQ 4: AL-TIKRITI', 'a) Walid Hamid Tawfiq al-Nasiri', '02', 'WALID HAMID', 'WALID HAMID', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1933', '20171206', '����췢[2017]158��', '1: WALID 2: HAMID 3: TAWFIQ 4: AL-TIKRITI', 'a) Walid Hamid Tawfiq al-Nasiri', '04', 'Walid Hamid Tawfiq al-Nasiri', 'WALID HAMID TAWFIQ AL-NASIRI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1934', '20171206', '����췢[2017]158��', '1: WATBAN 2: IBRAHIM 3: HASSAN 4: AL-TIKRITI', null, '02', 'WATBAN IBRAHIM', 'WATBAN IBRAHIM', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1935', '20171206', '����췢[2017]158��', '1: YAHIA 2: ABDALLAH 3: AL-UBAIDI 4: na', null, '02', 'YAHIA ABDALLAH', 'YAHIA ABDALLAH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1936', '20171206', '����췢[2017]158��', '1: YO''N 2: CHO''NG NAM 3: na 4: na', null, '02', 'YO''N CHO''NG NAM', 'YO''N CHO''NG NAM', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1937', '20171206', '����췢[2017]158��', '1: YU 2: CHOL U 3: na 4: na', null, '02', 'YU CHOL U', 'YU CHOL U', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1938', '20171206', '����췢[2017]158��', '1: Yasin 2: Ali 3: Baynah 4: na', 'a) ALI, Yasin Baynah; b) ALI, Yassin Mohamed; c) BAYNAH, Yasin; d) BAYNAH, Yassin; e) BAYNAX, Yasiin Cali; f) BEENAH, Yasin; g) BEENAH, Yassin; h) BEENAX, Yasin; i) BEENAX, Yassin; j) BENAH, Yasin; k) BENAH, Yassin; l) BENAX, Yassin; m) BEYNAH, Yasin; n) BINAH, Yassin; o) CALI, Yassiin Baynax', '02', 'Yasin Ali', 'YASIN ALI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1939', '20171206', '����췢[2017]158��', '1: Yasin 2: Ali 3: Baynah 4: na', 'a) ALI, Yasin Baynah; b) ALI, Yassin Mohamed; c) BAYNAH, Yasin; d) BAYNAH, Yassin; e) BAYNAX, Yasiin Cali; f) BEENAH, Yasin; g) BEENAH, Yassin; h) BEENAX, Yasin; i) BEENAX, Yassin; j) BENAH, Yasin; k) BENAH, Yassin; l) BENAX, Yassin; m) BEYNAH, Yasin; n) BINAH, Yassin; o) CALI, Yassiin Baynax', '04', 'ALI', 'ALI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1940', '20171206', '����췢[2017]158��', '1: Yasin 2: Ali 3: Baynah 4: na', 'a) ALI, Yasin Baynah; b) ALI, Yassin Mohamed; c) BAYNAH, Yasin; d) BAYNAH, Yassin; e) BAYNAX, Yasiin Cali; f) BEENAH, Yasin; g) BEENAH, Yassin; h) BEENAX, Yasin; i) BEENAX, Yassin; j) BENAH, Yasin; k) BENAH, Yassin; l) BENAX, Yassin; m) BEYNAH, Yasin; n) BINAH, Yassin; o) CALI, Yassiin Baynax', '04', 'CALI', 'CALI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1941', '20171206', '����췢[2017]158��', '1: Yasin 2: Ali 3: Baynah 4: na', 'a) ALI, Yasin Baynah; b) ALI, Yassin Mohamed; c) BAYNAH, Yasin; d) BAYNAH, Yassin; e) BAYNAX, Yasiin Cali; f) BEENAH, Yasin; g) BEENAH, Yassin; h) BEENAX, Yasin; i) BEENAX, Yassin; j) BENAH, Yasin; k) BENAH, Yassin; l) BENAX, Yassin; m) BEYNAH, Yasin; n) BINAH, Yassin; o) CALI, Yassiin Baynax', '04', 'BEENAX', 'BEENAX', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1942', '20171206', '����췢[2017]158��', '1: Yasin 2: Ali 3: Baynah 4: na', 'a) ALI, Yasin Baynah; b) ALI, Yassin Mohamed; c) BAYNAH, Yasin; d) BAYNAH, Yassin; e) BAYNAX, Yasiin Cali; f) BEENAH, Yasin; g) BEENAH, Yassin; h) BEENAX, Yasin; i) BEENAX, Yassin; j) BENAH, Yasin; k) BENAH, Yassin; l) BENAX, Yassin; m) BEYNAH, Yasin; n) BINAH, Yassin; o) CALI, Yassiin Baynax', '04', 'Yasiin Cali', 'YASIIN CALI', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1943', '20171206', '����췢[2017]158��', '1: Yasin 2: Ali 3: Baynah 4: na', 'a) ALI, Yasin Baynah; b) ALI, Yassin Mohamed; c) BAYNAH, Yasin; d) BAYNAH, Yassin; e) BAYNAX, Yasiin Cali; f) BEENAH, Yasin; g) BEENAH, Yassin; h) BEENAX, Yasin; i) BEENAX, Yassin; j) BENAH, Yasin; k) BENAH, Yassin; l) BENAX, Yassin; m) BEYNAH, Yasin; n) BINAH, Yassin; o) CALI, Yassiin Baynax', '04', 'BINAH', 'BINAH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1944', '20171206', '����췢[2017]158��', '1: Yasin 2: Ali 3: Baynah 4: na', 'a) ALI, Yasin Baynah; b) ALI, Yassin Mohamed; c) BAYNAH, Yasin; d) BAYNAH, Yassin; e) BAYNAX, Yasiin Cali; f) BEENAH, Yasin; g) BEENAH, Yassin; h) BEENAX, Yasin; i) BEENAX, Yassin; j) BENAH, Yasin; k) BENAH, Yassin; l) BENAX, Yassin; m) BEYNAH, Yasin; n) BINAH, Yassin; o) CALI, Yassiin Baynax', '04', 'Yasin Baynah', 'YASIN BAYNAH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1945', '20171206', '����췢[2017]158��', '1: Yasin 2: Ali 3: Baynah 4: na', 'a) ALI, Yasin Baynah; b) ALI, Yassin Mohamed; c) BAYNAH, Yasin; d) BAYNAH, Yassin; e) BAYNAX, Yasiin Cali; f) BEENAH, Yasin; g) BEENAH, Yassin; h) BEENAX, Yasin; i) BEENAX, Yassin; j) BENAH, Yasin; k) BENAH, Yassin; l) BENAX, Yassin; m) BEYNAH, Yasin; n) BINAH, Yassin; o) CALI, Yassiin Baynax', '04', 'Yassin Mohamed', 'YASSIN MOHAMED', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1946', '20171206', '����췢[2017]158��', '1: Yasin 2: Ali 3: Baynah 4: na', 'a) ALI, Yasin Baynah; b) ALI, Yassin Mohamed; c) BAYNAH, Yasin; d) BAYNAH, Yassin; e) BAYNAX, Yasiin Cali; f) BEENAH, Yasin; g) BEENAH, Yassin; h) BEENAX, Yasin; i) BEENAX, Yassin; j) BENAH, Yasin; k) BENAH, Yassin; l) BENAX, Yassin; m) BEYNAH, Yasin; n) BINAH, Yassin; o) CALI, Yassiin Baynax', '04', 'BAYNAH', 'BAYNAH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1947', '20171206', '����췢[2017]158��', '1: Yasin 2: Ali 3: Baynah 4: na', 'a) ALI, Yasin Baynah; b) ALI, Yassin Mohamed; c) BAYNAH, Yasin; d) BAYNAH, Yassin; e) BAYNAX, Yasiin Cali; f) BEENAH, Yasin; g) BEENAH, Yassin; h) BEENAX, Yasin; i) BEENAX, Yassin; j) BENAH, Yasin; k) BENAH, Yassin; l) BENAX, Yassin; m) BEYNAH, Yasin; n) BINAH, Yassin; o) CALI, Yassiin Baynax', '04', 'Yasin', 'YASIN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1948', '20171206', '����췢[2017]158��', '1: Yasin 2: Ali 3: Baynah 4: na', 'a) ALI, Yasin Baynah; b) ALI, Yassin Mohamed; c) BAYNAH, Yasin; d) BAYNAH, Yassin; e) BAYNAX, Yasiin Cali; f) BEENAH, Yasin; g) BEENAH, Yassin; h) BEENAX, Yasin; i) BEENAX, Yassin; j) BENAH, Yasin; k) BENAH, Yassin; l) BENAX, Yassin; m) BEYNAH, Yasin; n) BINAH, Yassin; o) CALI, Yassiin Baynax', '04', 'BAYNAH', 'BAYNAH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1949', '20171206', '����췢[2017]158��', '1: Yasin 2: Ali 3: Baynah 4: na', 'a) ALI, Yasin Baynah; b) ALI, Yassin Mohamed; c) BAYNAH, Yasin; d) BAYNAH, Yassin; e) BAYNAX, Yasiin Cali; f) BEENAH, Yasin; g) BEENAH, Yassin; h) BEENAX, Yasin; i) BEENAX, Yassin; j) BENAH, Yasin; k) BENAH, Yassin; l) BENAX, Yassin; m) BEYNAH, Yasin; n) BINAH, Yassin; o) CALI, Yassiin Baynax', '04', 'BAYNAX', 'BAYNAX', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1950', '20171206', '����췢[2017]158��', '1: Yasin 2: Ali 3: Baynah 4: na', 'a) ALI, Yasin Baynah; b) ALI, Yassin Mohamed; c) BAYNAH, Yasin; d) BAYNAH, Yassin; e) BAYNAX, Yasiin Cali; f) BEENAH, Yasin; g) BEENAH, Yassin; h) BEENAX, Yasin; i) BEENAX, Yassin; j) BENAH, Yasin; k) BENAH, Yassin; l) BENAX, Yassin; m) BEYNAH, Yasin; n) BINAH, Yassin; o) CALI, Yassiin Baynax', '04', 'BEENAH', 'BEENAH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1951', '20171206', '����췢[2017]158��', '1: Yasin 2: Ali 3: Baynah 4: na', 'a) ALI, Yasin Baynah; b) ALI, Yassin Mohamed; c) BAYNAH, Yasin; d) BAYNAH, Yassin; e) BAYNAX, Yasiin Cali; f) BEENAH, Yasin; g) BEENAH, Yassin; h) BEENAX, Yasin; i) BEENAX, Yassin; j) BENAH, Yasin; k) BENAH, Yassin; l) BENAX, Yassin; m) BEYNAH, Yasin; n) BINAH, Yassin; o) CALI, Yassiin Baynax', '04', 'Yassiin Baynax', 'YASSIIN BAYNAX', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1952', '20171206', '����췢[2017]158��', '1: Yasin 2: Ali 3: Baynah 4: na', 'a) ALI, Yasin Baynah; b) ALI, Yassin Mohamed; c) BAYNAH, Yasin; d) BAYNAH, Yassin; e) BAYNAX, Yasiin Cali; f) BEENAH, Yasin; g) BEENAH, Yassin; h) BEENAX, Yasin; i) BEENAX, Yassin; j) BENAH, Yasin; k) BENAH, Yassin; l) BENAX, Yassin; m) BEYNAH, Yasin; n) BINAH, Yassin; o) CALI, Yassiin Baynax', '04', 'BENAH', 'BENAH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1953', '20171206', '����췢[2017]158��', '1: Yasin 2: Ali 3: Baynah 4: na', 'a) ALI, Yasin Baynah; b) ALI, Yassin Mohamed; c) BAYNAH, Yasin; d) BAYNAH, Yassin; e) BAYNAX, Yasiin Cali; f) BEENAH, Yasin; g) BEENAH, Yassin; h) BEENAX, Yasin; i) BEENAX, Yassin; j) BENAH, Yasin; k) BENAH, Yassin; l) BENAX, Yassin; m) BEYNAH, Yasin; n) BINAH, Yassin; o) CALI, Yassiin Baynax', '04', 'BENAH', 'BENAH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1954', '20171206', '����췢[2017]158��', '1: Yasin 2: Ali 3: Baynah 4: na', 'a) ALI, Yasin Baynah; b) ALI, Yassin Mohamed; c) BAYNAH, Yasin; d) BAYNAH, Yassin; e) BAYNAX, Yasiin Cali; f) BEENAH, Yasin; g) BEENAH, Yassin; h) BEENAX, Yasin; i) BEENAX, Yassin; j) BENAH, Yasin; k) BENAH, Yassin; l) BENAX, Yassin; m) BEYNAH, Yasin; n) BINAH, Yassin; o) CALI, Yassiin Baynax', '04', 'BENAX', 'BENAX', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1955', '20171206', '����췢[2017]158��', '1: Yasin 2: Ali 3: Baynah 4: na', 'a) ALI, Yasin Baynah; b) ALI, Yassin Mohamed; c) BAYNAH, Yasin; d) BAYNAH, Yassin; e) BAYNAX, Yasiin Cali; f) BEENAH, Yasin; g) BEENAH, Yassin; h) BEENAX, Yasin; i) BEENAX, Yassin; j) BENAH, Yasin; k) BENAH, Yassin; l) BENAX, Yassin; m) BEYNAH, Yasin; n) BINAH, Yassin; o) CALI, Yassiin Baynax', '04', 'BEYNAH', 'BEYNAH', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1956', '20171206', '����췢[2017]158��', '1: ZUHAIR 2: TALIB 3: ABD-AL-SATTAR 4: AL-NAQIB', null, '02', 'ZUHAIR TALIB', 'ZUHAIR TALIB', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1957', '20171206', '����췢[2017]158��', 'CHANG CHANG HA', 'Jang Chang Ha', '01', 'CHANG CHANG HA', 'CHANG CHANG HA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1958', '20171206', '����췢[2017]158��', 'CHANG CHANG HA', 'Jang Chang Ha', '03', 'Jang Chang Ha', 'JANG CHANG HA', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1959', '20171206', '����췢[2017]158��', 'CHO CHUN RYONG', null, '01', 'CHO CHUN RYONG', 'CHO CHUN RYONG', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1960', '20171206', '����췢[2017]158��', 'JO YONG CHOL', null, '01', 'JO YONG CHOL', 'JO YONG CHOL', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1961', '20171206', '����췢[2017]158��', 'KIM CHOL SAM', null, '01', 'KIM CHOL SAM', 'KIM CHOL SAM', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1962', '20171206', '����췢[2017]158��', 'KIM SE GON', null, '01', 'KIM SE GON', 'KIM SE GON', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1963', '20171206', '����췢[2017]158��', 'KIM SOK CHOL', null, '01', 'KIM SOK CHOL', 'KIM SOK CHOL', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1964', '20171206', '����췢[2017]158��', 'KIM SONG CHOL', 'Kim Hak Song', '01', 'KIM SONG CHOL', 'KIM SONG CHOL', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1965', '20171206', '����췢[2017]158��', 'KIM SONG CHOL', 'Kim Hak Song', '03', 'Kim Hak Song', 'KIM HAK SONG', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1966', '20171206', '����췢[2017]158��', 'RI WON HO', null, '01', 'RI WON HO', 'RI WON HO', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1967', '20171206', '����췢[2017]158��', 'SON JONG HYOK', 'Son Min', '01', 'SON JONG HYOK', 'SON JONG HYOK', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1968', '20171206', '����췢[2017]158��', 'SON JONG HYOK', 'Son Min', '03', 'Son Min', 'SON MIN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1969', '20171206', '����췢[2017]158��', 'SON MUN SAN', null, '01', 'SON MUN SAN', 'SON MUN SAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1970', '20180112', '����췢[2018]8��', 'Billions No.18', null, '01', 'Billions No.18', 'BILLIONS NO.18', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1971', '20180112', '����췢[2018]8��', 'CH''OE SO''K MIN', null, '01', 'CH''OE SO''K MIN', 'CH''OE SO''K MIN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1972', '20180112', '����췢[2018]8��', 'CHU HYO''K', 'Ju Hyok', '01', 'CHU HYO''K', 'CHU HYO''K', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1973', '20180112', '����췢[2018]8��', 'CHU HYO''K', 'Ju Hyok', '03', 'Ju Hyok', 'JU HYOK', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1974', '20180112', '����췢[2018]8��', 'KIM JONG SIK', 'Kim Cho''ng-sik', '01', 'KIM JONG SIK', 'KIM JONG SIK', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1975', '20180112', '����췢[2018]8��', 'KIM JONG SIK', 'Kim Cho''ng-sik', '03', 'Kim Cho''ng-sik', 'KIM CHO''NG-SIK', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1976', '20180112', '����췢[2018]8��', 'KIM KYONG IL', 'Kim Kyo''ng-il', '01', 'KIM KYONG IL', 'KIM KYONG IL', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1977', '20180112', '����췢[2018]8��', 'KIM KYONG IL', 'Kim Kyo''ng-il', '03', 'Kim Kyo''ng-il', 'KIM KYO''NG-IL', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1978', '20180112', '����췢[2018]8��', 'KIM TONG CHOL', 'Kim Tong-ch''o''l', '01', 'KIM TONG CHOL', 'KIM TONG CHOL', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1979', '20180112', '����췢[2018]8��', 'KIM TONG CHOL', 'Kim Tong-ch''o''l', '03', 'Kim Tong-ch''o''l', 'KIM TONG-CH''O''L', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1980', '20180112', '����췢[2018]8��', 'KO CHOL MAN', 'Ko Ch''o''l-man', '01', 'KO CHOL MAN', 'KO CHOL MAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1981', '20180112', '����췢[2018]8��', 'KO CHOL MAN', 'Ko Ch''o''l-man', '03', 'Ko Ch''o''l-man', 'KO CH''O''L-MAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1982', '20180112', '����췢[2018]8��', 'KU JA HYONG', 'Ku Cha-hyo''ng', '01', 'KU JA HYONG', 'KU JA HYONG', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1983', '20180112', '����췢[2018]8��', 'KU JA HYONG', 'Ku Cha-hyo''ng', '03', 'Ku Cha-hyo''ng', 'KU CHA-HYO''NG', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1984', '20180112', '����췢[2018]8��', 'MINISTRY OF THE PEOPLE''S ARMED FORCES (MPAF)', null, '01', 'MINISTRY OF THE PEOPLE''S ARMED FORCES (MPAF)', 'MINISTRY OF THE PEOPLE''S ARMED FORCES (MPAF)', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1985', '20180112', '����췢[2018]8��', 'MUN KYONG HWAN', 'Mun Kyo''ng-hwan', '01', 'MUN KYONG HWAN', 'MUN KYONG HWAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1986', '20180112', '����췢[2018]8��', 'MUN KYONG HWAN', 'Mun Kyo''ng-hwan', '03', 'Mun Kyo''ng-hwan', 'MUN KYO''NG-HWAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1987', '20180112', '����췢[2018]8��', 'PAE WON UK', 'Pae Wo''n-uk', '01', 'PAE WON UK', 'PAE WON UK', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1988', '20180112', '����췢[2018]8��', 'PAE WON UK', 'Pae Wo''n-uk', '03', 'Pae Wo''n-uk', 'PAE WO''N-UK', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1989', '20180112', '����췢[2018]8��', 'PAK BONG NAM', 'Lui Wai Ming; Pak Pong Nam; Pak Pong-nam', '01', 'PAK BONG NAM', 'PAK BONG NAM', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1990', '20180112', '����췢[2018]8��', 'PAK BONG NAM', 'Lui Wai Ming; Pak Pong Nam; Pak Pong-nam', '04', 'Lui Wai Ming', 'LUI WAI MING', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1991', '20180112', '����췢[2018]8��', 'PAK BONG NAM', 'Lui Wai Ming; Pak Pong Nam; Pak Pong-nam', '04', 'Pak Pong Nam', 'PAK PONG NAM', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1992', '20180112', '����췢[2018]8��', 'PAK BONG NAM', 'Lui Wai Ming; Pak Pong Nam; Pak Pong-nam', '04', 'Pak Pong-nam', 'PAK PONG-NAM', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1993', '20180112', '����췢[2018]8��', 'PAK MUN IL', 'Pak Mun-il', '01', 'PAK MUN IL', 'PAK MUN IL', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1994', '20180112', '����췢[2018]8��', 'PAK MUN IL', 'Pak Mun-il', '03', 'Pak Mun-il', 'PAK MUN-IL', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1995', '20180112', '����췢[2018]8��', 'RI CHUN HWAN', 'Ri Ch''un-hwan', '01', 'RI CHUN HWAN', 'RI CHUN HWAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1996', '20180112', '����췢[2018]8��', 'RI CHUN HWAN', 'Ri Ch''un-hwan', '03', 'Ri Ch''un-hwan', 'RI CH''UN-HWAN', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1997', '20180112', '����췢[2018]8��', 'RI CHUN SONG', 'Ri Ch''un-so''ng', '01', 'RI CHUN SONG', 'RI CHUN SONG', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1998', '20180112', '����췢[2018]8��', 'RI CHUN SONG', 'Ri Ch''un-so''ng', '03', 'Ri Ch''un-so''ng', 'RI CH''UN-SO''NG', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('1999', '20180112', '����췢[2018]8��', 'RI PYONG CHUL', 'Ri Pyo''ng-ch''o''l', '01', 'RI PYONG CHUL', 'RI PYONG CHUL', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('2000', '20180112', '����췢[2018]8��', 'RI PYONG CHUL', 'Ri Pyo''ng-ch''o''l', '03', 'Ri Pyo''ng-ch''o''l', 'RI PYO''NG-CH''O''L', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('2001', '20180112', '����췢[2018]8��', 'RI SONG HYOK', 'Li Cheng He', '01', 'RI SONG HYOK', 'RI SONG HYOK', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('2002', '20180112', '����췢[2018]8��', 'RI SONG HYOK', 'Li Cheng He', '03', 'Li Cheng He', 'LI CHENG HE', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('2003', '20180112', '����췢[2018]8��', 'RI U''N SO''NG', 'Ri Eun Song; Ri Un Song', '01', 'RI U''N SO''NG', 'RI U''N SO''NG', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('2004', '20180112', '����췢[2018]8��', 'RI U''N SO''NG', 'Ri Eun Song; Ri Un Song', '03', 'Ri Eun Song', 'RI EUN SONG', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('2005', '20180112', '����췢[2018]8��', 'RI U''N SO''NG', 'Ri Eun Song; Ri Un Song', '03', 'Ri Un Song', 'RI UN SONG', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('2006', '20180112', '����췢[2018]8��', 'Rung Ra 2', null, '01', 'Rung Ra 2', 'RUNG RA 2', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('2007', '20180112', '����췢[2018]8��', 'Rye Song Gang 1', null, '01', 'Rye Song Gang 1', 'RYE SONG GANG 1', '01', null);

insert into CBRC_AML_RET_NAME (SEQ_NO, NOTICE_DATE, NOTICE_NAME, SAN_TAR_NAME, ALIAS_NAME, SPLIT_TYPE, KEY_WORDS, RET_NAME, STATUS, BAK)
values ('2008', '20180112', '����췢[2018]8��', 'Ul Ji Bong 6', null, '01', 'Ul Ji Bong 6', 'UL JI BONG 6', '01', null);